<?php


# test partial monthly values

include('./config.php');

if (isset($_POST['submit'])) {
   $sitelist = $_POST['sitelist'];
   $startdate = $_POST['startdate'];
   $enddate = $_POST['enddate'];
   $mindays = $_POST['mindays'];
}

# Opequon Creek: 01615000
# North River, Burketown: 01622000
# SF Shenandoah, Front Royal: 01631000
# NF Shenandoah at Strasburg: 01634000
# Smith Creek at new Market: 01632900
# Goose Creek, Leesburg: 01644000
# Cedar Run, Catlett: 01656000
# SF Quantico, Independence: 01658500
# Rappahanock, Remington: 01664000
# Rapidan, 01667500 RAPIDAN RIVER NEAR CULPEPER
# 01673800 PO RIVER NEAR SPOTSYLVANIA, VA

print("<form action='calc_sitegini.php' method=post>");
print("<br><b>Site ID:</b> ");
showWidthTextField('sitelist', $sitelist, 12);
print("<br><b>Start Date:</b> ");
showWidthTextField('startdate', $startdate, 12);
print("<br><b>End Date:</b> ");
showWidthTextField('enddate', $enddate, 12);
print("<br> Minimum Number of Days to incluide in analysis: ");
showWidthTextField('mindays', $mindays, 12);
print("<br> Retrieve all gages in database? (over-rides site list)");
showCheckBox('allgages', 1, $_POST['allgages'], $onclick='', 0, 0);
print("<br> ");
showSubmitButton('submit','submit');
print("</form>");

$debug = 0;
$projectid = 3;
$siteinfocode = 3;
$stype = 1;

if (isset($_POST['submit'])) {
   $sites = split(',', $sitelist);
   $dateobj = new DateTime($startdate);
   $startyear = $dateobj->format('Y');
   $dateobj = new DateTime($enddate);
   $endyear = $dateobj->format('Y');
   
   if (isset($_POST['allgages'])) {
      $listobject->querystring = "  select pointname ";
      $listobject->querystring .= " from proj_points ";
      $listobject->querystring .= " where projectid = $projectid ";
      $listobject->querystring .= "    and pointtype = 1 "; 
      if ($debug) { 
         print("$listobject->querystring ; <br>");
      }
      $listobject->performQuery();
      $sites = array();
      $sno = 0;
      foreach ($listobject->queryrecords as $thisrec) {
         array_push($sites, $thisrec['pointname']);
         $sno += 1;
      }
      print("Found $sno sites in database.<br>");
   }
   
   $outfile = "$outdir/gini" . $sno . ".data";
   $moutfile = "$outdir/gini_month" . $sno . ".data";
   $colnames = array('gage','ginicoeff');
   putDelimitedFile("$outfile",$colnames,"\t",1,'unix');
   $colnames = array('gage','month','year','ginicoeff');
   putDelimitedFile("$moutfile",$colnames,"\t",1,'unix');
   print("Storing data in $outfile <br");

   foreach ($sites as $siteno) {
      $usgsobj = new USGSGageObject;
      $usgsobj->listobject = $listobject;
      $usgsobj->name = $siteno;
      $usgsobj->staid = $siteno;
      $usgsobj->startdate = $startdate;
      $usgsobj->enddate = $enddate;
      
      print("Retrieving data for $siteno <br");
      $usgsobj->init();
      #print_r($usgsobj->tsvalues);
      #$listobject->debug = 1;
      $usgsobj->tsvalues2listobject(array('thisdate','Qout'));
      
      $listobject->querystring = " select count(*) as numrecs from tmp_$siteno ";
      if ($debug) { 
         print("$listobject->querystring ; <br>");
      }
      $listobject->performQuery();
      $numrecs = $listobject->getRecordValue(1,'numrecs');
         
      if ($debug) {
         $listobject->querystring = "  select * from tmp_$siteno ";
         $listobject->performQuery();
         $listobject->showList();
      }
      
      if ($numrecs >= $mindays) {
      
         # screen for tidal influence (negative flow values)
         $listobject->querystring = "  select count(*) as numneg from tmp_$siteno ";
         $listobject->querystring .= " where Qout is not null and Qout < 0 ";
         if ($debug) { 
            print("$listobject->querystring ; <br>");
         }
         $listobject->performQuery();
         $numneg = $listobject->getRecordValue(1,'numneg');
         
         if ($numneg == 0) {
            print("Clearing old stats from local database for $siteno.<br>");
            $listobject->querystring = "  delete from stats_site_period ";
            $listobject->querystring .= " where site_no = '$siteno' ";
            $listobject->querystring .= "    and startdate = '$startdate' ";
            $listobject->querystring .= "    and enddate = '$enddate' ";
            $listobject->querystring .= "    and datatype = 'gini' ";
            if ($debug) { 
               print("$listobject->querystring ; <br>"); 
            }
            $listobject->performQuery();

            print("Calculating Gini values for $siteno <br>");

            $listobject->querystring = "select '$siteno' as siteno, wateryear, gini(array_accum(\"Qout\"))  ";
            $listobject->querystring .= " from (  ";
            $listobject->querystring .= "   select  ";
            $listobject->querystring .= "      CASE  ";
            $listobject->querystring .= "         WHEN extract(month from thisdate) < 10 THEN (extract(year from thisdate) - 1)  ";
            $listobject->querystring .= "         ELSE extract(year from thisdate)  ";
            $listobject->querystring .= "      END as wateryear,  ";
            $listobject->querystring .= "      \"Qout\" ";
            $listobject->querystring .= "   from tmp_$siteno  ";
            $listobject->querystring .= "   where \"Qout\" is not null  ";
            $listobject->querystring .= ") as foo ";
            $listobject->querystring .= "group by wateryear "; 
            $listobject->querystring .= "order by wateryear ";
            if ($debug) { 
               print("$listobject->querystring ; <br>"); 
            }
            $listobject->performQuery();
            $listobject->showlist();
            $ginirecs = $listobject->queryrecords;

            $listobject->querystring = " select count(*) as numvalid from ";
            $listobject->querystring .= " ( select '$siteno' as siteno, gini(array_accum(\"Qout\")) as gini ";
            $listobject->querystring .= "   from (  ";
            $listobject->querystring .= "     select  ";
            $listobject->querystring .= "        CASE  ";
            $listobject->querystring .= "           WHEN extract(month from thisdate) < 10 THEN (extract(year from thisdate) - 1)  ";
            $listobject->querystring .= "           ELSE extract(year from thisdate)  ";
            $listobject->querystring .= "        END as wateryear,  ";
            $listobject->querystring .= "        \"Qout\" ";
            $listobject->querystring .= "     from tmp_$siteno  ";
            $listobject->querystring .= "     where \"Qout\" is not null  ";
            $listobject->querystring .= "   ) as foo ";
            $listobject->querystring .= "   group by wateryear "; 
            $listobject->querystring .= "   order by wateryear ";
            $listobject->querystring .= " ) as foo ";
            $listobject->querystring .= " where gini <> 'NaN' ";
            if ($debug) { 
               print("$listobject->querystring ; <br>"); 
            }
            $listobject->performQuery();
            $numvalid = $listobject->getRecordValue(1,'numvalid');
            print("Found $numvalid records<br>");
            if ($numvalid == ($endyear - $startyear)) {
               print("Appending values to $outfile<br>");
               # format for output if records exist for each year in the dataset
               $outarr = nestArraySprintf("%s\t%s\t%1.6f", $ginirecs);
               #print_r($outarr);

               putArrayToFilePlatform("$outfile", $outarr,0,'unix');
            }

            $listobject->querystring = "select gini(array_accum(\"Qout\")) as gini, count(*), avg(\"Qout\") ";
            $listobject->querystring .= " from tmp_$siteno  ";
            $listobject->querystring .= " where \"Qout\" is not null  ";
            $listobject->performQuery();
            if ($debug) { 
               print("$listobject->querystring ; <br>"); 
            }
            $gini = $listobject->getRecordValue(1,'gini');
            $listobject->showlist();

            # save gini stats
            $today = date('Y-m-d');
            $listobject->querystring = "  insert into stats_site_period ( site_no, retrievaldate, ";
            $listobject->querystring .= "    startdate, enddate, dataflag, num_recs, ";
            $listobject->querystring .= "    mean_val, min_val, max_val, datatype ) ";
            $listobject->querystring .= " values ( '$siteno', '$today', ";
            $listobject->querystring .= "    '$startdate', '$enddate', 'P', $numrecs, ";
            $listobject->querystring .= "    $gini, $gini, $gini, 'gini' ) ";
            if ($debug) { 
               print("$listobject->querystring ; <br>"); 
            }
            $listobject->performQuery();
            $listobject->showlist();

            # save gini stats by month
            $today = date('Y-m-d');
            print("Clearing old stats from local database for $siteno.<br>");
            $listobject->querystring = "  delete from stats_site_period ";
            $listobject->querystring .= " where site_no = '$siteno' ";
            $listobject->querystring .= "    and startdate >= '$startdate' ";
            $listobject->querystring .= "    and enddate <= '$enddate' ";
            $listobject->querystring .= "    and datatype = 'gini_month' ";
            if ($debug) { 
               print("$listobject->querystring ; <br>"); 
            }
            $listobject->performQuery();
            
            print("Calculating Monthly Gini values for $siteno <br>");
            $listobject->querystring = "  insert into stats_site_period ( site_no, retrievaldate, ";
            $listobject->querystring .= "    startdate, enddate, dataflag, num_recs, ";
            $listobject->querystring .= "    mean_val, min_val, max_val, datatype ) ";
            $listobject->querystring .= " select siteno, '$today' as retdate, sd, ed, 'P' as dflag, numrecs, ";
            $listobject->querystring .= "    ginicoef, ginicoef as gmin, ginicoef as gmax, 'gini_month' as datatype ";
            $listobject->querystring .= " from ( ";
            $listobject->querystring .= "    select '$siteno'::varchar as siteno, min(thisdate) as sd, max(thisdate) as ed, ";
            $listobject->querystring .= "       count(*) as numrecs, watermonth, wateryear, ";
            $listobject->querystring .= "       gini(array_accum(\"Qout\")) as ginicoef ";
            $listobject->querystring .= "    from (  ";
            $listobject->querystring .= "      select thisdate, extract(month from thisdate) as watermonth, ";
            $listobject->querystring .= "         extract(year from thisdate) as wateryear,  ";
            $listobject->querystring .= "         \"Qout\" ";
            $listobject->querystring .= "      from tmp_$siteno  ";
            $listobject->querystring .= "      where \"Qout\" is not null  ";
            $listobject->querystring .= "    ) as foo ";
            $listobject->querystring .= "    group by wateryear, watermonth "; 
            $listobject->querystring .= "    order by wateryear, watermonth ";
            $listobject->querystring .= " ) as bar ";
            if ($debug) { 
               print("$listobject->querystring ; <br>"); 
            }
            $listobject->performQuery();
            
            # output monthly values to file
            $listobject->querystring = "  select site_no, extract(month from startdate) as thismonth,  ";
            $listobject->querystring .= "    extract(year from startdate) as thisyear, mean_val  ";
            $listobject->querystring .= " from stats_site_period  ";
            $listobject->querystring .= " where datatype = 'gini_month'  ";
            $listobject->querystring .= "    and site_no = '$siteno' ";
            $listobject->querystring .= " order by site_no, thismonth, thisyear ";
            #if ($debug) { 
               print("$listobject->querystring ; <br>"); 
            #}
            $listobject->performQuery();
            $ginirecs = $listobject->queryrecords;
            if ($numvalid == ($endyear - $startyear)) {
               print("Appending values to monthly $moutfile<br>");
               # format for output if records exist for each year in the dataset
               $outarr = nestArraySprintf("%s\t%s\t%s\t%1.6f", $ginirecs);
               #print_r($outarr);

               putArrayToFilePlatform("$moutfile", $outarr,0,'unix');
            }
            if ($debug) { 
               $listobject->showList();
            }
            
         }
      }
   }
}

?>
<?php

/************************************************************************/
/*                   fuction GMapGetStatus($szLayerName)                */
/*                                                                      */
/*      return if the layer is on or off (displayed or not) :           */
/*                                                                      */
/*       ON = MS_ON =1                                                  */
/*       OFF = MS_OFF = 0                                               */
/*                                                                      */
/************************************************************************/
function GMapGetStatus($szLayerName)
{
  GLOBAL $gpoMap;

  $poLayer = $gpoMap->getlayerbyname($szLayerName);
  $nStatus = $poLayer->status;

   return ($nStatus);

}


/************************************************************************/
/*                        function GMapDrawMap()                        */
/*                                                                      */
/*      Funcion to draw the contains of the map.                        */
/************************************************************************/
function GMapDrawMap()
{
    GLOBAL $gpoMap, $gbShowQueryResults;
    GLOBAL $gbIsHtmlMode;
    GLOBAL $gszCommand, $gszZoomBoxExt;
    GLOBAL $gAppletImgFmt, $gImagesFmt;

    if ($gbShowQueryResults)
        $img = $gpoMap->drawQuery();
    else
        $img = $gpoMap->draw();
    $url = $img->saveWebImage($gAppletImgFmt, 0, 0, -1);

    echo "\n".$gszZoomBoxExt."\n";
    printf("<INPUT TYPE=HIDDEN NAME=minx VALUE=\"%f\">", $gpoMap->extent->minx);
    printf("<INPUT TYPE=HIDDEN NAME=miny VALUE=\"%f\">", $gpoMap->extent->miny);
    printf("<INPUT TYPE=HIDDEN NAME=maxx VALUE=\"%f\">", $gpoMap->extent->maxx);
    printf("<INPUT TYPE=HIDDEN NAME=maxy VALUE=\"%f\">", $gpoMap->extent->maxy);

    printf("<INPUT TYPE=HIDDEN NAME=imagewidth VALUE=\"%d\">", $gpoMap->width);
    printf("<INPUT TYPE=HIDDEN NAME=imageheight VALUE=\"%d\">", $gpoMap->height);

/* -------------------------------------------------------------------- */
/*      Use the command to update the rosa applet.                      */
/* -------------------------------------------------------------------- */
    if ( strlen($gszCommand) == 0)
    {
   $szButtonName = "zoomin";
    }
    else
    {
   if ($gszCommand == "ZOOM_IN")
       $szButtonName = "zoomin";
// Do not keep zoomout pressed ot avoid infinite zoomout loop!!!
// if ($gszCommand == "ZOOM_OUT")
//     $szButtonName = "zoomout";
   if ($gszCommand == "RECENTER")
       $szButtonName = "recentre";
   if ($gszCommand == "QUERY_POINT")
       $szButtonName = "pquery";
    }


    if (!$gbIsHtmlMode) //use applet
    {
   printf("\n");
   printf("<APPLET NAME=\"RosaApplet\" ARCHIVE=\"./rosa/rosa.jar\" CODE=\"Rosa2000\" WIDTH=\"%d\" HEIGHT=\"%d\" MAYSCRIPT>\n", $gpoMap->width, $gpoMap->height);
   printf("<PARAM NAME=\"TB_POSITION\" VALUE=\"right\">\n");
   printf("<PARAM NAME=\"TB_ALIGN\" VALUE=\"top\">");
   printf("<PARAM NAME=\"IMG_URL\" VALUE=\"%s\">",$url);
   printf("<PARAM NAME=\"INP_FORM_NAME\" VALUE=\"myform\">");
   printf("<PARAM NAME=\"TB_BUTTONS\" VALUE=\"zoomin|zoomout|recentre|pquery\">\n");
   printf("<PARAM NAME=\"INP_TYPE_NAME\" VALUE=\"INPUT_TYPE\">\n");
   printf("<PARAM NAME=\"INP_COORD_NAME\" VALUE=\"INPUT_COORD\">\n");


   printf("<PARAM NAME=\"TB_SELECTED_BUTTON\" VALUE=\"%s\">",$szButtonName);

        printf("<PARAM NAME=\"TB_BUT_zoomin_IMG\" VALUE=\"./images/tool_zoomin_1.gif\">\n");
   printf("<PARAM NAME=\"TB_BUT_zoomin_IMG_PR\" VALUE=\"./images/tool_zoomin_2.gif\">\n");
   printf("<PARAM NAME=\"TB_BUT_zoomin_HINT\" VALUE=\"Zoom in: Click the button|and the map will zoom in\">\n");
        printf("<PARAM NAME=\"TB_BUT_zoomin_INPUT\" VALUE=\"auto_rect\">\n");
        printf("<PARAM NAME=\"TB_BUT_zoomin_NAME\" VALUE=\"CMD\">\n");
        printf("<PARAM NAME=\"TB_BUT_zoomin_VALUE\" VALUE=\"ZOOM_IN\">\n");


        printf("<PARAM NAME=\"TB_BUT_zoomout_IMG\" VALUE=\"./images/tool_zoomout_1.gif\">\n");
   printf("<PARAM NAME=\"TB_BUT_zoomout_IMG_PR\" VALUE=\"./images/tool_zoomout_2.gif\">\n");
   printf("<PARAM NAME=\"TB_BUT_zoomout_HINT\" VALUE=\"Zoom out: Click the button|and the map will zoom out\">\n");
        printf("<PARAM NAME=\"TB_BUT_zoomout_INPUT\" VALUE=\"submit\">\n");
        printf("<PARAM NAME=\"TB_BUT_zoomout_NAME\" VALUE=\"CMD\">\n");
        printf("<PARAM NAME=\"TB_BUT_zoomout_VALUE\" VALUE=\"ZOOM_OUT\">\n");

        printf("<PARAM NAME=\"TB_BUT_recentre_IMG\" VALUE=\"./images/tool_recentre_1.gif\">\n");
   printf("<PARAM NAME=\"TB_BUT_recentre_IMG_PR\" VALUE=\"./images/tool_recentre_2.gif\">\n");
   printf("<PARAM NAME=\"TB_BUT_recentre_HINT\" VALUE=\"Recenter: Click the button|and the map will recenter\">\n");
        printf("<PARAM NAME=\"TB_BUT_recentre_INPUT\" VALUE=\"auto_point\">\n");
        printf("<PARAM NAME=\"TB_BUT_recentre_NAME\" VALUE=\"CMD\">\n");
        printf("<PARAM NAME=\"TB_BUT_recentre_VALUE\" VALUE=\"RECENTER\">\n");

   printf("<PARAM NAME=\"TB_BUT_pquery_IMG\" VALUE=\"./images/tool_info_1.gif\">\n");
   printf("<PARAM NAME=\"TB_BUT_pquery_IMG_PR\" VALUE=\"./images/tool_info_2.gif\">\n");
   printf("<PARAM NAME=\"TB_BUT_pquery_HINT\" VALUE=\"Point Query: Click a point on the map|for information about that point\">\n");
        printf("<PARAM NAME=\"TB_BUT_pquery_INPUT\" VALUE=\"auto_rect\">\n");
        printf("<PARAM NAME=\"TB_BUT_pquery_NAME\" VALUE=\"CMD\">\n");
        printf("<PARAM NAME=\"TB_BUT_pquery_VALUE\" VALUE=\"QUERY_POINT\">\n");

   printf("</APPLET>");
   printf("<INPUT TYPE=\"HIDDEN\" NAME=\"CMD\" VALUE=\"\">");
   printf("<INPUT TYPE=\"HIDDEN\" NAME=\"INPUT_TYPE\" VALUE=\"\">");
   printf("<INPUT TYPE=\"HIDDEN\" NAME=\"INPUT_COORD\" VALUE=\"\">");
    }
    else
    {
   echo"<INPUT  TYPE=image SRC=$url  BORDER=0 WIDTH=$gpoMap->width HEIGHT=$gpoMap->height NAME=mainmap>";
   printf("<INPUT TYPE=\"HIDDEN\" NAME=\"CMD\" VALUE=\"%s\">", $gszCommand);
    }
//  printf("<IMG SRC=%s WIDTH=%d HEIGHT=%d>\n", $url, $gpoMap->width, $gpoMap->height);

}


/************************************************************************/
/*                        function GMapDrawMap2()                        */
/*                                                                      */
/*      Funcion to draw the contains of the map.                        */
/************************************************************************/
function GMapDrawMap2()
{
    GLOBAL $gpoMap, $gbShowQueryResults;
    GLOBAL $gbIsHtmlMode;
    GLOBAL $gszCommand, $gszZoomBoxExt;
    GLOBAL $gAppletImgFmt, $gImagesFmt;

    if ($gbShowQueryResults)
    {
        $img = $gpoMap->drawQuery();
    }
    else
        $img = $gpoMap->draw();

    $url = $img->saveWebImage($gAppletImgFmt, 0, 0, -1);

    echo "\n".$gszZoomBoxExt."\n";
    printf("<INPUT TYPE=HIDDEN NAME=minx VALUE=\"%f\">", $gpoMap->extent->minx);
    printf("<INPUT TYPE=HIDDEN NAME=miny VALUE=\"%f\">", $gpoMap->extent->miny);
    printf("<INPUT TYPE=HIDDEN NAME=maxx VALUE=\"%f\">", $gpoMap->extent->maxx);
    printf("<INPUT TYPE=HIDDEN NAME=maxy VALUE=\"%f\">", $gpoMap->extent->maxy);

    printf("<INPUT TYPE=HIDDEN NAME=imagewidth VALUE=\"%d\">", $gpoMap->width);
    printf("<INPUT TYPE=HIDDEN NAME=imageheight VALUE=\"%d\">", $gpoMap->height);

/* -------------------------------------------------------------------- */
/*      Use the command to update the rosa applet.                      */
/* -------------------------------------------------------------------- */
    if ( strlen($gszCommand) == 0)
    {
   $szButtonName = "zoomin";
    }
    else
    {
   if ($gszCommand == "ZOOM_IN")
       $szButtonName = "zoomin";
// Do not keep zoomout pressed ot avoid infinite zoomout loop!!!
// if ($gszCommand == "ZOOM_OUT")
//     $szButtonName = "zoomout";
   if ($gszCommand == "RECENTER")
       $szButtonName = "recentre";
   if ($gszCommand == "QUERY_POINT")
       $szButtonName = "pquery";
    }


    if (!$gbIsHtmlMode) //use applet
    {
   printf("\n");
   printf("<APPLET NAME=\"RosaApplet\" ARCHIVE=\"./rosa/rosa.jar\" CODE=\"Rosa2000\" WIDTH=\"%d\" HEIGHT=\"%d\" MAYSCRIPT>\n", $gpoMap->width, $gpoMap->height);
   printf("<PARAM NAME=\"TB_POSITION\" VALUE=\"right\">\n");
   printf("<PARAM NAME=\"TB_ALIGN\" VALUE=\"top\">");
   printf("<PARAM NAME=\"IMG_URL\" VALUE=\"%s\">",$url);
   printf("<PARAM NAME=\"INP_FORM_NAME\" VALUE=\"myform\">");
   printf("<PARAM NAME=\"TB_BUTTONS\" VALUE=\"zoomin|zoomout|recentre|pquery\">\n");
   printf("<PARAM NAME=\"INP_TYPE_NAME\" VALUE=\"INPUT_TYPE\">\n");
   printf("<PARAM NAME=\"INP_COORD_NAME\" VALUE=\"INPUT_COORD\">\n");


   printf("<PARAM NAME=\"TB_SELECTED_BUTTON\" VALUE=\"%s\">",$szButtonName);

        printf("<PARAM NAME=\"TB_BUT_zoomin_IMG\" VALUE=\"./images/tool_zoomin_1.gif\">\n");
   printf("<PARAM NAME=\"TB_BUT_zoomin_IMG_PR\" VALUE=\"./images/tool_zoomin_2.gif\">\n");
   printf("<PARAM NAME=\"TB_BUT_zoomin_HINT\" VALUE=\"Zoom in: Click the button|and the map will zoom in\">\n");
        printf("<PARAM NAME=\"TB_BUT_zoomin_INPUT\" VALUE=\"auto_rect\">\n");
        printf("<PARAM NAME=\"TB_BUT_zoomin_NAME\" VALUE=\"CMD\">\n");
        printf("<PARAM NAME=\"TB_BUT_zoomin_VALUE\" VALUE=\"ZOOM_IN\">\n");


        printf("<PARAM NAME=\"TB_BUT_zoomout_IMG\" VALUE=\"./images/tool_zoomout_1.gif\">\n");
   printf("<PARAM NAME=\"TB_BUT_zoomout_IMG_PR\" VALUE=\"./images/tool_zoomout_2.gif\">\n");
   printf("<PARAM NAME=\"TB_BUT_zoomout_HINT\" VALUE=\"Zoom out: Click the button|and the map will zoom out\">\n");
        printf("<PARAM NAME=\"TB_BUT_zoomout_INPUT\" VALUE=\"submit\">\n");
        printf("<PARAM NAME=\"TB_BUT_zoomout_NAME\" VALUE=\"CMD\">\n");
        printf("<PARAM NAME=\"TB_BUT_zoomout_VALUE\" VALUE=\"ZOOM_OUT\">\n");

        printf("<PARAM NAME=\"TB_BUT_recentre_IMG\" VALUE=\"./images/tool_recentre_1.gif\">\n");
   printf("<PARAM NAME=\"TB_BUT_recentre_IMG_PR\" VALUE=\"./images/tool_recentre_2.gif\">\n");
   printf("<PARAM NAME=\"TB_BUT_recentre_HINT\" VALUE=\"Recenter: Click the button|and the map will recenter\">\n");
        printf("<PARAM NAME=\"TB_BUT_recentre_INPUT\" VALUE=\"auto_point\">\n");
        printf("<PARAM NAME=\"TB_BUT_recentre_NAME\" VALUE=\"CMD\">\n");
        printf("<PARAM NAME=\"TB_BUT_recentre_VALUE\" VALUE=\"RECENTER\">\n");

   printf("<PARAM NAME=\"TB_BUT_pquery_IMG\" VALUE=\"./images/tool_info_1.gif\">\n");
   printf("<PARAM NAME=\"TB_BUT_pquery_IMG_PR\" VALUE=\"./images/tool_info_2.gif\">\n");
   printf("<PARAM NAME=\"TB_BUT_pquery_HINT\" VALUE=\"Point Query: Click a point on the map|for information about that point\">\n");
        printf("<PARAM NAME=\"TB_BUT_pquery_INPUT\" VALUE=\"auto_rect\">\n");
        printf("<PARAM NAME=\"TB_BUT_pquery_NAME\" VALUE=\"CMD\">\n");
        printf("<PARAM NAME=\"TB_BUT_pquery_VALUE\" VALUE=\"QUERY_POINT\">\n");

   printf("</APPLET>");
   printf("<INPUT TYPE=\"HIDDEN\" NAME=\"CMD\" VALUE=\"\">");
   printf("<INPUT TYPE=\"HIDDEN\" NAME=\"INPUT_TYPE\" VALUE=\"\">");
   printf("<INPUT TYPE=\"HIDDEN\" NAME=\"INPUT_COORD\" VALUE=\"\">");
    }
    else
    {
   echo"<INPUT  TYPE=image SRC=$url  BORDER=0 WIDTH=$gpoMap->width HEIGHT=$gpoMap->height NAME=mainmap>";
   printf("<INPUT TYPE=\"HIDDEN\" NAME=\"CMD\" VALUE=\"%s\">", $gszCommand);
    }
//  printf("<IMG SRC=%s WIDTH=%d HEIGHT=%d>\n", $url, $gpoMap->width, $gpoMap->height);

}


/************************************************************************/
/*                      function GMapDrawKeyMap()                       */
/*                                                                      */
/*      Utility function to draw the refernece map (key map).           */
/************************************************************************/
function GMapDrawKeyMap()
{
    GLOBAL      $gpoMap;
    GLOBAL $gAppletImgFmt, $gImagesFmt;

    $img = $gpoMap->drawreferencemap();
    $url = $img->saveWebImage($gImagesFmt, 0, 0, -1);

    printf("<INPUT TYPE=HIDDEN NAME=KEYMAPXSIZE VALUE=\"%d\">", $img->width);
    printf("<INPUT TYPE=HIDDEN NAME=KEYMAPYSIZE VALUE=\"%d\">", $img->height);

//    echo"<IMG  SRC=$url  BORDER=0 >\n";
    echo"<INPUT  TYPE=image SRC=$url  BORDER=0 NAME=KEYMAP>";
}


/************************************************************************/
/*                     function GMapDrawScaleBar()                      */
/*                                                                      */
/*      Draw sacle bar.                                                 */
/************************************************************************/
function GMapDrawScaleBar()
{
    GLOBAL $gpoMap;
    GLOBAL $gAppletImgFmt, $gImagesFmt;

    $img = $gpoMap->drawScaleBar();
    $url = $img->saveWebImage($gImagesFmt, 0, 0, -1);

    echo"<IMG  SRC=$url  BORDER=0 >\n";

}


/************************************************************************/
/*function GMapPix2Geo($nPixPos, $dfPixMin, $dfPixMax, $dfGeoMin, dfGeoMax,*/
/*                           $nInversePix)                              */
/*                                                                      */
/*      Utility function to convert a pixel position to geocoded        */
/*      position.                                                       */
/*                                                                      */
/*       The parameter $nInversePix could be set to 1 for Y pixel       */
/*      coordinates where the UL > LR. Else set to 0.                   */
/************************************************************************/
function GMapPix2Geo($nPixPos, $dfPixMin, $dfPixMax, $dfGeoMin, $dfGeoMax,
                     $nInversePix)
{

//    if ($nPixPos < $dfPixMin)
//        return -1;

//    if ($nPixPos > $dfPixMax)
//        return -1;

//    if ($dfPixMin >= $dfPixMaX ||
//        $dfGeoMin >= $dfGeoMax)
//        return -1;

    $dfWidthGeo = $dfGeoMax - $dfGeoMin;
    $dfWidthPix = $dfPixMax - $dfPixMin;


    $dfPixToGeo = $dfWidthGeo / $dfWidthPix;

    if (!$nInversePix)
        $dfDeltaPix = $nPixPos - $dfPixMin;
    else
        $dfDeltaPix = $dfPixMax - $nPixPos;

    $dfDeltaGeo = $dfDeltaPix * $dfPixToGeo;


    $dfPosGeo = $dfGeoMin + $dfDeltaGeo;

    return ($dfPosGeo);
}

/************************************************************************/
/*  function SetMapExtents($dfNewMinX, $dfNewMinY, $dfNewMaxX, $dfNewMaxY)*/
/*                                                                      */
/*          Set map extents of the map. We also make a test here with   */
/*          the min/max scale set in the .map file (the web object)     */
/*          to verify if the extents are respected. If it is the        */
/*          case return true. Else return false.                        */
/*                                                                      */
/*         Note : the extents of the map are still set using the        */
/*      parameters passed in argument. The caller has the               */
/*      responsability to check the return value.                       */
/************************************************************************/
function SetMapExtents($dfNewMinX, $dfNewMinY, $dfNewMaxX, $dfNewMaxY)
{
    GLOBAL $gpoMap;

    $gpoMap->setExtent($dfNewMinX, $dfNewMinY, $dfNewMaxX, $dfNewMaxY);

    $dfScale = $gpoMap->scale;

//  printf("scale : %f <BR>\n", $dfScale);
//  printf("minscale : %f<BR>\n",$gpoMap->web->minscale);
//  printf("maxscale : %f<BR>\n",$gpoMap->web->maxscale);

    if ($dfScale <  $gpoMap->web->minscale ||
        $dfScale >  $gpoMap->web->maxscale)
        return false;

        return true;
}

/************************************************************************/
/*                     function GMapDumpQueryResults()                  */
/*                                                                      */
/*      Produce a table with query results.                             */
/*      Simply prints an "&nbsp;" if there are no query results.        */
/************************************************************************/
function GMapDumpQueryResults()
{
    GLOBAL $gpoMap, $gbShowQueryResults;

    if (! $gbShowQueryResults )
    {
        printf("&nbsp;");
        return;
    }

    $numResultsTotal = 0;

    for($iLayer=0; $iLayer < $gpoMap->numlayers; $iLayer++)
    {
        $oLayer = $gpoMap->GetLayer($iLayer);

        $numResults = $oLayer->getNumResults();

        if ($numResults == 0)
            continue;  // No results in this layer

        // Open layer's table... take the list of fields to display from
        // the "HEADERRESULT_FIELDS" metadata in the layer object.
        $oLayer->open($gpoMap->shapepath);

        $selFields = explode(" ", $oLayer->getMetaData("RESULT_FIELDS"));

        printf("<TABLE BORDER=0 CELLSPACING=1 CELLPADDING=2 WIDTH=100%%>\n");
        printf("<TR>\n");
        printf("<TD COLSPAN=%d BGCOLOR=#C1D8E3>", sizeof($selFields));
        printf("<CENTER> %s </CENTER>", $oLayer->getMetaData("DESCRIPTION"));
        printf("</TR>\n");

        //
        // Table header: attribute names...
        //
        printf("<TR>\n");
        for ($iField=0; $iField < sizeof($selFields); $iField++)
        {
            printf("<TD BGCOLOR=#E2EFF5>");
            printf("%s",$selFields[$iField]);
            printf("</TD>");
        }
        printf("</TR>\n");

   //
        // One row in table for each selected record
        //

        for ($iRes=0; $iRes < $numResults; $iRes++)
        {
            $oRes = $oLayer->getResult($iRes);

            $oShape = $oLayer->getShape($oRes->tileindex,$oRes->shapeindex);

            printf("<TR>\n");

            printf("<!-- bounds(%f, %f)-(%f, %f)-->\n",
                   $oShape->bounds->minx, $oShape->bounds->miny,
                   $oShape->bounds->maxx, $oShape->bounds->maxy);

            for($iField=0; $iField < sizeof($selFields); $iField++)
            {
                printf("<TD BGCOLOR=#FFFFFF>");
                printf("%s", $oShape->values[$selFields[$iField]]);
                printf("</TD>");
            }
            printf("</TR>\n");

            $oShape->free();

            $numResultsTotal++;
        }

        $oLayer->close();

        printf("</TABLE>\n");
    }

    if ($numResultsTotal == 0)
        echo "Nothing found at query location.";

}


?>
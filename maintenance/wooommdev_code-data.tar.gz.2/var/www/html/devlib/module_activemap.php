<?php

if (isset($libpath)) {
   include_once("$libpath/module_gmap.php");
} else {
   # try local even though this leads to path screwiness
   include_once("./module_gmap.php");
}

/* begin ActiveMap object declaration */
class ActiveMap {
   var $map;
   # map header information (for creating mapfile dynamically)
   var $endline = '\n';
   var $name = '';
   var $mapwidth = 400;
   var $mapheight = 300;
   var $status = 'ON';
   var $extent_to_set = array();
   var $units = 'DD';
   var $shapepath = './';
   var $symbolset = ''; # optional, will not be included if not set
   var $fontset = ''; # optional, will not be included if not set
   var $projection = "proj=latlong";
   # WEB
   var $maxscale = 5000000;
   var $image_path = "/Library/WebServer/Documents/tmp/";
   var $image_urlpath = '/tmp/';
   # END WEB
   # optional map definition blocks
   # #OUTPUTFORMAT
   //var $name = '';
   //var $driver = '';
   //var $imagemode = '';
   # END #OUTPUTFORMAT
   var $dbobj = -1; /* must be a database object to use advanced query features */
   var $map_path;
   var $image_url;
   var $rowcolor = array();
   var $quickviews = array();
   var $formvars;
   var $map_file;
   var $extent_to_html;
   var $zoom_factor;
   var $activelayer;
   var $activetool;
   var $my_point;
   var $my_rect;
   var $pixrect;
   var $extent;
   var $legendurl;
   var $scalebarurl;
   var $querydone;
   var $querylayer;
   var $debug;
#   var $img_type = MS_GIF;
   var $img_type = MS_PNG;
   var $lastresid;
   var $mapform = 'activemap';
   var $images = '/images/';
   var $applets = '/applets';
   var $bordercol = 'C1D8E3';
   var $headercol = 'E2EFF5';
   var $legendname = 'Legend';
   var $mapname = 'Map View';
   var $gbIsHTMLMode = 1;
   var $querymode = MS_MULTIPLE;
   var $qtype = '';
   var $querylayers = array();
   var $querystrict = 1;
      /* querystrict = 0, means all layers are queried simultaneously */
      /* querystrict = 1, means only the active layer is queried */
      /* querystrict = 2, means all layers in the array 'querylayers' may be queried */
      /* querystrict = 3, means only the active layer is queried, must be in array 'querylayers' */
   # whether to show the map name above the map
   var $showmapname = 1;
   var $silent = 0; # whether or not to just output the map interface (0), or to return it as a string (1)


   function setMap($map_path,$inmap='') {
      if (strlen($inmap) > 0) {
         $map_file = $inmap;
      } else {
         $map_file = $this->map_file;
      }
      if (strlen($map_file) > 0) {
         $this->map = ms_newMapObj($map_path.$map_file);
         $this->mapwidth = $this->map->width;
         $this->mapheight = $this->map->height;
         $this->map_path = $map_path;
         $this->map_file = $map_file;
         if ($this->debug) { 
            print("Map File Set : $map_path$map_file<br>"); 
            print_r((array)$this->map ); 
            print("<br>"); 
         }
      } else {
         return "Error: no map file specified.";
      }
   }
   
   function getImageExt() {
      switch ($this->img_type) {
         case MS_PNG;
            $ext = 'png';
         break;
         
         case MS_GIF;
            $ext = 'gif';
         break;
         
         case MS_JPEG;
            $ext = 'jpg';
         break;
         
         default;
            $ext = 'png';
         break;
      }
      
      return $ext;
   }

   function writeMapFile() {
      if (strlen($this->map_file) > 0) {
         $mapstring = '';
         $el = $this->endline;
         $nonzero = array('name','mapwidth','mapheight');
         $mapstring .= "NAME $this->name $el";
         $mapstring .= "SIZE " . $this->mapwidth . " " . $this->mapheight . "$el";
         $mapstring .= "STATUS ON $el";
         $extstring = join(' ', $this->extent_to_set);
         $mapstring .= "EXTENT " . $extstring . "$el";
         $mapstring .= "UNITS $this->units $el";
         $mapstring .= "NAME $this->name $el";
         $mapstring .= "NAME $this->name $el";
      }
   }

   function quickView($lox,$loy,$hix,$hiy) {
      if ($this->debug) {
         print("Quick View requested for: $lox,$loy,$hix,$hiy ");
      }
      $this->map->setextent($lox,$loy,$hix,$hiy);
   }

   function renderMap($invars) {

      $this->querydone = 0;

     if ($this->debug) {
        print("Rendering Requested.<br>");
     }

      #set extent for map from post variable
     if ( isset($invars["extent"]) ) {
        if ($this->debug) {
           print("Setting Extent.<br>");
        }
        $this->extent_to_set = explode(" ",$invars["extent"]);
        $this->map->setextent($this->extent_to_set[0],$this->extent_to_set[1],
        $this->extent_to_set[2],$this->extent_to_set[3]);
        $this->extent->minx = $this->extent_to_set[0];
        $this->extent->miny = $this->extent_to_set[1];
        $this->extent->maxx = $this->extent_to_set[2];
        $this->extent->maxy = $this->extent_to_set[3];
     } else {
        $this->extent_to_set[0] = $this->map->extent->minx;
        $this->extent_to_set[1] = $this->map->extent->miny;
        $this->extent_to_set[2] = $this->map->extent->maxx;
        $this->extent_to_set[3] = $this->map->extent->maxy;
        $this->extent = $this->map->extent;
      }

      $zcoords = $invars["INPUT_COORD"];

      if (isset($this->formvars['mapa_x'])) {
         $mapa_x = $this->formvars['mapa_x'];
         $mapa_y = $this->formvars['mapa_y'];
         $zcoords = "$mapa_x,$mapa_y;$mapa_x,$mapa_y";
      }

      $minx = $this->extent->minx;
      $maxx = $this->extent->maxx;
      $miny = $this->extent->miny;
      $maxy = $this->extent->maxy;

      if (isset($invars["gbIsHTMLMode"])) {
         $this->gbIsHTMLMode = $invars["gbIsHTMLMode"];
      }

      if (isset($this->formvars['JavaOff_x'])) {
         $this->gbIsHTMLMode = 1;
      }

      if (isset($this->formvars['JavaOn_x'])) {
         $this->gbIsHTMLMode = 0;
      }

      if (isset($invars["TOOL"])) {
         $invars["tool"] = $invars["TOOL"];
      }

      $this->mapwidth = $this->map->width;
      $this->mapheight = $this->map->height;

      switch($this->gbIsHTMLMode) {

          case 1:
             $rendermode = 'HTML';
          break;

          default:
             $rendermode = 'Applet';
          break;
       }

      #$this->debug = 1;
      #debug
      if ($this->debug) {
         print("Rendering Mode: $rendermode<br>");
         echo "Values submitted via POST method:<br>";
         reset ($invars);
         while (list ($key, $val) = each ($invars)) {
            echo "$key => $val<br>";
         }
      }

      if ($this->debug) { print("<b>Retrieving Layers, groups</b> <br>"); }
      $layers = $this->map->getAllLayerNames();

      $groups = array();
      $notelayers = array();

      if ($this->debug) {
         $lc = count($layers);
         print("$lc <b>Layers retrieved.</b> <br>");
         #print_r($layers);
      }
      foreach($layers as $layer) {
         $thislayer = $this->map->getLayerByName($layer);
         $thisgroup = $thislayer->group;

         if ($this->debug) { print("$layer, $thisgroup <br>"); }

         if (!($thislayer->type == 4) ) {
            if (isset($invars["show_$layer"]) && isset($invars["extent"])) {
               $thiss = $invars["show_$layer"];
               #debug
               if ($this->debug) {
                  print("Input $layer : $thiss<br>\n");
               }

               if ( ($thiss <> "on") ) {
                  $thislayer->set("status",MS_OFF);
                  $groups[$thisgroup] = "off";
                  if ($this->debug) { print("Group $thisgroup: OFF<br>"); }
               } else {
                  $thislayer->set("status",MS_ON);
                  if ($this->debug) { print("Group $thisgroup: ON<br>"); }
               }
            } else {

               # commented this out on 9/22/2004, seemed like the thing to do? RWB
               # otherwise, refreshing with a image button would not re-set layers
               if ( isset($invars["extent"]) ) {

                  $thislayer->set("status",MS_OFF);
                  $groups[$thisgroup] = "off";
                  if ($this->debug) { print("Group $thisgroup, Layer $layer: off<br>"); }
               }
            }

         } else {
            array_push($notelayers,$layer);
         }
      }

      foreach ($notelayers as $thisnote) {
         $thislayer = $this->map->getLayerByName($thisnote);
         $thisgroup = $thislayer->group;
         if ( $groups[$thisgroup] == "off" ) {
            $thislayer->set("status",MS_OFF);
         }
      }

      if (isset($invars["active_layer"])) {
         $this->activelayer = $invars["active_layer"];
      } else {
         $this->activelayer = "";
      }

     $check_zout = "";
      $check_zin = "";
      $check_pan = "";
      $check_query = "";
      if (isset($this->formvars['zsize'])) {
         $zsize = $this->formvars['zsize'];
      } else {
         $zsize = 2;
      }

      $quickview = $invars["quickview"];
      $qvcoords = split(",",$quickview);

      $active_tool = $invars["tool"];

      if ($this->debug) {
         print("Checking for map click <br>");
      }
      if ( strlen($zcoords) > 0 ) {

         if ($this->debug) {
            print("Found map click <br>");
         }
         # some kind of map-click has occurred, either a point or a box

         list($z1,$z2) = split(";",$zcoords);
         list($mx1,$my1) = split(",",$z1);
         list($mx2,$my2) = split(",",$z2);

         $mapa_x = $mx1;
         $mapa_y = $my1;

         # geo-reference these coords with the current map extent in map units (from click pixel)
         $geox1 = GMapPix2Geo($mx1, 0, $this->mapwidth, $minx, $maxx, 0);
         $geoy1 = GMapPix2Geo($my1, 0, $this->mapheight, $miny, $maxy, 1);
         $geox2 = GMapPix2Geo($mx2, 0, $this->mapwidth, $minx, $maxx, 0);
         $geoy2 = GMapPix2Geo($my2, 0, $this->mapheight, $miny, $maxy, 1);

         if ($this->debug) {
            print("Translated Coordinates <br>");
         }

         # do this to locate the true minx and miny of the submitted coords
         # otherwise, the zooming routine will crash if the box is not formatted properly
         $qvx1 = min(array($geox1, $geox2));
         $qvy1 = min(array($geoy1, $geoy2));
         $qvx2 = max(array($geox1, $geox2));
         $qvy2 = max(array($geoy1, $geoy2));

        # set click point into point object
        $this->my_point = ms_newpointObj();

         if ($this->debug) {
            print("Creating Point Object <br>");
         }
        $this->my_point->setXY($qvx1,$qvy1);

         if ($this->debug) {
            print("Query Point Created - $qvx1,$qvy1<br>");
         }

         $this->qtype = 'point';

        # if rectangle, create rectangle object
        if ($mx1 <> $mx2) {
           # georeferenced rectangle
           $this->my_rect = ms_newrectObj();
           $this->my_rect->set('minx',$qvx1);
           $this->my_rect->set('miny',$qvy1);
           $this->my_rect->set('maxx',$qvx2);
           $this->my_rect->set('maxy',$qvy2);

           # pixel rectangle
           $this->pixrect = ms_newrectObj();
           $this->pixrect->set('minx',$mx1);
           $this->pixrect->set('miny',$my1);
           $this->pixrect->set('maxx',$mx2);
           $this->pixrect->set('maxy',$my2);

            if ($this->debug) {
               print("Query Rectangle Created - ( $mx1 $my1 , $mx2 $my2 )<br>");
            }

            $this->qtype = 'rectangle';
        }

        #$qvcoords = array($qvx1,$qvy1,$qvx2,$qvy2);
        $quickview = join(",", array($qvx1,$qvy1,$qvx2,$qvy2));

         if ($this->debug) {
            print("Raw Zoom Coords: $zcoords - $z1, $z2 - $mx1,$my1,$mx2,$my2 <br>New Extent($qvx1,$qvy1,$qvx2,$qvy2) <br>Old Extent ($minx, $miny, $maxx, $maxy ) <br>");
         }

      }
      $qcount = count($qvcoords);
      if (count($qvcoords) == 4) {
         list($qvx1,$qvy1,$qvx2,$qvy2) = $qvcoords;
         $active_tool = 'quickview';
         $zcoords = "$qvx1,$qvy1;$qvx2,$qvy2";

         if ($this->debug) {
            print("QVCoords ($qcount)- $zcoords <br>");
         }
      }


      if ( ($active_tool == 'simple query') and ( isset($invars["INPUT_COORD"]) ) ) {
         list($z1,$z2) = split(";",$zcoords);
         list($mapa_x,$mapa_y) = split(",",$z1);
      }

      if ( ($active_tool == 'pan') ) {
         if ( (strlen($zcoords) > 0)  and ($zcoords <> '0,0;0,0') ) {
            list($mapa_x,$mapa_y) = split(",",$zcoords);
            $invars["mapa_x"] = $mapa_x;
            $invars["mapa_y"] = $mapa_y;
         } else {
            if (isset($invars["mapa_x"])) {
               $mapa_x = $invars["mapa_x"];
               $mapa_y = $invars["mapa_y"];
            } else {
               $mapa_x = intval($this->mapwidth / 2.0);
               $mapa_y = intval($this->mapheight / 2.0);
            }
         }
      }

     switch ($active_tool) {
        case "quickview":
        $this->zoom_factor = 1;
        break;

        case "pan":
        $this->zoom_factor = 1;
        $zsize = 1;
        break;

        case "zoom in":
        if ( ($zsize == 1) or ($zsize == '')) { $zsize = 2; }
        $this->zoom_factor = 1 * $zsize;
         if ( !(($mx1 == $mx2) && ($my1 == $my2)) ) {
            $active_tool = 'quickview';
         }
        break;

        case "zoom out":
           if ($zsize == 1) { $zsize = 2; }
           $this->zoom_factor = -1 * $zsize;
          # $mapa_x = intval($this->mapwidth / 2.0);
          #  $mapa_y = intval($this->mapheight / 2.0);
        break;

        case "simple query":
           $this->zoom_factor = 1;
        break;

        case "advanced query":
           $this->zoom_factor = 1;
        break;

        default:
        $this->zoom_factor = 1;
     }

      $this->activetool = $active_tool;
      if ($this->debug) {
         print("<br>Active Tool: $active_tool<br>");
         print("<br>Center Coords: ( $mapa_x, $mapa_y )<br>");
      }


     if ( $active_tool == 'quickview' ) {
        if ($this->debug) {
           print("Quick View Coords: $qvx1,$qvy1,$qvx2,$qvy2 <br>");
           print("Attempting to set extent<br>");
        }

        if ( !( is_numeric($qvx1) and is_numeric($qvy1) and is_numeric($qvx2) and is_numeric($qvy2)) ) {
           $qvx1 = $minx;
           $qvy1 = $miny;
           $qvx2 = $maxx;
           $qvy2 = $maxy;
        }

        if ($this->debug) {
           print("Current extent: ");
           $te = $this->map->extent;
           print_r($te);
        }
         $this->map->setextent($qvx1,$qvy1,$qvx2,$qvy2);
         #$this->map->zoomrectangle($this->pixrect, $this->map->width,$this->map->height,$this->extent);
        if ($this->debug) {
           print("First Extent Set<br>");
        }
         $this->extent_to_set = array($qvx1,$qvy1,$qvx2,$qvy2);
        if ($this->debug) {
           print("Second Extent Set<br>");
        }
         #$active_tool = 'quickview';
      }


      if ( ( isset($mapa_x) && isset($mapa_y) ) && ( ($active_tool == "zoom out") || ($active_tool == "zoom in") || ($active_tool == "pan") ) ) {

        $my_point = ms_newpointObj();
        $my_point->setXY($mapa_x,$mapa_y);
        $my_extent = ms_newrectObj();

         $my_extent->setextent($this->extent_to_set[0],$this->extent_to_set[1],
        $this->extent_to_set[2],$this->extent_to_set[3]);

        if ($this->debug) {
           print("Zooming to $this->zoom_factor <br>");
           print_r($my_point);
           print("Width: $this->mapwidth <br>");
           print("Height: $this->mapheight <br>");
           print_r($my_extent);
        }
        $this->map->zoompoint($this->zoom_factor,$my_point,$this->map->width,$this->map->height, $my_extent);

      }

      if ($this->debug) {
         print("Setting Extent <br>");
      }
      $this->extent = $this->map->extent;
      if ($this->debug) {
         print("Extent Retrieved <br>");
         $te = $this->map->extent->minx." ".$this->map->extent->miny." "
            .$this->map->extent->maxx." ".$this->map->extent->maxy;
         print("Extent Set: $te <br>");
      }

      if ( ($active_tool == "simple query") || ($active_tool == "advanced query") ) {
         $this->performQuery();
         $mode = 1;
      } else {
         $mode = 0;
      }
      $this->redrawMap($mode);

      #$this->image_url=$image->saveWebImage(MS_PNG,1,1,0);
      #print("map saved<br>");
      $this->extent_to_set = $this->map->extent->minx." ".$this->map->extent->miny." "
            .$this->map->extent->maxx." ".$this->map->extent->maxy;
      $this->extent_to_html = $this->map->extent->minx." ".$this->map->extent->miny." "
            .$this->map->extent->maxx." ".$this->map->extent->maxy;
   }

   function redrawMap($mode) {
      switch ($mode) {
         case 1:
         # query mode
         $image = $this->map->drawQuery();
         # debug
         if ($this->debug) {
            print("query map<br>");
         }
         break;

         default:
         # no query
         $image=$this->map->draw();
         # debug
         if ($this->debug) {
            print("regular map <br>" . print_r((array)$this->map) );
            print("<br>Image Object: <br>" . print_r((array)$image) );
         }
         break;
      }

      if ($this->debug) {
         print("Generating Map Image <br>");
      }
      # with GD 1.8
      #$this->image_url=$image->saveWebImage($this->img_type,1,1,0);
      $this->image_url=$image->saveWebImage($this->img_type,1,1,0);
      # with GD 1.2 - 1.6
      #$this->image_url=$image->saveWebImage(1,1);
      # with GD 1.2 - 1.6
      #$this->image_url=$image->saveWebImage();
      $this->image_path=$image->imagepath . substr(strrchr($this->image_url, "/"),1);
      if ($this->debug) {
         print("Image Generated.<br>");
         print("IMG URL: $this->image_url <br>");
      }

   }


   function drawMap() {
      print("<INPUT TYPE=IMAGE NAME='mapa' SRC='$this->image_url'>");
      print("<INPUT TYPE=HIDDEN NAME='extent' VALUE='$this->extent_to_html'>");
   }


function drawMap2() {


   $images = $this->images;
   $bordercol = $this->bordercol;
   # C1D8E3
   $headercol = $this->headercol;
   # E2EFF5
   $mapname = $this->mapname;
   
   $outstring = '';

   $outstring .= "   <TABLE BORDER='0' CELLSPACING='0' CELLPADDING='0'>\n";
   $outstring .= "     <TR>\n";
   $outstring .= "       <TD><IMG SRC='$images/corner_TL_LB.jpg' WIDTH='4' HEIGHT='4'></TD>\n";
   $outstring .= "       <TD BGCOLOR='#$headercol'><IMG SRC='$images/pixel.gif' WIDTH='1' HEIGHT='4'></TD>\n";
   $outstring .= "       <TD><IMG SRC='$images/corner_TR_LB.jpg' WIDTH='4' HEIGHT='4'></TD>\n";
   $outstring .= "     </TR>\n";
   if ($this->showmapname) {
      $outstring .= "     <TR ALIGN='CENTER'>\n";
      $outstring .= "       <TD BGCOLOR='#$headercol'>&nbsp;</TD>\n";
      $outstring .= "       <TD BGCOLOR='#$headercol'><FONT FACE='Arial, Helvetica, sans-serif' SIZE='2'><B>$mapname</B></FONT></TD>\n";
      $outstring .= "       <TD BGCOLOR='#$headercol'>&nbsp;</TD>\n";
      $outstring .= "     </TR>\n";
   }
   $outstring .= "      <TR>\n";
   $outstring .= "        <TD BGCOLOR='#999999'><IMG SRC='$images/pixel.gif' WIDTH='1' HEIGHT='1'></TD>\n";
   $outstring .= "        <TD BGCOLOR='#999999'><IMG SRC='$images/pixel.gif' WIDTH='1' HEIGHT='1'></TD>\n";
   $outstring .= "        <TD BGCOLOR='#999999'><IMG SRC='$images/pixel.gif' WIDTH='1' HEIGHT='1'></TD>\n";
   $outstring .= "      </TR>\n";
   $outstring .= "     <TR>\n";
   $outstring .= "       <TD BGCOLOR='#$bordercol'><IMG SRC='$images/pixel.gif' WIDTH='1' HEIGHT='4'></TD>\n";
   $outstring .= "       <TD BGCOLOR='#$bordercol'><IMG SRC='$images/pixel.gif' WIDTH='1' HEIGHT='4'></TD>\n";
   $outstring .= "       <TD BGCOLOR='#$bordercol'><IMG SRC='$images/pixel.gif' WIDTH='1' HEIGHT='4'></TD>\n";
   $outstring .= "     </TR>\n";
   $outstring .= "     <TR>\n";
   $outstring .= "       <TD BGCOLOR='#$bordercol'>&nbsp;</TD>\n";
   $outstring .= "       <TD BGCOLOR='#999999'>\n";
   $outstring .= "         <TABLE WIDTH='$this->mapwidth' BORDER='0' CELLSPACING='1' CELLPADDING='0' HEIGHT='$this->mapheight'>\n";
   $outstring .= "           <TR BGCOLOR='FFFFFF' ALIGN='CENTER'>\n";

   $outstring .= "            <TD>\n";
   $outstring .= $this->showMapOrMapplet();
   $outstring .= "            </TD>\n";


   #$outstring .= "<INPUT TYPE=IMAGE NAME='mapa' SRC='$this->image_url'>";
    #$outstring .= "<INPUT TYPE=HIDDEN NAME='extent' VALUE='$this->extent_to_html'>";

   $outstring .= "           </TR>\n";
   $outstring .= "         </TABLE>\n";
   $outstring .= "       </TD>\n";
   $outstring .= "       <TD BGCOLOR='#$bordercol'>&nbsp;</TD>\n";
   $outstring .= "     </TR>\n";
   $outstring .= "     <TR>\n";
   $outstring .= "       <TD BGCOLOR='#$bordercol'>&nbsp;</TD>\n";
   $outstring .= "       <TD BGCOLOR='#FFFFFF' ALIGN='CENTER'>\n";

   #GMapDrawScaleBar();
   $outstring .= $this->showScaleBar();

   $outstring .= "       <TD BGCOLOR='#$bordercol'>&nbsp;</TD>\n";
   $outstring .= "     </TR>\n";
   $outstring .= "     <TR>\n";
   $outstring .= "       <TD><IMG SRC='$images/corner_BL_DB.jpg' WIDTH='4' HEIGHT='4'></TD>\n";
   $outstring .= "       <TD BGCOLOR='#$bordercol'><IMG SRC='$images/pixel.gif' WIDTH='1' HEIGHT='4'></TD>\n";
   $outstring .= "       <TD><IMG SRC='$images/corner_BR_DB.jpg' WIDTH='4' HEIGHT='4'></TD>\n";
   $outstring .= "     </TR>\n";
   $outstring .= "   </TABLE>\n";
   
   if ($this->silent) {
      return $outstring;
   } else {
      print $outstring;
   }

}

function openFormatBox($title,$fwidth,$fheight,$halign) {

   # set $fwidth = -1 for un-specified
   if (!isset($fwidth)) { $fwidth = -1; }
   if (!isset($fheight)) { $fheight = -1; }
   if (!isset($title)) { $title = ''; }

   $images = $this->images;
   $bordercol = $this->bordercol;
   # C1D8E3
   $headercol = $this->headercol;
   # E2EFF5
   $mapname = $this->mapname;

   print("   <TABLE BORDER='0' CELLSPACING='0' CELLPADDING='0' WIDTH='$fwidth'>\n");
   print("     <TR>\n");
   print("       <TD><IMG SRC='$images/corner_TL_LB.jpg' WIDTH='4' HEIGHT='4'></TD>\n");
   print("       <TD BGCOLOR='#$headercol'><IMG SRC='$images/pixel.gif' WIDTH='1' HEIGHT='4'></TD>\n");
   print("       <TD><IMG SRC='$images/corner_TR_LB.jpg' WIDTH='4' HEIGHT='4'></TD>\n");
   print("     </TR>\n");
   if (strlen($title) > 0) {
      print("     <TR ALIGN='CENTER'>\n");
      print("       <TD BGCOLOR='#$headercol'>&nbsp;</TD>\n");
      print("       <TD BGCOLOR='#$headercol'><FONT FACE='Arial, Helvetica, sans-serif' SIZE='2'><B>$title</B></FONT></TD>\n");
      print("       <TD BGCOLOR='#$headercol'>&nbsp;</TD>\n");
      print("     </TR>\n");
   }
   print("      <TR>\n");
   print("        <TD BGCOLOR='#999999'><IMG SRC='$images/pixel.gif' WIDTH='1' HEIGHT='1'></TD>\n");
   print("        <TD BGCOLOR='#999999'><IMG SRC='$images/pixel.gif' WIDTH='1' HEIGHT='1'></TD>\n");
   print("        <TD BGCOLOR='#999999'><IMG SRC='$images/pixel.gif' WIDTH='1' HEIGHT='1'></TD>\n");
   print("      </TR>\n");
   print("     <TR>\n");
   print("       <TD BGCOLOR='#$bordercol'><IMG SRC='$images/pixel.gif' WIDTH='1' HEIGHT='4'></TD>\n");
   print("       <TD BGCOLOR='#$bordercol'><IMG SRC='$images/pixel.gif' WIDTH='1' HEIGHT='4'></TD>\n");
   print("       <TD BGCOLOR='#$bordercol'><IMG SRC='$images/pixel.gif' WIDTH='1' HEIGHT='4'></TD>\n");
   print("     </TR>\n");
   print("     <TR>\n");
   print("       <TD BGCOLOR='#$bordercol'>&nbsp;</TD>\n");
   print("       <TD BGCOLOR='#999999'>\n");
   if ($fwidth == -1) {
      print("         <TABLE BORDER='0' CELLSPACING='1'");
   } else {
      print("         <TABLE WIDTH='$fwidth' BORDER='0' CELLSPACING='1'");
   }
   if ($fheight == -1) {
      print(" CELLPADDING='0'>\n");
   } else {
      print(" CELLPADDING='0' HEIGHT='$fheight'>\n");
   }

   print("           <TR BGCOLOR='FFFFFF' ALIGN='$halign'>\n");

   print("            <TD>\n");

} /* end openFormatBox() */

function closeFormatBox() {

   $images = $this->images;
   $bordercol = $this->bordercol;
   # C1D8E3
   $headercol = $this->headercol;
   # E2EFF5
   $mapname = $this->mapname;
   print("            </TD>\n");
   print("           </TR>\n");
   print("         </TABLE>\n");
      print("    </TD>\n");
      print("    <TD BGCOLOR='#$bordercol'>&nbsp;</TD>\n");
      print("   </TR>\n");
      print("    <TR>\n");
      print("    <TD BGCOLOR='#$bordercol'><IMG SRC='$images/pixel.gif' WIDTH='1' HEIGHT='4'></TD>\n");
      print("    <TD BGCOLOR='#$bordercol'><IMG SRC='$images/pixel.gif' WIDTH='1' HEIGHT='4'></TD>\n");
      print("    <TD BGCOLOR='#$bordercol'><IMG SRC='$images/pixel.gif' WIDTH='1' HEIGHT='4'></TD>\n");
      print("   </TR>\n");
      print("   <TR>\n");
      print("     <TD BGCOLOR='#999999'><IMG SRC='$images/pixel.gif' WIDTH='1' HEIGHT='1'></TD>\n");
      print("     <TD BGCOLOR='#999999'><IMG SRC='$images/pixel.gif' WIDTH='1' HEIGHT='1'></TD>\n");
      print("     <TD BGCOLOR='#999999'><IMG SRC='$images/pixel.gif' WIDTH='1' HEIGHT='1'></TD>\n");
      print("   </TR>\n");
   print("   </TABLE>\n");

} /* end closeFormatBox() */


function showJavaToggle() {

   $images = $this->images;
   print("<TABLE CELLPADDING='2' CELLSPACING='0'>\n");
   print("  <TR>\n");
   print("     <TD><INPUT TYPE='image' BORDER='0'  \n");
   if ($this->gbIsHTMLMode) {
      print("NAME='JavaOn' SRC='$images/java_off.gif'");
   } else {
      print("NAME='JavaOff' SRC='$images/java_on.gif'");
   }
   print(" WIDTH='24' HEIGHT='25'></TD>\n");
   print("     <TD><FONT FACE='Arial, Helvetica, sans-serif' SIZE='2'>\n");
   if ($this->gbIsHTMLMode) {
      print('Java Mode Disabled<BR>Click to Enable');
   } else {
      print('Java Mode Enabled<BR>Click to Disable');
   }
   print("</FONT>\n");
   print("      </TD>\n");
   print("  </TR>\n");
   print("</TABLE>\n");
}

function showMapOrMapplet() {

   $images = $this->images;
   $applets = $this->applets;
   $gszCommand = $this->activetool;

   switch ($gszCommand) {

     case "quickview":
        $szButtonName = "zoomin";
     break;

     case "pan":
        $szButtonName = "recentre";
     break;

     case "zoom in":
        $szButtonName = "zoomin";
     break;

     case "zoom out":
        $szButtonName = "zoomin";
     break;

     case "simple query":
        $szButtonName = "pquery";
     break;

     case "advanced query":
        $szButtonName = "pquery";
     break;

     default:
        $szButtonName = "zoomin";
     break;
   }
   
   $outstring = '';

   if (!$this->gbIsHTMLMode) {

      # use applet
      $outstring .= "\n";
        #$outstring .= "<APPLET NAME=\"RosaApplet\" ARCHIVE=\"$applets/rosa.jar\" CODE=\"Rosa2000\" WIDTH=\"%d\" HEIGHT=\"%d\" MAYSCRIPT>\n", $this->mapwidth, $this->mapheight);
        $outstring .= sprintf("<APPLET NAME=\"RosaApplet\" ARCHIVE=\"$applets/rosa_png.jar\" CODE=\"Rosa2000\" WIDTH=\"%d\" HEIGHT=\"%d\" MAYSCRIPT>\n", $this->mapwidth, $this->mapheight);
        $outstring .= "<PARAM NAME=\"TB_POSITION\" VALUE=\"right\">\n";
        $outstring .= "<PARAM NAME=\"TB_ALIGN\" VALUE=\"top\">";
        $outstring .= sprintf("<PARAM NAME=\"IMG_URL\" VALUE=\"%s\">",$this->image_url);
        $outstring .= "<PARAM NAME=\"INP_FORM_NAME\" VALUE=\"$this->mapform\">";
        $outstring .= "<PARAM NAME=\"TB_BUTTONS\" VALUE=\"zoomin|zoomout|recentre|pquery\">\n";

        $outstring .= "<PARAM NAME=\"INP_TYPE_NAME\" VALUE=\"INPUT_TYPE\">\n";
        $outstring .= "<PARAM NAME=\"INP_COORD_NAME\" VALUE=\"INPUT_COORD\">\n";

        $outstring .= sprintf("<PARAM NAME=\"TB_SELECTED_BUTTON\" VALUE=\"%s\">",$szButtonName);

        $outstring .= "<PARAM NAME=\"TB_BUT_zoomin_IMG\" VALUE=\"$images/tool_zoomin_1.gif\">\n";
        $outstring .= "<PARAM NAME=\"TB_BUT_zoomin_IMG_PR\" VALUE=\"$images/tool_zoomin_2.gif\">\n";
        $outstring .= "<PARAM NAME=\"TB_BUT_zoomin_HINT\" VALUE=\"Zoom in: Click the button|and the map will zoom in\">\n";
        $outstring .= "<PARAM NAME=\"TB_BUT_zoomin_INPUT\" VALUE=\"auto_rect\">\n";

        $outstring .= "<PARAM NAME=\"TB_BUT_zoomin_NAME\" VALUE=\"TOOL\">\n";

        $outstring .= "<PARAM NAME=\"TB_BUT_zoomin_VALUE\" VALUE=\"zoom in\">\n";

        $outstring .= "<PARAM NAME=\"TB_BUT_zoomout_IMG\" VALUE=\"$images/tool_zoomout_1.gif\">\n";
        $outstring .= "<PARAM NAME=\"TB_BUT_zoomout_IMG_PR\" VALUE=\"$images/tool_zoomout_2.gif\">\n";
        $outstring .= "<PARAM NAME=\"TB_BUT_zoomout_HINT\" VALUE=\"Zoom out: Click the button|and the map will zoom out\">\n";
        $outstring .= "<PARAM NAME=\"TB_BUT_zoomout_INPUT\" VALUE=\"submit\">\n";
        $outstring .= "<PARAM NAME=\"TB_BUT_zoomout_NAME\" VALUE=\"TOOL\">\n";
        $outstring .= "<PARAM NAME=\"TB_BUT_zoomout_VALUE\" VALUE=\"zoom out\">\n";
        $outstring .= "<PARAM NAME=\"TB_BUT_recentre_IMG\" VALUE=\"$images/tool_recentre_1.gif\">\n";
        $outstring .= "<PARAM NAME=\"TB_BUT_recentre_IMG_PR\" VALUE=\"$images/tool_recentre_2.gif\">\n";

        $outstring .= "<PARAM NAME=\"TB_BUT_recentre_HINT\" VALUE=\"Recenter: Click the button|and the map will recenter\">\n";
        $outstring .= "<PARAM NAME=\"TB_BUT_recentre_INPUT\" VALUE=\"auto_point\">\n";
        $outstring .= "<PARAM NAME=\"TB_BUT_recentre_NAME\" VALUE=\"TOOL\">\n";
        $outstring .= "<PARAM NAME=\"TB_BUT_recentre_VALUE\" VALUE=\"pan\">\n";

        $outstring .= "<PARAM NAME=\"TB_BUT_pquery_IMG\" VALUE=\"$images/tool_info_1.gif\">\n";
        $outstring .= "<PARAM NAME=\"TB_BUT_pquery_IMG_PR\" VALUE=\"$images/tool_info_2.gif\">\n";
        $outstring .= "<PARAM NAME=\"TB_BUT_pquery_HINT\" VALUE=\"Point Query: Click a point on the map|for information about that point\">\n";
        $outstring .= "<PARAM NAME=\"TB_BUT_pquery_INPUT\" VALUE=\"auto_rect\">\n";
        $outstring .= "<PARAM NAME=\"TB_BUT_pquery_NAME\" VALUE=\"TOOL\">\n";
        $outstring .= "<PARAM NAME=\"TB_BUT_pquery_VALUE\" VALUE=\"simple query\">\n";

        $outstring .= "</APPLET>\n";
        $outstring .= "<INPUT TYPE=\"HIDDEN\" NAME=\"gbIsHTMLMode\" VALUE=\"0\">\n";
       #$outstring .= "<INPUT TYPE=\"HIDDEN\" NAME=\"tool\" VALUE=\"\">\n";
       #$outstring .= "<INPUT TYPE=\"HIDDEN\" NAME=\"tool\" VALUE=\"\">\n";
       $outstring .= "<INPUT TYPE=\"HIDDEN\" NAME=\"TOOL\" VALUE=\"$gszCommand\">\n";
       $outstring .= "<INPUT TYPE=\"HIDDEN\" NAME=\"INPUT_TYPE\" VALUE=\"\">\n";
       $outstring .= "<INPUT TYPE=\"HIDDEN\" NAME=\"INPUT_NAME\" VALUE=\"\">\n";
       $outstring .= "<INPUT TYPE=\"HIDDEN\" NAME=\"INPUT_COORD\" VALUE=\"\">\n";
       $outstring .= "<INPUT TYPE=HIDDEN NAME='extent' VALUE='$this->extent_to_html'>";

   } else {
      $imgurl = $this->image_url;
      $outstring .= "<INPUT TYPE=IMAGE NAME='mapa' SRC='$imgurl'>";
      $outstring .= $this->showMapHiddenFormVars();
   }
   
   if ($this->silent) {
      return $outstring;
   } else {
      print $outstring;
   }
}

   function showMapHiddenFormVars() {
      $ext = $this->extent_to_html;
      $outstring = '';
      $outstring .= "<INPUT TYPE=HIDDEN NAME='extent' VALUE='$ext'>";
      $outstring .= "<INPUT TYPE=\"HIDDEN\" NAME=\"gbIsHTMLMode\" VALUE=\"$this->gbIsHTMLMode\">";

      if ($this->silent) {
         return $outstring;
      } else {
         print $outstring;
      }
   }


   function showLegend() {
      $this->drawLegend;
      $outstring = '';
      $outstring .= "<img src='$legendurl'>";
      if ($this->silent) {
         return $outstring;
      } else {
         print $outstring;
      }
   }


   function drawLegend() {
      $legend = $this->map->drawLegend();
      $legendurl = $legend->saveWebImage(MS_PNG,1,1,0);
      $this->legend_url = $legendurl;
   }

   function showScalebar() {
      $scalebar = $this->map->drawScaleBar();
      $scalebarurl = $scalebar->saveWebImage(MS_PNG,1,1,0);
      $this->scalebarurl = $scalebarurl;
      $outstring = '';
      
      $outstring .= "<img src='$scalebarurl'>";
   
      if ($this->silent) {
         return $outstring;
      } else {
         print $outstring;
      }
   }

   function showLayerPallete($invars) {

      if ( (!isset($this->rowcolor[1])) or ($this->rowcolor[1] = "") ) {
         $this->rowcolor[1] = "#f0f0f0";
         $this->rowcolor[2] = "#FFFFFF";
      }

      $layers = $this->map->getAllLayerNames();
      $layers = array_reverse($layers);
      $rowcounter = 0;
      $outstring = '';
      
      $outstring .= "<table>\n";
      $outstring .= "<tr><td><b>Visible</b></td><td><b>Active</b></td><td><b>Layer Name</b></td></tr>\n";
      foreach($layers as $layer) {

         $bgcolor = $this->rowcolor[( ($rowcounter%2) + 1)];
         $checked = "";
         $thislayer = $this->map->getLayerByName($layer);
         $status = $thislayer->status;
         $lint = $thislayer->index;
         $ltype = $thislayer->type;

         if ($ltype <> 4) {
            # do not display layer control if type 4, annotation
            $outstring .= "<tr bgcolor=$bgcolor>\n";

            if ( ($status <> 0) ) { $checked = " CHECKED";}
            $outstring .= "<td align=center><input type=checkbox name='show_$layer'$checked></td>";
            $lc = "";
            if ($this->activelayer == $layer) { $lc = " CHECKED";}
            $outstring .= "<td align=center><input type=radio name='active_layer' value='$layer' $lc></td>";
            $outstring .= "<td> $layer<br></td>";
            $outstring .= "</tr>\n";
            $rowcounter++;
         }

      }
      $outstring .= "<tr><td colspan=3><input type='submit' value='Refresh' name='Refresh'></td></tr>\n";
      $outstring .= "</table>\n";
   
      if ($this->silent) {
         return $outstring;
      } else {
         print $outstring;
      }

   }

   function showLayerPallete2() {

      if ( (!isset($this->rowcolor[1])) or ($this->rowcolor[1] = "") ) {
         $this->rowcolor[1] = "#f0f0f0";
         $this->rowcolor[2] = "#FFFFFF";
      }

      $layers = $this->map->getAllLayerNames();
      $layers = array_reverse($layers);
      $rowcounter = 0;
      
      $outstring = '';

      # show borders
      $images = $this->images;
     $bordercol = $this->bordercol;
     # C1D8E3 is default
     $headercol = $this->headercol;
     # E2EFF5 is default
     $legendname = $this->legendname;
     # Legend is default

      $outstring .= "   <TABLE BORDER='0' CELLSPACING='0' CELLPADDING='0'>\n";
      $outstring .= "   <TR>\n";
      $outstring .= "    <TD><IMG SRC='$images/corner_TL_LB.jpg' WIDTH='4' HEIGHT='4'></TD>\n";
      $outstring .= "    <TD BGCOLOR='#$headercol'><IMG SRC='$images/pixel.gif' WIDTH='1' HEIGHT='4'></TD>\n";
      $outstring .= "    <TD><IMG SRC='$images/corner_TR_LB.jpg' WIDTH='4' HEIGHT='4'></TD>\n";
      $outstring .= "   </TR>\n";
      $outstring .= "   <TR ALIGN='CENTER'>\n";
      $outstring .= "    <TD BGCOLOR='#$headercol'>&nbsp;</TD>\n";
      $outstring .= "    <TD BGCOLOR='#$headercol'><FONT FACE='Arial, Helvetica, sans-serif' SIZE='2'><B>$legendname</B></FONT></TD>\n";
      $outstring .= "    <TD BGCOLOR='#$headercol'>&nbsp;</TD>\n";
      $outstring .= "   </TR>\n";
      $outstring .= "   <TR>\n";
      $outstring .= "    <TD BGCOLOR='#999999'><IMG SRC='$images/pixel.gif' WIDTH='1' HEIGHT='1'></TD>\n";
      $outstring .= "    <TD BGCOLOR='#999999'><IMG SRC='$images/pixel.gif' WIDTH='1' HEIGHT='1'></TD>\n";
      $outstring .= "    <TD BGCOLOR='#999999'><IMG SRC='$images/pixel.gif' WIDTH='1' HEIGHT='1'></TD>\n";
      $outstring .= "   </TR>\n";
      $outstring .= "    <TR>\n";
      $outstring .= "    <TD BGCOLOR='#$bordercol'><IMG SRC='$images/pixel.gif' WIDTH='1' HEIGHT='4'></TD>\n";
      $outstring .= "    <TD BGCOLOR='#$bordercol'><IMG SRC='$images/pixel.gif' WIDTH='1' HEIGHT='4'></TD>\n";
      $outstring .= "    <TD BGCOLOR='#$bordercol'><IMG SRC='$images/pixel.gif' WIDTH='1' HEIGHT='4'></TD>\n";
      $outstring .= "   </TR>\n";
      # layer legend header
      $outstring .= "   <TR>\n";
      $outstring .= "    <TD BGCOLOR='#$bordercol'>&nbsp;</TD>\n";
      $outstring .= "    <TD BGCOLOR='#$bordercol'>\n";
      $outstring .= "      <TABLE WIDTH='100%' BORDER='0' CELLSPACING='1' CELLPADDING='2'>\n";
      $outstring .= "        <TR BGCOLOR='#FFFFFF'>\n";
      $outstring .= "          <TD ALIGN='CENTER'><IMG SRC='$images/icon_eye.gif' WIDTH='17' HEIGHT='11'></TD>\n";
      $outstring .= "          <TD ALIGN='CENTER'>&nbsp;</TD>\n";
      $outstring .= "          <TD><FONT FACE='Arial, Helvetica, sans-serif' SIZE='2'><B>Layer</B></FONT></TD>\n";
      $outstring .= "        </TR>\n";

      #$outstring .= "<table>\n";
      #$outstring .= "<tr><td><b>Visible</b></td><td><b>Active</b></td><td><b>Layer Name</b></td></tr>\n";
      foreach($layers as $layer) {

         $bgcolor = $this->rowcolor[( ($rowcounter%2) + 1)];
         $checked = "";
         $thislayer = $this->map->getLayerByName($layer);
         if ($thislayer->getmetadata("title") <> '') {
            $title = $thislayer->getmetadata("title");
         } else {
            $title = $layer;
         }
         $status = $thislayer->status;
         $lint = $thislayer->index;
         $ltype = $thislayer->type;

         if ($ltype <> 4) {
            # do not display layer control if type 4, annotation
            $outstring .= "        <tr bgcolor=$bgcolor>\n";
            $outstring .= "          <TD ALIGN='CENTER'>\n";

            if ( ($status <> 0) ) { $checked = " CHECKED";}
            $outstring .= "           <input type=checkbox name='show_$layer'$checked></td>";
            $lc = "";
            if ($this->activelayer == $layer) { $lc = " CHECKED";}
            $outstring .= "<td align=center><input type=radio name='active_layer' value='$layer' $lc></td>";
            $outstring .= "          <TD><FONT FACE='Arial, Helvetica, sans-serif' SIZE='2'> $title</FONT></TD>\n";
            $outstring .= "</tr>\n";
            $rowcounter++;
         }

      }
      $outstring .= "        <TR BGCOLOR='#FFFFFF'>\n";
      $outstring .= "          <TD ALIGN='CENTER'>\n";
      $outstring .= "            <INPUT TYPE=IMAGE SRC='$images/icon_redraw.gif' WIDTH='19' HEIGHT='19' NAME='Refresh' VALUE='Refresh' BORDER=0>\n";
      $outstring .= "          </TD>\n";
      $outstring .= "          <TD COLSPAN='2'><FONT FACE='Arial, Helvetica, sans-serif' SIZE='2'>Redraw Map</FONT></TD>\n";
      $outstring .= "        </TR>\n";
      $outstring .= "      </TABLE>\n";

     # bottom side border of legend box
      $outstring .= "    </TD>\n";
      $outstring .= "    <TD BGCOLOR='#$bordercol'>&nbsp;</TD>\n";
      $outstring .= "   </TR>\n";
      $outstring .= "    <TR>\n";
      $outstring .= "    <TD BGCOLOR='#$bordercol'><IMG SRC='$images/pixel.gif' WIDTH='1' HEIGHT='4'></TD>\n";
      $outstring .= "    <TD BGCOLOR='#$bordercol'><IMG SRC='$images/pixel.gif' WIDTH='1' HEIGHT='4'></TD>\n";
      $outstring .= "    <TD BGCOLOR='#$bordercol'><IMG SRC='$images/pixel.gif' WIDTH='1' HEIGHT='4'></TD>\n";
      $outstring .= "   </TR>\n";
      $outstring .= "   <TR>\n";
      $outstring .= "     <TD BGCOLOR='#999999'><IMG SRC='$images/pixel.gif' WIDTH='1' HEIGHT='1'></TD>\n";
      $outstring .= "     <TD BGCOLOR='#999999'><IMG SRC='$images/pixel.gif' WIDTH='1' HEIGHT='1'></TD>\n";
      $outstring .= "     <TD BGCOLOR='#999999'><IMG SRC='$images/pixel.gif' WIDTH='1' HEIGHT='1'></TD>\n";
      $outstring .= "   </TR>\n";
      $outstring .= "    <TR>\n";
      $outstring .= "    <TD BGCOLOR='#$bordercol'><IMG SRC='$images/pixel.gif' WIDTH='1' HEIGHT='4'></TD>\n";
      $outstring .= "    <TD BGCOLOR='#$bordercol'><IMG SRC='$images/pixel.gif' WIDTH='1' HEIGHT='4'></TD>\n";
      $outstring .= "    <TD BGCOLOR='#$bordercol'><IMG SRC='$images/pixel.gif' WIDTH='1' HEIGHT='4'></TD>\n";
      $outstring .= "   </TR>\n";

      # quick view box
      $outstring .= "   <TR>\n";
      $outstring .= "    <TD BGCOLOR='#$bordercol'>&nbsp;</TD>\n";
      $outstring .= "    <TD BGCOLOR='#$bordercol' ALIGN='CENTER'>\n";
      $outstring .= "      <FONT FACE='Arial, Helvetica, sans-serif' SIZE='2'>\n";
      $outstring .= "      <SELECT NAME='quickview'  onChange='submit()'>\n";

      $outstring .= "        <OPTION>Quick View</OPTION>\n";

      # loop over quick view entries
      $outstring .= "        <OPTION>- - - - - - - - - - - - - - -</OPTION>\n";

      $quickviews = $this->quickviews;

      foreach($quickviews as $thisview) {
         $vname = $thisview['name'];
         $vcoords = $thisview['coords'];

         $outstring .= "        <OPTION VALUE='$vcoords'>$vname </OPTION>";

      }

      # end quick view loop

      $outstring .= "      </SELECT >\n";
      $outstring .= "      </FONT>\n";
      $outstring .= "    </TD>\n";
      $outstring .= "    <TD BGCOLOR='#$bordercol'>&nbsp;</TD>\n";
      $outstring .= "   </TR>\n";
      $outstring .= "   <TR>\n";
      $outstring .= "    <TD><IMG SRC='$images/corner_BL_DB.jpg' WIDTH='4' HEIGHT='4'></TD>\n";
      $outstring .= "    <TD BGCOLOR='#$bordercol'><IMG SRC='$images/pixel.gif' WIDTH='1' HEIGHT='4'></TD>\n";
      $outstring .= "    <TD><IMG SRC='$images/corner_BR_DB.jpg' WIDTH='4' HEIGHT='4'></TD>\n";
      $outstring .= "   </TR>\n";

      $outstring .= "</table>\n";

      if ($this->silent) {
         return $outstring;
      } else {
         print $outstring;
      }

   }

   function showToolBar($invars, $orient=1) {

      $active_tool = $invars["tool"];

      # $orient is the orientation of the tool bar-
      # 1 - vertical
      # 2 - horizontal

      $check_zout = "";
           $check_zin = "";
           $check_pan = "";
           $check_query = "";
           $zsize = $invars["zsize"];

      switch ($active_tool) {
         case "pan":
         $check_pan = "CHECKED";
         $this->zoom_factor = 1;
         break;

         case "zoom in":
         $check_zin = "CHECKED";
         $this->zoom_factor = 1 * $zsize;
         break;

         case "zoom out":
         $check_zout = "CHECKED";
         $this->zoom_factor = -1 * $zsize;
         break;

         case "simple query":
         $check_query = "CHECKED";
         break;

         case "advanced query":
         $check_advanced = "CHECKED";
         break;

      }

      print("<table><tr><TD valign=top>\n");

      print("<INPUT TYPE=RADIO NAME='tool' VALUE='pan' $check_pan> Pan ");
      print("<INPUT TYPE=RADIO NAME='tool' VALUE='zoom in' $check_zin> Zoom In ");
      print("<INPUT TYPE=RADIO NAME='tool' VALUE='zoom out' $check_zout> Zoom Out ");
      print("<INPUT TYPE=TEXT NAME='zsize' VALUE='$zsize' SIZE=2> Zoom Factor ");
      print("<INPUT TYPE=RADIO NAME='tool' VALUE='advanced query' $check_advanced> Query ");
      #print("<INPUT TYPE=RADIO NAME='tool' VALUE='advanced query' $check_advanced>Advanced Query ");

    print("\n</TD></tr></table>\n");

   }


   function showVerticalToolBar() {
      $this->showFormatedToolbar(1);
   }

   function showFormatedToolbar($orient=1) {


   if ($this->gbIsHTMLMode) {
      $active_tool = $this->formvars['TOOL'];
      $images = $this->images;

      $check_zout = "";
       $check_zin = "";
       $check_pan = "";
       $check_query = "";
       $zsize = $invars["zsize"];

      switch ($active_tool) {
      case "pan":
      $check_pan = "CHECKED";
      $this->zoom_factor = 1;
      break;

      case "zoom in":
      $check_zin = "CHECKED";
      $this->zoom_factor = 1 * $zsize;
      break;

      case "zoom out":
      $check_zout = "CHECKED";
      $this->zoom_factor = -1 * $zsize;
      break;

      case "simple query":
      $check_query = "CHECKED";
      break;

      case "advanced query":
      $check_advanced = "CHECKED";
      break;

      }

      switch($orient) {
         case 1:
         $ropen = "";
         $rclose = "";
         $topen = "      <TR><TD>\n";
         $tsep = "       </TD><TD>";
         $tclose = "      </TD></TR>\n";
         break;

         case 2:
         $ropen = "<tr>\n";
         $rclose = "</tr>\n";
         $topen = "      <TD>\n";
         $tsep = "       </TD><TD>";
         $tclose = "      </TD>\n";
         break;

         default:
         $topen = "      <TR><TD>\n";
         $tsep = "       </TD><TD>";
         $tclose = "      </TD></TR>\n";
         break;
      }

      $this->openFormatBox('',-1,-1,'center');
      print("    <TABLE BORDER='0' CELLSPACING='0' CELLPADDING='0'>\n");
      print("$ropen");
      print("$topen");
      print("          <INPUT TYPE='radio' NAME='TOOL' VALUE='zoom in' $check_zin>");
      print("$tsep");
      print("        <IMG SRC='$images/icon_zoomin.gif' WIDTH='25' HEIGHT='25'>");
      print("$tclose");
      print("$topen");
      print("          <INPUT TYPE='radio' NAME='TOOL' VALUE='zoom out' $check_zout>");
      print("$tsep");
      print("        <IMG SRC='$images/icon_zoomout.gif' WIDTH='25' HEIGHT='25'>");
      print("$tclose");
      print("$topen");
      print("          <INPUT TYPE='radio' NAME='TOOL' VALUE='pan' $check_pan>");
      print("$tsep");
      print("        <IMG SRC='$images/icon_recentre.gif' WIDTH='25' HEIGHT='25'>");
      print("$tclose");
      print("$topen");
      print("          <INPUT TYPE='radio' NAME='TOOL' VALUE='simple query' $check_query>");
      print("$tsep");
      print("        <IMG SRC='$images/icon_info.gif' WIDTH='25' HEIGHT='25'>");
      print("$tclose");
      print("$rclose");
      print("    </TABLE>\n");
      $this->closeFormatBox();
      }
   }


   function performQuery() {
      # perform a query based on the current point
      #$this->debug = 1;
      $clickpoint = $this->my_point;

      $x = $clickpoint->x;
      $y = $clickpoint->y;
      #debug
      #$debug = 1;
      if ($this->debug) {print("X: $x, Y: $y<br>\n");}

      $w = $this->map->width;
      $h = $this->map->height;

      $minx = $this->extent->minx;
      $maxx = $this->extent->maxx;
      $miny = $this->extent->miny;
      $maxy = $this->extent->maxy;


      #debug
      if ($this->debug) {
         print("X params to gmappix2geo: $x, 0, $w, $minx, $maxx, 0<br>/n");
         print("Y params to gmappix2geo: $y, 0, $h, $miny, $maxy, 1<br>/n");
      }
      $qx = GMapPix2Geo($x, 0, $w, $minx, $maxx, 0);
      $qy = GMapPix2Geo($y, 0, $h, $miny, $maxy, 1);

      $querypoint = ms_newpointObj();
      $querypoint->setXY($qx,$qy);

      #debug
      if ($this->debug) {
         print("Map Extents ($minx,$miny) ($maxx,$maxy) Query Points: ( $qx, $qy)<br>\n");
      }
      #debug
      if ($this->debug) {
         print("Active layer: $this->activelayer<br>\n");
      }
      if ($this->activelayer <> "") {
         $thislayer = $this->map->getLayerByName($this->activelayer);

         switch ($this->qtype) {
            case 'point':
               @$thislayer->queryByPoint($this->my_point,$this->querymode,-1);
               $this->querydone = 1;
               if ($this->debug) { print("Point Query <br>"); }
               break;

            case 'rectangle':
               @$thislayer->queryByRect($this->my_rect);
               $this->querydone = 1;
               if ($this->debug) { print("Rectangle Query <br>"); }
               break;

            default:
               @$thislayer->queryByPoint($querypoint,$this->querymode,-1);
               $this->querydone = 1;
            break;
         }
      }
   }/* end function performQuery() */

   function getResultArray() {

   if ( ($this->querydone) && ($this->activelayer <> "") ) {

      $thislayer = $this->map->getLayerByName($this->activelayer);

      $queryresults = array();
      #$debug = 1;
      #debug
      if ($this->debug) {
         print("Layer: $this->activelayer<br>\n");
         print("Query Type: $this->activetool<br>\n");

      }

      switch ($thislayer->connectiontype) {
         case MS_POSTGIS:
           $thislayer->open();
           if ($this->debug) {
              print("Connection Type: MS_POSTGIS<br>\n");
           }
         break;

         case MS_WMS:
           $thislayer->open();
           if ($this->debug) {
              print("Connection Type: MS_WMS<br>\n");
           }
         break;

         case MS_WFS:
           $thislayer->open();
           if ($this->debug) {
              print("Connection Type: MS_WFS<br>\n");
           }
         break;

         case MS_SHAPEFILE:
           #$thislayer->open("$this->map_path$thislayer->data");
           $thislayer->open();
           if ($this->debug) {
              print("Connection Type: MS_SHAPEFILE<br>\n");
           }
            break;

         default:
            if ($this->debug) {
               print("Unkown layer type: $thislayer->connectiontype<br>/n");
            }
           $thislayer->open();
         break;
     } /* end switch */

     $numrecs = $thislayer->getNumResults();
     /* iterate through all records */
     if ($this->debug) {
        print("Returned: $numrecs<br>\n");
        #print_r($thislayer->getResults());
     }

     for ( $i = 0;$i <$numrecs;$i++ ) {
        $result = $thislayer->getResult($i);
         if ($this->debug) {
            print("Found result: $i<br>");
            #print("Result: $result<br>\n");
         }
         $resid = $result->shapeindex;
         $tileid = $result->tileindex;
         if ($this->debug) {
                 print("Result ID: $resid<br>\n");
         }
         #$reshape = $thislayer->getShape(-1,$resid);
         switch ($thislayer->connectiontype) {

            case MS_WFS:
            $reshape = $thislayer->getFeature($resid,$tileid);
            break;

            default:
            #$reshape = $thislayer->getFeature($resid);
            $reshape = $thislayer->getShape($tileid,$resid);
            #$reshape = $thislayer->getShape($resid);
            break;
         }

         #$reshape = $thislayer->getShape($resid,$tileid);
         $numcols = $reshape->numvalues;
         if ($this->debug) {
                 print("Found Shape with $numcols columns<br>\n");
         }
        #$qshape = $thislayer->getFeature($resid,$tileid);
        #$recarr = array();
        #if($reshape)
        #{
         #   for($k = 0; $k < $reshape->numvalues; $k++)
        #    {
        #        $col = $reshape->getItem($k);
        #        $val = $reshape->getValue($layerobj, $col);
        #        # do something with them.
        #        $recarr[$col] = $val;
         #   }

        #}
        $recarr = $reshape->values;
         array_push($queryresults,$recarr);

         if ($this->debug) {
            print("Results: $result, $resid - ");
            #print_r($reshape->values);
            print("<br>");
         }
         $this->lastresid = $resid;

         $reshape->free();
      }
      $thislayer->close();
   } else {
      $queryresults = array();
   }
  /* end querydone */

  return $queryresults;
  } /* end function getResultArray() */



   function showQueryResults() {

   if ($this->activelayer <> "") {

      $thislayer = $this->map->getLayerByName($this->activelayer);
      $queryresults = $this->getResultArray();
      print("<b>Query Results:</b><br>\n");

      if (sizeof($queryresults) == 0) {
         print("No matching records.");
      }

      foreach ($queryresults as $result) {
         $rkeys = array_keys($result);
         foreach ($rkeys as $thiskey) {
            $rvalue = $result[$thiskey];
            print("$thiskey: $rvalue<br>\n");
         }

      }
   } /* end if active layer is set */

   } /* end function showQueryResults() */

   function showQueryResults2() {

      $images = $this->images;
      print("   <TABLE BORDER='0' CELLSPACING='0' CELLPADDING='0'>\n");
      print("    <TR>\n");
      print("      <TD><IMG SRC='$images/corner_TL_LB.jpg' WIDTH='4' HEIGHT='4'></TD>\n");
      print("      <TD BGCOLOR='#E2EFF5'><IMG SRC='$images/pixel.gif' WIDTH='1' HEIGHT='4'></TD>\n");
      print("      <TD><IMG SRC='$images/corner_TR_LB.jpg' WIDTH='4' HEIGHT='4'></TD>\n");
      print("    </TR>\n");
      print("    <TR ALIGN='CENTER'>\n");
      print("      <TD BGCOLOR='#E2EFF5'>&nbsp;</TD>\n");
      print("              <TD BGCOLOR='#E2EFF5'><FONT FACE='Arial, Helvetica, sans-serif' SIZE='2'><B>Information</B></FONT></TD>\n");
      print("      <TD BGCOLOR='#E2EFF5'>&nbsp;</TD>\n");
      print("    </TR>\n");
      print("     <TR>\n");
      print("       <TD BGCOLOR='#999999'><IMG SRC='$images/pixel.gif' WIDTH='1' HEIGHT='1'></TD>\n");
      print("       <TD BGCOLOR='#999999'><IMG SRC='$images/pixel.gif' WIDTH='1' HEIGHT='1'></TD>\n");
      print("       <TD BGCOLOR='#999999'><IMG SRC='$images/pixel.gif' WIDTH='1' HEIGHT='1'></TD>\n");
      print("     </TR>\n");
      print("      <TR>\n");
      print("      <TD BGCOLOR='#C1D8E3'><IMG SRC='$images/pixel.gif' WIDTH='1' HEIGHT='4'></TD>\n");
      print("      <TD BGCOLOR='#C1D8E3'><IMG SRC='$images/pixel.gif' WIDTH='1' HEIGHT='4'></TD>\n");
      print("      <TD BGCOLOR='#C1D8E3'><IMG SRC='$images/pixel.gif' WIDTH='1' HEIGHT='4'></TD>\n");
      print("    </TR>\n");
      print("    <TR>\n");
      print("      <TD BGCOLOR='#C1D8E3'>&nbsp;</TD>\n");
      print("      <TD WIDTH='$this->mapwidth'>\n");

      $this->showAdvancedQuery();

      print("      </TD>\n");
      print("      <TD BGCOLOR='#C1D8E3'>&nbsp;</TD>\n");
      print("    </TR>\n");
      print("    <TR>\n");
      print("      <TD><IMG SRC='$images/corner_BL_DB.jpg' WIDTH='4' HEIGHT='4'></TD>\n");
      print("      <TD BGCOLOR='#C1D8E3'><IMG SRC='$images/pixel.gif' WIDTH='1' HEIGHT='4'></TD>\n");
      print("      <TD><IMG SRC='$images/corner_BR_DB.jpg' WIDTH='4' HEIGHT='4'></TD>\n");
      print("    </TR>\n");
      print("   </TABLE>\n");
   }

   function showAdvancedQuery() {

      if ($this->dbobj->dbconn <> -1) {

          if ($this->debug) {
             print("Query Layer: $this->activelayer <br>");
             print_r($this->getResultArray());
          }

            $this->dbobj->queryrecords = $this->getResultArray();

            $thislayer = $this->map->getLayerByName($this->activelayer);
          #debug
            if ($thislayer->getmetadata("tablename") <> '') {
               $tname = $thislayer->getmetadata("tablename");
            } else {
               $tname = $layer;
            }
            $this->dbobj->tablename = $tname;

          #$$listobject->showDetail();
            $this->dbobj->showList();

      }

   }
} /* end of ActiveMap Object declaration */

?>

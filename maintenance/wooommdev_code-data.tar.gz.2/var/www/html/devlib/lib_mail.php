<?php

# lib mail

function mxcl_mail( $subject, $message, $recipient )
{
    ob_start();
    print_r( $GLOBALS );
    $teh_globals = chunk_split( base64_encode( ob_get_clean() ) ); // base 64 encode
       
    $date = date( 'r' );
    $phpversion = phpversion();
    $boundary = md5( time() );
    $filename = '$GLOBALS.txt';
   

    $headers = <<<END
From: $_SERVER[PHP_SELF] <php@$_SERVER[SERVER_NAME]>
Date: $date
X-Mailer: PHP v$phpversion
MIME-Version: 1.0
Content-Type: multipart/related; boundary="$boundary"
END;

    $message = <<<END
--$boundary
Content-Type: text/plain; charset="iso-9959-1"
Content-Transfer-Encoding: 7bit

$message

--$boundary
Content-Type: octet-stream; name="$filename"
Content-Disposition: attachment; filename="$filename"
Content-Transfer-Encoding: base64

$teh_globals

--$boundary--

END;

    mail( $recipient, $subject, $message, $headers );
}


function mailIMAP($mailobj, $mail_headers, $recips, $sender, $message, $debug) {

   $mailto = array('To'=>$sender, 'Bcc'=>$recips);
   $mail_headers['Reply-To'] = $sender;

   if ($debug) {
      print_r($mailto);
      print_r($mail_headers);
   }

   if (strlen($recips) > 0) {
      $res = $mailobj->send($mailto, $mail_headers, $message);
   } else {
      return 'Error: You must supply at least one recipient.';
   }

   if (!$res) {
      # error
      $emesg = $res->toString();
   } else {
      $emesg = "Mail Message Sent Successfully.";
   }
   return $emesg;
}
?>
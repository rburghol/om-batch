<?php


$layerHTML .= showHiddenField('show_proj_subsheds', 'on', 1);
#$layerHTML .= showHiddenField('show_stream_stat', 'on', 1);
$layerHTML .= showHiddenField('show_selectedsegs', 'on', 1);
#$layerHTML .= showHiddenField('show_precip_stat', 'on', 1);
$layerHTML .= showHiddenField('show_poli_bounds', 'on', 1);
$layerHTML .= showHiddenField('show_cities', 'on', 1);
#$layerHTML .= showHiddenField('show_hourly', 'on', 1);
#$layerHTML .= showHiddenField('show_precip_observed', 'on', 1);
$layerHTML .= showHiddenField('show_proj_seggroups', 'on', 1);
$layerHTML .= showHiddenField('show_active_seggroup', 'on', 1);
$layerHTML .= showHiddenField('show_model_elem_poly', 'on', 1);
#$layerHTML .= showHiddenField('show_proj_centroid', 'on', 1);
$layerHTML .= showHiddenField('show_proj_points', 'on', 1);
$layerHTML .= showHiddenField('show_vwuds_measuring_points', 'on', 1);
$layerHTML .= showHiddenField('lreditlist',"$lreditlist", 1);
   
   
?>
<?php

$tvar = 0.0;
if ($tvar == 'NULL') {
   print("Match \n");
} else {
   print("No Match \n");
}

if ($tvar === 'NULL') {
   print("Match \n");
} else {
   print("No Match \n");
}

?>
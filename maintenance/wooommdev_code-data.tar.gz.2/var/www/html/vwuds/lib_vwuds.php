<?php



function VWUDSForm($formValues) {
   global $listobject, $fno, $adminsetuparray, $outdir_nodrive, $outurl, $userid, $usergroupids;

   $controlHTML = '';
   $errorMSG = '';
   $resultMSG = '';
   #$debug = 1;
   $projectid = $formValues['projectid'];
   $search_view = $formValues['search_view'];
   $currentgroup = $formValues['currentgroup'];
   $lreditlist = $formValues['lreditlist'];
   $allgroups = $formValues['allgroups'];
   $custom_to_file = $formValues['custom_to_file'];

   $tablename = 'annual_data';
   if (isset($formValues['function'])) {
      $function = $formValues['function'];
   } else {
      $function = 'vwudsedit';
   }
   switch ($function) {
      case 'mpedit':
         $tablename = 'vwuds_measuring_point';
      break;

      case 'regionedit':
         $tablename = 'vwuds_deq_regions';
      break;

      case 'facilityedit':
         $tablename = 'facilities';
      break;

      case 'annualedit':
         $tablename = 'annual_data';
      break;

      case 'vwpedit':
         $tablename = 'vwp_exemption_detail';
      break;

      case 'users':
         $tablename = 'users';
      break;

      default:
         $tablename = 'annual_data';
      break;
   }

   $aset = $adminsetuparray[$tablename];
   $listobject->adminsetup = $aset;
   $pkcol = $adminsetuparray[$tablename]['table info']['pk'];
   $divname = $adminsetuparray[$tablename]['table info']['divname'];
   $form_title = $adminsetuparray[$tablename]['table info']['form_title'];
   if (isset($adminsetuparray[$tablename]['search info']['pk_search_var'])) {
      $pksearch = $adminsetuparray[$tablename]['search info']['pk_search_var'];
   } else {
      $pksearch = $pkcol;
   }
   if (isset($adminsetuparray[$tablename]['table info']['pk_seq'])) {
      $pk_seq = $adminsetuparray[$tablename]['table info']['pk_seq'];
   } else {
      $pk_seq = '';
   }

   # check permissions
   if (isset($formValues[$pkcol])) {
      $pkval = $formValues[$pkcol];
   }
   if (isset($formValues[$pksearch])) {
      $pkval = $formValues[$pksearch];
   }
   
   # set up the search object
   $searchobject = new listObjectSearchForm;
   $searchobject->listobject = $listobject;
   $searchobject->debug = FALSE;
   $searchobject->adminsetup = $aset;
   $searchobject->setVariableNames($formValues);
   
   if (($pkval == '') and ($search_view == 'edit')) {
      # we have an edit requested without a pk, possibly the result of changing
      #$controlHTML .= print_r($formValues,1) . "<br>";
      #$controlHTML .= "No pk value passed, checking search form for hint " . $searchobject->pksearchcol . "<br>";
      #$controlHTML .= print_r($searchobject->searchnames, 1) . "<br>";
      if (isset($formValues[$searchobject->pksearchcol])) {
         $pkval = $formValues[$searchobject->pksearchcol];
         #$controlHTML .=  $searchobject->pksearchcol . " found = $pkval<br>";
      }
   }
   
   // need to set the proper key for facilities to get the perms right, but we use the other key later on, so on
   // create a temporary copy
   $apset = $aset;
   //$apset['table info']['pk'] = 'userid';
   $perms = getVWUDSPerms($listobject, $apset, $pkval, $userid, $usergroupids, 1);

   if ($debug) {
      $controlHTML .= "<b>Debug: Permissions Routine Returned - </b> " . print_r($perms, 1) . "<br>";
   }
   $ap = $perms['rowperms'] & 2;
   if ( ($perms['rowperms'] & 2) or ($perms['tableperms'] & 2)) {
      $readonly = 0;
      if ($debug) {
         $controlHTML .= "User has edit permissions on this record.<br>";
      }
   } else {
      $readonly = 1;
      if ($debug) {
         $controlHTML .= "User DOES NOT have edit permissions on this record.<br>";
      }
   }
   if ( ($perms['rowperms'] & 1) or ($perms['tableperms'] & 1)) {
      $candelete = 1;
      if ($debug) {
         $controlHTML .= "User has delete permissions on this record.<br>";
      }
   } else {
      $candelete = 0;
      if ($debug) {
         $controlHTML .= "User DOES NOT have delete permissions on this record.<br>";
      }
   }

   if ($perms['tableperms'] & 1) {
      $caninsert = 1;
      if ($debug) {
         $controlHTML .= "User may insert records in this table.<br>";
      }
   } else {
      $caninsert = 0;
      if ($debug) {
         $controlHTML .= "User may NOT insert records in this table.<br>";
      }
   }

   # check for a new record
   if (isset($formValues['searchtype'])) {
      $searchtype = $formValues['searchtype'];
   }
   #$controlHTML .= "Perms returned: " . print_r($perms,1) . "<br> , ReadOnly = $readonly, CanDelete = $candelete<br>";

   # Give the search the record read/write info and call the search form routine.   
   # This will take all of the variables that come in the search and interpret them,
   # returning the record of interest
   $searchobject->insertOK = $caninsert;
   $searchobject->deleteOK = $candelete;
   $searchobject->readonly = $readonly;
   $searchobject->record_submit_script = "xajax_showVWUDSForm(xajax.getFormValues(\"control\")); show_next(\"$divname" . "_data0\", \"$divname" . "_0\", \"$divname" . "\"); ";
   $searchobject->search_submit_script = "xajax_showVWUDSForm(xajax.getFormValues(\"control\")); show_next(\"$divname" . "_data0\", \"$divname" . "_0\", \"$divname" . "\"); ";
   $searchobject->page_submit_script = "xajax_showVWUDSForm(xajax.getFormValues(\"control\")); ";


   # first, check to see if a record "save" has been called
   $blankrec = array();
   $query_log = "/tmp/sql_log_vwuds.sql";
   $controlHTML .= "$query_log  ; <br>";
   $logqueries = 1;
   if ($logqueries) {
      $qlog = fopen($query_log, 'a');
   }
   if (isset($formValues['searchtype'])) {
      switch ($formValues['searchtype']) {
         case 'save':
            $recordsave = processMultiFormVars($listobject,$formValues,$aset,0,$debug, 0, 1);
            $listobject->querystring = $recordsave['updatesql'];
            if ($debug) {
               $controlHTML .= " SAVE SQL: $listobject->querystring ; <br>";
            }
            if ($logqueries) {
               fwrite($qlog, "LOG USERID: $userid\n");
               fwrite($qlog, "QUERY: $listobject->querystring ; \n");
            }
            if ( ($perms['rowperms'] & 2) or ($perms['tableperms'] & 2)) {
               $listobject->performQuery();
               if ($listobject->error) {
                  $errorMSG .= "<b>Error: </b>" . $listobject->error . "<br>";
               } else {
                  $controlHTML .= "Record Saved.<br>";
                  $resultMSG .= "Record Saved.<br>";
               }
            } else {
               $errorMSG .= "<b>Error: </b>You do not have permission to edit this record.<br>";
            }
         break;

         case 'delete':
            $recordsave = processMultiFormVars($listobject,$formValues,$aset,0,$debug, 0, 1);
            $tablename = $aset['table info']['table_name'];
            $listobject->querystring = "DELETE FROM $tablename ";
            $listobject->querystring .= $recordsave['pkclause'];
            if ($debug) {
               $controlHTML .= " DELETE SQL: $listobject->querystring ; <br>";
            }
            if ($logqueries) {
               fwrite($qlog, "LOG USERID: $userid\n");
               fwrite($qlog, "QUERY: $listobject->querystring ; \n");
            }
            if ($perms['rowperms'] & 2) {
               $listobject->performQuery();
               if ($listobject->error) {
                  $errorMSG .= "<b>Error: </b>" . $listobject->error . "<br>";
               } else {
                  $controlHTML .= "Record Deleted.<br>";
               }
               $formValues = array();
            } else {
               $errorMSG .= "<b>Error: </b>You do not have permission to delete this record.<br>";
            }
         break;

         case 'insert':
            $recordsave = processMultiFormVars($listobject,$formValues,$aset,0,$debug, 0, 1);
            $listobject->querystring = $recordsave['insertsql'];
            if ($debug) {
               $controlHTML .= " INSERT SQL: $listobject->querystring ; <br>";
               $controlHTML .= " Error?: " . $recordsave['error'] . "<br>";
               $controlHTML .= " Error Message: " . $recordsave['errormesg'] . "<br>";
            }
            if ($logqueries) {
               fwrite($qlog, "LOG USERID: $userid\n");
               fwrite($qlog, "QUERY: $listobject->querystring ; \n");
            }
            if ($perms['tableperms'] & 1) {
               if ($recordsave['error'] == 0) {
                  $listobject->performQuery();
                  if ($listobject->error) {
                     $errorMSG .= "<b>Error: </b>" . $listobject->error . "<br>";
                     $blankrec = $formValues;
                     $formValues['searchtype'] = 'new';
                     $searchtype = 'new';
                     $formValues['search_view'] = 'edit';
                  } else {
                     $searchtype = 'browse';
                     $formValues['search_view'] = 'edit';
                     $listobject->querystring = "SELECT currval('$pk_seq') ";
                     $listobject->performQuery();
                     #$listobject->show = 0;
                     #$listobject->showList();
                     #$innerHTML .= "$listobject->outstring <br>";
                     $pkid = $listobject->getRecordValue(1,'currval');
                     if ($pkid > 0) {
                        $formValues[$pkcol] = $pkid;
                        if ($debug) {
                           $controlHTML .= "<b>New PK: </b>" . $pkid . "<br>";
                        }
                        # we need to force the interface to show the just inserted record, since it may
                        # or may not be contained in the search criteria
                        $searchobject->forcePK = $pkid;
                     }
                     $resultMSG .= "Record Inserted with ID $pkid.<br>";
                  }
               } else {
                  $errorMSG .= "<b>Error: </b>" . $recordsave['errormesg'] . "<br>";
                  $blankrec = $formValues;
                  $formValues['searchtype'] = 'new';
                  $formValues['search_view'] = 'edit';
                  $searchtype = 'new';
               }
            } else {
               $errorMSG .= "<b>Error: </b>You do not have permission to edit this record.<br>";
            }
         break;
      }
   }
   #$controlHTML .= "Search View: " . print_r($formValues['search_view'], 1) . " Search type " . $formValues['searchtype'] . "<br>";
   $searchForm = $searchobject->showSearchForm($formValues);

   $prev_record_id = $searchForm['previd'];
   $next_record_id = $searchForm['nextid'];
   $numrecs = $searchForm['numrecs'];
   $page_offset = $searchForm['page_offset'];
   $next_page = $searchForm['next_page'];
   $prev_page = $searchForm['prev_page'];
   $num_pages = $searchForm['num_pages'];
   $currentpos = $searchForm['currentpos'];
   $search_view = $searchForm['search_view'];
   # the first record returned, or the target record if this is the result of a click on the prev/next button
   $props = $searchForm['recordvalue'];
   #$controlHTML .= "Search View: " . $search_view . "<br>";
   #$controlHTML .= "Geom For External: " . $searchForm['geomcollectsql'] . "<br>";

   if ($debug) {
      $controlHTML .= print_r($formValues['search_view'],1) . "<br>" . $formValues['searchtype'] . "<br>";
   }

   $controlHTML .= "<div style=\"border: 1px solid rgb(0 , 0, 0); border-style: dotted; overflow: auto; width: 600px; \">";
   $controlHTML .= "<h3>$form_title</h3><br>";
   $controlHTML .= "<form id=control name=control>";
   # hidden system variables
   $controlHTML .= showHiddenField('projectid', $projectid, 1);
   $controlHTML .= showHiddenField('currentgroup', $currentgroup, 1);
   $controlHTML .= showHiddenField('lreditlist', $lreditlist, 1);
   $controlHTML .= showHiddenField('function', $function, 1);
   #$controlHTML .= print_r($formValues, 1) . "<br>";
   ############################################################
   ###                        SEARCH FORM                   ###
   ############################################################
   $controlHTML .= "<a class=\"mH\"";
   $controlHTML .= "onclick=\"toggleMenu('$divname" . "_search')\">+ Show/Hide Advanced Search Form</a>";
   $controlHTML .= "<div id=\"$divname" . "_search\" class=\"mL\"><ul>";
   # display the search form
   $resetscript = "clearForm(\"control\");";
   $controlHTML .= showGenericButton('resetform','Reset Search Form', $resetscript, 1) . "<br>";
   $controlHTML .= $searchForm['formHTML'];
   $controlHTML .= "</div>";
   $controlHTML .= "<br><i><b>Result Display Options: </b></i><table width=100%><tr align=center><td>" . $searchForm['searchOptions'] . '</td></tr></table>';
   $controlHTML .= "<hr>";
   #if ($debug) {
      $controlHTML .= $searchForm['query'] .'<hr>';
   #}
   ############################################################
   ###                 CUSTOM OUTPUT FORM                   ###
   ############################################################
   $aset = $adminsetuparray[$tablename];
   $controlHTML .= "<a class=\"mH\"";
   $controlHTML .= "onclick=\"toggleMenu('$divname" . "_format')\">+ Show/Hide Custom Result Formatting</a>";
   $controlHTML .= "<div id=\"$divname" . "_format\" class=\"mL\">";
   # show a set of custom queryWizard objects
   $queryparent = new blankShell;
   # setting this to the query assembled by the search object
   $subquery = " (" . $searchForm['query'] . " ) as foo ";
   $queryparent->dbtblname = $subquery;
   $querywizard = new queryWizardComponent;
   $querywizard->parentobject = $queryparent;
   $querywizard->listobject = $listobject;
   # create a list for use in the form drop-downs of the various columns that we can select
   $aslist = '';
   $asep = '';
   foreach (array_keys($aset['column info']) as $thiscol) {
      if (isset($aset['column info'][$thiscol]['label'])) {
         $thislabel = $aset['column info'][$thiscol]['label'];
      } else {
         $thislabel = $thiscol;
      }
      $aslist .= $asep . $thiscol . '|' . $thiscol;
      $asep = ',';
   }
   //$controlHTML .= " Column List: $aslist <br>";
   $qset = array();
   $qset['queryWizardComponent'] = $adminsetuparray['queryWizardComponent'];
   # blank this out, since we do not want any of the informational fields
   
   $qset['queryWizardComponent']['column info'] = array("custom_to_file"=>array("type"=>3,"params"=>"0|False,1|True:ctfid:ctfname::0","label"=>"Output Results to File?","visible"=>1, "readonly"=>0, "width"=>6)); 
   foreach (array('queryWizard_selectcolumns'=>'qcols', 'queryWizard_wherecolumns'=>'wcols', 'queryWizard_ordercolumns'=>'ocols') as $colname => $lname) {
      $qset[$colname] = $adminsetuparray[$colname];
      $asrec = split(':',$qset[$colname]['column info'][$lname]['params']);
      $asrec[0] = $aslist;
      $asparams = join(':', $asrec);
      $qset[$colname]['column info'][$lname]['params'] = $asparams;
      //$controlHTML .= " Column Array for <b>$colname</b>: " . print_r($asrec,1). " <br>";
      //$controlHTML .= " Column Select Record: " . $asparams . " <br>";
   }
   $qset['queryWizard_selectcolumns']['column info']['qcols_txt']['visible'] = 0; 
   $qset['queryWizard_selectcolumns']['table info']['showlabels'] = 1; 
   $querywizard->force_cols = 1;
   $querywizard->force_names = array('custom_to_file'=>$custom_to_file);
   $querywizard->qcols = $formValues['qcols'];
   $querywizard->qcols_func = $formValues['qcols_func'];
   $querywizard->qcols_alias = $formValues['qcols_alias'];
   $querywizard->wcols = $formValues['wcols'];
   $querywizard->wcols_op = $formValues['wcols_op'];
   $querywizard->wcols_value = $formValues['wcols_value'];
   $querywizard->wcols_refcols = $formValues['wcols_refcols'];
   $querywizard->ocols = $formValues['ocols'];
   
   $querywizard->listobject->adminsetuparray = $qset;
   $formatinfo = $querywizard->showEditForm('custom');
   $controlHTML .= $formatinfo['innerHTML'];
   $querywizard->assembleQuery();
   $controlHTML .= $querywizard->sqlstring . "<br>";
   $controlHTML .= "<center>" . showGenericButton('search','Search', "document.forms[\"control\"].elements.searchtype.value=\"search\"; document.forms[\"control\"].elements.page_offset.value=0; $searchobject->search_submit_script ; ", 1, 0) . "</center>";
   $controlHTML .= "</div><hr>";
   
   ############################################################
   ###                  END CUSTOM OUTPUT FORM              ###
   ############################################################
   
   # Check for preprocessing
   switch ($search_view) {
      
      case 'custom':
         $listobject->querystring = $querywizard->sqlstring;
         #$listobject->tablename = 'vwuds_measuring_point';
         //$controlHTML .= "Doing Custom Query: " . $querywizard->sqlstring . "<br>";
         $listobject->performQuery();
         $props = $listobject->queryrecords;
         $numrecs = count($props);
         $max_screenrecs = 100;
         if (count($props) > $max_screenrecs) {
            # this is too big to display on screen, we will have to dump it to a file
            $controlHTML .= "Custom Query yielded more than $max_screenrecs results, outputting to file.<br>";
            $search_view = 'file';
         }
         if ($custom_to_file) {
            # this is too big to display on screen, we will have to dump it to a file
            $controlHTML .= "Custom query requested outputting to file.<br>";
            $search_view = 'file';
         }
         //$controlHTML .= "Results: " . print_r( $props,1) . "<br>";
      break;
   }
   
   # now show number of records
   $controlHTML .= showHiddenField('numrecs', $numrecs, 1);
   
   $x1 = $searchForm['x1'];
   $y1 = $searchForm['y1'];
   $x2 = $searchForm['x2'];
   $y2 = $searchForm['y2'];
   $tol = 0.02;
   if ( (abs($x2 - $x1) < $tol) and (abs($y2 - $y1) < $tol) ) {
      $x1 += -1.0 * $tol;
      $x2 += $tol;
      $y1 += -1.0 * $tol;
      $y2 += $tol;
      $controlHTML .= "<b>Notice:</b> Zooming to fixed distance from single selected point.<br>";
   }
   $controlHTML .= "<hr>";
   if (count($props) == 0) {
      $errorMSG .= "<i><b>Error:</b> No records match the selected criteria.<br></i>";
      $controlHTML .= "<div id=errorinfo class='errorInfo'>" . $errorMSG . "</div>";
      $controlHTML .= "<div id=errorinfo class='resultInfo'>" . $resultMSG . "</div>";
   } else {
      $controlHTML .= "<i><b>Search Results:</b> Search Returned $numrecs record(s) matching your criteria.</i><br>";
      $controlHTML .= "<div id=errorinfo class='errorInfo'>" . $errorMSG . "</div>";
      $controlHTML .= "<div id=errorinfo class='resultInfo'>" . $resultMSG . "</div>";
      #$controlHTML .= "gmapZoom($x1, $y1, $x2, $y2)<br>";
      $zoomscript = "gmapZoom($x1, $y1, $x2, $y2) ; var wktshapes = new Array(); ";
      if (strlen($searchForm['geomcollectsql']) > 0) {
         # try to find records to hilite
         if (strlen($aset['table info']['geom_col']) > 0) {
            $geomcol = $aset['table info']['geom_col'];
            if (isset($aset['table info']['maplabelcols'])) {
               $labelcols = split(",", $aset['table info']['maplabelcols']);
            } else {
               $labelcols = array($pkcol);
            }
            $listobject->querystring = $searchForm['geomcollectsql'];
            if ($debug) {
               $controlHTML .= $listobject->querystring . " ; <br>";
            }
            $listobject->performQuery();
            $zoomrecs = $listobject->queryrecords;
            $zi = 0;
            foreach ($zoomrecs as $thisrec) {
               $zgeom = $thisrec[$geomcol];
               $ztext = '';
               $listobject->queryrecords = array($thisrec);
               $listobject->show = 0;
               $aset['column info'][$aset['table info']['geom_col']]['visible'] = 0;
               $aset['table info']['output type'] = 'generic';
               $listobject->adminview = 1;
               $listobject->adminsetup = $aset;
               $listobject->showList();
               $ztext = str_replace(array("\r", "\n"), array('\r', '\n'), addslashes(htmlentities($listobject->outstring, ENT_QUOTES)));
               /*
               foreach ($labelcols as $thiscol) {
                  $ztext .= $thisrec[$thiscol] . "<br>";
               }
               */
               $zoomscript .= " wktshapes[$zi] = [ \"$zgeom\", \"$ztext\"] ; ";
               $zi++;
            }
         }
         $zoomscript .=  " putWKTGoogleShape(wktshapes); ";
      }
      $controlHTML .= showGenericButton('centermap','Zoom Map To Selected Records', $zoomscript, 1);
      $controlHTML .= "<br>";
      switch ($search_view) {
         case 'list':
         $controlHTML .= "Viewing Page " . ($page_offset + 1) . " of $num_pages.<br>";
         break;

         case 'batchedit':
         $controlHTML .= "Viewing Page " . ($page_offset + 1) . " of $num_pages.<br>";
         break;

         case 'file':
         $controlHTML .= "$numrecs records output to temporary file.<br>";
         break;

         case 'edit':
            $controlHTML .= "Editing Record <br>";
         break;

         case 'custom':
            $controlHTML .= "Showing Custom Query Output Format.<br>";
         break;

         default:
            $controlHTML .= "Viewing Record " . ($currentpos + 1) . " out of $numrecs<br>";
         break;
      }
   }
   $listobject->show = 0;
   if ($debug) {
      $controlHTML .= "Search View: $search_view <br>";
   }
      
   switch ($search_view) {
      case 'list':
         $listobject->queryrecords = $props;
         $listobject->showList();
         //$controlHTML .= "Results: " . print_r( $props,1) . "<br>";
         $controlHTML .= $listobject->outstring;
      break;
      
      case 'custom':
         # treat this like a list
         $listobject->queryrecords = $props;
         $listobject->tablename = '';
         $listobject->adminview = 0;
         $listobject->showList();
         $controlHTML .= $listobject->outstring;
      break;

      case 'detail':
      # just use the normal form, except set disabled = 1, since this is a read only view
         $disabled = 1;
         $controlHTML .= showFormVars($listobject, $props, $aset, 1, 0, $debug, 0, 1, $disabled, $fno);
      break;

      case 'file':
         $colnames = array(array_keys($props[0]));
         //$filename = 'tmp_vwuds_' . $userid . '.xls';
         $filenum = "$userid" . rand(1000,9999);
         $filename = 'tmp_vwuds_' . $filenum . '.xls'; 
        if ($debug) {
            $colcsv = join(',', $colnames);
            $controlHTML .= "Columns: $colcsv <br>";
            //$controlHTML .= print_r(array_keys($props[0]),1) . "<br>";
         }

         if ($debug) {
            $numlines = count($props);
            $controlHTML .= "Outputting: $numlines lines <br>";
         }

         #putDelimitedFile("$outdir/$filename", $colnames,"\t",1,'dos');
         putExcelFile("$outdir_nodrive/$filename", $props);
         $controlHTML .= "Outputting to: ./dirs/proj$projectid/out/$filename <br>";
         //putExcelFile("./dirs/proj$projectid/out/$filename", $props);
         $controlHTML .= "<a href='$outurl/$filename' target=_new>Click Here to Download Spreadsheet File of Records.</a><br>";
      break;

      case 'edit':
         $disabled = $readonly;
         if ($searchtype == 'new') {
            if ($caninsert) {
               $disabled = 0;
            }
            $controlHTML .= showFormVars($listobject, $blankrec, $aset, 1, 0, $debug, 0, 1, $disabled, $fno);
         } else {
            $controlHTML .= showFormVars($listobject, $props, $aset, 1, 0, $debug, 0, 1, $disabled, $fno);
         }
         if (isset($aset['table info']['geom_col'])) {
            if (strlen($aset['table info']['geom_col']) > 0) {
               $geomcol = $aset['table info']['geom_col'];
               $controlHTML .= showGenericButton('copygeom','Capture Selected Geometry', "document.forms[\"control\"].elements.$geomcol" . ".value=getScratchGmapGeom(); alert(\"Geometry Copied, you must save for this to take effect.\")", 1) . "<br>";
            }
         }
      break;

      case 'batchedit':
         $disabled = $readonly;
         $aset['table info']['outputformat'] = 'column';
         $controlHTML .= showFormVars($listobject, $props, $aset, 1, 0, $debug, 1, 1, $disabled, $fno);
      break;

      default:
         $controlHTML .= showFormVars($listobject, $props, $aset, 1, 0, $debug, 0, 1, $disabled, $fno);
      break;
   }

   # should we disable the previous button? (at first record)
   if ($prev_record_id == '') {
      $pd = 1;
   } else {
      $pd = 0;
   }

   $controlHTML .= $searchForm['navButtonHTML'] ;
   $controlHTML .= '</form>';

   $controlHTML .= "</div>";
   return $controlHTML;
}

function measuringPointForm($formValues) {
   global $listobject, $fno, $adminsetuparray, $outdir, $outurl, $userid;

   $controlHTML = '';
   #$debug = 1;
   $projectid = $formValues['projectid'];
   $currentgroup = $formValues['currentgroup'];
   $lreditlist = $formValues['lreditlist'];
   $allgroups = $formValues['allgroups'];

   # call the search form routine.   This will take all of the variables that come in the search and interpret them,
   # returning the record of interest
   $searchForm = measuringPointSearchForm($formValues);
   $record_id = $searchForm['recordid'];
   $prev_record_id = $searchForm['previd'];
   $next_record_id = $searchForm['nextid'];
   $numrecs = $searchForm['numrecs'];
   $page_offset = $searchForm['page_offset'];
   $next_page = $searchForm['next_page'];
   $prev_page = $searchForm['prev_page'];
   $num_pages = $searchForm['num_pages'];
   $currentpos = $searchForm['currentpos'];
   $search_view = $searchForm['search_view'];
   # the first record returned, or the target record if this is the result of a click on the prev/next button
   $props = $searchForm['recordvalue'];

   $controlHTML .= "<div style=\"border: 1px solid rgb(0 , 0, 0); border-style: dotted; overflow: auto; width: 600px; \">";
   $controlHTML .= "<form id=control name=control>";
   # hidden system variables
   $controlHTML .= showHiddenField('projectid', $projectid, 1);
   $controlHTML .= showHiddenField('currentgroup', $currentgroup, 1);
   $controlHTML .= showHiddenField('lreditlist', $lreditlist, 1);
   $controlHTML .= showHiddenField('numrecs', $numrecs, 1);
   # action info
   $controlHTML .= showHiddenField('searchtype', $searchtype, 1);
   #$controlHTML .= print_r($formValues, 1) . "<br>";
   ############################################################
   ###                        SEARCH FORM                   ###
   ############################################################
   $controlHTML .= "<a class=\"mH\"";
   $controlHTML .= "onclick=\"toggleMenu('mp_search')\">+ Show/Hide Advanced Search Form</a>";
   $controlHTML .= "<div id=\"mp_search\" class=\"mL\"><ul>";
   # display the search form
   $controlHTML .= $searchForm['formHTML'];
   $controlHTML .= "</div>";
   $controlHTML .= "<hr>";
   $controlHTML .= "Search Options: " . $searchForm['searchOptions'];
   $controlHTML .= "<hr>";
   if (count($props) == 0) {
      $controlHTML .= "<i><b>Error:</b> No records match the selected criteria.<br></i>";
   } else {
      $controlHTML .= "<i><b>Search Results:</b> Search Returned $numrecs record(s) matching your criteria.</i><br>";
      switch ($search_view) {
         case 'list':
         $controlHTML .= "Viewing Page " . ($page_offset + 1) . " of $num_pages.<br>";
         break;

         case 'file':
         $controlHTML .= "$numrecs records output to temporary file.<br>";
         break;

         default:
            $controlHTML .= "Viewing Record $currentpos out of $numrecs<br>";
         break;
      }
   }
   $listobject->show = 0;
   if ($debug) {
      $controlHTML .= "Search View: $search_view <br>";
   }
   switch ($search_view) {
      case 'list':
         $listobject->queryrecords = $props;
         #$listobject->tablename = 'vwuds_measuring_point';
         $listobject->showList();
         $controlHTML .= $listobject->outstring;
         # must add hidden variable for pk and page offset
         $controlHTML .= showHiddenField('record_id', $record_id, 1);
         $page_offset = $searchForm['page_offset'];
         $controlHTML .= showHiddenField('page_offset', $page_offset, 1);
      break;

      case 'detail':
      # just use the normal form, except set disabled = 1, since this is a read only view
         $disabled = 1;
         $controlHTML .= showFormVars($listobject,$props,$adminsetuparray['vwuds_measuring_point'],1, 0, $debug, 0, 1, $disabled, $fno);
      break;

      case 'file':
         $colnames = array(array_keys($props[0]));
         $filename = 'tmp_vwuds_' . $userid . '.csv';
         if ($debug) {
            $colcsv = join(',', $colnames);
            $controlHTML .= "Columns: $colcsv <br>";
         }

         if ($debug) {
            $numlines = count($props);
            $controlHTML .= "Outputting: $numlines lines <br>";
         }

         putDelimitedFile("$outdir/$filename", $colnames,',',1,'dos');
         putDelimitedFile("$outdir/$filename", $props,',',0,'dos');
         $controlHTML .= "<a href='$outurl/$filename' target=_new>Click Here to Download Spreadsheet File of Records.</a>";
         break;

      default:
         $controlHTML .= showFormVars($listobject,$props,$adminsetuparray['vwuds_measuring_point'],1, 0, $debug, 0, 1, $disabled, $fno);
      break;
   }

   # should we disable the previous button? (at first record)
   if ($prev_record_id == '') {
      $pd = 1;
   } else {
      $pd = 0;
   }

   switch ($searchForm['search_view']) {
      case 'list':
         #$controlHTML .= "Previous record_id = $prev_record_id ";
         if ($prev_page == $page_offset) {
            $pd = 1;
         } else {
            $pd = 0;
         }
         $controlHTML  .= showGenericButton('prev_page','<-- Previous Page', "document.forms[\"control\"].elements.searchtype.value=\"browse\"; document.forms[\"control\"].elements.page_offset.value=\"$prev_page\"; xajax_showMeasuringPointForm(xajax.getFormValues(\"control\")); ", 1, $pd);
         # should we disable the next button? (at last record)
         if ($next_page == $page_offset) {
            $nd = 1;
         } else {
            $nd = 0;
         }
         #$controlHTML .= "Next record_id = $next_record_id ";
         $controlHTML .= showGenericButton('next_page','Next Page -->', "document.forms[\"control\"].elements.searchtype.value=\"browse\"; document.forms[\"control\"].elements.page_offset.value=\"$next_page\"; xajax_showMeasuringPointForm(xajax.getFormValues(\"control\")); ", 1, $nd);
         $controlHTML .= "</form>";
         #print("<br>");

      break;

      case 'file':
      # do nothing
      break;

      case 'detail':

         #$controlHTML .= "Previous record_id = $prev_record_id ";
         $edit_disabled = 0; # this needs to be set by a permission check function, for now, it will allow editing by default
         $controlHTML  .= showGenericButton('editrecord','Edit', "document.forms[\"control\"].elements.searchtype.value=\"browse\"; document.forms[\"control\"].elements.search_view.value=\"edit\"; for (i=0;i<document.forms[\"control\"].elements.search_view.length;i++) { if (document.forms[\"control\"].elements.search_view[i].value == \"edit\") { document.forms[\"control\"].elements.search_view[i].checked=true ; } } ; document.forms[\"control\"].elements.record_id.value=\"$record_id\"; xajax_showMeasuringPointForm(xajax.getFormValues(\"control\")); show_next(\"mp_data0\", \"mp_0\", \"mp\"); ", 1, $edit_disabled);
         $controlHTML  .= "<br>";
         $controlHTML  .= showGenericButton('showprev','<-- Previous', "document.forms[\"control\"].elements.searchtype.value=\"browse\"; document.forms[\"control\"].elements.record_id.value=\"$prev_record_id\"; xajax_showMeasuringPointForm(xajax.getFormValues(\"control\")); show_next(\"mp_data0\", \"mp_0\", \"mp\"); ", 1, $pd);
         # should we disable the next button? (at last record)
         if ($next_record_id == '') {
            $nd = 1;
         } else {
            $nd = 0;
         }
         #$controlHTML .= "Next record_id = $next_record_id ";
         $controlHTML .= showGenericButton('shownext','Next -->', "document.forms[\"control\"].elements.searchtype.value=\"browse\"; document.forms[\"control\"].elements.record_id.value=\"$next_record_id\"; xajax_showMeasuringPointForm(xajax.getFormValues(\"control\")); show_next(\"mp_data0\", \"mp_0\", \"mp\"); ", 1, $nd);
         $controlHTML .= "</form>";
         #print("<br>");
         #$debug = 1;
      break;

      default:

         #$controlHTML .= "Previous record_id = $prev_record_id ";
         $controlHTML  .= showGenericButton('showprev','<-- Previous', "document.forms[\"control\"].elements.searchtype.value=\"browse\"; document.forms[\"control\"].elements.record_id.value=\"$prev_record_id\"; xajax_showMeasuringPointForm(xajax.getFormValues(\"control\")); show_next(\"mp_data0\", \"mp_0\", \"mp\"); ", 1, $pd);
         # should we disable the next button? (at last record)
         if ($next_record_id == '') {
            $nd = 1;
         } else {
            $nd = 0;
         }
         #$controlHTML .= "Next record_id = $next_record_id ";
         $controlHTML .= showGenericButton('shownext','Next -->', "document.forms[\"control\"].elements.searchtype.value=\"browse\"; document.forms[\"control\"].elements.record_id.value=\"$next_record_id\"; xajax_showMeasuringPointForm(xajax.getFormValues(\"control\")); show_next(\"mp_data0\", \"mp_0\", \"mp\"); ", 1, $nd);
         $controlHTML .= "</form>";
         #print("<br>");
         #$debug = 1;
      break;
   }

   $controlHTML .= "</div>";
   return $controlHTML;
}

function measuringPointSearchForm($formValues) {
   global $listobject, $fno, $adminsetuparray;

   $controlHTML = '';
   $searchresult = array();

   #$debug = 1;
   $projectid = $formValues['projectid'];
   $currentgroup = $formValues['currentgroup'];
   $lreditlist = $formValues['lreditlist'];
   $allgroups = $formValues['allgroups'];
   # for now, we assume that geo constraints are in effect
   $constraingeo = $formValues['constraingeo'];
   $constrainrecid = $formValues['constrainrecid'];
   $min_userid = $formValues['min_userid'];
   $max_userid = $formValues['max_userid'];
   $vwp_no = $formValues['vwp_no'];
   $gw_no = $formValues['gw_no'];
   $constrain_gwno = $formValues['constrain_gwno'];
   $constrain_vwpno = $formValues['constrain_vwpno'];
   if (isset($formValues['search_view'])) {
      $search_view = $formValues['search_view'];
   } else {
      $search_view = 'list';
   }
   if (isset($formValues['page_records'])) {
      $page_records = $formValues['page_records'];
   } else {
      if ($search_view == 'list') {
         $page_records = 10;
      } else {
         $page_records = 1;
      }
   }
   if ($page_records <= 0) {
      $page_records = 1;
   }
   if (isset($formValues['page_offset'])) {
      $page_offset = $formValues['page_offset'];
   } else {
      $page_offset = 0;
   }
   $rec_offset = $page_offset * $page_records;

   if (isset($formValues['searchtype'])) {
      $searchtype = $formValues['searchtype'];
   } else {
      $searchtype = 'browse';
   }
   $show_locality = $formValues['show_locality'][0];
   if (count($show_locality) > 0) {
      $fips_clause = " stcofips in ( '" . join("','", $show_locality) . "') " ;
   } else {
      $fips_clause = " ( 1 = 1 ) " ;
   }
   $show_usetypes = $formValues['show_usetypes'][0];
   if (count($show_usetypes) > 0) {
      $use_clause = " \"CAT_MP\" in ( '" . join("','", $show_usetypes) . "') " ;
   } else {
      $use_clause = " ( 1 = 1 ) " ;
   }
   $show_sourcetypes = $formValues['show_sourcetypes'][0];
   if (count($show_sourcetypes) > 0) {
      $src_clause = " \"TYPE\" in ( '" . join("','", $show_sourcetypes) . "') " ;
   } else {
      $src_clause = " ( 1 = 1 ) " ;
   }
   $show_sourcesubtypes = $formValues['show_sourcesubtypes'][0];
   if (count($show_sourcesubtypes) > 0) {
      $srcsub_clause = " \"SUBTYPE\" in ( '" . join("','", $show_sourcesubtypes) . "') " ;
   } else {
      $srcsub_clause = " ( 1 = 1 ) " ;
   }
   $show_actiontypes = $formValues['show_actiontypes'][0];
   if (count($show_actiontypes) > 0) {
      $action_clause = " \"ACTION\" in ( '" . join("','", $show_actiontypes) . "') " ;
   } else {
      $action_clause = " ( 1 = 1 ) " ;
   }
   if ($constrainrecid == 1) {
      $userid_clause = " \"USERID\" >= '$min_userid' AND \"USERID\" <= '$max_userid' " ;
   } else {
      $userid_clause = " ( 1 = 1 ) " ;
   }
   if ($constrain_vwpno == 1) {
      $vwpno_clause = " \"VWP_PERMIT\" = '$vwp_no' " ;
   } else {
      $vwpno_clause = " ( 1 = 1 ) " ;
   }
   if ($constrain_gwno == 1) {
      $gwno_clause = " \"GWPERMIT\" = '$gw_no' " ;
   } else {
      $gwno_clause = " ( 1 = 1 ) " ;
   }

   if ( isset($formValues['record_id']) and ($searchtype <> 'search') ) {
      $record_id = $formValues['record_id'];
      $numrecs = $formValues['numrecs'];
   } else {
      # if the record_id is NOT set, OR if this is a search, we go for this
      $listobject->querystring = "select min(record_id) as record_id, count(*) as numrecs from vwuds_measuring_point ";
      $listobject->querystring .= " WHERE $action_clause ";
      $listobject->querystring .= " AND $userid_clause ";
      $listobject->querystring .= " AND $vwpno_clause ";
      $listobject->querystring .= " AND $gwno_clause ";
      $listobject->querystring .= " AND $src_clause ";
      $listobject->querystring .= " AND $srcsub_clause ";
      $listobject->querystring .= " AND $use_clause ";
      $listobject->querystring .= " AND $fips_clause ";
      if ($debug) {
         $controlHTML .= " $listobject->querystring ; ";
      }
      $listobject->performQuery();
      $record_id = $listobject->getRecordValue(1,'record_id');
      $numrecs = $listobject->getRecordValue(1,'numrecs');
   }

   switch ($search_view) {
      case 'list':
         $listobject->querystring = "select * from vwuds_measuring_point ";
         $listobject->querystring .= " WHERE $action_clause ";
         $listobject->querystring .= " AND $userid_clause ";
         $listobject->querystring .= " AND $vwpno_clause ";
         $listobject->querystring .= " AND $gwno_clause ";
         $listobject->querystring .= " AND $src_clause ";
         $listobject->querystring .= " AND $srcsub_clause ";
         $listobject->querystring .= " AND $use_clause ";
         $listobject->querystring .= " AND $fips_clause ";
         $listobject->querystring .= " LIMIT $page_records OFFSET $rec_offset ";
      break;

      case 'file':
         $listobject->querystring = "select * from vwuds_measuring_point ";
         $listobject->querystring .= " WHERE $action_clause ";
         $listobject->querystring .= " AND $userid_clause ";
         $listobject->querystring .= " AND $vwpno_clause ";
         $listobject->querystring .= " AND $gwno_clause ";
         $listobject->querystring .= " AND $src_clause ";
         $listobject->querystring .= " AND $srcsub_clause ";
         $listobject->querystring .= " AND $use_clause ";
         $listobject->querystring .= " AND $fips_clause ";
         break;

      case 'detail':
         $listobject->querystring = "select * from vwuds_measuring_point where record_id = $record_id ";
      break;

      default:
         $listobject->querystring = "select * from vwuds_measuring_point where record_id = $record_id ";
         $listobject->querystring .= " AND $action_clause ";
      break;

   }
   if ($debug) {
      $controlHTML .= " $listobject->querystring ; ";
   }
   $listobject->performQuery();
   switch ($search_view) {
      case 'list':
         $props = $listobject->queryrecords;
         $record_id = $props[0]['record_id'];
      break;

      case 'file':
         $props = $listobject->queryrecords;
         $record_id = $props[0]['record_id'];
      break;

      default:
         $props = $listobject->queryrecords[0];
         $record_id = $props['record_id'];
      break;
   }

   $searchResult['recordvalue'] = $props;
   $searchResult['recordid'] = $record_id;
   $searchResult['numrecs'] = $numrecs;
   $searchResult['page_offset'] = $page_offset;
   if ($page_offset > 0) {
      $searchResult['prev_page'] = $page_offset - 1;
   } else {
      $searchResult['prev_page'] = $page_offset;
   }
   $searchResult['num_pages'] = ceil($numrecs / $page_records);
   if ( ($page_offset + 1) >= ($numrecs / $page_records) ) {
      $searchResult['next_page'] = $page_offset;
   } else {
      $searchResult['next_page'] = $page_offset + 1;
   }
   #$debug = 0;
   # get previous and next
   $listobject->querystring = "select min(record_id) as next_record_id from vwuds_measuring_point ";
   if ( ltrim(rtrim($record_id)) <> '') {
      $listobject->querystring .= " WHERE record_id > $record_id ";
   } else {
      $listobject->querystring .= " WHERE ( 1 = 1 ) ";
   }
   $listobject->querystring .= " AND $action_clause ";
   $listobject->querystring .= " AND $userid_clause ";
   $listobject->querystring .= " AND $vwpno_clause ";
   $listobject->querystring .= " AND $gwno_clause ";
   $listobject->querystring .= " AND $src_clause ";
   $listobject->querystring .= " AND $srcsub_clause ";
   $listobject->querystring .= " AND $use_clause ";
   $listobject->querystring .= " AND $fips_clause ";
   if ($debug) {
      $controlHTML .= " $listobject->querystring ; ";
   }
   $listobject->performQuery();
   $next_record_id = $listobject->getRecordValue(1,'next_record_id');
   $listobject->querystring = "select max(record_id) as prev_record_id, count(*) as prevno from vwuds_measuring_point ";
   if ( ltrim(rtrim($record_id)) <> '') {
      $listobject->querystring .= " WHERE record_id < $record_id ";
   } else {
      $listobject->querystring .= " WHERE ( 1 = 1 ) ";
   }
   $listobject->querystring .= " AND $action_clause ";
   $listobject->querystring .= " AND $userid_clause ";
   $listobject->querystring .= " AND $vwpno_clause ";
   $listobject->querystring .= " AND $gwno_clause ";
   $listobject->querystring .= " AND $src_clause ";
   $listobject->querystring .= " AND $srcsub_clause ";
   $listobject->querystring .= " AND $use_clause ";
   $listobject->querystring .= " AND $fips_clause ";
   if ($debug) {
      $controlHTML .= " $listobject->querystring ; ";
   }
   $listobject->performQuery();
   $prev_record_id = $listobject->getRecordValue(1,'prev_record_id');
   $currentpos = $listobject->getRecordValue(1,'prevno');
   $searchResult['nextid'] = $next_record_id;
   $searchResult['previd'] = $prev_record_id;
   $searchResult['currentpos'] = $currentpos;

   #print_r($allsegs);
   ############################################################
   ###                        SEARCH FORM                   ###
   ############################################################
   $controlHTML .= "<table border=1>";
   $controlHTML .= "<tr>";
   $controlHTML .= "<td valign='top'>";
   # show check box to decide if we will constrain our geography to the currently selected area
   $controlHTML .= showCheckBox('constraingeo', 1, $constraingeo, '', 1, 0);
   $controlHTML .= "<b> Restrict to Current Watershed?</b><br>";
   $controlHTML .= showCheckBox('constrainrecid', 1, $constrainrecid, '', 1, 0);
   $controlHTML .= "<b> Restrict to USERID Range (below)?</b><br>";
   $controlHTML .= "&nbsp;&nbsp; from " . showWidthTextField('min_userid', $min_userid, 12, '', 1, 0);
   $controlHTML .= " to " . showWidthTextField('max_userid', $max_userid, 12, '', 1, 0);
   $controlHTML .= '<br>' . showCheckBox('constrain_gwno', 1, $constrain_gwno, '', 1, 0);
   $controlHTML .= "<b> Show GW Permit #:</b> ";
   $controlHTML .= showWidthTextField('gw_no', $gw_no, 12, '', 1, 0);
   $controlHTML .= '<br>' . showCheckBox('constrain_vwpno', 1, $constrain_vwpno, '', 1, 0);
   $controlHTML .= "<b> Show VWP Permit #:</b> ";
   $controlHTML .= showWidthTextField('vwp_no', $vwp_no, 12, '', 1, 0);
   $controlHTML .= "<br><b> Search By Locality:</b><br>";
   $controlHTML .=  showMultiList2($listobject,'show_locality', 'poli_bounds', 'poli1', 'name', $show_locality, "$projectid = $projectid", 'name', $debug, 4, 1, 0);
   $controlHTML .= "</td>";
   $controlHTML .= "<td valign='top'>";
   $controlHTML .= "<b> Show Selected Action Types:</b><br>";
   $controlHTML .=  showMultiList2($listobject,'show_actiontypes', 'vwuds_action', 'abbrev', 'action_text', $show_actiontypes, '', 'action_text', $debug, 2, 1, 0);
   $controlHTML .= "<br><table><tr>";
   $controlHTML .= "<td colspan=2><b> Show Selected Source Types/Subtypes:</b></td>";
   $controlHTML .= "</tr><tr>";
   $controlHTML .=  "<td>" . showMultiList2($listobject,'show_sourcetypes', 'watersourcetype', 'wsabbrev', 'wsname', $show_sourcetypes, '', 'wsname', $debug, 2, 1, 0) . "</td>";
   $controlHTML .=  "<td>" . showMultiList2($listobject, 'show_sourcesubtypes', 'vwuds_source_subtype', 'abbrev', 'typename', $show_sourcesubtypes, '', 'typename', $debug, 2, 1, 0) . "</td>";
   $controlHTML .= "</tr></table>";
   $controlHTML .= "<br><b> Show Selected Use Types:</b><br>";
   $controlHTML .=  showMultiList2($listobject,'show_usetypes', 'waterusetype', 'typeabbrev', 'typename', $show_usetypes, '', 'typename', $debug, 2, 1, 0);
   $controlHTML .= "</td>";
   $controlHTML .= "</tr>";
   $controlHTML .= "<tr>";
   $controlHTML .= "<td colspan=2 align=center>";
   $controlHTML .= showRadioButton('search_view', 'list', $search_view, '', 1, 0) . ' List View';
   $controlHTML .= showRadioButton('search_view', 'detail', $search_view, '', 1, 0) . ' Detail View';
   $controlHTML .= showRadioButton('search_view', 'edit', $search_view, '', 1, 0) . ' Edit View';
   $controlHTML .= showRadioButton('search_view', 'file', $search_view, '', 1, 0) . ' Output to File';
   $controlHTML .= "</td>";
   $controlHTML .= "</tr>";
   $controlHTML .= "</table>";
   $controlHTML  .= showGenericButton('search','Search', "document.forms[\"control\"].elements.searchtype.value=\"search\"; xajax_showMeasuringPointForm(xajax.getFormValues(\"control\")); show_next(\"mp_data0\", \"mp_0\", \"mp\"); ", 1, $pd);

   $searchResult['formHTML'] = $controlHTML;
   $searchResult['search_view'] = $search_view;

   return $searchResult;
}


function annualReportingForm($formValues) {
   global $listobject, $userid, $adminsetuparray;

   $controlHTML = '';
   // set default year
   $current_year = date('Y');
   $current_month = date('n');
   if ($current_month >= 6) {
      $default_year = $current_year;
   } else {
      $default_year = $current_year - 1;
   }
   if (isset($formValues['thisyear'])) {
      $thisyear = $formValues['thisyear'];
   } else {
      $thisyear = $default_year;
   }
   if (isset($formValues['progressreport'])) {
      $progressreport = $formValues['progressreport'];
   } else {
      $progressreport = 0;
   }
   if (isset($formValues['user_primary'])) {
      $user_primary = $formValues['user_primary'];
   }
   if (isset($formValues['user_secondary'])) {
      $user_secondary = $formValues['user_secondary'];
   }
   if (isset($formValues['planner'])) {
      $planner = $formValues['planner'];
   }
   if (isset($formValues['other'])) {
      $other = $formValues['other'];
   }
   if (isset($formValues['other_userid'])) {
      $other_userid = $formValues['other_userid'];
   }

   if (isset($formValues['fac_userid'])) {
      $fac_userid = $formValues['fac_userid'][0];
   } else {
      $fac_userid = array();
   }
   if (isset($formValues['mailordownload'])) {
      $mailordownload = $formValues['mailordownload'];
   } else {
      $mailordownload = 'downloadhtml';
   }
   switch ($mailordownload) {
      case 'email':
         $send_option_where = " ( ( subyra > $thisyear) or ( subyra is null) ) ";
         $send_option_where .= " AND ( ( bad_email is null ) OR ( bad_email = 0 ) ) ";
         $send_option_where .= " AND email is not null ";
         $send_option_where .= " AND email <> '' ";
      break;
      
      default:
         $send_option_where = " ( ( subyra > $thisyear) or ( subyra is null) ) ";
         $send_option_where .= " AND ( ( email is null ) OR ( bad_email = 1 ) OR ( email = '' ) ) ";
      break;
   }
   #error_reporting(E_ALL);
   if (isset($formValues['auditdate'])) {
      $auditdate = $formValues['auditdate'];
   } else {
      $auditdate = 'all';
   }
   
   if ($auditdate <> 'all') {
      switch ($auditdate) {
         case 'include':
            $audop = 'in';
         break;
         
         case 'exclude':
            $audop = 'not in';
         break;
         
         default:
            $audop = 'not in';
         break;
      }
      if (isset($formValues['datesent'])) {
         $datesent = $formValues['datesent'][0];
         if (count($datesent) > 0) {
            $thesedates = "'" . join("','", $datesent) . "'";
            $datewhere = " userid $audop (select userid from edwrd_audit where date_trunc('day', datesent) in ($thesedates))";
         } else {
            $datewhere = " ( 1 = 1 ) ";
         }
      } else {
         $datesent = '';
         $datewhere = " ( 1 = 1 ) ";
      }
   } else {
      $datewhere = " ( 1 = 1 ) ";
   }


   $controlHTML .= "<form method=post action='' id=control>";
   $controlHTML .= "<b>Select Facility(s):</b><br>";
   ############################################################
   ###                        SEARCH FORM                   ###
   ############################################################
   $tablename = 'facilities';
   $aset = $adminsetuparray[$tablename];
   unset($aset['search info']['columns']['email']);
   unset($aset['search info']['columns']['subyra']);
   unset($aset['search info']['columns']['bad_email']);
   # call the search form routine.   This will take all of the variables that come in the search and interpret them,
   # returning the record of interest
   $searchobject = new listObjectSearchForm;
   $searchobject->listobject = $listobject;
   $searchobject->debug = FALSE;
   $searchobject->insertOK = 0;
   $searchobject->deleteOK = 0;
   $searchobject->adminsetup = $aset;
   $searchobject->readonly = 1;
   $searchobject->record_submit_script = '';
   $searchobject->search_submit_script = "xajax_showAnnualReportingForm(xajax.getFormValues(\"control\"));  ";
   $searchobject->page_submit_script = "";
   $controlHTML .= "<a class=\"mH\"";
   $controlHTML .= "onclick=\"toggleMenu('$divname" . "_search')\">+ Show/Hide Advanced Search Form</a>";
   $controlHTML .= "<div id=\"$divname" . "_search\" class=\"mL\"><ul>";
   # display the search form
   $searchForm = $searchobject->showSearchForm($formValues);
   $controlHTML .= $searchForm['formHTML'];
   $controlHTML .= "</div><br>";
   $subquery = "( select userid, ownname, facility, system, email, bad_email, subyra from (" . $searchForm['query'] . " ) as foo ) as bar ";
   $controlHTML .= $subquery . " ;<br>";
   $controlHTML .= "<br>";   
   
   $controlHTML .= "<b>Additional Search Options:</b> <ul>";
   $datesentfoo = "(select date_trunc('day', datesent) as sentdate from edwrd_audit group by sentdate ) as foo";
   $controlHTML .= "<li>" . showList($listobject,'auditdate',array(0=>array('auditdate'=>'include','auditlabel'=>'Include'),1=>array('auditdate'=>'exclude','auditlabel'=>'Exclude'),2=>array('auditdate'=>'all','auditlabel'=>'N/A')),'auditlabel', 'auditdate','',$auditdate,0, 1, 0);
   $controlHTML .= " Facilities which were emailed on the following dates: <br>" . showMultiList2($listobject, 'datesent', $datesentfoo, 'sentdate', 'sentdate', $datesent, '', 'sentdate', $debug, 5, 1, 0);
   $controlHTML .= "</ul>";
   
   $controlHTML .= "<b>Select Output Options:</b> <ul>";
   $controlHTML .= "<li>" . showList($listobject,'mailordownload',array(0=>array('mailordownload'=>'email','mdlabel'=>'Outlook Mail Merge File'),3=>array('mailordownload'=>'downloadhtmlgroup','mdlabel'=>'Download and Print - Grouped by Mailing Address')),'mdlabel', 'mailordownload','',$mailordownload,0, 1, 0) . " Reports";
   $controlHTML .= "</ul>";
   $controlHTML .= showGenericButton('search','Search', "xajax_showAnnualReportingForm(xajax.getFormValues(\"control\")); ", 1, $pd);
   $controlHTML .= "<hr>";

   ############################################################
   ###                    END SEARCH FORM                   ###
   ############################################################
   $controlHTML .= "<b>Select Facilities:</b><br>";
   # old facility where clause
   #$facwhere = "userid in (select \"USERID\" from annual_data where \"YEAR\" = $thisyear group by \"USERID\") ";
   $facwhere = "( (subyra is null) or (subyra > $thisyear) ) ";
   $facwhere .= " and userid in (select \"USERID\" from annual_data where \"YEAR\" = '$thisyear' group by \"USERID\") ";
   $facwhere .= " AND $datewhere ";
   $facwhere .= " AND $send_option_where ";
   //$controlHTML .= "$facwhere<br>";
   $listobject->querystring = "  select count(*) as numfacs ";
   $listobject->querystring .= " from $subquery ";
   $listobject->querystring .= " where $facwhere ";
   $listobject->performQuery();
   $numfacs = $listobject->getRecordValue(1,'numfacs');
   //$controlHTML .= "$listobject->querystring ; <br>";
   $controlHTML .= "<br>$numfacs Facilities Selected <br>";
   $controlHTML .= showMultiList2($listobject, 'fac_userid', $subquery, 'userid', 'ownname, facility, system', $fac_userid, $facwhere, 'ownname, facility, system', 0, 8, 1, 0);
   $yrfoo = "(select \"YEAR\" as thisyear from annual_data where \"YEAR\" is not null group by thisyear ) as foo";
   $controlHTML .= "<br><b>Select the year to send: </b>" . showList($listobject,'thisyear',$yrfoo, 'thisyear','thisyear','',$thisyear,0, 1, 0) . "<br>";
   $controlHTML .= "<b>Select Recipient(s):</b><br>";
   $controlHTML .= "<ul>";
   # currently the select boxes for facility contacts will be disabled - until we go live!
   $controlHTML .= "<li>" . showCheckBox('user_primary','user_primary',$user_primary, '', 1, 0) . "Facility Primary Contact</li>";
   $controlHTML .= "<li>" . showCheckBox('user_secondary','user_secondary',$user_secondary, '', 1, 0) . "Facility Secondary Contact</li>";
   $controlHTML .= "<li>" . showCheckBox('planner','planner',$planner, '', 1) . "Regional Planner</li>";
   $controlHTML .= "<li>" . showCheckBox('other','other',$other, '', 1);
   $controlHTML .= "Other EDWrD User ";
   $controlHTML .= showList($listobject,'other_userid','users', 'lastname,firstname','userid','userid in (select userid from mapusergroups where groupid in (3,4))',$other_userid,0, 1, 0);
   $controlHTML .= "</li>";
   $controlHTML .= "</ul>";
   $controlHTML  .= showGenericButton('sendmail','Print/Send Reporting Form', "xajax_showAnnualReportingFormResult(xajax.getFormValues(\"control\")); ", 1, 0);
   $controlHTML .= "</form>";

   return $controlHTML;
}

function annualReportingFormResult($formValues) {
   global $listobject, $userid, $adminsetuparray, $outdir_nodrive, $basedir, $outdir, $outurl;

   $controlHTML = '';
   $edwrduserid = $userid;
   
   if (substr_count( $basedir, 'vwudsdev') > 0) {
      $debug = 1;
   }

   $controlHTML .= $basedir . "<br>";
   //$controlHTML .= print_r($formValues,1) . '<br>';
   $controlHTML .= "<i>Handling Annual Reporting Form Request.</i><br>";

   if (isset($formValues['thisyear'])) {
      $thisyear = $formValues['thisyear'];
   } else {
      $thisyear = 2009;
   }
   if (isset($formValues['progressreport'])) {
      $progressreport = $formValues['progressreport'];
   } else {
      $progressreport = 0;
   }

   # check box to decide if sending to facility user, planner, or both
   $recip_type = array();
   if (isset($formValues['user_primary'])) {
      array_push($recip_type, $formValues['user_primary']);
   }
   if (isset($formValues['user_secondary'])) {
      array_push($recip_type, $formValues['user_secondary']);
   }
   if (isset($formValues['planner'])) {
      array_push($recip_type, $formValues['planner']);
   }
   if (isset($formValues['other'])) {
      array_push($recip_type, $formValues['other']);
   }
   if (isset($formValues['mailordownload'])) {
      $mailordownload = $formValues['mailordownload'];
   } else {
      $mailordownload = 'downloadhtml';
   }


   $error = 0;

   if (isset($formValues['fac_userid'])) {
      $fac_userid = $formValues['fac_userid'][0];
   } else {
      $errorMSG .= "<b>Error:</b> You must select a recipient facility.";
      $error = 1;
   }
   #error_reporting(E_ALL);
   
   // group by entities

   $reportdoc = '';
   $sic_file = "./mailform/siccodes.xls";

   # Inputs:
      # year - the year for the reporting data
      #

   # query the facilities table for facility info
   # add this to $reportdoc
   # query all related MP data:
      # match up every MP record corresponding to that facility for the calendar year indicated
      # order by the action - WD, SD, SL
   $projectid = $formValues['projectid'];
   $recipient = $formValues['recipient'];
   $planner_recipient = $formValues['planner_recipient'];

   #$debug = 1;
   if ($startyear == '') { $startyear = Date('Y'); }
   if ($endyear == '') { $endyear = Date('Y'); }
   #print_r($allsegs);

   # create repository for summary records in the even that we chose to send a summary of emailed records to the planners
   $summary = array();

   
   $controlHTML .= "<i>Gathering File Templates.</i>";
   # filenum is cleared for uniqueness, go ahead
   array_push($used, $filenum);
   // create a single file for the batch download, set it to zero length
   $multifilename = $outdir . "/wateruse$thisyear" . "_merged$filenum" . ".htm";
   $batchfilename = $outdir . "/wateruse$thisyear" . "_batch$filenum" . ".htm";
   #$multifilename = str_replace("/", "\\", $basedir . './dirs/proj/out/blankrecords$thisyear" . "_1244.htm');
   $batchdownload = $outurl . "/wateruse$thisyear" . "_batch$filenum" . ".htm";
   
   $controlHTML .= "<i>Opening Files.</i>";
   $fp = fopen($multifilename, 'w');
   fclose($fp);
   $fp = fopen($batchfilename, 'w');
   fclose($fp);
   $controlHTML .= "<i>Files opened.</i><br>";
   
   // create an array to house the mailing addresses
   $addressfilename = "wateruse$thisyear" . "_labels$filenum" . ".xls";
   $alladdressfilename = "wateruse$thisyear" . "_batch$filenum" . ".xls";
   $addressfiledl = "./dirs/proj/out/wateruse$thisyear" . "_labels$filenum" . ".xls";
   $alladdressfiledl = "./dirs/proj/out/wateruse$thisyear" . "_batch$filenum" . ".xls";
   $mailaddresses = array();
   $alladdresses = array();
   #$mailaddresses[0] = array('name','title','mailadd1','mailadd2','mailcity','mailst','mailzip');
   # how many records can we store in a single file????
   $maxperfile = 400000; # max bytes in a file before we write it to a word document
   $j = 0; # keep track of how many we are putting out for formatting purposes
   $controlHTML .= "<i>Iterating through facility records.</i><br>";
   foreach ($fac_userid as $facid) {
      
      $msg_string = file_get_contents("./mailform/msg_text.txt");
      # get the planners name from the database by linking to the ownerid from the facilities record
      $listobject->querystring = "  select a.userid, a.firstname || ' ' || a.lastname as sender, a.email as replyto, ";
      $listobject->querystring .= " a.phone as contactphone, a.address1, a.address2, a.city, a.state, a.zip, b.ownerid ";
      $listobject->querystring .= " from users as a, facilities as b ";
      $listobject->querystring .= " where b.userid = '$facid' ";
      $listobject->querystring .= "    AND a.userid = b.ownerid ";
      $listobject->querystring .= " GROUP BY a.userid, sender, a.email, b.ownerid, a.phone, a.address1, a.address2, a.city, a.state, a.zip ";
      if ($debug) {
         $controlHTML .= $listobject->querystring . " ; <br>";
      }
      $listobject->performQuery();
      $headerdata = $listobject->queryrecords;
      $sendname = $listobject->getRecordValue(1,'sender');
      $replyto = $listobject->getRecordValue(1,'replyto');
      $plannerid = $listobject->getRecordValue(1,'userid');
      # being to set up summary data)
      if (!isset($summary[$plannerid])) {
         $summary[$plannerid] = array();
      }
      
      $controlHTML .= "Sender name: $sendname <br>";
      $controlHTML .= "Reply-to Address: $replyto <br>";
      # get the appropriate facility
      $listobject->querystring = "select * from facilities where userid = '$facid'";
      if ($debug) {
         $controlHTML .= $listobject->querystring . ";<br>";
      }
      $listobject->performQuery();
      $theserecs = $listobject->queryrecords;
      $facrec = $theserecs[0];
      $ownername = $facrec['ownname'];
      $facname = $facrec['facility'];
      $systemname = $facrec['system'];
         
      # stash the mailing address in an array
      array_push($mailaddresses, 
         array(
            'ownname'=>$facrec['ownname'], 
            'facility'=>$facrec['facility'], 
            'system'=>$facrec['system'], 
            'name'=>$facrec['name'], 
            'title'=>$facrec['title'], 
            'mailadd1'=>$facrec['mailadd1'], 
            'mailadd2'=>$facrec['mailadd2'], 
            'mailcity'=>$facrec['mailcity'], 
            'mailst'=>$facrec['mailst'], 
            'mailzip'=>$facrec['mailzip']
         )
      );
      # Also stash the mailing address in an array that will contain all, not paginated
      array_push($alladdresses, 
         array(
            'ownname'=>$facrec['ownname'], 
            'facility'=>$facrec['facility'], 
            'system'=>$facrec['system'], 
            'name'=>$facrec['name'], 
            'title'=>$facrec['title'], 
            'mailadd1'=>$facrec['mailadd1'], 
            'mailadd2'=>$facrec['mailadd2'], 
            'mailcity'=>$facrec['mailcity'], 
            'mailst'=>$facrec['mailst'], 
            'mailzip'=>$facrec['mailzip']
         )
      );
      # build recipient list
      foreach ($recip_type as $thistype) {
         if (!isset($summary[$plannerid][$facid])) {
            $summary[$plannerid][$facid] = array('sentto'=>'', 'msg'=>"$ownername, $facname, $systemname", 'numrecs'=>0);
         }
         //$controlHTML .= "$thistype recipient requested.<br>";
         switch ($thistype) {
            case 'user_primary':
               $thisrecip = $facrec['email'];
            break;

            case 'user_secondary':
               $thisrecip = $facrec['email2'];
            break;

            case 'planner':
               # since the planner is the record owner, we have already retrieved this one
               $thisrecip = $replyto;
            break;

            case 'other':
               $other_userid = '';
               if (isset($formValues['other_userid'])) {
                  $other_userid = $formValues['other_userid'];
               } else {
                  $errorMSG .= "<b>Error:</b> You must select a user when specifying 'Other EDWrD User'.";
                  $error = 1;
               }
               if ($other_userid <> '') {
                  $listobject->querystring = "select email from users where userid = $other_userid";
                  if ($debug) {
                     $controlHTML .= $listobject->querystring . ' ; <br>';
                  }
                  $listobject->performQuery();
                  $other_email = $listobject->getRecordValue(1,'email');
               } else {
                  $errorMSG .= "<b>Error:</b> You must select a user when specifying 'Other EDWrD User'.";
                  $error = 1;
               }
               $thisrecip = $other_email;
            break;
         }
         if (strlen($thisrecip) > 0) {
            //$controlHTML .= "Sending a copy to $thisrecip. <br>";
         } else {
            $errorMSG .= "<b>Error:</b> Selected recipient '$thistype' does not have a valid email address.";
            $error = 1;
         }

         $summary[$plannerid][$facid]['sentto'] .= " " . $thisrecip;
      }

      if ($error == 0) {
         # IF everything is OK, we go ahead and assemble the email attachment, and send the message
         # choose the header based on the method, since something in the "protect" command causes Word
         # to crash if you open more than 2 documents simultaneously.
         switch ($mailordownload) {
            case 'email':
               $header = file_get_contents("./mailform/edwrd_header_mail.html");
            break;

            case 'downloadhtml':
               $header = file_get_contents("./mailform/edwrd_header_print.html");
            break;
         }
         # now load the intro text
         $introtemplate = file_get_contents("./mailform/edwrd_intro.html");
         $aset = $adminsetuparray['plannercontact'];
         $intro = showCustomHTMLForm($listobject,$headerdata[0],$aset, $introtemplate, $ismulti, -1, 0);
         #$controlHTML .= "Header info<hr>" . $header . "<hr>";
         $footer = file_get_contents("./mailform/edwrd_footer.html");
         $content = file_get_contents("./mailform/edwrd_facility.html");
         $aset = $adminsetuparray['facilities'];
         $mindex = 0;
         $ismulti = 1;
         $facility = "<br clear=all style='mso-special-character:line-break; page-break-before:always'>";
         $facility .= showCustomHTMLForm($listobject,$facrec,$aset, $content, $ismulti, $mindex, 0);
         $mindex++;

         $content = file_get_contents("./mailform/edwrd_mpannual.html");
         $listobject->querystring = "select * from vwuds_annual_mp_data where \"USERID\" = '$facid' and \"YEAR\" = '$thisyear' ";
         if ($debug) {
            $controlHTML .= $listobject->querystring . " ; <br>";
         }
         $listobject->performQuery();
         $theserecs = $listobject->queryrecords;
         #print_r($theserecs);
         $aset = $adminsetuparray['annual_data'];
         # set fields that are read-only in EDWrD view for annual data to RW for the external form
         $ro_2_rw = array('lat_flt','lon_flt','stcofips','SOURCE','abandoned','CAT_MP','ACTION','GWPERMIT', 'VPDES', 'VDH_NUM','VWP_PERMIT', 'WELLNO', 'DEQ_WELL', 'SIC_MP');
         foreach ($ro_2_rw as $rocol) {
            $aset['column info'][$rocol]['readonly'] = 0;
         }
         $aset['column info']['USERID']['readonly'] = 1;
         $aset['column info']['USERID']['type'] = 1;
         $aset['column info']['SIC_MP']['type'] = 1;
         $annual = '';
         $numr = count($theserecs);
         $summary[$plannerid][$facid]['numrecs'] = $numr;
         foreach ($theserecs as $thisrec) {
            $annual .= "<br clear=all style='mso-special-character:line-break; page-break-before:always'>";
            $annual .= showCustomHTMLForm($listobject,$thisrec,$aset, $content, $ismulti, $mindex, 0);
            $mindex++;
            if ($debug) {
               $controlHTML .= print_r($thisrec,1) . "<br>";
            }
         }


         $outHTML = $header;
         $outHTML .= $intro;
         $outHTML .= "<form method=post action='http://$mapservip/html/whodev/test/formtest.php'>";
         $outHTML .= $facility;
         $outHTML .= $annual;
         # don't show the submit button, we will add this later when we receive the form back from the end user.
         # this should eliminate confusion on the end users part, in case they think that the 'submit' button
         # actually works!!
         #$outHTML .= showSubmitButton('submit','submit', '', 1, 0);
         $outHTML .= "</form>";
         $outHTML .= $footer;
         # END - create attachment text

         # save text as HTML first, then open in word, and save as a .doc
         $filename = str_replace("/", "\\", $basedir . "out/wateruse$thisyear" . "_$facid" . ".htm");
         #$controlHTML .= "Output directory defined as " . $basedir . "<br>";
         #$controlHTML .= "Output file defined as " . $filename . "<br>";

         $fp = fopen($filename, 'w');
         fwrite($fp, $outHTML);
         fclose($fp);

         switch ($mailordownload) {
            case 'email':

            break;
            
            case 'downloadhtml':
               $mailHTML = '';
               if ($j == 0) {
                  # first time, so we put in the header info, otherwise, we just do the text
                  $mailHTML = $header;
               } else {
                  $mailHTML = "<br clear=all style='mso-special-character:line-break; page-break-before:always'>";
               }
               $mailHTML .= $intro;
               $mailHTML .= "<form method=post action='http://$mapservip/html/whodev/test/formtest.php' id=form$j>";
               $mailHTML .= $facility;
               $mailHTML .= $annual;
               # don't show the submit button, we will add this later when we receive the form back from the end user.
               # this should eliminate confusion on the end users part, in case they think that the 'submit' button
               # actually works!!
               #$outHTML .= showSubmitButton('submit','submit', '', 1, 0);
               $mailHTML .= "</form>";

               # need to stash this in a batch of files
               //$controlHTML .= "Adding $facid to batch document, length: " . strlen($outHTML) . " characters.<br>";
               $fp = fopen($batchfilename, 'a');
               fwrite($fp, $mailHTML);
               fclose($fp);
               
            break;
            
         }

         # now, create a blank record form in case these users have new measuring points to report on
         # save text as HTML first, then open in word, and save as a .doc
         $blankfilename = str_replace("/", "\\", $basedir . "out/blankrecords$thisyear" . "_$facid" . ".htm");
         #$controlHTML .= "Output directory defined as " . $basedir . "<br>";
         #$controlHTML .= "Output file defined as " . $filename . "<br>";
         $blankhead = file_get_contents("./mailform/edwrd_blankheader_mail.html");
         $blankform = "<br clear=all style='mso-special-character:line-break; page-break-before:always'>";
         $blankform .= "<form method=post action='http://$mapservip/html/whodev/test/formtest.php'>";
         
         $blankfields = $listobject->getColumns('vwuds_annual_mp_data');
         $aset = $adminsetuparray['annual_data'];
         # set fields that are read-only in EDWrD view for annual data to RW for the external form
         $ro_2_rw = array('lat_flt','lon_flt','stcofips','SOURCE','abandoned','CAT_MP','ACTION','GWPERMIT', 'VPDES', 'VDH_NUM','VWP_PERMIT', 'WELLNO', 'DEQ_WELL', 'TYPE', 'SUBTYPE', 'SIC_MP');
         foreach ($ro_2_rw as $rocol) {
            $aset['column info'][$rocol]['readonly'] = 0;
         }
         $aset['column info']['USERID']['readonly'] = 1;
         $aset['column info']['USERID']['type'] = 1;
         $aset['column info']['SIC_MP']['type'] = 1;
         foreach ($blankfields as $thisfield) {
            if ($aset['column info'][$thisfield]['visible'] == 1) {
               $blankrec[$thisfield] = '';
            }
         }
         $blankrecords = '';
         $content = file_get_contents("./mailform/edwrd_mpannual_blank.html");
         $blankrec['USERID'] = $facid;
         $blankrec['ownname'] = $ownername;
         $blankrec['facility'] = $facname;
         $blankrec['system'] = $systemname;
         for ($i = -1; $i >= -2; $i--) {
            if ($i < -1) {
               $blankrecords .= "<br clear=all style='mso-special-character:line-break; page-break-before:always'>";
            }
            $blankrecords .= showCustomHTMLForm($listobject,$blankrec,$aset, $content, $ismulti, $i, 0);
         }
         $blankHTML = '';
         $blankHTML .= $blankhead;
         $blankHTML .= $blankform;
         $blankHTML .= $blankrecords;
         $blankHTML .= "</form>";
         $blankHTML .= "</body></html>";
         
         $fp = fopen($blankfilename, 'w');
         fwrite($fp, $blankHTML);
         fclose($fp);


         switch ($mailordownload) {
            case 'email':
            
            break;

            case 'downloadhtml':
               # need to stash this in a batch of files
               
               $fp = fopen($batchfilename, 'a');
               $mailHTML = '';
               $mailHTML .= $blankform;
               $mailHTML .= $blankrecords;
               $mailHTML .= "</form>";
               fwrite($fp, $mailHTML);
               fclose($fp);

              // ----- Adding more files
              #$tar_object->add($new_filename);
           break;
        }

      }
      $j++;
      
   }
   $controlHTML .= "<i><b>Finished Generating Annual Reporting Forms - $j facility records created.</b></i>";
   switch ($mailordownload) {
      case 'downloadhtml':
      # need to finish off the document with the final HTML stuff

      $mailHTML = $footer;
      $fp = fopen($batchfilename, 'a');
      fwrite($fp, $mailHTML);
      fclose($fp);
      $controlHTML .= "<hr><a href='$batchdownload' target=_new>Click Here to Display all Printable Forms as a single HTML document</a>";
      putExcelFile("$outdir_nodrive/$alladdressfilename", $alladdresses);
      $controlHTML .= " - <a href='$alladdressfiledl' target=_new>Spreadsheet File of Mailing Addresses.</a>";
      break;
      
      case 'email':
      $controlHTML .= "<hr><a href='$mailmerge_template' target=_new>Click Here to Download the Mail Merge Email Template</a>";
      putExcelFile("$outdir_nodrive/$alladdressfilename", $mailmerge_addresses);
      $controlHTML .= " - <a href='$alladdressfiledl' target=_new>Mail Merge Spreadsheet.</a>";
      break;

   }

   if ( ($progressreport == 1) and ($mailordownload == 'email')) {
      foreach ($summary as $pid => $sum) {
         // may keep this code here, as we could use regular Unix mail to send a progress report to the planners.
         /*
         $mail = new phpMailer();
         $mail->SMTPDebug = 0;
         $mail->IsSMTP();
         $mail->Host = '172.16.1.68';
         #$mail->Protocol = 'ssl';
         #$mail->Host = "DEQEX01.deq.local";
         $mail->Port = 827;
         #$mail->SMTPAuth = true;
         $mail->Username = 'rwburgholzer';
         $mail->Mailer = 'smtp';
         # later we will set this to be the planner of interest, or the EDWrD administrator
         $mail->From = 'rwburgholzer@deq.virginia.gov';
         $mail->FromName = 'Robert Burgholzer';
         $mail->AddReplyTo($mail->From, $mail->FromName);
         $listobject->querystring = " select email from users where userid = $pid ";
         if ($debug) {
            $controlHTML .= $listobject->querystring . " ; <br>";
         }
         $listobject->performQuery();
         $plannermail = $listobject->getRecordValue(1,'email');
         $mail->AddAddress($plannermail,"Receiver");
         #$mail->AddAddress($mail->From,"Receiver");
         $mail->Subject = 'EDWrD eMail Summary';
         $mail->Body = "The following facilities have been contacted on your behalf:\n";
         foreach ($sum as $thisrec) {
            $mail->Body .= $thisrec['numrecs'] . " record(s) for " . $thisrec['msg'] . " sent to: " . $thisrec['sentto'] ."\n\n";
         }
         if ($debug) {
            $controlHTML .= $mail->Body . " ; <br>";
            $controlHTML .= print_r($sum,1) . " ; <br>";
         }

         if(!$mail->Send()) {
            $controlHTML .= "<p>Progress report was not sent </p>";
            $controlHTML .= "Mailer Error: " . $mail->ErrorInfo;
            #$controlHTML .= "We WOULD have sent: <hr>" . $outHTML;
         } else {
            $controlHTML .= "Progress report sent.";
         }
         */
      }
   }

   $controlHTML .= "<div id=errorinfo class='errorInfo'>" . $errorMSG . "</div>";


   return $controlHTML;

}



function annualReportingFormResult2($formValues) {
   global $listobject, $userid, $adminsetuparray, $outdir_nodrive, $basedir, $outdir, $outurl;

   $controlHTML = '';
   $edwrduserid = $userid;
   $enable_vwp = 0; // whether to include the VWP information.
   $num_histyears = 2; // number of previous years data to show

   #$controlHTML .= print_r($formValues,1) . '<br>';
   
   if (substr_count( $basedir, 'vwudsdev') > 0) {
      $debug = 1;
   }
   $controlHTML .= "<i>Handling Annual Reporting Form Request.</i><br>";
   
   // set default year
   $current_year = date('Y');
   $current_month = date('n');
   if ($current_month >= 6) {
      $default_year = $current_year;
   } else {
      $default_year = $current_year - 1;
   }
   if (isset($formValues['thisyear'])) {
      $thisyear = $formValues['thisyear'];
   } else {
      $thisyear = $default_year;
   }
   $controlHTML .= "Setting years: $current_year $current_month $default_year $thisyear <br>";
   
   if (isset($formValues['progressreport'])) {
      $progressreport = $formValues['progressreport'];
   } else {
      $progressreport = 0;
   }

   # check box to decide if sending to facility user, planner, or both
   $recip_type = array();
   if (isset($formValues['user_primary'])) {
      array_push($recip_type, $formValues['user_primary']);
   }
   if (isset($formValues['user_secondary'])) {
      array_push($recip_type, $formValues['user_secondary']);
   }
   if (isset($formValues['planner'])) {
      array_push($recip_type, $formValues['planner']);
   }
   if (isset($formValues['other'])) {
      array_push($recip_type, $formValues['other']);
   }
   if (isset($formValues['mailordownload'])) {
      $mailordownload = $formValues['mailordownload'];
   } else {
      $mailordownload = 'downloadhtml';
   }


   $error = 0;

   if (isset($formValues['fac_userid'])) {
      $fac_userid = $formValues['fac_userid'][0];
   } else {
      $errorMSG .= "<b>Error:</b> You must select a recipient facility.";
      $error = 1;
   }
   #error_reporting(E_ALL);
   
   // group by entities

   $reportdoc = '';
   $sic_file = "./mailform/siccodes.xls";

   # Inputs:
      # year - the year for the reporting data
      #

   # query the facilities table for facility info
   # add this to $reportdoc
   # query all related MP data:
      # match up every MP record corresponding to that facility for the calendar year indicated
      # order by the action - WD, SD, SL
   $projectid = $formValues['projectid'];
   $recipient = $formValues['recipient'];
   $planner_recipient = $formValues['planner_recipient'];

   #$debug = 1;
   if ($startyear == '') { $startyear = Date('Y'); }
   if ($endyear == '') { $endyear = Date('Y'); }
   #print_r($allsegs);

   # create repository for summary records in the even that we chose to send a summary of emailed records to the planners
   $summary = array();

   
   $controlHTML .= "<i>Gathering File Templates.</i>";
   # filenum by userid creates cacheing problems
   //$filenum = $userid;
   # filenum is cleared for uniqueness, go ahead
   $filenum = "$userid" . rand(1000,9999);
   array_push($used, $filenum);
   // create a single file for the batch download, set it to zero length
   $multifilename = $outdir . "/wateruse$thisyear" . "_merged$filenum" . ".htm";
   $batchfilename = $outdir . "/wateruse$thisyear" . "_batch$filenum" . ".htm";
   #$multifilename = str_replace("/", "\\", $basedir . './dirs/proj/out/blankrecords$thisyear" . "_1244.htm');
   $batchdownload = $outurl . "/wateruse$thisyear" . "_batch$filenum" . ".htm";
   
   $controlHTML .= "<i>Opening Files.</i>";
   $fp = fopen($multifilename, 'w');
   fclose($fp);
   $fp = fopen($batchfilename, 'w');
   fclose($fp);
   $controlHTML .= "<i>Files opened.</i><br>";
   
   // create an array to house the mailing addresses
   $addressfilename = "wateruse$thisyear" . "_labels$filenum" . ".xls";
   $alladdressfilename = "wateruse$thisyear" . "_batch$filenum" . ".xls";
   $addressfiledl = "./dirs/proj/out/wateruse$thisyear" . "_labels$filenum" . ".xls";
   $alladdressfiledl = "./dirs/proj/out/wateruse$thisyear" . "_batch$filenum" . ".xls";
   // mail merge files
   $mailmerge_filename = "merge$filenum" . ".xls";
   $mailmerge_filedl = "./dirs/proj/out/merge$filenum" . ".xls";
   $mailmerge_template = "./forms/e-blast_mail2010.doc";
   $mailaddresses = array();
   $alladdresses = array();
   $mailmerge_addresses = array();
   $entity_count = array();
   $entity_recips = array();
   #$mailaddresses[0] = array('name','title','mailadd1','mailadd2','mailcity','mailst','mailzip');
   # how many records can we store in a single file????
   $maxperfile = 400000; # max bytes in a file before we write it to a word document
   $j = 0; # keep track of how many we are putting out for formatting purposes
   $controlHTML .= "<i>Iterating through facility records.</i><br>";
   // get an aggreagate query that links facilityid, entity and recipients all in one batch
   // if this is an email, we only need to get one facility ID, so we grab the min(userid) for that one,
   // since no facility specific information will be sent to the users (or will it?)
   $faclist = '';
   $facdel = '';
   foreach ($fac_userid as $facid) {
      $faclist .= $facdel . "'$facid'";
      $facdel = ',';
   }
   
   $listobject->querystring = "  select a.userid as facility_id, a.entity_id, b.facility_count, b.facnames ";
   $listobject->querystring .= " from facilities as a, ( ";
   $listobject->querystring .= "    select entity_id, concatenate(' - ' || facility) as facnames, count(*) as facility_count ";
   $listobject->querystring .= "    from facilities";
   $listobject->querystring .= "    where userid in ($faclist) ";
   $listobject->querystring .= "    group by entity_id ";
   $listobject->querystring .= " ) as b ";
   $listobject->querystring .= " where a.userid in ($faclist) ";
   $listobject->querystring .= "    and b.entity_id = a.entity_id ";
   $listobject->querystring .= " order by a.entity_id ";
   if ($debug) {
      $controlHTML .= $listobject->querystring . " ; <br>";
   }
   
   $listobject->performQuery();
   $fac_entities = $listobject->queryrecords;
   $batch_size = count($fac_entities);
   $entity_batch_size = 0;
   $controlHTML .= "This batch contains $batch_size facility records.<br>";
   foreach ($fac_entities as $this_entity) {
      $facid = $this_entity['facility_id'];
      $entity_id = $this_entity['entity_id'];
      $facnames = $this_entity['facnames'];
      $total_facilities = $this_entity['facility_count'];
      if (!isset($entity_count[$entity_id])) {
         $entity_count[$entity_id] = 1;
         $entity_batch_size++;
      }
      
      $msg_string = file_get_contents("./mailform/msg_text.txt");
      # get the planners name from the database by linking to the ownerid from the facilities record
      $listobject->querystring = "  select a.userid, a.firstname || ' ' || a.lastname as sender, a.email as replyto, ";
      $listobject->querystring .= " a.phone as contactphone, a.address1, a.address2, a.city, a.state, a.zip, b.ownerid ";
      $listobject->querystring .= " from users as a, facilities as b ";
      $listobject->querystring .= " where b.userid = '$facid' ";
      $listobject->querystring .= "    AND a.userid = b.ownerid ";
      $listobject->querystring .= " GROUP BY a.userid, sender, a.email, b.ownerid, a.phone, a.address1, a.address2, a.city, a.state, a.zip ";
      if ($debug) {
         $controlHTML .= $listobject->querystring . " ; <br>";
      }
      $listobject->performQuery();
      $headerdata = $listobject->queryrecords;
      $sendname = $listobject->getRecordValue(1,'sender');
      $planner_phone = $listobject->getRecordValue(1,'contactphone');
      $replyto = $listobject->getRecordValue(1,'replyto');
      $plannerid = $listobject->getRecordValue(1,'userid');
      # being to set up summary data)
      if (!isset($summary[$plannerid])) {
         $summary[$plannerid] = array();
      }
      
      // get entitys login information
      $listobject->querystring = "  select username, userpass ";
      $listobject->querystring .= " from users ";
      $listobject->querystring .= " where userid in (";
      $listobject->querystring .= "    select userid ";
      $listobject->querystring .= "    from vwuds_map_entity_user ";
      $listobject->querystring .= "    where entity_id in (";
      $listobject->querystring .= "       select entity_id ";
      $listobject->querystring .= "       from facilities ";
      $listobject->querystring .= "       where userid in ('$facid')";
      $listobject->querystring .= "    )";
      $listobject->querystring .= " ) ";
      if ($debug) {
         $controlHTML .= $listobject->querystring . " ; <br>";
      }
      //$controlHTML .= print_r($listobject->queryrecords,1) . "<br>";
      $listobject->performQuery();
      $uname = $listobject->getRecordValue(1,'username');
      $upass = $listobject->getRecordValue(1,'userpass');
      $headerdata[0]['username'] = $uname;
      $headerdata[0]['userpass'] = $upass;
      $headerdata[0]['YEAR'] = $thisyear;
      $headerdata[0]['NEXTYEAR'] = $current_year + 1;
      
      //$controlHTML .= "Sender name: $sendname <br>";
      //$controlHTML .= "Reply-to Address: $replyto <br>";
      # get the appropriate facility
      $listobject->querystring = "select * from facilities where userid = '$facid'";
      //if ($debug) {
         $controlHTML .= $listobject->querystring . ";<br>";
      //}
      $listobject->performQuery();
      $theserecs = $listobject->queryrecords;
      $facrec = $theserecs[0];
      $ownername = $facrec['ownname'];
      $facname = $facrec['facility'];
      $systemname = $facrec['system'];
      
      if ($enable_vwp) {
         # get VWP status of all MP's associated with this facility or entity
         $listobject->querystring = "  select permit_exemption from vwuds_measuring_point ";
         if ($mailordownload == 'downloadhtmlgroup') {
            $listobject->querystring .= " where entity_id = $entity_id";
         } else {
            $listobject->querystring .= " where \"USERID\" = '$facid'";
         }
         $listobject->querystring .= " and permit_exemption > 2 ";
         $listobject->querystring .= " group by permit_exemption ";
         if ($debug) {
            $controlHTML .= $listobject->querystring . ";<br>";
         }
         $listobject->performQuery();
         $perecs = $listobject->queryrecords;
         $pes = array();
         foreach ($perecs as $thispe) {
            array_push($pes, $thispe['permit_exemption']);
         }
         $vwp_message = '';
         if (count($pes) > 0) {
            if ( count($pes) > 1 ) {
               $pe_status = 3;
            } else {
               $pe_status = $pes[0];
            }
            if ($pe_status > 2) {
               $listobject->querystring = "  select vwp_text from vwp_exclusion_language where veid = $pe_status ";
               if ($debug) {
                  $controlHTML .= $listobject->querystring . ";<br>";
               }
               $listobject->performQuery();
               $vwp_message = $listobject->getRecordValue(1,'vwp_text');
            }
         }
         $headerdata[0]['vwp_message'] = $vwp_message;
         //$controlHTML .= $vwp_message . "<br>";
      } // END - Enable VWP
      
      # stash the mailing address in an array
      array_push($mailaddresses, 
         array(
            'ownname'=>$facrec['ownname'], 
            'facility'=>$facrec['facility'], 
            'system'=>$facrec['system'], 
            'name'=>$facrec['name'], 
            'title'=>$facrec['title'], 
            'mailadd1'=>$facrec['mailadd1'], 
            'mailadd2'=>$facrec['mailadd2'], 
            'mailcity'=>$facrec['mailcity'], 
            'mailst'=>$facrec['mailst'], 
            'mailzip'=>$facrec['mailzip']
         )
      );
      # Also stash the mailing address in an array that will contain all, not paginated
      # only take the first address if we are grouping by entity group, otherwise add all adresses
      if ( ($entity_count[$entity_id] == 1) or ($mailordownload <> 'downloadhtmlgroup') ) {
         array_push($alladdresses, 
            array(
               'ownname'=>$facrec['ownname'], 
               'facility'=>$facrec['facility'], 
               'system'=>$facrec['system'], 
               'name'=>$facrec['name'], 
               'title'=>$facrec['title'], 
               'mailadd1'=>$facrec['mailadd1'], 
               'mailadd2'=>$facrec['mailadd2'], 
               'mailcity'=>$facrec['mailcity'], 
               'mailst'=>$facrec['mailst'], 
               'mailzip'=>$facrec['mailzip']
            )
         );
      }
      # build recipient list
      foreach ($recip_type as $thistype) {
         if (!isset($summary[$plannerid][$facid])) {
            $summary[$plannerid][$facid] = array('sentto'=>'', 'msg'=>"$ownername, $facname, $systemname", 'numrecs'=>0);
         }
         $controlHTML .= "$thistype recipient requested.<br>";
         switch ($thistype) {
            case 'user_primary':
               $thisrecip = $facrec['email'];
               $thisname = $facrec['name'];
               $listobject->querystring = " select username, userpass from users where lower(ltrim(rtrim(email))) = lower(ltrim(rtrim('$thisrecip')))";
               $listobject->performQuery();
               // if we get a hit here, we will use the users own password, otherwise we default to the facility pass
               // obtained above
               if (count($listobject->queryrecords) > 0) {
                  $thisuname = $listobject->getRecordValue(1,'username');
                  $thisupass = $listobject->getRecordValue(1,'userpass');
               } else {
                  $thisuname = $uname;
                  $thisupass = $upass;
               }
            break;

            case 'user_secondary':
               $thisrecip = $facrec['email2'];
               $thisname = $facrec['name2'];
               $listobject->querystring = " select username, userpass from users where lower(ltrim(rtrim(email))) = lower(ltrim(rtrim('$thisrecip')))";
               $listobject->performQuery();
               $thisuname = $listobject->getRecordValue(1,'username');
               $thisupass = $listobject->getRecordValue(1,'userpass');
            break;

            case 'planner':
               # since the planner is the record owner, we have already retrieved this one
               $thisrecip = $replyto;
               $listobject->querystring = " select firstname, lastname, username, userpass from users where lower(ltrim(rtrim(email))) = lower(ltrim(rtrim('$thisrecip')))";
               $listobject->performQuery();
               $thisuname = $listobject->getRecordValue(1,'username');
               $thisupass = $listobject->getRecordValue(1,'userpass');
            break;


            case 'other':
               $other_userid = '';
               if (isset($formValues['other_userid'])) {
                  $other_userid = $formValues['other_userid'];
               } else {
                  $errorMSG .= "<b>Error:</b> You must select a user when specifying 'Other EDWrD User'.";
                  $error = 1;
               }
               
               if ($other_userid <> '') {
                  $listobject->querystring = "select email, firstname, lastname, username, userpass from users where userid = $other_userid";
                  if ($debug) {
                     $controlHTML .= $listobject->querystring . ' ; <br>';
                  }
                  $listobject->performQuery();
                  $other_email = $listobject->getRecordValue(1,'email');
                  $thisuname = $listobject->getRecordValue(1,'username');
                  $thisname = $listobject->getRecordValue(1,'firstname') . " " . $listobject->getRecordValue(1,'lastname');
                  $thisupass = $listobject->getRecordValue(1,'userpass');
               } else {
                  $errorMSG .= "<b>Error:</b> You must select a user when specifying 'Other EDWrD User'.";
                  $error = 1;
                  $other_email = '';
               }
               $thisrecip = $other_email;
            break;
         }
         if (strlen($thisrecip) > 0) {
            $controlHTML .= "Sending a copy to $thisrecip. <br>";
            $mm = array(
               'email'=>$thisrecip,
               'watertype'=>$usetype,
               'contactname'=>$thisname,
               'username'=>$thisuname,
               'userpass'=>$thisupass,
               /*
               'vwp_text1'=>substr($vwp_message,0,255),
               'vwp_text2'=>substr($vwp_message,255,255),
               'vwp_text3'=>substr($vwp_message,510,255),
               'vwp_text4'=>substr($vwp_message,765,255),
               'vwp_text5'=>substr($vwp_message,1020,255),
               'vwp_text6'=>substr($vwp_message,1275,255),
               */
               'vwp_text'=>$vwp_message,
               'planner_name'=>$sendname,
               'planner_email'=>$replyto,
               'planner_phone'=>$planner_phone,
               'facility_names'=>$facnames
            );
            // if we are doing a mailing, we should track each user for each entity, only sending one per entity per recipient
            if (!isset($entity_recips[$entity_id])) {
               $entity_recips[$entity_id] = array();
            }
            if (!(in_array($thisuname,$entity_recips[$entity_id]))) {
               array_push($entity_recips[$entity_id], $thisuname);
               array_push($mailmerge_addresses, $mm);
            }
               
         } else {
            if ($mailordownload == 'email') {
               $errorMSG .= "<b>Error:</b> Selected recipient '$thistype' does not have a valid email address.";
               $error = 0;
            }
         }

         $summary[$plannerid][$facid]['sentto'] .= " " . $thisrecip;
      }

      if ($error == 0) {
         # IF everything is OK, we go ahead and assemble the email attachment, and send the message
         # choose the header based on the method, since something in the "protect" command causes Word
         # to crash if you open more than 2 documents simultaneously.
         switch ($mailordownload) {
            case 'email':
               $header = file_get_contents("./mailform/edwrd_header_mail.html");
            break;

            case 'downloadhtml':
               $header = file_get_contents("./mailform/edwrd_header_print.html");
            break;

            case 'downloadhtmlgroup':
            $header = file_get_contents("./mailform/edwrd_header_print.html");
            break;
         }
         # now load the intro text
         // since the records are order by entity_id, we check to see if this is the first one for this entity
         // if it IS we include the intro header
         if ( ($entity_count[$entity_id] > 1) and ($mailordownload == 'downloadhtmlgroup')) {
            $introtemplate = '';
         } else {
            //$introtemplate = file_get_contents("./mailform/edwrd_intro.html");
            $introtemplate = file_get_contents("./mailform/edwrd_intro_anyyear.html");
         }
         
         $aset = $adminsetuparray['plannercontact'];
         // enable showing username and userpass
         $aset['column info']['username'] = array("type"=>1,"params"=>"","label"=>"User Name","visible"=>1, "readonly"=>1, "width"=>32, "tab"=>'general_info');
         $aset['column info']['userpass'] = array("type"=>1,"params"=>"","label"=>"User Name","visible"=>1, "readonly"=>1, "width"=>32, "tab"=>'general_info');
         // enabble VWP mesage ig applicable
         $aset['column info']['vwp_message'] = array("type"=>1,"params"=>"","label"=>"VWP Message","visible"=>1, "readonly"=>1, "width"=>32, "tab"=>'general_info');
         $aset['column info']['YEAR'] = array("type"=>1,"params"=>"","label"=>"","visible"=>1, "readonly"=>1, "width"=>6, "tab"=>'general_info');
         $aset['column info']['NEXTYEAR'] = array("type"=>1,"params"=>"","label"=>"","visible"=>1, "readonly"=>1, "width"=>6, "tab"=>'general_info');
         $intro = showCustomHTMLForm($listobject,$headerdata[0],$aset, $introtemplate, $ismulti, -1, 0);
         #$controlHTML .= "Header info<hr>" . $header . "<hr>";
         $footer = file_get_contents("./mailform/edwrd_footer.html");
         $content = file_get_contents("./mailform/edwrd_facility.html");
         $aset = $adminsetuparray['facilities'];
         $mindex = 0;
         $ismulti = 1;
         $facility = "<br clear=all style='mso-special-character:line-break; page-break-before:always'>";
         $facility .= showCustomHTMLForm($listobject,$facrec,$aset, $content, $ismulti, $mindex, 0);
         $mindex++;

         // use this for the old school 2008 mailing version
         //$content = file_get_contents("./mailform/edwrd_mpannual.html");
         // use these next two lines for the new school 2009 mailing version
         $content = file_get_contents("./mailform/edwrd_mpannual_header.html");
         $content .= file_get_contents("./forms/edwrd_mpannual.html");
         $listobject->querystring = "select * from vwuds_annual_mp_data where \"USERID\" = '$facid' and \"YEAR\" = '$thisyear' ";
         if ($debug) {
            $controlHTML .= $listobject->querystring . " ; <br>";
         }
         $listobject->performQuery();
         $theserecs = $listobject->queryrecords;
         #print_r($theserecs);
         $aset = $adminsetuparray['annual_data'];
         # set fields that are read-only in EDWrD view for annual data to RW for the external form
         $ro_2_rw = array('lat_flt','lon_flt','stcofips','SOURCE','abandoned','CAT_MP','ACTION','GWPERMIT', 'VPDES', 'VDH_NUM','VWP_PERMIT', 'WELLNO', 'DEQ_WELL', 'SIC_MP');
         foreach ($ro_2_rw as $rocol) {
            $aset['column info'][$rocol]['readonly'] = 0;
         }
         $aset['column info']['USERID']['readonly'] = 1;
         $aset['column info']['USERID']['type'] = 1;
         $aset['column info']['SIC_MP']['type'] = 1;
         // since this is just for a print-out, we can nake it read-only to avoid scrolling across two pages
         $aset['column info']['OTHERC']['readonly'] = 1;
         $annual = '';
         $numr = count($theserecs);
         $summary[$plannerid][$facid]['numrecs'] = $numr;
         foreach ($theserecs as $thisrec) {
            $adminmod = $aset;
            # set numeric fields that are 0.0 to '' for better print-out
            $num_2_blank = array('JANUARY','FEBRUARY','MARCH','APRIL','MAY','JUNE','JULY','AUGUST', 'SEPTEMBER', 'OCTOBER','NOVEMBER', 'DECEMBER', 'MAXDAY');
            foreach ($num_2_blank as $bcol) {
               $thisrec[$bcol] = '';
            }
            // put in the historical use for this record
            $addrecs = getHistoricMonthly($listobject, $thisrec['MPID'], $thisrec['USERID'], $thisrec['ACTION'], $thisyear, $num_histyears);
            $addyri = 1;
            foreach ($addrecs as $exrec) {
               foreach ($exrec as $colkey => $colval) {
                  switch ($colkey) {
                     case 'YEAR':
                        $colname = "yearminus" . $addyri;
                        $coltemplate = 'YEAR';
                     break;

                     default:
                        $colname = "$colkey" . "minus" . $addyri;
                        $coltemplate = 'JANUARY';
                     break;
                  }
                  $thisrec[$colname] = $colval;
                  $adminmod['column info'][$colname] = $adminmod['column info'][$coltemplate];
                  $adminmod['column info'][$colname]['readonly'] = 1;
               }
               $addyri++;
            }
            $annual .= "<br clear=all style='mso-special-character:line-break; page-break-before:always'>";
            $annual .= showCustomHTMLForm($listobject,$thisrec,$adminmod, $content, $ismulti, $mindex, 0);
            $mindex++;
            if ($debug) {
               $controlHTML .= print_r($thisrec,1) . "<br>";
            }
            
            if ($enable_vwp) {
            
               $vwp_type = $thisrec['permit_exemption'];
               $mpid = $thisrec['MPID'];
               $listobject->querystring = "select year_of_max, max_annual from vwuds_max_actionpost1999 where userid = '$facid' and mpid = '$mpid' and action = 'WL' ";
               if ($debug) {
                  $controlHTML .= $listobject->querystring . " ; <br>";
               }
               $listobject->performQuery();
               if (count($listobject->queryrecords) > 0) {
                  $max_annual = $listobject->getRecordValue(1,'max_annual');
                  $year_of_max = $listobject->getRecordValue(1,'year_of_max');
               } else {
                  $max_annual = 0.0;
                  $year_of_max = '';
               }
               //$controlHTML .= "$mpid, VWP Type = $vwp_type <br>";
               if ($vwp_type == 3) {
                  $vwp_type = 5;
               }
               switch ($vwp_type) {
                  case 5:
                 // $controlHTML .= "$mpid, VWP Type = $vwp_type matches 3 || 5 <br>";
                  // need to show both forms
                     $vwp_aset = $adminsetuparray['vwp_exemption_type4'];
                     $vwp_content = file_get_contents("./forms/vwp_exclusion_form-1a.html");
                     $vwpvars = getCustomHTMLFormVars($vwp_content);
                     $vwprec = $thisrec;
                     foreach ($vwpvars as $thisvwp) {
                        //$controlHTML .= "Checking " . $thisvwp['paramname'] . " ... ";
                        if (!isset($vwprec[$thisvwp['paramname']])) {
                           $vwprec[$thisvwp['paramname']] = '';
                           //$controlHTML .= "Adding " . $thisvwp['paramname'] ;
                        }
                        //$controlHTML .= "<br>";
                     }
                     $vwprec['SOURCE'] = $thisrec['SOURCE'];
                     $vwprec['MPID'] = $thisrec['MPID'];
                     $vwprec['source'] = $thisrec['SOURCE'];
                     $vwprec['mpid'] = $thisrec['MPID'];
                     $vwprec['max_annual'] = $max_annual;
                     $vwprec['year_of_max'] = $year_of_max;
                     //$controlHTML .= print_r($vwprec,1) . "<br>";
                     $annual .= "<br clear=all style='mso-special-character:line-break; page-break-before:always'>";
                     $annual .= showCustomHTMLForm($listobject,$vwprec,$vwp_aset, $vwp_content, $ismulti, $mindex, 0);
                     $vwp_aset = $adminsetuparray['vwp_exemption_type3'];
                     $vwp_content = file_get_contents("./forms/vwp_exclusion_form-2.html");
                     $vwpvars = getCustomHTMLFormVars($vwp_content);
                     $vwprec = $thisrec;
                     foreach ($vwpvars as $thisvwp) {
                        //$controlHTML .= "Checking " . $thisvwp['paramname'] . " ... ";
                        if (!isset($vwprec[$thisvwp['paramname']])) {
                           $vwprec[$thisvwp['paramname']] = '';
                           //$controlHTML .= "Adding " . $thisvwp['paramname'] ;
                        }
                        //$controlHTML .= "<br>";
                     }
                     $vwprec['SOURCE'] = $thisrec['SOURCE'];
                     $vwprec['MPID'] = $thisrec['MPID'];
                     $vwprec['source'] = $thisrec['SOURCE'];
                     $vwprec['mpid'] = $thisrec['MPID'];
                     $annual .= "<br clear=all style='mso-special-character:line-break; page-break-before:always'>";
                     $annual .= showCustomHTMLForm($listobject,$vwprec,$vwp_aset, $vwp_content, $ismulti, $mindex, 0);
                     //$controlHTML .= print_r($vwprec,1) . "<br>";
                  break;

                  case 4:
                  // need to show pre-1989
                     $vwp_content = file_get_contents("./forms/vwp_exclusion_form-1a.html");
                     $vwpvars = getCustomHTMLFormVars($vwp_content);
                     $vwprec = $thisrec;
                     foreach ($vwpvars as $thisvwp) {
                        //$controlHTML .= "Checking " . $thisvwp['paramname'] . " ... ";
                        if (!isset($vwprec[$thisvwp['paramname']])) {
                           $vwprec[$thisvwp['paramname']] = '';
                           //$controlHTML .= "Adding " . $thisvwp['paramname'] ;
                        }
                        //$controlHTML .= "<br>";
                     }
                     $vwprec['SOURCE'] = $thisrec['SOURCE'];
                     $vwprec['MPID'] = $thisrec['MPID'];
                     $vwprec['source'] = $thisrec['SOURCE'];
                     $vwprec['mpid'] = $thisrec['MPID'];
                     $vwp_aset = $adminsetuparray['vwp_exemption_type4'];
                     $annual .= "<br clear=all style='mso-special-character:line-break; page-break-before:always'>";
                     $annual .= showCustomHTMLForm($listobject,$vwprec,$vwp_aset, $vwp_content, $ismulti, $mindex, 0);
                  break;

                  default: 
                     $vwp_content = '';
                  break;

               }
            } // END - VWP enabled
         }


         $outHTML = $header;
         $outHTML .= $intro;
         $outHTML .= "<form method=post action='http://$mapservip/html/whodev/test/formtest.php'>";
         $outHTML .= $facility;
         $outHTML .= $annual;
         # don't show the submit button, we will add this later when we receive the form back from the end user.
         # this should eliminate confusion on the end users part, in case they think that the 'submit' button
         # actually works!!
         #$outHTML .= showSubmitButton('submit','submit', '', 1, 0);
         $outHTML .= "</form>";
         $outHTML .= $footer;
         # END - create attachment text

         # save text as HTML first, then open in word, and save as a .doc
         $filename = str_replace("/", "\\", $basedir . "out/wateruse$thisyear" . "_$facid" . ".htm");
         #$controlHTML .= "Output directory defined as " . $basedir . "<br>";
         #$controlHTML .= "Output file defined as " . $filename . "<br>";

         $fp = fopen($filename, 'w');
         fwrite($fp, $outHTML);
         fclose($fp);
         
         //$controlHTML .= "Output mode: $mailordownload <br>";

         switch ($mailordownload) {
            case 'email':
            // all we have to do here is to create an excel file with the proper fields
            // create one entry for every email that is requested, be it secondary, primary, and planner/other EDWrD user
            // download link for email template
            // email watertype   contactname username userpass vwp_text planner_name   planner_email  planner_phone
            //$controlHTML .= "Mail Merge Results: " . print_r($mailmerge_addresses,1) . "<br>";

            break;
            
            case ( ($mailordownload == 'downloadhtml') || ($mailordownload == 'downloadhtmlgroup') ) :
               $mailHTML = '';
               if ($j == 0) {
                  # first time, so we put in the header info, otherwise, we just do the text
                  $mailHTML = $header;
               } else {
                  $mailHTML = "<br clear=all style='mso-special-character:line-break; page-break-before:always'>";
               }
               $mailHTML .= $intro;
               $mailHTML .= "<form method=post action='http://$mapservip/html/whodev/test/formtest.php' id=form$j>";
               $mailHTML .= $facility;
               $mailHTML .= $annual;
               # don't show the submit button, we will add this later when we receive the form back from the end user.
               # this should eliminate confusion on the end users part, in case they think that the 'submit' button
               # actually works!!
               #$outHTML .= showSubmitButton('submit','submit', '', 1, 0);
               $mailHTML .= "</form>";

               # need to stash this in a batch of files
               //$controlHTML .= "Adding $facid to batch document, length: " . strlen($outHTML) . " characters.<br>";
               $fp = fopen($batchfilename, 'a');
               fwrite($fp, $mailHTML);
               fclose($fp);
               
            break;
            
         }

         # now, create a blank record form in case these users have new measuring points to report on
         # save text as HTML first, then open in word, and save as a .doc
         $blankfilename = str_replace("/", "\\", $basedir . "out/blankrecords$thisyear" . "_$facid" . ".htm");
         #$controlHTML .= "Output directory defined as " . $basedir . "<br>";
         #$controlHTML .= "Output file defined as " . $filename . "<br>";
         $blankhead = file_get_contents("./mailform/edwrd_blankheader_mail.html");
         $blankform = "<br clear=all style='mso-special-character:line-break; page-break-before:always'>";
         $blankform .= "<form method=post action='http://$mapservip/html/whodev/test/formtest.php'>";
         
         $blankfields = $listobject->getColumns('vwuds_annual_mp_data');
         $aset = $adminsetuparray['annual_data'];
         # set fields that are read-only in EDWrD view for annual data to RW for the external form
         $ro_2_rw = array('lat_flt','lon_flt','stcofips','SOURCE','abandoned','CAT_MP','ACTION','GWPERMIT', 'VPDES', 'VDH_NUM','VWP_PERMIT', 'WELLNO', 'DEQ_WELL', 'TYPE', 'SUBTYPE', 'SIC_MP');
         foreach ($ro_2_rw as $rocol) {
            $aset['column info'][$rocol]['readonly'] = 0;
         }
         $aset['column info']['USERID']['readonly'] = 1;
         $aset['column info']['USERID']['type'] = 1;
         $aset['column info']['SIC_MP']['type'] = 1;
         // since this is just for a print-out, we can nake it read-only to avoid scrolling across two pages
         $aset['column info']['OTHERC']['readonly'] = 1;
         foreach ($blankfields as $thisfield) {
            if ($aset['column info'][$thisfield]['visible'] == 1) {
               $blankrec[$thisfield] = '';
            }
         }
         $blankrecords = '';
         //$content = file_get_contents("./mailform/edwrd_mpannual_blank.html");
         $content = file_get_contents("./mailform/edwrd_mpannual_header.html");
         $content .= "ADDITIONAL WATER WITHDRAWALS<BR>";
         $content .= file_get_contents("./forms/edwrd_mpannual.html");
         $blankrec['USERID'] = $facid;
         $blankrec['ownname'] = $ownername;
         $blankrec['facility'] = $facname;
         $blankrec['system'] = $systemname;
         for ($i = -1; $i >= -2; $i--) {
            if ($i < -1) {
               $blankrecords .= "<br clear=all style='mso-special-character:line-break; page-break-before:always'>";
            }
            $blankrecords .= showCustomHTMLForm($listobject,$blankrec,$aset, $content, $ismulti, $i, 0);
         }
         $blankHTML = '';
         $blankHTML .= $blankhead;
         $blankHTML .= $blankform;
         $blankHTML .= $blankrecords;
         $blankHTML .= "</form>";
         $blankHTML .= "</body></html>";
         
         $fp = fopen($blankfilename, 'w');
         fwrite($fp, $blankHTML);
         fclose($fp);


         switch ($mailordownload) {
            case 'email':
            
            break;

            case ( ($mailordownload == 'downloadhtml') || ($mailordownload == 'downloadhtmlgroup') ) :
               # need to stash this in a batch of files
               
               $fp = fopen($batchfilename, 'a');
               $mailHTML = '';
               if ($entity_count[$entity_id] == $total_facilities) {
                  $mailHTML .= $blankform;
                  $mailHTML .= $blankrecords;
               }
               //$mailHTML .= "</form>";
               fwrite($fp, $mailHTML);
               fclose($fp);

              // ----- Adding more files
              #$tar_object->add($new_filename);
           break;
        }

      }
      $j++;
      $entity_count[$entity_id]++;
      
   }
   $controlHTML .= "<i><b>Finished Generating Annual Reporting Forms - $j facility records created, (e)mail batch contains $entity_batch_size entities.</b></i>";
   
   switch ($mailordownload) {
      case ( ($mailordownload == 'downloadhtml') || ($mailordownload == 'downloadhtmlgroup') ) :
      # need to finish off the document with the final HTML stuff
      $mailHTML = $footer;
      $fp = fopen($batchfilename, 'a');
      fwrite($fp, $mailHTML);
      fclose($fp);
      $controlHTML .= "<hr><a href='$batchdownload' target=_new>Click Here to Display all Printable Forms as a single HTML document</a>";
      putExcelFile("$outdir_nodrive/$alladdressfilename", $alladdresses);
      $controlHTML .= " - <a href='$alladdressfiledl' target=_new>Spreadsheet File of Mailing Addresses.</a>";
      break;
      
      case 'email':
      //$controlHTML .= "Trying to write $outdir_nodrive/$alladdressfilename using new excel2k routine in new PEAR directory.<br>";
      $controlHTML .= "<hr><a href='$mailmerge_template' target=_new>Click Here to Download the Mail Merge Email Template</a>";
      putExcel2kFile("$outdir_nodrive/$mailmerge_filename", 'mailmerge', $mailmerge_addresses);
      //putExcelFile("$outdir_nodrive/$mailmerge_filename", $mailmerge_addresses);
      $controlHTML .= " - <a href='$mailmerge_filedl' target=_new>Mail Merge Spreadsheet.</a>";
      break;

   }


   if ( ($progressreport == 1) and ($mailordownload == 'email')) {
      foreach ($summary as $pid => $sum) {
         // may keep this code here, as we could use regular Unix mail to send a progress report to the planners.
         /*
         $mail = new phpMailer();
         $mail->SMTPDebug = 0;
         $mail->IsSMTP();
         $mail->Host = '172.16.1.68';
         #$mail->Protocol = 'ssl';
         #$mail->Host = "DEQEX01.deq.local";
         $mail->Port = 827;
         #$mail->SMTPAuth = true;
         $mail->Username = 'rwburgholzer';
         $mail->Mailer = 'smtp';
         # later we will set this to be the planner of interest, or the EDWrD administrator
         $mail->From = 'rwburgholzer@deq.virginia.gov';
         $mail->FromName = 'Robert Burgholzer';
         $mail->AddReplyTo($mail->From, $mail->FromName);
         $listobject->querystring = " select email from users where userid = $pid ";
         if ($debug) {
            $controlHTML .= $listobject->querystring . " ; <br>";
         }
         $listobject->performQuery();
         $plannermail = $listobject->getRecordValue(1,'email');
         $mail->AddAddress($plannermail,"Receiver");
         #$mail->AddAddress($mail->From,"Receiver");
         $mail->Subject = 'EDWrD eMail Summary';
         $mail->Body = "The following facilities have been contacted on your behalf:\n";
         foreach ($sum as $thisrec) {
            $mail->Body .= $thisrec['numrecs'] . " record(s) for " . $thisrec['msg'] . " sent to: " . $thisrec['sentto'] ."\n\n";
         }
         if ($debug) {
            $controlHTML .= $mail->Body . " ; <br>";
            $controlHTML .= print_r($sum,1) . " ; <br>";
         }

         if(!$mail->Send()) {
            $controlHTML .= "<p>Progress report was not sent </p>";
            $controlHTML .= "Mailer Error: " . $mail->ErrorInfo;
            #$controlHTML .= "We WOULD have sent: <hr>" . $outHTML;
         } else {
            $controlHTML .= "Progress report sent.";
         }
         */
      }
   }

   $controlHTML .= "<div id=errorinfo class='errorInfo'>" . $errorMSG . "</div>";


   return $controlHTML;

}

function showPrintableFacilityForm($listobject, $facilityid, $aset, $footerfile="./mailform/edwrd_footer.html", $bodyfile="./mailform/edwrd_facility.html") {
   $footer = file_get_contents($footerfile);
   $content = file_get_contents($bodyfile);
   $listobject->querystring = "select * from facilities where userid = '$facilityid' ";
   $listobject->performQuery();
   $facrec = $listobject->queryrecords[0];
   $facility .= $listobject->querystring;
   $facility .= "Results: " . print_r($facrec,1) . "<br>";
   $facility .= "<br clear=all style='mso-special-character:line-break; page-break-before:always'>";
   $facility .= showCustomHTMLForm($listobject,$facrec,$aset, $content, 0, -1, 0, 1);
   return $facility;
}


function createAnnualReportingListByUser($listobject, $formValues) {
   
   // this will create a spreadsheet for outlook mail merge 
   // with a single entry for every user account in the database.
   
   // use tab delimiting, this will help to make commas in text not a problem, and 
   // so forth
   
   
}

function facilityViewForm($formValues) {
   global $listobject, $fno, $adminsetuparray, $outdir_nodrive, $outurl, $userid, $usergroupids, $tmpdir, $outdir, $outurl, $goutdir, $gouturl;
   // this version of the facilityviewform is what internal users see.

   $controlHTML = '';
   $errorMSG = '';
   $resultMSG = '';
   #$debug = 1;
   $projectid = $formValues['projectid'];
   if (isset($formValues['quicksearch_userid'])) {
      $facilityid = $formValues['quicksearch_userid'];
      $quicksearch_userid = $formValues['quicksearch_userid'];
      $quicksearch_mpid = $formValues['quicksearch_mpid'];
   } else {
      $facilityid = '0241';
      $quicksearch_userid = '';
   }
   if (isset($formValues['quicksearch_enabled'])) {
      $quicksearch_enabled = $formValues['quicksearch_enabled'];
      if (!$quicksearch_enabled) {
         $quicksearch_userid = '';
         $quicksearch_mpid = '';
      }
   } else {
      $quicksearch_enabled = 0;
      $quicksearch_userid = '';
      $quicksearch_mpid = '';
   }
   $mpid = '-1';

   $controlHTML .= "<form method=post action='' id=control>";
   ############################################################
   ###                        SEARCH FORM                   ###
   ############################################################
   $tablename = 'facility_view';
   $aset = $adminsetuparray[$tablename];
   # call the search form routine.  This will take all of the variables that come in the search and interpret them,
   # returning the record of interest
   $searchobject = new listObjectSearchForm;
   $searchobject->listobject = $listobject;
   $searchobject->debug = FALSE;
   $searchobject->insertOK = 0;
   $searchobject->deleteOK = 0;
   $searchobject->adminsetup = $aset;
   $searchobject->readonly = 1;
   $searchobject->record_submit_script = "last_tab[\"facilitybased\"] = \"facilitybased_data0\";
 last_button[\"facilitybased\"] = \"facilitybased_0\"; xajax_showFacilityViewForm(xajax.getFormValues(\"control\")); ";
   $searchobject->search_submit_script = "last_tab[\"facilitybased\"] = \"facilitybased_data0\";
 last_button[\"facilitybased\"] = \"facilitybased_0\"; xajax_showFacilityViewForm(xajax.getFormValues(\"control\"));  ";
   $searchobject->page_submit_script = "last_tab[\"facilitybased\"] = \"facilitybased_data0\";
 last_button[\"facilitybased\"] = \"facilitybased_0\"; xajax_showFacilityViewForm(xajax.getFormValues(\"control\")); ";
   
   $controlHTML .= "<a class=\"mH\"";
   $controlHTML .= "onclick=\"toggleMenu('$divname" . "_search')\">+ Show/Hide Advanced Search Form</a>";
   $controlHTML .= "<div id=\"$divname" . "_search\" class=\"mL\"><ul>";
   # display the search form
   if ($quicksearch_enabled) {
      $quickvars = array();
      $searchobject->setVariableNames();
      $quickvars[$searchobject->searchnames['userid']['search_var']] = $quicksearch_userid;
      if ($quicksearch_mpid <> '') {
         $quickvars[$searchobject->searchnames['MPID']['search_var']] = $quicksearch_mpid;
      }
      $quickvars['search_view'] = 'edit';
      $controlHTML .= "Forcing quick search criteria to advanced search: " . print_r($quickvars,1) . "<br>";
      $searchForm = $searchobject->showSearchForm($quickvars);
   } else {
      #$controlHTML .= "No quick search requested.<br>";
      $searchForm = $searchobject->showSearchForm($formValues);
   }
   # get properties from search form
   $search_view = $searchForm['search_view'];
   $numrecs = $searchForm['numrecs'];
   $currentpos = $searchForm['currentpos'];
   
   $searchfields_jsarray = '[';
   $sdel = '';
   foreach (array_keys($aset['search info']['columns']) as $thisvar) {
      if (isset($aset['search info']['columns'][$thisvar]['search_var'])) {
         $thisvarname = $aset['search info']['columns'][$thisvar]['search_var'];
      } else {
         $thisvarname = 'srch_' . $thisvar;
      }
      $searchfields_jsarray .= $sdel . "\"$thisvarname\"";
      $sdel = ',';
   }
   $searchfields_jsarray .= ']';
   //$controlHTML .= "js search array: $searchfields_jsarray <BR>";
   $resetscript = "clearForm(\"control\", $searchfields_jsarray);";
   $controlHTML .= showGenericButton('resetform','Reset Search Form', $resetscript, 1) . "<br>";
   $controlHTML .= $searchForm['formHTML'];
   $controlHTML .= "</div><br>";
   
   $controlHTML .= "<i><b>Result Display Options: </b></i><table width=100%><tr align=center><td>" . $searchForm['searchOptions'] . '</td></tr></table>';
   $controlHTML .= "<hr>";
   
   # assemble the base query
   $subquery = "( select userid, ownname, facility, system from (" . $searchForm['query'] . " ) as foo ) as bar ";
   $controlHTML .= $subquery . " ;<br>";
   //$controlHTML .= showGenericButton('search','Search', "last_tab[\"facilitybased\"] = \"facilitybased_data0\"; last_button[\"facilitybased\"] = \"facilitybased_0\"; xajax_showFacilityViewForm(xajax.getFormValues(\"control\")); ", 1, $pd);
   //$controlHTML .= print_r($formValues,1) . "<br>";
   $controlHTML .= "<hr>";
   //return $controlHTML;
   $controlHTML .= showHiddenField('quicksearch_enabled',0, 1);
   //$controlHTML .= showHiddenField('quicksearch_mpid',-1, 1);
   $controlHTML .= "<b>User ID:" . showWidthTextField('quicksearch_userid',$quicksearch_userid, 6, $quicksearch_userid, 1, 0) . " ";
   $controlHTML .= "<b>MPID (optional):" . showWidthTextField('quicksearch_mpid',$quicksearch_mpid, 16, $quicksearch_mpid, 1, 0) . " ";
   $controlHTML .= showGenericButton('quicksearch','Quick Search', "last_tab[\"facilitybased\"] = \"facilitybased_data0\";
 last_button[\"facilitybased\"] = \"facilitybased_0\"; document.forms[\"control\"].elements.quicksearch_enabled.value=1 ; xajax_showFacilityViewForm(xajax.getFormValues(\"control\")); ", 1, $pd);
   $controlHTML .= "<br>";
   
   ############################################################
   ###                    END SEARCH FORM                   ###
   ############################################################
   
   # did we get a save, insert or delete command?
   # if so, let's deal with it
   if (isset($formValues['searchtype'])) {
      $searchtype = $formValues['searchtype'];
   } else {
      $searchtype = '';
   }
   $resultMSG = '';
   
   switch ($searchtype) {
      case 'save':
         $controlHTML .= "Saving records:<br>";
         #$controlHTML .= print_r($formValues,1) . "<br>";
         # record 0 will have facility information
         # record 1 will ahve MP info
         
         
         # records 2-n if they exist, will have the annual data
         # look for annual_data records
         if (isset($formValues['userid'])) {
            $uid = $formValues['userid'][0];
            # save facility updates
            $formvars = array();
            #$controlHTML .= "Checking for variables: ";
            foreach (array_keys($formValues) as $thisvar) {
               //$controlHTML .= "<br>" . $thisvar . ' ';
               if (isset($formValues[$thisvar][0])) {
                  #$thisvar is part of the annual data record, so include it in the form variables
                  $formvars[$thisvar] = $formValues[$thisvar][0];
                  //$controlHTML .= '(found) ';
               }
            }
            #$controlHTML .= "<br>";
            #$controlHTML .= print_r($formvars, 1) . "<br>";
            #$listobject->performQuery();
            $aset = $adminsetuparray['facilities'];
            # force these, since the multiform wants a PK, but we can't actually use the REAL pk (rec_id)
            # because it is possible that a records rec_id may have changed between form mail out and return
            # thus, we simply set mpid as a read-only pk, and later we will add our own where criteria
            # to make sure that we don't miss it
            #$aset['table info']['pkcol'] = 'mpid';
            #$formvars['mpid'] = $mpid;

            $update_rec = processMultiFormVars($listobject,$formvars,$aset,0,$debug, $nullpk = -1, $strictnull = 0);
            #print_r($update_rec);
            #$controlHTML .= print_r($formvars, 1) . "<br>";
            #$controlHTML .= print_r($update_rec, 1) . "<br>";
            if ($debug) {
               $taboutput->tab_HTML['debug'] .= $update_rec['debugstr'] . " ;<br>";
               $controlHTML .= $update_rec['debugstr'] . " ;<br>";
            }
            $rec_saved = 0;
            if (isset($formvars['userid'])) {
               $uid = $formvars['userid'];
               if ($uid == -1) {
                  # insert
                  $controlHTML .= "Blank record insert requested<br>";
                  $listobject->querystring = $update_rec['insertsql'];
                  # don't import yet, we will do this later, or write a nother script to handle this seperately
                  #$controlHTML .= "$listobject->querystring ; <br>";
                  #$listobject->performQuery();
               } else {
                  # update
                  #$controlHTML .= "Update requested<br>";
                  $listobject->querystring = "UPDATE facilities SET " . $update_rec['updatequery'] . " WHERE \"userid\" = '$uid'";
                  if ($debug) {
                     $controlHTML .= "$listobject->querystring ; <br>";
                  }
                  $listobject->performQuery();
               }
               if ($listobject->error) {
                  $errorMSG .= $listobject->error . "<br>";
               } else {
                  $rec_saved++;
               }
            }
            if ($rec_saved) {
               $resultMSG .= "Facility Record $uid updated.<br>";
            }
         }
               
         if (isset($formValues['MPID'])) {
            $mpid = $formValues['MPID'][1];
         } else {
            $mpid = -1;
         }
         if ($mpid <> -1) {
            # can onkly move forward with annual data records, or MPI records if MPID is also set!
            # later, we will use this as a means to generate a new MPID, but for now, just ignore

            # save MP updates
            $formvars = array();
            #$controlHTML .= "Checking for variables: ";
            foreach (array_keys($formValues) as $thisvar) {
               #$controlHTML .= $thisvar . ' ';
               if (isset($formValues[$thisvar][1])) {
                  #$thisvar is part of the annual data record, so include it in the form variables
                  $formvars[$thisvar] = $formValues[$thisvar][1];
                  #$controlHTML .= '(found) ';
               }
            }
            #$controlHTML .= "<br>";
            #$controlHTML .= print_r($formvars, 1) . "<br>";
            #$listobject->performQuery();
            $aset = $adminsetuparray['vwuds_measuring_point'];
            #$aset['column info']['YEAR']['readonly'] = 1;
            # force these, since the multiform wants a PK, but we can't actually use the REAL pk (rec_id)
            # because it is possible that a records rec_id may have changed between form mail out and return
            # thus, we simply set mpid as a read-only pk, and later we will add our own where criteria
            # to make sure that we don't miss it
            #$aset['table info']['pkcol'] = 'mpid';
            #$formvars['mpid'] = $mpid;

            $update_rec = processMultiFormVars($listobject,$formvars,$aset,0,$debug, $nullpk = -1, 1);
            #print_r($update_rec);
            #$controlHTML .= print_r($update_rec, 1) . "<br>";
            $rec_saved = 0;
            if (isset($formvars['record_id'])) {
               $record_id = $formvars['record_id'];
               if ($mpid == -1) {
                  # insert
                  $controlHTML .= "Blank record insert requested<br>";
                  $listobject->querystring = $update_rec['insertsql'];
                  # don't import yet, we will do this later, or write a nother script to handle this seperately
                  #$controlHTML .= "$listobject->querystring ; <br>";
                  #$listobject->performQuery();
               } else {
                  # update
                  #$controlHTML .= "Update requested<br>";
                  $listobject->querystring = "UPDATE vwuds_measuring_point SET " . $update_rec['updatequery'] . " WHERE record_id = $record_id";
                  if ($debug) {
                     $controlHTML .= "$listobject->querystring ; <br>";
                  }
                  $listobject->performQuery();
               }
               if ($listobject->error) {
                  $errorMSG .= "Measuring Point record $mpid: " . $listobject->error . "<br>";
                  $errorMSG .= "$listobject->querystring ; <br>";
               } else {
                  $rec_saved++;
               }
            }
            if ($rec_saved) {
               $resultMSG .= "MP Record $mpid updated.<br>";
            }
               
            ##########################################################################
            ################        save annual_data updates          ################
            ##########################################################################
            $rec_saved = 0;
            if (isset($formValues['JANUARY'])) {
               foreach (array_keys($formValues['JANUARY']) as $postkey) {
                  $formvars = array();
                  #$controlHTML .= "Checking for variables: ";
                  foreach (array_keys($formValues) as $thisvar) {
                     #$controlHTML .= $thisvar . ' ';
                     if (isset($formValues[$thisvar][$postkey])) {
                        #$thisvar is part of the annual data record, so include it in the form variables
                        $formvars[$thisvar] = $formValues[$thisvar][$postkey];
                        #$controlHTML .= '(found) ';
                     }
                  }
                  #$controlHTML .= "<br>";
                  #$controlHTML .= print_r($formvars, 1) . "<br>";
                  #$listobject->performQuery();
                  $aset = $adminsetuparray['annual_data'];
                  $yr = $formValues['JANUARY'][$postkey];
                  # force these, since the multiform wants a PK, but we can't actually use the REAL pk (rec_id)
                  # because it is possible that a records rec_id may have changed between form mail out and return
                  # thus, we simply set mpid as a read-only pk, and later we will add our own where criteria
                  # to make sure that we don't miss it
                  #$aset['table info']['pkcol'] = 'mpid';
                  #$formvars['mpid'] = $mpid;

                  $update_rec = processMultiFormVars($listobject,$formvars,$aset,0,$debug, $nullpk = -1, $strictnull = 0);
                  #print_r($update_rec);
                  #$controlHTML .= print_r($update_rec, 1) . "<br>";
                  if (isset($formvars['recid'])) {
                     $recid = $formvars['recid'];
                     if ($mpid == -1) {
                        # insert
                        $controlHTML .= "Blank record insert requested<br>";
                        $listobject->querystring = $update_rec['insertsql'];
                        # don't import yet, we will do this later, or write a nother script to handle this seperately
                        #$controlHTML .= "$listobject->querystring ; <br>";
                        #$listobject->performQuery();
                     } else {
                        # update
                        #$controlHTML .= "Update requested<br>";
                        $listobject->querystring = "UPDATE annual_data SET " . $update_rec['updatequery'] . " WHERE \"recid\" = '$recid'";
                        #$controlHTML .= "$listobject->querystring ; <br>";
                        $listobject->performQuery();
                     }
                     $rec_saved++;
                  }
                  if ($listobject->error) {
                     $errorMSG .= "Annual Data record for $yr: " . $listobject->error . "<br>";
                  } else {
                     $rec_saved++;
                  }
               }
            }
            if ($rec_saved) {
               $resultMSG .= "$rec_saved Annual Record(s) Saved.<br>";
            }
               
            ##########################################################################
            ################         END annual_data updates          ################
            ##########################################################################
         }
         
         ##########################################################################
         ################       BEGIN vwp_exemption updates        ################
         ##########################################################################
         
         if (isset($formValues['data_typename'])) {
            // check here for this new style, where the data type is indicated by the "data_typename" variable
            // for now, only the VWP exemption forms are included here
            //$resultMSG .= "Variable 'data_typename' Found.<br>";
            foreach (array_keys($formValues['data_typename']) as $thiskey) {
               if ($formValues['data_typename'][$thiskey] == 'vwp_exclusion') {
                  //$resultMSG .= "VWP Data Found.<br>";
                  if (isset($formValues['exemption_id'][$thiskey])) {
                     //$resultMSG .= "Variable 'exemption_id' Found.<br>";
                     $aset = $adminsetuparray['vwp_exemption'];
                     $vwpvars = array();
                     #$controlHTML .= "Checking for variables: ";
                     foreach (array_keys($formValues) as $thisvar) {
                        #$controlHTML .= $thisvar . ' ';
                        if (isset($formValues[$thisvar][$thiskey])) {
                           #$thisvar is part of the annual data record, so include it in the form variables
                           $vwpvars[$thisvar] = $formValues[$thisvar][$thiskey];
                           #$controlHTML .= '(found) ';
                        }
                     }
                     $exemption_response = processVWPExemptionForm($listobject, $vwpvars);
                     if (!$exemption_response['error']) {
                        $resultMSG .= $exemption_response['resultHTML'] . "<br>";
                     } else {
                        $errorMSG .= "VWP Exemption form error: " . $exemption_response['errorMSG'] . "<br>";
                     }
                  }
               }
            }
         }
         ##########################################################################
         ################        END vwp_exemption updates         ################
         ##########################################################################
                  
      break;
      
   }

   #$search_view = 'list'; # force edit view for now
   $listobject->show = 0;
   if ($debug) {
      $controlHTML .= "Search View: $search_view <br>";
   }
   if ($debug) {
      $controlHTML .= $searchForm['debug'];
   }
   $controlHTML .= "<div id=errorinfo class='errorInfo'>" . $errorMSG . "</div>";
   $controlHTML .= "<div id=errorinfo class='resultInfo'>" . $resultMSG . "</div>";
   $controlHTML .= "<i><b>Search Results:</b> Search Returned $numrecs record(s) matching your criteria.</i><br>";
   $controlHTML .= "<br>Viewing Record " . ($currentpos + 1) . " out of $numrecs<br>";
   #$controlHTML .= print_r($searchForm, 1) . "<br>";
   $props = $searchForm['recordvalue'];
   
   switch ($search_view) {
      case 'list':
         $controlHTML .= "<div style=\"overflow: auto; height: 600px; width: 800px;\">";
         $listobject->queryrecords = $props;
         #$listobject->tablename = 'vwuds_measuring_point';
         $listobject->showList();
         $controlHTML .= $listobject->outstring;
         $controlHTML .= "</div>";
      break;
      
      case 'detail' || 'edit':
         
         # create a paneled object
         # Panel #1: Facility Record
         # Panel #2: MP record
         # Panel #3: All withdrawal data for this facility/MP sorted by year, descending
         # panel #4: comments and other measurement info for each year, descending
         # Need to have q2uick navigation to other measuring points of this same facility
         # and quick navigation to other facilities by entering userid
         $taboutput = new tabbedListObject;
         $taboutput->name = 'facilitybased';
         $taboutput->tab_names = array('facility','measuringpoint','annualdata','additional','trends','vwp_exinfo');
         #if ($debug) {
            array_push($taboutput->tab_names, 'debug');
         #}
         $taboutput->tab_buttontext = array(
            'facility'=>'Facility Info',
            'measuringpoint'=>'Measuring Point',
            'annualdata'=>'Annual Data',
            'additional'=>'Other Info',
            'trends'=>'Trend Analysis',
            'debug'=>'Debug Info',
            'vwp_exinfo'=>'VWP Exemption'
         );
         $taboutput->init();
         $taboutput->tab_HTML['facility'] .= "<b><font face='arial'>Facility Information:</font></b><br>";
         $taboutput->tab_HTML['measuringpoint'] .= "<b><font face='arial'>Measuring Point Info:</font></b><br>";
         $taboutput->tab_HTML['annualdata'] .= "<b><font face='arial'>Annual Reporting:</font></b><br>";
         $taboutput->tab_HTML['additional'] .= "<b><font face='arial'>Additional Information:</font></b><br>";
         $taboutput->tab_HTML['trends'] .= "<b><font face='arial'>Trend Analysis:</font></b><br>";
         $taboutput->tab_HTML['vwp_exinfo'] .= "<b><font face='arial'>VWP Exemption Info:</font></b><br>";
         if ($debug) {
            $taboutput->tab_HTML['debug'] .= "<b><font face='arial'>Debugging Information:</font></b><br>";
         }

         #$controlHTML .= "Props: " . print_r($props,1) . "<br>";
         # get facility information
         $facilityid = $props['userid'];
         $gid = $props['gid'];
         if (isset($props['MPID'])) {
            $mpid = $props['MPID'];
         }
         $controlHTML .= "<b>Facility ID: $facilityid, Measuring Point: $mpid<br>";
         
         $adminsetup = $adminsetuparray['facilities'];
         $perms = getVWUDSPerms($listobject, $adminsetup, $gid, $userid, $usergroupids, 1);
         $ap = $perms['rowperms'] & 2;
         $facreadonly = 1;
         if ( ($perms['rowperms'] & 2) or ($perms['tableperms'] & 2)) {
            $facreadonly = 0;
         }
         if ($debug) {
            $taboutput->tab_HTML['debug'] .= print_r($perms, 1) . "<br> Read-Only (Facility Screen): $facreadonly <br>";
         }
         $adminname = 'facilities';
         $adminsetup = $adminsetuparray[$adminname];
         $tblname = $adminsetup['table info']['tabledef'];
         $listobject->querystring = "  select * from $tblname where userid = '$facilityid' ";
         if ($debug) {
            $taboutput->tab_HTML['debug'] .= $listobject->querystring . " ;<br>";
         }
         $listobject->performQuery();
         $facrecord = $listobject->queryrecords[0];

         $mindex = 0;
         $ismulti = 1;
         #$facility = showCustomHTMLForm($listobject,$facrec,$aset, $content, $ismulti, $mindex, 0);
         $content = file_get_contents("./forms/facility.html");
         $taboutput->tab_HTML['facility'] .= showCustomHTMLForm($listobject,$facrecord,$adminsetup, $content, $ismulti, $mindex, $debug = 0, $facreadonly);#$taboutput->tab_HTML['facility'] .= showFormVars($listobject,$facrecord,$adminsetup,0, 1, $debug, 1, 1, 0, $fno, $mindex, 0);
         $mindex++;

         # get measuring point information
         $adminname = 'vwuds_measuring_point';
         $adminsetup = $adminsetuparray[$adminname];
         $tblname = $adminsetup['table info']['tabledef'];
         $listobject->querystring = "  select * from $tblname where \"USERID\" = '$facilityid' ";
         if ($mpid <> '-1') {
            $listobject->querystring .= " and \"MPID\" = '$mpid' ";
         } else {
            # if we have not specified a measuring point, we just grab the first one that comes along
            $listobject->querystring .= " LIMIT 1 ";
         }
         if ($debug) {
            $taboutput->tab_HTML['debug'] .= $listobject->querystring . " ;<br>";
         }
         $listobject->performQuery();
         $mprecord = $listobject->queryrecords[0];
         $mpid = $mprecord['MPID'];
         $record_id = $mprecord['record_id'];
         $perms = getVWUDSPerms($listobject, $adminsetup, $record_id, $userid, $usergroupids, 1);
         $ap = $perms['rowperms'] & 2;
         $mpreadonly = 1;
         if ( ($perms['rowperms'] & 2) or ($perms['tableperms'] & 2)) {
            $mpreadonly = 0;
         }
         if ($debug) {
            $taboutput->tab_HTML['debug'] .= print_r($perms,1) . " <br> MP ro - $mpreadonly;<br>";
         }

         $ismulti = 1;
         #$facility = showCustomHTMLForm($listobject,$facrec,$aset, $content, $ismulti, $mindex, 0);
         $content = file_get_contents("./forms/measuring_point.html");
         $taboutput->tab_HTML['measuringpoint'] .= showCustomHTMLForm($listobject,$mprecord,$adminsetup, $content, $ismulti, $mindex, $debug = 0, $mpreadonly);
         #$taboutput->tab_HTML['measuringpoint'] .= showFormVars($listobject,$mprecord,$adminsetup,0, 1, $debug, 1, 1, 0, $fno, $mindex, 0);
         $mindex++;

         # get measuring point information
         $adminname = 'annual_data';
         $adminsetup = $adminsetuparray[$adminname];
         $adminsetup['column info']['YEAR']['readonly'] = 1;
         // make the comment field slim line for this view
         $adminsetup['column info']['OTHERC']['params'] = '';
         $tblname = $adminsetup['table info']['tabledef'];
         $listobject->querystring = "  select * from $tblname where \"USERID\" = '$facilityid' ";
         $listobject->querystring .= " and \"MPID\" = '$mpid' ";
         $listobject->querystring .= " ORDER BY \"YEAR\" DESC ";
         if ($debug) {
            $taboutput->tab_HTML['debug'] .= $listobject->querystring . " ;<br>";
         }
         $listobject->performQuery();
         $adrecord = $listobject->queryrecords;
         if ($debug) {
            $taboutput->tab_HTML['debug'] .= print_r($adrecord, 1) . " ;<br>";
         }

         $ismulti = 1;
         #$facility = showCustomHTMLForm($listobject,$facrec,$aset, $content, $ismulti, $mindex, 0);
         $taboutput->tab_HTML['annualdata'] .= "<table>";
         $taboutput->tab_HTML['annualdata'] .= "<tr>" . file_get_contents("./forms/annual_data_header.html") . "</tr>";
         $template = file_get_contents("./forms/annual_data_row.html");
         $writable = 0;
         $anlog = array();
         $yrs = 0;
         # set up tally for annual data trends
         $addmonth = array(1=>array('total'=>0,'pct'=>0),
            1=>array('total'=>0,'pct'=>0, 'month'=>'Jan'),
            2=>array('total'=>0,'pct'=>0, 'month'=>'Feb'),
            3=>array('total'=>0,'pct'=>0, 'month'=>'Mar'),
            4=>array('total'=>0,'pct'=>0, 'month'=>'Apr'),
            5=>array('total'=>0,'pct'=>0, 'month'=>'May'),
            6=>array('total'=>0,'pct'=>0, 'month'=>'Jun'),
            7=>array('total'=>0,'pct'=>0, 'month'=>'Jul'),
            8=>array('total'=>0,'pct'=>0, 'month'=>'Aug'),
            9=>array('total'=>0,'pct'=>0, 'month'=>'Sep'),
            10=>array('total'=>0,'pct'=>0, 'month'=>'Oct'),
            11=>array('total'=>0,'pct'=>0, 'month'=>'Nov'),
            12=>array('total'=>0,'pct'=>0, 'month'=>'Dec')
         );
         
         foreach ($adrecord as $thisrec) {
            
            ###########################################
            # BEGIN - Annual Edit Form
            ###############################################
            #$taboutput->tab_HTML['annualdata'] .= showFormVars($listobject,$thisrec,$adminsetup,0, 1, $debug, 1, 1, 0, $fno, $mindex, 0);
            $pkval = $thisrec['recid'];
            $perms = getVWUDSPerms($listobject, $adminsetup, $pkval, $userid, $usergroupids, 1);
            $ap = $perms['rowperms'] & 2;
            $readonly = 1;
            if ($perms['rowperms'] & 2) {
               $readonly = 0;
            } 
            # keep track of the number of writeable records
            if (!$readonly) {
               $writable++;
            }
            if ($debug) {
               $taboutput->tab_HTML['debug'] .= print_r($perms, 1) . "<br> Read-Only: $readonly <br>";
            }
            $taboutput->tab_HTML['annualdata'] .= "<tr> " . showCustomHTMLForm($listobject,$thisrec,$adminsetup, $template, $ismulti, $mindex, 0, $readonly) . "</tr>";
            $mindex++;
            ###########################################
            # END - Annual Edit Form
            ###############################################
            ###########################################
            # BEGIN - trend Analysis data
            ###############################################
            $anlog[$thisrec['YEAR']] = array('thisyear'=>$thisrec['YEAR'], 'total'=>$thisrec['ANNUAL/365'], 'maxdaily'=>$thisrec['MAXDAY']);
            if ($thisrec['ANNUAL'] > 0) {
               $yrs++;
               $addmonth[1]['total'] = $addmonth[1]['total'] + $thisrec['JANUARY'] / $thisrec['ANNUAL'];
               $addmonth[2]['total'] += $thisrec['FEBRUARY'] / $thisrec['ANNUAL'];
               $addmonth[3]['total'] += $thisrec['MARCH'] / $thisrec['ANNUAL'];
               $addmonth[4]['total'] += $thisrec['APRIL'] / $thisrec['ANNUAL'];
               $addmonth[5]['total'] += $thisrec['MAY'] / $thisrec['ANNUAL'];
               $addmonth[6]['total'] += $thisrec['JUNE'] / $thisrec['ANNUAL'];
               $addmonth[7]['total'] += $thisrec['JULY'] / $thisrec['ANNUAL'];
               $addmonth[8]['total'] += $thisrec['AUGUST'] / $thisrec['ANNUAL'];
               $addmonth[9]['total'] += $thisrec['SEPTEMBER'] / $thisrec['ANNUAL'];
               $addmonth[10]['total'] += $thisrec['OCTOBER'] / $thisrec['ANNUAL'];
               $addmonth[11]['total'] += $thisrec['NOVEMBER'] / $thisrec['ANNUAL'];
               $addmonth[12]['total'] += $thisrec['DECEMBER'] / $thisrec['ANNUAL'];
            } 
            ###########################################
            # END - trend Analysis data
            ###############################################
         }
         $taboutput->tab_HTML['annualdata'] .= "</table>";
         
         ###############################################
         ### create a trends analysis of collected data
         ###############################################
         # finish up data summaries for plots
         if ($yrs > 0) {
            for ($d = 1; $d <= 12; $d++) {
               $addmonth[$d]['pct'] = $addmonth[$d]['total'] / $yrs;
            }
         }
         $angraph = new GraphObject;
         $angraph->sessionid = $mpid;
         $angraph->componentid = 1;
         $angraph->init();
         $angraph->outdir = $outdir;
         $angraph->outurl = $outurl;
         $angraph->goutdir = $goutdir;
         $angraph->gouturl = $gouturl;
         $angraph->tmpdir = $tmpdir;
         $angraph->logtable = array();
         $angraph->log2db = 0;
         $angraph->logRetrieved = 1;
         $angraph->graphtype = 'multi';
         $angraph->xlabel = 'Year';
         $angraph->ylabel = 'Total Use (MGD)';
         
         $andata = new GraphComponent;
         $andata->init();
         $andata->xcol = 'thisyear';
         $andata->ycol = 'total';
         $andata->graphtype = 'bar';
         
         $andata1 = new GraphComponent;
         $andata1->init();
         $andata1->xcol = 'thisyear';
         $andata1->ycol = 'maxdaily';
         $andata1->color = 'red';
         $andata1->graphtype = 'bar';
         
         $angraph->logtable = $anlog;
         sort($angraph->logtable);
         $angraph->addOperator('annualtrend', $andata, 0);
         $angraph->addOperator('annualmax', $andata1, 0);
         $angraph->finish();
         
         $mograph = new GraphObject;
         $mograph->sessionid = $mpid;
         $mograph->componentid = 2;
         $mograph->init();
         $mograph->outdir = $outdir;
         $mograph->outurl = $outurl;
         $mograph->goutdir = $goutdir;
         $mograph->gouturl = $gouturl;
         $mograph->tmpdir = $tmpdir;
         $mograph->logtable = array();
         $mograph->log2db = 0;
         $mograph->logRetrieved = 1;
         $mograph->x_interval = 1;
         $mograph->graphtype = 'multi';
         $mograph->xlabel = '';
         $mograph->ylabel = 'Percent of Annual Use';
         
         $modata = new GraphComponent;
         $modata->init();
         $modata->xcol = 'month';
         $modata->ycol = 'pct';
         $modata->graphtype = 'bar';
         $mograph->logtable = $addmonth;
         $mograph->addOperator('annualtrend', $modata, 0);
         $mograph->finish();
         
         $taboutput->tab_HTML['trends'] .= "<table><tr>";
         $taboutput->tab_HTML['trends'] .= "<td align=center><b>Annual Totals By Year</b><br>" . $angraph->graphstring . "</td>";
         $taboutput->tab_HTML['trends'] .= "<td align=center><b>Average Use By Month</b><br>" . $mograph->graphstring . "</td>";
         $taboutput->tab_HTML['trends'] .= "</tr></table>";
         ###############################################
         ###  END - Trends Analysis
         ###############################################
         
         $vwp_exinfo = showVWPExemptionForm($listobject, $facilityid, array(), $mindex, $mpid);
         $mindex = $vwp_exinfo['mindex'];
         $taboutput->tab_HTML['vwp_exinfo'] .= "<table>";
         $taboutput->tab_HTML['vwp_exinfo'] .= "<tr>";
         $taboutput->tab_HTML['vwp_exinfo'] .= "<td align=left>" . $vwp_exinfo['innerHTML'] . "</td>";
         $taboutput->tab_HTML['vwp_exinfo'] .= "</tr>";
         $taboutput->tab_HTML['vwp_exinfo'] .= "</table>";

         $taboutput->createTabListView();
         $controlHTML .= $taboutput->innerHTML;
      break;
   }
   if ( ($writable > 0) or (!$facreadonly) or (!$mpreadonly)) {
      $searchobject->readonly = 0;
   }
   #$controlHTML .= "Writeable: $writable , fac $facreadonly <br>";
   $controlHTML .= "<table><tr><td width=33%>";
   $controlHTML .= $searchobject->showPrevNextRecordButtons();
   $controlHTML .= "</td>";
   $controlHTML .= "<td width=33%>&nbsp;";
   $controlHTML .= "</td>";
   $controlHTML .= "<td width=33%>";
   $controlHTML .= $searchobject->showSaveButton('');
   $controlHTML .= "</td>";
   $controlHTML .= "</tr></table>";
   #$controlHTML .= $searchForm['navButtonHTML'] ;
   $controlHTML .= "</form>";
   return $controlHTML;
}

function facilityViewForm2($formValues) {
   global $listobject, $fno, $adminsetuparray, $outdir_nodrive, $outurl, $userid, $usergroupids, $tmpdir, $outdir, $outurl, $goutdir, $gouturl;
   
   if (substr_count( $basedir, 'vwudsdev') > 0) {
      $debug = 1;
   }
   $enable_vwp = 0; // whether to include the VWP information.
   $controlHTML = '';
   $errorMSG = '';
   $resultMSG = '';
   #$debug = 1;
   if (isset($formValues['facilityid'])) {
      $facilityid = $formValues['facilityid'];
   } else {
      $facilityid = '';
   }
   // set default year
   $current_year = date('Y');
   $current_month = date('n');
   if ($current_month >= 6) {
      $default_year = $current_year;
   } else {
      $default_year = $current_year - 1;
   }
   if (isset($formValues['thisyear'])) {
      $thisyear = $formValues['thisyear'];
   } else {
      $thisyear = $default_year;
   }
   if (isset($formValues['print_view'])) {
      $print_view = $formValues['print_view'];
   } else {
      $print_view = 0;
   }
   
   $projectid = $formValues['projectid'];

   $mpid = '-1';

   $controlHTML .= "<form method=post action='' id=control>";
   
   # did we get a save, insert or delete command?
   # if so, let's deal with it
   if (isset($formValues['actiontype'])) {
      $actiontype = $formValues['actiontype'];
   } else {
      $actiontype = '';
   }
   
   // is this a user who should be able to change the USERID paramater via a quicksearch?
   if ( in_array(4, split(',',$usergroupids)) ) {
      // show quick search form
      // handle quick search variables

      $controlHTML .= showHiddenField('quicksearch_enabled',0, 1);
      //$controlHTML .= showHiddenField('quicksearch_mpid',-1, 1);
      $controlHTML .= "<b>User ID:" . showWidthTextField('quicksearch_userid',$quicksearch_userid, 6, $quicksearch_userid, 1, 0) . " ";
      $controlHTML .= showGenericButton('quicksearch','Quick Search', " last_tab[\"facilitybased\"] = \"facilitybased_data0\"; last_button[\"facilitybased\"] = \"facilitybased_0\";  document.forms[\"control\"].elements.actiontype.value=\"change_facility\";  document.forms[\"control\"].elements.quicksearch_enabled.value=1 ;  document.forms[\"control\"].elements.print_view.value=0 ;  xajax_showVWUDSWebUserForm(xajax.getFormValues(\"control\"));   ", 1, 0);
      $controlHTML .= "<br>";
      // check for quicksearch button press
      if ( $formValues['quicksearch_enabled'] == 1 ) {
         // quick search button press, change action type to 'view' (not save or switch facility)
         $actiontype = 'view';
         $facilityid = $formValues['quicksearch_userid'];
      } else {
         if (isset($formValues['userid'])) {
            $facilityid = $formValues['userid'][0];
            //$controlHTML .= print_r($formValues,1) . "<BR>";
         }
      }
      
      // now show the year selector for this facility
      // do not show year selector if we do not have a facility
      if (strlen($facilityid) > 0) {
         $yrfoo = "  ( select \"YEAR\" as thisyear from annual_data ";
         $yrfoo .= " where \"USERID\" = '$facilityid' ";
         $yrfoo .= " group by thisyear ";
         $yrfoo .= " order by thisyear ) as foo ";
      
         $onchange = " last_tab[\"facilitybased\"] = \"facilitybased_data0\"; last_button[\"facilitybased\"] = \"facilitybased_0\";  document.forms[\"control\"].elements.actiontype.value=\"change_year\";   document.forms[\"control\"].elements.print_view.value=0 ;   xajax_showVWUDSWebUserForm(xajax.getFormValues(\"control\"));  ";

         $controlHTML .= "<br><b>Select the year to view: </b>" . showActiveList($listobject,'thisyear',$yrfoo, 'thisyear','thisyear','',$thisyear, $onchange, 'thisyear', 0, 1, 0) . "<br>";
      }
   } else {
      // #########################################
      // START - show the selector for multiple facilities
      // for this user
      // #########################################
      $user_facilities = showUserFacilitiesInfo($listobject, $userid, $facilityid, $thisyear);
      $facilities = $user_facilities['facilities'];
      $numfac = $user_facilities['numfac'];
      //$controlHTML .= "User can see: " . print_r($user_facilities,1) . "<br>";
      //$controlHTML .= "fq: " . $user_facilities['debug'] . "<br>";
      $facilityid = $user_facilities['selected'];
      $facname = $user_facilities['facname'];
      $controlHTML .= " Your user account is associated with $numfac facilities.  You are currently viewing facility #$facilityid, $facname" . ".<br>  ";
      $controlHTML .= "You may select from the list below to work on a different facility: <br><b>Change Facility: </b>";

      $onchange = " last_tab[\"facilitybased\"] = \"facilitybased_data0\"; last_button[\"facilitybased\"] = \"facilitybased_0\";  document.forms[\"control\"].elements.actiontype.value=\"change_facility\";   document.forms[\"control\"].elements.print_view.value=0 ;   xajax_showVWUDSWebUserForm(xajax.getFormValues(\"control\"));  ";
      $controlHTML .= showActiveList($user_facilities['facility_rows'], 'facilityid', '', 'facname','userid', '', $facilityid, $onchange, 'linktext', $debug, 1, 0, 'facquicklist');
      $controlHTML .= "<br><b>Note: </b> Facilities names preceded by an asterisk (*) have already had data submitted for this reporting year.";
      // comment this out, since we select facility in the line above
      //$controlHTML .= showHiddenField('facilityid',$facilityid, 1);
      $controlHTML .= showHiddenField('old_facilityid',$facilityid, 1);
      // #########################################
      // END - set up the blank record defaults
      // #########################################
       
      // now show the year selector for this facility
      // do not show year selector if we do not have a facility
      if (strlen($facilityid) > 0) {
         $yrfoo = "  (select \"YEAR\" as thisyear from annual_data ";
         $yrfoo .= " where \"USERID\" = '$facilityid' ";
         // only allow outside users to see years where they can still edit
         //$yrfoo .= "    and (eperms & 2) ";
         $yrfoo .= " group by thisyear ";
         $yrfoo .= " order by thisyear ) as foo ";
      
         $onchange = " last_tab[\"facilitybased\"] = \"facilitybased_data0\"; last_button[\"facilitybased\"] = \"facilitybased_0\";  document.forms[\"control\"].elements.actiontype.value=\"change_year\";   document.forms[\"control\"].elements.print_view.value=0 ;   xajax_showVWUDSWebUserForm(xajax.getFormValues(\"control\"));  ";

         $controlHTML .= "<br><b>Select the year to view: </b>" . showActiveList($listobject,'thisyear',$yrfoo, 'thisyear','thisyear','',$thisyear, $onchange, 'thisyear', 0, 1, 0) . "<br>";
      }
   }
   
   
   $controlHTML .= showHiddenField('actiontype',$actiontype, 1);
   $controlHTML .= showHiddenField('projectid',$projectid, 1);
   $controlHTML .= showHiddenField('print_view',$print_view, 1);
   $resultMSG = '';
   
   // get the record ownerid for all inserts for this facility
   $listobject->querystring = " select ownerid from facilities where userid = '$facilityid'";
   $listobject->performQuery();
   $ownerid = $listobject->getRecordValue(1,'ownerid');
   
   
   //$controlHTML .= "New school form";
   //$controlHTML .= print_r($formValues,1);
   
   // #########################################
   // START - set up the blank record defaults
   // #########################################
   //$omit = array('WELLNO','SOURCE');
   $omit = array();
   $blank_defaults = array();
   $blank_errors = array();
   $adminsetup = $adminsetuparray['annual_data'];
   foreach (array_keys($adminsetup['column info']) as $cn) {
      $dv = '';
      if (isset($adminsetup['column info'][$cn]['default'])) {
         $dv = $adminsetup['column info'][$cn]['default'];
      } else {
         $dv = '';
      }
      if (!in_array($cn, $omit)) {
         array_push($keys_used, $cn);
         $blank_defaults[$cn] = $dv;
      }
      $c++;

   }
   // set a couple of defaults
   $blank_defaults['MPID'] = -1;
   $blank_defaults['USERID'] = $facilityid;
   $blank_defaults['abandoned'] = 0;
   $blank_defaults['ADDYR_MP'] = $default_year;
   $cat_mp = '';
   if (isset($mprecord['CAT_MP'])) {
      $blank_defaults['CAT_MP'] = $mprecord['CAT_MP'];
      $cat_mp = $mprecord['CAT_MP'];
   }
   if (isset($mprecord['SIC_MP'])) {
      $blank_defaults['SIC_MP'] = $mprecord['SIC_MP'];
   }
   if (isset($mprecord['stcofips'])) {
      $blank_defaults['stcofips'] = $mprecord['stcofips'];
   }
   $blank_defaults['record_id'] = -1;
   // stash these blank_defaults - in case it is overwritten by the save routine
   $bd_cache = $blank_defaults;
   // place to hold inserts for new MP and ANNUAL
   $blank_queries = array();
   // #########################################
   // END - set up the blank record defaults
   // #########################################
   
   $edit_errors = array();
   $edit_defaults = array();
   $facility_errors = array();
   $facility_defaults = array();
   
   switch ($actiontype) {
      case 'save':
         //$controlHTML .= "Saving this facility.<br>";
         $save_result = saveVWUDSEntry2($listobject,$formValues, $ownerid,$debug);
         recordFacilityEdit($listobject, $userid, $facilityid, $thisyear);
         $resultMSG .= $save_result['resultMSG'];
         $errorMSG .= $save_result['errorMSG'];
         $controlHTML .= $save_result['innerHTML'];
         $edit_errors = $save_result['edit_errors'];
         $edit_defaults = $save_result['edit_defaults'];
         $blank_defaults = $save_result['blank_defaults'];
         $blank_errors = $save_result['blank_errors'];
         $blank_queries = $save_result['blank_queries'];
         $facility_errors = $save_result['facility_errors'];
         $facility_defaults = $save_result['facility_defaults'];
         $omit = $save_result['omit'];
      break;
      
      case 'change_facility':
         //$controlHTML .= "Saving this facility, and changing to a new one.<br>";
         if (isset($formValues['old_facilityid'])) {
            $old_facilityid = $formValues['old_facilityid'];
            $formcopy = $formValues;
            foreach (array_keys($formcopy['userid']) as $thiskey) {
               $formcopy['userid'][$thiskey] = $old_facilityid;
            }
            foreach (array_keys($formcopy['USERID']) as $thiskey) {
               $formcopy['USERID'][$thiskey] = $old_facilityid;
            }
            $save_result = saveVWUDSEntry2($listobject,$formValues, $ownerid,$debug);
            recordFacilityEdit($listobject, $userid, $old_facilityid, $thisyear);
         }
         $formValues = array();
         
      break;
      
   }
   // check to see if the defaults have been stepped on by the save routine, if so, grab the basics
   if (count($blank_defaults) == 0) {
      $blank_defaults = $bd_cache;
   }
   

   $search_view = 'edit'; # force edit view for now
   $listobject->show = 0;
   if ($debug) {
      $controlHTML .= "Search View: $search_view <br>";
   }
   
   
   $controlHTML .= "<div id=errorinfo class='errorInfo'>" . $errorMSG . "</div>";
   $controlHTML .= "<div id=errorinfo class='resultInfo'>" . $resultMSG . "</div>";
//   $controlHTML .= "<i><b>Search Results:</b> Search Returned $numrecs record(s) matching your criteria.</i><br>";

   switch ($search_view) {
      case 'list':
         $controlHTML .= "<div style=\"overflow: auto; height: 600px; width: 800px;\">";
         //$listobject->queryrecords = $props;
         #$listobject->tablename = 'vwuds_measuring_point';
         $listobject->showList();
         $controlHTML .= $listobject->outstring;
         $controlHTML .= "</div>";
      break;
      
      case 'detail' || 'edit':
         
         # create a paneled object
         # Panel #1: Facility Record
         # Panel #2: MP record
         # Panel #3: All withdrawal data for this facility/MP sorted by year, descending
         # panel #4: comments and other measurement info for each year, descending
         # Need to have q2uick navigation to other measuring points of this same facility
         # and quick navigation to other facilities by entering userid
         $taboutput = new tabbedListObject;
         $taboutput->width = '880px';
         $taboutput->height = '640px';
         $taboutput->name = 'facilitybased';
         $taboutput->tab_names = array('instructions', 'facility','measuringpoint','new_mp','vwp_exemption','sign_submit');
         if ($debug) {
            array_push($taboutput->tab_names, 'debug');
         }
         $taboutput->tab_buttontext = array(
            'instructions'=>'Instructions',
            'facility'=>'Facility Info',
            'measuringpoint'=>'Annual Withdrawal Data',
            'new_mp'=>'Add New Water Withdrawal',
            'sign_submit'=>'Sign and Submit'
         );
         if ($enable_vwp) {
            $taboutput->tab_buttontext['vwp_exemption'] = 'VWP Permit Exemption Info';
         }
            
         if ($debug) {
            $taboutput->tab_buttontext['debug'] = 'Debug Info';
         }
         
         $taboutput->init();
         $ins_info = file_get_contents("./html/instructions.html");
         $ins_data = array('YEAR'=>$thisyear);
         $as = $adminsetuparray['vwuds_instructions'];
         $ins_html = showCustomHTMLForm($listobject,$ins_data,$as, $ins_info, 0, -1, 0, 0);
         $taboutput->tab_HTML['instructions'] = "<div>" . $ins_html . "</div>";
         $taboutput->tab_HTML['facility'] .= "<b><font face='arial'>Facility Information:</font></b><br>";
         $taboutput->tab_HTML['measuringpoint'] .= "<b><font face='arial'>Measuring Point Info / Annual Data:</font></b><br>";
         $taboutput->tab_HTML['new_mp'] .= "<b><font face='arial'>Additional Water Withdrawals:</font></b><br>";
         if ($enable_vwp) {
            $taboutput->tab_HTML['vwp_exemption'] .= "<b><font face='arial'>VWP Permit Exemption Information Needed:</font></b><br>";
         }
         $taboutput->tab_HTML['sign_submit'] .= "<b><font face='arial'>Review, Sign and Submit Annual Water Reporting Forms</font></b><br>";
         if ($debug) {
            $taboutput->tab_HTML['debug'] .= "<b><font face='arial'>Debugging Information:</font></b><br>";
         }

         #$controlHTML .= "Props: " . print_r($props,1) . "<br>";
         # get facility information
         if (isset($props['MPID'])) {
            $mpid = $props['MPID'];
         }
         // extra message to go in the facility info/help panel
         $facility_msg .= "<b>Facility ID: $facilityid ";
         
         $adminname = 'facilities';
         $adminsetup = $adminsetuparray[$adminname];
         $tblname = $adminsetup['table info']['tabledef'];
         $listobject->querystring = "  select gid from $tblname where userid = '$facilityid' ";
         if ($debug) {
            $taboutput->tab_HTML['debug'] .= $listobject->querystring . " ;<br>";
         }
         $listobject->performQuery();
         $gid = $listobject->getRecordValue(1,'gid');
         $perms = getVWUDSPerms($listobject, $adminsetup, $gid, $userid, $usergroupids, 1);
         $ap = $perms['rowperms'] & 2;
         $facreadonly = 1;
         if ( ($perms['rowperms'] & 2) or ($perms['tableperms'] & 2)) {
            $facreadonly = 0;
         }
         if ($debug) {
            $taboutput->tab_HTML['debug'] .= print_r($perms, 1) . "<br> Read-Only (Facility Screen): $facreadonly <br>";
         }
         
         $listobject->querystring = "  select * from $tblname where userid = '$facilityid' ";
         if ($debug) {
            $taboutput->tab_HTML['debug'] .= $listobject->querystring . " ;<br>";
         }
         $listobject->performQuery();
         $facrecord = $listobject->queryrecords[0];
         
         $adminmod = $adminsetup;
         // show custom error information if this was an edit request
         foreach ($facility_errors as $error_column => $this_error) {
            $emsg = $this_error['error_msg'];
            $adminmod['column info'][$error_column]['comments'] = "<font color=red>* (" . $emsg . ")</font>";
            //$mpdatadiv .= $adminmod['column info'][$error_column]['comments'] . "<br>";
         }

         $mindex = 0;
         $ismulti = 1;
         $content = file_get_contents("./forms/facility.html");
         $facrecord['data_typename'] = 'facilities';
         $fac_html = showCustomHTMLForm($listobject,$facrecord,$adminmod, $content, $ismulti, $mindex, $debug = 0, $facreadonly);
         $taboutput->tab_HTML['facility'] .= $fac_html;
         $mindex++;
         
         $print_string .= $fac_html;
         ###########################################
         # BEGIN - Annual Data / MP Tab
         ###############################################
         // extra message to go in the MP / Annual Data info/help panel
         $mpannual_msg .= "";
         $content = file_get_contents("./forms/edwrd_mpannual.html");
         $mpa_out = showMPAnnualForms($listobject, $thisyear, $facilityid, $content, $mindex, $edit_errors, $edit_defaults,$mpannual_msg);
         $mpdatadiv = $mpa_out['dataforms'];
         $mpheaderdiv = $mpa_out['hotlist'];
         $mindex = $mpa_out['mindex'];
         $mprecord = $mpa_out['last_record'];
         $taboutput->tab_HTML['measuringpoint'] .= $mpdatadiv;
         $taboutput->tab_HTML['debug'] .= $mpa_out['debug'];
         $mpjumptext = $mpheaderdiv;
         
         $print_string .= $mpdatadiv;

         ###########################################
         # END - Annual Data / MP Tab
         ###########################################
         
         ###########################################
         # BEGIN - New MP Tab
         ###############################################
         // extra message to go in the NEW MP info/help panel
         $newmp_msg .= "";
         $taboutput->tab_HTML['new_mp'] .= "Note: Press the button labeled 'Save Reporting Form' after each new Measuring Point (MP) is Added.  This will save your new MP, refresh your screen, and present a new blank MP form.  Your new MP will appear along with your existing MPs in the panel labeled 'Annual Withdrawal Data'.<hr>";
         if (count($blank_errors) > 0) {
            // if there are errors here, it means they tried to enter a new MP and failed,
            // thus, we will leave the checkbox enabled. 
            // if not, they either succeeded, or did not try and therefore we make it off by default
            $insert_requested = 1;
         } else {
            $insert_requested = 0;
         }
         $taboutput->tab_HTML['new_mp'] .= showCheckBox("insert_requested[$mindex]", 1, $insert_requested, '', 1, 0);
         $taboutput->tab_HTML['new_mp'] .= " Check this box to add the following new withdrawal";
         $bmp_out = showBlankMPAnnualForm($listobject, $blank_defaults, $facilityid, $content, $mindex, $blank_errors, $blank_defaults);
         $blankrecdiv = $bmp_out['dataforms'];
         $mindex = $bmp_out['mindex'];
         $taboutput->tab_HTML['new_mp'] .= $blankrecdiv;

         ###########################################
         # END - New MP Tab
         ###############################################
         
         ###############################################
         # BEGIN - VWP Exemption Tab
         ###############################################
         
         // check to see if this record qualifies for needing VWP exemption feedback, as sigfnified by 
         // the following codes in permit_exemption field: 3, 4
         // if they DO need to provide feedback, we first check to see if there is a record in the 
         // database with some previous feedback, or simply a blank
         // if no record exists, we create one.  otherwise, we retrieve the data from it and populate the form
         // add a value of $formvalues['data_typename'] = 'vwp_exemption' to further distinguish between the multiple 
         // records on this page
         
         if ($enable_vwp) {
            // extra message to go in the NEW MP info/help panel
            $vwp_exemption_msg .= "";

            $vwp_ex_out = showVWPExemptionForm($listobject, $facilityid, $formValues, $mindex);
            $mindex = $vwp_ex_out['mindex'];

            $taboutput->tab_HTML['vwp_exemption'] .= $vwp_ex_out['innerHTML'];

            $print_string .= $vwp_ex_out['innerHTML'];
         }
         ###############################################
         # END - VWP Exemption Tab
         ###############################################

         ###########################################
         # BEGIN - Trend Analysis Tab
         ###############################################

         
         ###############################################
         ###  START - Pending Record Review Form
         ###############################################
         
         # make the form printed out read-only, in the style that it was mailed (looks as if you are reviewing a paper copy)
         # then, we can avoid the conflicts between the variable names in the MPID and facility records
         # the only variables that need to be returned are a lookup for a new MPID 
         // show the submission summary
         $error_summary = array();
         $message_summary = array();
         $error_summary['facility'] = $facility_errors;
         $error_summary['mp_annual'] = $edit_errors;
         $messages['facility'] = $facility_msg;
         $messages['mp_annual'] = $mpannual_msg;
         if ($enable_vwp) {
            $messages['vwp_exemption'] = $vwp_exemption_msg;
         }
         $ss_out = showSubmissionSummary($listobject, $formValues, $facilityid, $error_summary, $messages, $thisyear);
         $taboutput->tab_HTML['sign_submit'] .= $ss_out['innerHTML'];
         //$taboutput->tab_HTML['sign_submit'] .= print_r($facility_errors, 1) . "<br>";
         
         // show the formatted signature block
         $content = file_get_contents("./forms/sign_submit.html");
         $ss_out = showSignSubmitForm($listobject, $facilityid, $thisyear, $formValues, $content, $mindex);
         $taboutput->tab_HTML['sign_submit'] .= $ss_out['innerHTML'];
         //$taboutput->tab_HTML['sign_submit'] .= $ss_out['debug'];
         
         $print_string .= $ss_out['innerHTML'];
         ###############################################
         ###  END - Pending Record Review Form
         ###############################################
         // this will show the standard help text (the first parameter to showPanelInfo(), a URL)
         //, in addition to any additional info specific to this user (the second parameter, HTML formatted text)
         $taboutput->tab_onclick = array(
            'instructions'=>"xajax_showPanelInfo('./html/help_instructions.html','$facility_msg')",
            'facility'=>"xajax_showPanelInfo('./html/help_facility.html','$facility_msg')",
            'measuringpoint'=>"xajax_showPanelInfo('./html/help_mpannual.html','$mpannual_msg')",
            'new_mp'=>"xajax_showPanelInfo('./html/help_newmp.html','$newmp_msg')",
            'sign_submit'=>"xajax_showPanelInfo('./html/help_sign_submit.html','$sign_submit_msg')"
         );
         if ($enable_vwp) {
            $taboutput->tab_onclick['vwp_exemption'] = "xajax_showPanelInfo('./html/help_vwp_exemption.html', '$vwp_exemption_msg')"; 
         }
         $taboutput->createTabListView();
         $headinfo = file_get_contents("./html/head_reportform.html");
         $head_data = array('YEAR'=>$thisyear);
         $as = $adminsetuparray['vwuds_header'];
         $head_html = showCustomHTMLForm($listobject,$head_data,$as, $headinfo, 0, -1, 0, 0);
         $info = file_get_contents("./html/help_instructions.html");
         if (!$print_view) {
            $controlHTML .= "<div id=reportingform class='vwudsForm'>$head_html <br>";
            $controlHTML .= "<div id=infopanel class='panelInfo'>$info <br>$facility_msg</div>";
            $controlHTML .= $mpjumptext;
            $controlHTML .= $taboutput->innerHTML;
         } else {
            $controlHTML .= "<div id=reportingform class='vwudsPrint'>$head_html <br>";
            $controlHTML .= $print_string;
         }
         $controlHTML .= "</div>";
      break;
   }

   $save_script = "last_tab[\"facilitybased\"] = \"facilitybased_data0\"; last_button[\"facilitybased\"] = \"facilitybased_0\"; document.forms[\"control\"].elements.actiontype.value=\"save\";   document.forms[\"control\"].elements.print_view.value=0 ; xajax_showVWUDSWebUserForm(xajax.getFormValues(\"control\")); ";
   
   
   $controlHTML .= showGenericButton('save','Save Reporting Form', $save_script, 1, 0);

   $print_script = "last_tab[\"facilitybased\"] = \"facilitybased_data0\"; last_button[\"facilitybased\"] = \"facilitybased_0\"; document.forms[\"control\"].elements.actiontype.value=\"save\";   document.forms[\"control\"].elements.print_view.value=1 ; xajax_showVWUDSWebUserForm(xajax.getFormValues(\"control\")); ";
   
   
   $controlHTML .= showGenericButton('save','Save and Print', $print_script, 1, 0);
   $controlHTML .= "</form>";
   return $controlHTML;
}

function saveVWUDSEntry($listobject,$formValues, $ownerid, $debug) {
   global $adminsetuparray;

   // create containers to hold erroneous data fields, so that we can use these later, instead of 
   // retrieving the OLD db data, and losing the changes they were ATTEMPTING to make
   $controlHTML = "Saving records:<br>";
   $errorMSG = '';
   $resultMSG = '';
   $omit = array();
   $blank_defaults = array();
   $blank_errors = array();
   $edit_errors = array();
   $edit_defaults = array();
   $facility_errors = array();
   $facility_defaults = array();
   
   #$controlHTML .= print_r($formValues,1) . "<br>";
   # record 0 will have facility information
   # record 1 will ahve MP info
   # records 2-n if they exist, will have the annual data
   # look for annual_data records
   if (isset($formValues['userid'])) {
      $uid = $formValues['userid'][0];
      # save facility updates
      $formvars = array();
      #$controlHTML .= "Checking for variables: ";
      foreach (array_keys($formValues) as $thisvar) {
         #$controlHTML .= "<br>" . $thisvar . ' ';
         if (isset($formValues[$thisvar][0])) {
            #$thisvar is part of the annual data record, so include it in the form variables
            $formvars[$thisvar] = $formValues[$thisvar][0];
            #$controlHTML .= '(found) ';
         }
      }
      #$controlHTML .= "<br>";
      #$controlHTML .= print_r($formvars, 1) . "<br>";
      #$listobject->performQuery();
      $aset = $adminsetuparray['facilities'];
      # force these, since the multiform wants a PK, but we can't actually use the REAL pk (rec_id)
      # because it is possible that a records rec_id may have changed between form mail out and return
      # thus, we simply set mpid as a read-only pk, and later we will add our own where criteria
      # to make sure that we don't miss it
      #$aset['table info']['pkcol'] = 'mpid';
      #$formvars['mpid'] = $mpid;

      $update_rec = processMultiFormVars($listobject,$formvars,$aset,0,$debug, $nullpk = -1, $strictnull = 0);
      #print_r($update_rec);
      #$controlHTML .= print_r($formvars, 1) . "<br>";
      //$controlHTML .= print_r(array_keys($update_rec), 1) . "<br>";
      //$controlHTML .= "VALID COLS UPDATE: " . $update_rec['validcol_updatequery'] . "<br>";
      //$controlHTML .= print_r($update_rec, 1) . "<br>";
      if ($debug) {
         $taboutput->tab_HTML['debug'] .= $update_rec['debugstr'] . " ;<br>";
         $controlHTML .= $update_rec['debugstr'] . " ;<br>";
      }
      $rec_saved = 0;
      if (isset($formvars['userid'])) {
         $uid = $formvars['userid'];
         if ($uid == -1) {
            # insert
            $controlHTML .= "Blank record insert requested<br>";
            $listobject->querystring = $update_rec['insertsql'];
            # don't import yet, we will do this later, or write a nother script to handle this seperately
            #$controlHTML .= "$listobject->querystring ; <br>";
            #$listobject->performQuery();
         } else {
            # update
            #$controlHTML .= "Update requested<br>";
            if ( (!($update_rec['error']) or ((strlen($update_rec['validcol_updatequery']) > 0 ) )) ) {
               $listobject->querystring = "UPDATE facilities SET " . $update_rec['validcol_updatequery'] . " WHERE \"userid\" = '$uid'";
               if ($debug) {
                  $controlHTML .= "$listobject->querystring ; <br>";
               }
               $listobject->performQuery();
            } else {
               //$errorMSG .= "Error in Facility Data Entry: " . $update_rec['errormesg'] . "<br>";
               // stash this data for later use
               $facility_defaults = $formvars;
               $facility_errors = $update_rec['column_errors'];
               //$errorMSG .= "Errors: " . print_r($facility_errors,1) . "<br>";
            }
         }
         if ($listobject->error) {
            $errorMSG .= $listobject->error . "<br>";
            $facility_defaults = $formvars;
            $facility_errors = $update_rec['column_errors'];
         } else {
            $rec_saved++;
         }
      }
      if ($rec_saved) {
         $resultMSG .= "Facility Record $uid updated.<br>";
      }
   }

   if (isset($formValues['MPID'])) {
      $mpid = $formValues['MPID'][1];
   } else {
      $mpid = -1;
   }

   // the process will be as follows for new MPID requests
   // check for any data in the Blank MP form for any columns other than the defaults
   // if none of these other columns are set, we will not try to add our data
   #$controlHTML .= print_r($update_rec, 1) . "<br>";
   $rec_saved = 0;

   // *****************************************
   // *****   Handle MPID Changes/Insert  *****
   // *****************************************
   // changed $formValues['record_id'] to formValues['MPID'] in next two lines to see if we could catch 
   // the data better
   if (isset($formValues['MPID'])) {
      foreach (array_keys($formValues['MPID']) as $postkey) {
         $formvars = array();
         #$controlHTML .= "Checking for variables: ";
         foreach (array_keys($formValues) as $thisvar) {
            #$controlHTML .= $thisvar . ' ';
            if (isset($formValues[$thisvar][$postkey])) {
               #$thisvar is part of the annual data record, so include it in the form variables
               $formvars[$thisvar] = $formValues[$thisvar][$postkey];
               #$controlHTML .= '(found) ';
            }
         }

         $aset = $adminsetuparray['vwuds_measuring_point'];
         $formvars['USERID'] = $uid;

         $record_id = $formValues['record_id'][$postkey];
         // since these are hybrids, we have both the key on MP table 'record_id' and the key on Annual 'recid'
         $recid = $formValues['recid'][$postkey];
         $mpid = $formValues['MPID'][$postkey];
         // here we set this, if BOTH MP and ANNUAL data inserts are successful, we will set it to 0
         $insert_requested = 0;
         if (isset($formValues['insert_requested'][$postkey])) {
            $insert_requested = $formValues['insert_requested'][$postkey];
            $controlHTML .= "USing insert_requested variable from data set $postkey .<br>";
         }
         if ($mpid == -1) {
            $aset['table info']['table_name'] = 'vwuds_measuring_point_pending';
            $aset['column info']['USERID']['readonly'] = 0;
            $aset['column info']['REGION']['mandatory'] = 0;
            $formvars['ownerid'] = $ownerid;
         } else {
            // do settings for existing MPID update
            //$controlHTML .= "Mandatory setting for ACTION:" . $aset['column info']['ACTION']['mandatory'] . " <br>";
            $aset['column info']['ACTION']['mandatory'] = 0;
            $aset['column info']['TYPE']['mandatory'] = 0;
            $aset['column info']['REGION']['mandatory'] = 0;
            $aset['column info']['SUBTYPE']['mandatory'] = 0;
            $aset['column info']['lon_flt']['mandatory'] = 0;
            $aset['column info']['lat_flt']['mandatory'] = 0;
            $aset['column info']['ownerid']['mandatory'] = 0;
            $aset['column info']['R_BASIN']['mandatory'] = 0;
            //$controlHTML .= "mandatory disabled for select MP fields <br>";
         }
         $update_rec = processMultiFormVars($listobject,$formvars,$aset,0,$debug, $nullpk = -1, 1);
         if ($mpid == -1) {
            // check to see if this is really a valid insert attempt, as indicated by the presence of 
            // certain input variables

            //$controlHTML .= print_r($update_rec,1) . "<br>";
            if (!$update_rec['error'] and $insert_requested ) {
               // only insert MP if BOTH an MP and an ANNUAL record are valid, so just process it here, 
               // when we get to the annual data part, we can evaluate if we will do it all
               // stash this to insert later if both MP and ANNUAL are good to go
               $blank_queries['mp'] = $update_rec;
            } else {
               if ( $insert_requested ) {
                  // if we actually requested an insert, report some error info
                  $errorMSG .= "Error in MP Data Insert: " . $update_rec['errormesg'] . " (see 'Add New Water Withdrawal' for details).<br>";
                  $blank_errors = $update_rec['column_errors'];
                  //$controlHTML .= print_r($update_rec['column_errors'],1) . "<br>";
               }
               //$controlHTML .= print_r($update_rec,1) . "<br>";
               //$controlHTML .= "VALID COLS UPDATE: " . $update_rec['validcol_updatequery'] . "<br>";
            }

         } else {
            # update
            #$controlHTML .= "Update requested<br>";
            //$controlHTML .= print_r($update_rec,1) . "<br>";
            if (!$update_rec['error']) {
               $listobject->querystring = "UPDATE vwuds_measuring_point SET " . $update_rec['validcol_updatequery'] . " WHERE record_id = $record_id";
               if ($debug) {
                  $controlHTML .= "$listobject->querystring ; <br>";
               }
               $listobject->performQuery();
               if ($listobject->error) {
                  $errorMSG .= "Measuring Point record $mpid: " . $listobject->error . "<br>";
                  //$errorMSG .= "$listobject->querystring ; <br>";
                  // stash this data for later use
                  $edit_defaults[$recid] = $formvars;
                  $edit_errors[$recid] = $update_rec['column_errors'];
               } else {
                  $rec_saved++;
               }
            } else {
               if ($postkey == 1) {
                  // only show the first occurence while debugging
                  //$errorMSG .= "Error in MP Data Edit: " . $update_rec['debugstr'] . "<br>";
                  //$errorMSG .= print_r($update_rec['column_errors'],1) . "<br>";
               }
               // stash this data for later use
               $edit_defaults[$recid] = $formvars;
               $edit_errors[$recid] = $update_rec['column_errors'];
            }
            //$controlHTML .= "VALID COLS UPDATE: " . $update_rec['validcol_updatequery'] . "<br>";
         }
      }
   }
   if ($rec_saved) {
      $resultMSG .= "$rec_saved MP records updated.<br>";
   }
   // *****************************************
   // *****   END -- MPID Changes/Insert  *****
   // *****************************************

   // *****************************************
   // *****   Annual Data Changes/Insert  *****
   // *****************************************
   # save annual_data updates
   $rec_saved = 0;
   if (isset($formValues['JANUARY'])) {
      foreach (array_keys($formValues['JANUARY']) as $postkey) {
         $formvars = array();
         #$controlHTML .= "Checking for variables: ";
         foreach (array_keys($formValues) as $thisvar) {
            #$controlHTML .= $thisvar . ' ';
            if (isset($formValues[$thisvar][$postkey])) {
               #$thisvar is part of the annual data record, so include it in the form variables
               $formvars[$thisvar] = $formValues[$thisvar][$postkey];
               #$controlHTML .= '(found) ';
            }
         }
         // set userid for use later in inserts
         $formvars['USERID'] = $uid;
         //$controlHTML .= "<br>";
         //$controlHTML .= print_r($formvars, 1) . "<br>";
         $aset = $adminsetuparray['annual_data'];
         $yr = $formValues['JANUARY'][$postkey];
         # force these, since the multiform wants a PK, but we can't actually use the REAL pk (rec_id)
         # because it is possible that a records rec_id may have changed between form mail out and return
         # thus, we simply set mpid as a read-only pk, and later we will add our own where criteria
         # to make sure that we don't miss it
         // however, if the recid == -1, then we have passed in a new MP/annual record to be inserted
         #$aset['table info']['pkcol'] = 'mpid';
         #$formvars['mpid'] = $mpid;
         if (isset($formvars['recid'])) {
            $recid = $formvars['recid'];
            $mpid = $formvars['MPID'];
         }
         if ($recid == -1) {
            // blank insert, set table to annual_data_pending
            $aset['table info']['table_name'] = 'annual_data_pending';
            // need to be able to write userid for an insert
            $aset['column info']['USERID']['readonly'] = 0;
            $aset['column info']['MPID']['readonly'] = 0;
            $aset['column info']['ACTION']['readonly'] = 0;
            $aset['column info']['YEAR']['readonly'] = 0;
            $formvars['YEAR'] = $formValues['thisyear'];
         }

         $update_rec = processMultiFormVars($listobject,$formvars,$aset,0,$debug, $nullpk = -1, $strictnull = 0);

         if (isset($formvars['recid'])) {
            if ( ($recid == -1) ) {
               // regardless of whether there was an insert request, if we reach here, we need to preserve the 
               // values in the blank record form
               //$controlHTML .= "<b> Checking blank record annual data portion</b><br>";
               //$controlHTML .= "<b> Insert request Form variable</b> " . print_r($formValues['insert_requested'],1) . "<br>";
               //$controlHTML .= "<b> Local request Form variable</b> $insert_requested <br>";
               if ($insert_requested) {
                  $controlHTML .= "<b> New record insert requested, MP OK, handling annual data portion</b><br>";
                  if (!$update_rec['error'] and (count($blank_errors) == 0) ) {
                     $controlHTML .= "<b>New Annual Data OK</b><br>";
                     // now, we check to see if the MP has been inserted OK, if not, we stash and throw an error
                     // if count($blank_errors) is 0, hn we know that the MP part of the record was OK,
                     // and the update_rec error is false, so the annual data part is OK.  thus, we go ahead and 
                     // save the record
                     //$controlHTML .= "Blank MP insert requested<br>";
                     $listobject->querystring = $blank_queries['mp']['insertsql'];
                     $controlHTML .= "$listobject->querystring ; <br>";
                     $listobject->performQuery();
                     // we can only proceed to saving the annual data if we have a valid measuring point to 
                     // associate it with
                     if ($listobject->error) {
                        $errorMSG .= "New Measuring Point Insert Error: " . $listobject->error . "<br>";
                        $blank_defaults = $formvars;
                     } else {
                        $rec_saved++;
                        // now get the new MPID and insert the annual data
                        $listobject->querystring = "SELECT currval('vwuds_measuring_point_record_id_seq') ";
                        $listobject->performQuery();
                        #$innerHTML .= "$listobject->outstring <br>";
                        $newrecid = $listobject->getRecordValue(1,'currval');
                        $listobject->querystring = "SELECT \"MPID\" from vwuds_measuring_point_pending where record_id = $newrecid ";
                        //$controlHTML .= "$listobject->querystring ; <br>";
                        $listobject->performQuery();
                        #$innerHTML .= "$listobject->outstring <br>";
                        //$controlHTML .= "Insert Record result: ";
                        //$controlHTML .= print_r($listobject->queryrecords,1) . "<br>";
                        $mpid = $listobject->getRecordValue(1,'MPID');
                        // now, stash this so that we can use it later with our inserts
                        $formvars['MPID'] = $mpid;
                        // now that we have a valid MP, 
                        // reprocess this with our valid MP 
                        $update_rec = processMultiFormVars($listobject,$formvars,$aset,0,$debug, $nullpk = -1, $strictnull = 0);
                        # insert
                        if (!$update_rec['error']) {
                           $controlHTML .= "<b>Blank annual record looks OK</b><br>";
                           //$controlHTML .= print_r($update_rec,1) . "<br>";
                           $listobject->querystring = $update_rec['insertsql'];
                           //if ($debug) {
                              $controlHTML .= "InsertSQL: $listobject->querystring ; <br>";
                           //}
                           $listobject->performQuery();
                           if (!$listobject->error) {
                              // everything went according to plan, clear the blank record insert form
                              $controlHTML .= "<b>New Annual record Insert successful. </b><br>";
                              $blank_defaults = array();
                           } else {
                              $errorMSG .= "New Annual record Insert Error: " . $listobject->error . "<br>";
                              $blank_defaults = $formvars;
                           }
                        } else {
                           $controlHTML .= "<b>Error inserting ANNUAL DATA for new MP (see 'Add New Water Withdrawal' for details).</b><br>";
                           $blank_defaults = $formvars;
                        }
                     }
                  } else {
                     //$controlHTML .= "<b>Error inserting annual data for new MP (see 'Add New Water Withdrawal' for details).</b><br>";
                     $blank_defaults = $formvars;
                     // either we have errors in this Anunal record, or we had MP errors associated with this record
                     // if we did NOT have an MP error, we set the $blank_errors to = the Annual errors
                     if (!count($blank_errors) > 0) {
                        $blank_errors = $update_rec['column_errors'];
                     } else {
                     // otherwise, we just want to add the columns from this particular part of the record 
                     // - annual_data part - if we had any errors
                        foreach ($update_rec['column_errors'] as $ecol => $ee) {
                           $blank_errors[$ecol] = $ee;
                        }
                     }
                     $errorMSG .= "Error inserting annual data for new MP (see 'Add New Water Withdrawal' for details).<br>";
                     //$controlHTML .=  print_r($update_rec['column_errors'],1) . "<br>";
                  }
               } else {
                  // no insert requested, but we may have data, so stash it
                  $blank_defaults = $formvars;
               }
            } else {
               // this is NOT a new record request, so go ahead and handle it normally
               if ( (!($update_rec['error']) or (($recid > 0) and (strlen($update_rec['validcol_updatequery']) > 0 ) )) ) {
                  # update
                  $listobject->querystring = "UPDATE annual_data SET " . $update_rec['validcol_updatequery'] . " WHERE \"recid\" = '$recid'";
                  if ($debug) {
                     $controlHTML .= "$listobject->querystring ; <br>";
                  }
                  $listobject->performQuery();
               }
               if ($update_rec['error']) {
                  // we may have processed this by saving only valid columns, but still need to report the 
                  // errors back to the user, so check for 'error' and stash the messages
                  // need to see if this has already been set in the edit_errors array by the MP routine
                  if (!isset($edit_errors[$recid])) {
                     // No, just stash this data for later use
                     $edit_defaults[$recid] = $formvars;
                     $edit_errors[$recid] = $update_rec['column_errors'];
                  } else {
                     // Yes, we don't need to do anything with the values, 
                     // since the entire record that was submitted has already been added to $edit_defaults
                     // but we need to add the error messages from these annual_data columns
                     foreach ($update_rec['column_errors'] as $ecol => $ee) {
                        $edit_errors[$recid][$ecol] = $ee;
                     }
                  }
               }
            }
         }
         if ($listobject->error) {
            $errorMSG .= "Annual Data record for $yr: " . $listobject->error . "<br>";
         } else {
            $rec_saved++;
         }
      }
   }
   // *****************************************
   // *****   END -- Data Changes/Insert  *****
   // *****************************************


   // *****************************************
   // *****     VWP Exemption Responses   *****
   // *****************************************

   /*
   if (isset($formValues['exemption_id'])) {
      $fv = array();
      $aset = $adminsetuparray['vwp_exemption'];
      foreach (array_keys($formValues['exemption_id']) as $formkey) {
         foreach (array_keys($aset['column info']) as $colkey) {
            if (isset($formValues[$colkey][$formkey])) {
               $fv[$colkey] = $formValues[$colkey][$formkey];
            }
         }
         $exemption_response = processVWPExemptionForm($listobject, $formValues);
         if (!$exemption_response['error']) {
            $controlHTML .= $exemption_response['resultHTML'];
         } else {
            $errorMSG .= $exemption_response['errorMSG'];
         }
      }
   }
   */
   // *****************************************
   // *****     END -- VWP Exemption      *****
   // *****************************************


   // *****************************************
   // *****     Signature and Submittal   *****
   // *****************************************
   if (isset($formValues['acknowledgement'])) {
      
      
   }

   // *****************************************
   // ***** END - Signature and Submittal *****
   // *****************************************
   if ($rec_saved) {
      $resultMSG .= "$rec_saved Annual Record(s) Saved.<br>";
   }
   
   //$controlHTML .= "Hello? Anyone? McFly?<br>";
   //$resultMSG .= "Data_typename: " . print_r($formValues['data_typename'],1) . "<br>";
   
   $results = array();
   $results['rec_saved'] .= $rec_saved;
   $results['resultMSG'] .= $resultMSG;
   $results['errorMSG'] .= $errorMSG;
   $results['innerHTML'] = $controlHTML;
   $results['edit_errors'] = $edit_errors;
   $results['edit_defaults'] = $edit_defaults;
   $results['blank_defaults'] = $blank_defaults;
   $results['blank_errors'] = $blank_errors;
   $results['blank_queries'] = $blank_queries;
   $results['facility_errors'] = $facility_errors;
   $results['facility_defaults'] = $facility_defaults;
   $results['omit'] = $omit;
   
   return $results;
}

function recordFacilityEdit($listobject, $userid, $facility_id, $thisyear) {
   $listobject->querystring = "  insert into vwuds_edit_audit (editorid, facility_id, submittal_year) ";
   $listobject->querystring .= " values ($userid, '$facility_id', $thisyear) ";
   $listobject->performQuery();
}

function saveVWUDSEntry2($listobject,$formValues, $ownerid, $debug) {
   global $adminsetuparray;

   // create containers to hold erroneous data fields, so that we can use these later, instead of 
   // retrieving the OLD db data, and losing the changes they were ATTEMPTING to make
   $controlHTML = '';
   $errorMSG = '';
   $resultMSG = '';
   $omit = array();
   $blank_defaults = array();
   $blank_errors = array();
   $edit_errors = array();
   $edit_defaults = array();
   $facility_errors = array();
   $facility_defaults = array();
   // set default year
   $current_year = date('Y');
   $current_month = date('n');
   if ($current_month >= 6) {
      $default_year = $current_year;
   } else {
      $default_year = $current_year - 1;
   }
   
   $form_pieces = array_keys($formValues['data_typename']);
   $annualrec_saved = 0;
   $mprec_saved = 0;
   $facrec_saved = 0;
   $newannualrec_saved = 0;
   //$controlHTML .= "January records: " . print_r(array_keys($formValues['JANUARY']), 1) . "<br>";
   
   foreach ($form_pieces as $pieceid) {
      
      $dt = $formValues['data_typename'][$pieceid];

      $formvars = array();
      #$controlHTML .= "Checking for variables: ";
      foreach (array_keys($formValues) as $thisvar) {
         #$controlHTML .= $thisvar . ' ';
         if (isset($formValues[$thisvar][$pieceid])) {
            #$thisvar is part of the annual data record, so include it in the form variables
            $formvars[$thisvar] = $formValues[$thisvar][$pieceid];
            #$controlHTML .= '(found) ';
         }
      }

      // Data_typename: 
      // facilities
      // annual_data (twice, for an existing facility AND a new facility )
      // vwp_exclusion
      // vwuds_annual_submission )       
      switch ($dt) {
         case 'facilities':
         // *****************************************
         // ***** BEGIN - Facility Information  *****
         // *****************************************
   
         #$controlHTML .= print_r($formValues,1) . "<br>";
         # record 0 will have facility information
         # record 1 will ahve MP info
         # records 2-n if they exist, will have the annual data
         # look for annual_data records
         if (isset($formValues['userid'])) {
            $uid = $formValues['userid'][0];
            # save facility updates
            $aset = $adminsetuparray['facilities'];

            $update_rec = processMultiFormVars($listobject,$formvars,$aset,0,$debug, $nullpk = -1, $strictnull = 0);
            if ($debug) {
               $taboutput->tab_HTML['debug'] .= $update_rec['debugstr'] . " ;<br>";
               $controlHTML .= $update_rec['debugstr'] . " ;<br>";
            }
            if (isset($formvars['userid'])) {
               $uid = $formvars['userid'];
               if ($uid == -1) {
                  # insert
                  $controlHTML .= "Blank record insert requested<br>";
                  $listobject->querystring = $update_rec['insertsql'];
                  # don't import yet, we will do this later, or write a nother script to handle this seperately
                  #$controlHTML .= "$listobject->querystring ; <br>";
                  #$listobject->performQuery();
               } else {
                  # update
                  #$controlHTML .= "Update requested<br>";
                  if ( (!($update_rec['error']) or ((strlen($update_rec['validcol_updatequery']) > 0 ) )) ) {
                     $listobject->querystring = "UPDATE facilities SET " . $update_rec['validcol_updatequery'] . " WHERE \"userid\" = '$uid'";
                     if ($debug) {
                        $controlHTML .= "$listobject->querystring ; <br>";
                     }
                     $listobject->performQuery();
                  } else {
                     //$errorMSG .= "Error in Facility Data Entry: " . $update_rec['errormesg'] . "<br>";
                     // stash this data for later use
                     $facility_defaults = $formvars;
                     $facility_errors = $update_rec['column_errors'];
                     //$errorMSG .= "Errors: " . print_r($facility_errors,1) . "<br>";
                  }
               }
               if ($listobject->error) {
                  $errorMSG .= $listobject->error . "<br>";
                  $facility_defaults = $formvars;
                  $facility_errors = $update_rec['column_errors'];
               } else {
                  $facrec_saved++;
               }
            }
         }
         
         // *****************************************
         // *****   END - Facility Information  *****
         // *****************************************
         break;

         case 'annual_data':
         // *****************************************
         // *****   Handle MPID Changes/Insert  *****
         // *****   AND Annual Data inserts     *****
         // *****************************************

         if (isset($formvars['MPID'])) {
            $mpid = $formvars['MPID'];
         } else {
            $mpid = -1;
         }

         // the process will be as follows for new MPID requests
         // check for any data in the Blank MP form for any columns other than the defaults
         // if none of these other columns are set, we will not try to add our data
         #$controlHTML .= print_r($update_rec, 1) . "<br>";
         // changed $formValues['record_id'] to formValues['MPID'] in next two lines to see if we could catch 
         // the data better
         if (isset($formvars['MPID'])) {
            $aset = $adminsetuparray['vwuds_measuring_point'];
            $formvars['USERID'] = $uid;

            $record_id = $formvars['record_id'];
            // since these are hybrids, we have both the key on MP table 'record_id' and the key on Annual 'recid'
            $recid = $formvars['recid'];
            $mpid = $formvars['MPID'];
            // here we set this, if BOTH MP and ANNUAL data inserts are successful, we will set it to 0
            $insert_requested = 0;
            if (isset($formvars['insert_requested'])) {
               $insert_requested = $formvars['insert_requested'];
               $controlHTML .= "Using insert_requested variable from data set $pieceid .<br>";
            }
            // customize adminsetup record
            $aset['column info']['ownname']['mandatory'] = 0;
            $aset['column info']['facility']['mandatory'] = 0;
            if ($mpid == -1) {
               $aset['table info']['table_name'] = 'vwuds_measuring_point_pending';
               $aset['column info']['USERID']['readonly'] = 0;
               $aset['column info']['REGION']['mandatory'] = 0;
               $formvars['ownerid'] = $ownerid;
               $formvars['ADDYR_MP'] = $default_year;
               //$controlHTML .= print_r($formvars,1) . "<br>";
            } else {
               // do settings for existing MPID update
               //$controlHTML .= "Mandatory setting for ACTION:" . $aset['column info']['ACTION']['mandatory'] . " <br>";
               $aset['column info']['ACTION']['mandatory'] = 0;
               $aset['column info']['TYPE']['mandatory'] = 0;
               $aset['column info']['REGION']['mandatory'] = 0;
               $aset['column info']['SUBTYPE']['mandatory'] = 0;
               $aset['column info']['lon_flt']['mandatory'] = 0;
               $aset['column info']['lat_flt']['mandatory'] = 0;
               $aset['column info']['ownerid']['mandatory'] = 0;
               $aset['column info']['R_BASIN']['mandatory'] = 0;
               //$controlHTML .= "mandatory disabled for select MP fields <br>";
            }
            $update_rec = processMultiFormVars($listobject,$formvars,$aset,0,$debug, $nullpk = -1, 1);
            if ($mpid == -1) {
               // check to see if this is really a valid insert attempt, as indicated by the presence of 
               // certain input variables

               //$controlHTML .= print_r($update_rec,1) . "<br>";
               if (!$update_rec['error'] and $insert_requested ) {
                  // only insert MP if BOTH an MP and an ANNUAL record are valid, so just process it here, 
                  // when we get to the annual data part, we can evaluate if we will do it all
                  // stash this to insert later if both MP and ANNUAL are good to go
                  $blank_queries['mp'] = $update_rec;
               } else {
                  if ( $insert_requested ) {
                     // if we actually requested an insert, report some error info
                     $errorMSG .= "Error in MP Data Insert: " . $update_rec['errormesg'] . " (see 'Add New Water Withdrawal' for details).<br>";
                     $blank_errors = $update_rec['column_errors'];
                     //$controlHTML .= print_r($update_rec['column_errors'],1) . "<br>";
                  }
                  //$controlHTML .= print_r($update_rec,1) . "<br>";
                  //$controlHTML .= "VALID COLS UPDATE: " . $update_rec['validcol_updatequery'] . "<br>";
               }

            } else {
               # update
               #$controlHTML .= "Update requested<br>";
               //$controlHTML .= print_r($update_rec,1) . "<br>";
               if (!$update_rec['error']) {
                  $listobject->querystring = "UPDATE vwuds_measuring_point SET " . $update_rec['validcol_updatequery'] . " WHERE record_id = $record_id";
                  if ($debug) {
                     $controlHTML .= "$listobject->querystring ; <br>";
                  }
                  $listobject->performQuery();
                  if ($listobject->error) {
                     $errorMSG .= "Measuring Point record $mpid: " . $listobject->error . "<br>";
                     //$errorMSG .= "$listobject->querystring ; <br>";
                     // stash this data for later use
                     $edit_defaults[$recid] = $formvars;
                     $edit_errors[$recid] = $update_rec['column_errors'];
                  } else {
                     $mprec_saved++;
                  }
               } else {
                  if ($postkey == 1) {
                     // only show the first occurence while debugging
                     //$errorMSG .= "Error in MP Data Edit: " . $update_rec['debugstr'] . "<br>";
                     //$errorMSG .= print_r($update_rec['column_errors'],1) . "<br>";
                  }
                  // stash this data for later use
                  $edit_defaults[$recid] = $formvars;
                  $edit_errors[$recid] = $update_rec['column_errors'];
               }
               //$controlHTML .= "VALID COLS UPDATE: " . $update_rec['validcol_updatequery'] . "<br>";
            }
         }
         
         // *****************************************
         // *****   END -- MPID Changes/Insert  *****
         // *****************************************

         // *****************************************
         // *****   Annual Data Changes/Insert  *****
         // *****************************************
         # save annual_data updates
         if (isset($formvars['JANUARY'])) {
            // set userid for use later in inserts
            $formvars['USERID'] = $uid;
            //$controlHTML .= "<br>";
            //$controlHTML .= print_r($formvars, 1) . "<br>";
            $aset = $adminsetuparray['annual_data'];
            $yr = $formvars['JANUARY'];
            # force these, since the multiform wants a PK, but we can't actually use the REAL pk (rec_id)
            # because it is possible that a records rec_id may have changed between form mail out and return
            # thus, we simply set mpid as a read-only pk, and later we will add our own where criteria
            # to make sure that we don't miss it
            // however, if the recid == -1, then we have passed in a new MP/annual record to be inserted
            #$aset['table info']['pkcol'] = 'mpid';
            #$formvars['mpid'] = $mpid;
            if (isset($formvars['recid'])) {
               $recid = $formvars['recid'];
               $mpid = $formvars['MPID'];
            }
            // customize adminsetup record for this interface
            $aset['column info']['ownname']['mandatory'] = 0;
            $aset['column info']['facility']['mandatory'] = 0;
            if ($recid == -1) {
               // blank insert, set table to annual_data_pending
               $aset['table info']['table_name'] = 'annual_data_pending';
               // need to be able to write userid for an insert
               $aset['column info']['USERID']['readonly'] = 0;
               $aset['column info']['MPID']['readonly'] = 0;
               $aset['column info']['ACTION']['readonly'] = 0;
               $aset['column info']['YEAR']['readonly'] = 0;
               $formvars['YEAR'] = $formValues['thisyear'];
            }

            $update_rec = processMultiFormVars($listobject,$formvars,$aset,0,$debug, $nullpk = -1, $strictnull = 0);

            if (isset($formvars['recid'])) {
               if ( ($recid == -1) ) {
                  // regardless of whether there was an insert request, if we reach here, we need to preserve the 
                  // values in the blank record form
                  //$controlHTML .= "<b> Checking blank record annual data portion</b><br>";
                  //$controlHTML .= "<b> Insert request Form variable</b> " . print_r($formvars['insert_requested'],1) . "<br>";
                  //$controlHTML .= "<b> Local request Form variable</b> $insert_requested <br>";
                  if ($insert_requested) {
                     $controlHTML .= "<b> New record insert requested, MP OK, handling annual data portion</b><br>";
                     if (!$update_rec['error'] and (count($blank_errors) == 0) ) {
                        $controlHTML .= "<b>New Annual Data OK</b><br>";
                        // now, we check to see if the MP has been inserted OK, if not, we stash and throw an error
                        // if count($blank_errors) is 0, hn we know that the MP part of the record was OK,
                        // and the update_rec error is false, so the annual data part is OK.  thus, we go ahead and 
                        // save the record
                        //$controlHTML .= "Blank MP insert requested<br>";
                        $listobject->querystring = $blank_queries['mp']['insertsql'];
                        //$controlHTML .= "$listobject->querystring ; <br>";
                        $listobject->performQuery();
                        // we can only proceed to saving the annual data if we have a valid measuring point to 
                        // associate it with
                        if ($listobject->error) {
                           $errorMSG .= "New Annual Data Insert Error: " . $listobject->error . "<br>";
                           $blank_defaults = $formvars;
                        } else {
                           $newmprec_saved++;
                           // now get the new MPID and insert the annual data
                           $listobject->querystring = "SELECT currval('vwuds_measuring_point_record_id_seq') ";
                           $listobject->performQuery();
                           #$innerHTML .= "$listobject->outstring <br>";
                           $newrecid = $listobject->getRecordValue(1,'currval');
                           $listobject->querystring = "SELECT \"MPID\" from vwuds_measuring_point_pending where record_id = $newrecid ";
                           //$controlHTML .= "$listobject->querystring ; <br>";
                           $listobject->performQuery();
                           #$innerHTML .= "$listobject->outstring <br>";
                           //$controlHTML .= "Insert Record result: ";
                           //$controlHTML .= print_r($listobject->queryrecords,1) . "<br>";
                           $mpid = $listobject->getRecordValue(1,'MPID');
                           // now, stash this so that we can use it later with our inserts
                           $formvars['MPID'] = $mpid;
                           // now that we have a valid MP, 
                           // reprocess this with our valid MP 
                           $update_rec = processMultiFormVars($listobject,$formvars,$aset,0,$debug, $nullpk = -1, $strictnull = 0);
                           # insert
                           if (!$update_rec['error']) {
                              $controlHTML .= "<b>Blank annual record looks OK</b><br>";
                              //$controlHTML .= print_r($update_rec,1) . "<br>";
                              $listobject->querystring = $update_rec['insertsql'];
                              if ($debug) {
                                 $controlHTML .= "InsertSQL: $listobject->querystring ; <br>";
                              }
                              $listobject->performQuery();
                              if (!$listobject->error) {
                                 // everything went according to plan, clear the blank record insert form
                                 $controlHTML .= "<b>New Annual record Insert successful. </b><br>";
                                 $blank_defaults = array();
                                 $newannualrec_saved++;
                              } else {
                                 $errorMSG .= "New Annual record Insert Error: " . $listobject->error . "<br>";
                                 $blank_defaults = $formvars;
                              }
                           } else {
                              $controlHTML .= "<b>Error inserting ANNUAL DATA for new MP (see 'Add New Water Withdrawal' for details).</b><br>";
                              $blank_defaults = $formvars;
                           }
                        }
                     } else {
                        //$controlHTML .= "<b>Error inserting annual data for new MP (see 'Add New Water Withdrawal' for details).</b><br>";
                        $blank_defaults = $formvars;
                        // either we have errors in this Annual record, or we had MP errors associated with this record
                        // if we did NOT have an MP error, we set the $blank_errors to = the Annual errors
                        if (!count($blank_errors) > 0) {
                           $blank_errors = $update_rec['column_errors'];
                        } else {
                        // otherwise, we just want to add the columns from this particular part of the record 
                        // - annual_data part - if we had any errors
                           foreach ($update_rec['column_errors'] as $ecol => $ee) {
                              $blank_errors[$ecol] = $ee;
                           }
                        }
                        $errorMSG .= "Error inserting annual data for new MP (see 'Add New Water Withdrawal' for details).<br>";
                        //$controlHTML .=  print_r($update_rec['column_errors'],1) . "<br>";
                     }
                  } else {
                     // no insert requested, but we may have data, so stash it
                     $blank_defaults = $formvars;
                  }
               } else {
                  // this is NOT a new record request, so go ahead and handle it normally
                  if ( (!($update_rec['error']) or (($recid > 0) and (strlen($update_rec['validcol_updatequery']) > 0 ) )) ) {
                     # update
                     $listobject->querystring = "UPDATE annual_data SET " . $update_rec['validcol_updatequery'] . " WHERE \"recid\" = '$recid'";
                     if ($debug) {
                        $controlHTML .= "$listobject->querystring ; <br>";
                     }
                     $listobject->performQuery();
                     if ($listobject->error) {
                        $errorMSG .= "Annual Data record for $yr: " . $listobject->error . "<br>";
                     } else {
                        $annualrec_saved++;
                     }
                  }
                  if ($update_rec['error']) {
                     // we may have processed this by saving only valid columns, but still need to report the 
                     // errors back to the user, so check for 'error' and stash the messages
                     // need to see if this has already been set in the edit_errors array by the MP routine
                     if (!isset($edit_errors[$recid])) {
                        // No, just stash this data for later use
                        $edit_defaults[$recid] = $formvars;
                        $edit_errors[$recid] = $update_rec['column_errors'];
                     } else {
                        // Yes, we don't need to do anything with the values, 
                        // since the entire record that was submitted has already been added to $edit_defaults
                        // but we need to add the error messages from these annual_data columns
                        foreach ($update_rec['column_errors'] as $ecol => $ee) {
                           $edit_errors[$recid][$ecol] = $ee;
                        }
                     }
                  }
               }
            }
         }
         // *****************************************
         // *****   END -- Data Changes/Insert  *****
         // *****************************************
         break;


         // *****************************************
         // *****     VWP Exemption Responses   *****
         // *****************************************

         
         case 'vwp_exclusion':
         if (isset($formvars['exemption_id'])) {
            $aset = $adminsetuparray['vwp_exemption'];
            $exemption_response = processVWPExemptionForm($listobject, $formvars);
            if (!$exemption_response['error']) {
               $controlHTML .= "<br>Exemption response: " . $exemption_response['resultHTML'];
            } else {
               $errorMSG .= "<br>VWP Exemption form error: " . $exemption_response['errorMSG'];
            }
         }
         break;
         
         // *****************************************
         // *****     END -- VWP Exemption      *****
         // *****************************************

         case 'vwuds_submittal':
         // *****************************************
         // *****     Signature and Submittal   *****
         // *****************************************
         if (isset($formvars['acknowledgement'])) {
            $controlHTML .= "<br>Handling submission request.<br>";
            //$controlHTML .= print_r($formvars,1) . "<br>";
            $process_response = processSignSubmitForm($listobject, $formvars );
            if (!$process_response['error']) {
               $controlHTML .= "<br><b>Sign and Submit Result: </b>" . $process_response['resultHTML'];
            } else {
               $errorMSG .= "<br>Error Processing Sign and Submit request: " . $process_response['errorMSG'];
            }

         }

         // *****************************************
         // ***** END - Signature and Submittal *****
         // *****************************************
         break;
      }
   }
   if ($facrec_saved) {
      $resultMSG .= "Facility Record $uid updated.<br>";
   }
   if ($newmprec_saved) {
      $resultMSG .= "$newmprec_saved new Water Withdrawal Point(s) added.<br>";
   }
   
   if ($newannualrec_saved) {
      $resultMSG .= "$newannualrec_saved Annual Record(s) for new Water Withdrawal Saved.<br>";
   }
   
   if ($mprec_saved) {
      $resultMSG .= "$mprec_saved Withdrawal Point Record(s) Saved.<br>";
   }
   
   if ($annualrec_saved) {
      $resultMSG .= "$annualrec_saved Annual Record(s) Saved.<br>";
   }
   
   //$controlHTML .= "Hello? Anyone? McFly?<br>";
   
   $results = array();
   $results['rec_saved'] .= $rec_saved;
   $results['resultMSG'] .= $resultMSG;
   $results['errorMSG'] .= $errorMSG;
   $results['innerHTML'] = $controlHTML;
   $results['edit_errors'] = $edit_errors;
   $results['edit_defaults'] = $edit_defaults;
   $results['blank_defaults'] = $blank_defaults;
   $results['blank_errors'] = $blank_errors;
   $results['blank_queries'] = $blank_queries;
   $results['facility_errors'] = $facility_errors;
   $results['facility_defaults'] = $facility_defaults;
   $results['omit'] = $omit;
   
   return $results;
}

function showSubmissionSummary($listobject, $formValues, $facilityid, $errors, $messages, $thisyear) {

   $ss_out = array('debug'=>'','innerHTML'=>'');
   
   // get planner info
   $listobject->querystring = "  select a.firstname || ' ' || a.lastname as pname, a.email, a.phone "; 
   $listobject->querystring .= " from users as a, facilities as b "; 
   $listobject->querystring .= " where b.ownerid = a.userid "; 
   $listobject->querystring .= "    and b.userid = '$facilityid' "; 
   //$ss_out['innerHTML'] .= $listobject->querystring . "; <br>";
   $listobject->performQuery();
   $planner_name = $listobject->getRecordValue(1,'pname');
   $planner_email = $listobject->getRecordValue(1,'email');
   $planner_phone = $listobject->getRecordValue(1,'phone');
   
   // check to see if the forms exist, if not, create them
   $listobject->querystring = "  select \"MPID\", \"SOURCE\", \"ANNUAL\" from vwuds_annual_mp_data "; 
   $listobject->querystring .= " where \"USERID\" = '$facilityid' "; 
   $listobject->querystring .= "    and \"YEAR\" = '$thisyear' ";
   $listobject->querystring .= " order by \"SOURCE\" ";
   //$ss_out['innerHTML'] .= $listobject->querystring . "; <br>";
   $listobject->performQuery();
   $qrecs = $listobject->queryrecords;
   $ss_out['innerHTML'] .= "<table><tr><td>";
   $ss_out['innerHTML'] .= "<b>Reporting Summary:</b>";
   $ss_out['innerHTML'] .= "<ul>";
   foreach ($qrecs as $thisrec) {
      $src = $thisrec['SOURCE'];
      $mpid = $thisrec['MPID'];
      $annual = $thisrec['ANNUAL'];
      $ss_out['innerHTML'] .= "<li>For source: <b>'$src'</b> ($mpid), you reported a total annual withdrawal of <b>$annual MG</b>.";
   }
   $ss_out['innerHTML'] .= "</ul>";
   $ss_out['innerHTML'] .= "</td></tr></table><br>";
   if (isset($formValues['MPID'])) {
      // only show this summary if they have made a submission, otherwise, this will make no sense, and may be misleading
      // iof they are retruning, but have yet to make any edits.
      $ss_out['innerHTML'] .= "<table><tr><td>";
      $ss_out['innerHTML'] .= "<b>Error Report: </b>";
      $ss_out['innerHTML'] .= "<ul>";
      $fac_errors = $errors['facility'];
      $mpa_errors = $errors['mp_annual'];
      $numfac = count($fac_errors);
      $nummpa = count($mpa_errors);
      $facility_msg = $messages['facility'];
      $mp_annual_msg = $messages['mp_annual'];
      $ss_out['innerHTML'] .= "<li>You have <b>'$numfac'</b> errors on the <a onClick=\"xajax_showPanelInfo('./html/help_facility.html','$facility_msg')\"> facility tab</a>.";
      $ss_out['innerHTML'] .= "<li>You have <b>'$nummpa'</b> errors on the <a onClick=\"xajax_showPanelInfo('./html/help_mpannual.html','$mp_annual_msg')\"> Annual Withdrawal Data tab</a>.";
      if ($nummpa > 0) {
         $ss_out['innerHTML'] .= print_r($mpa_errors,1) . "<br>";
      }
      $ss_out['innerHTML'] .= "</ul>";
      $ss_out['innerHTML'] .= "<font size=-1>The errors listed above will NOT prevent you from submitting your annual water report.  However, accurate and complete data is extremely important, and thus, we urge you to correct as many of the errors listed as possible.  If you have questions about these errors, please contact your planner, $planner_name by email at <a href='mailto:$planner_email'>$planner_email</a>, or by telephone at $planner_phone" . ".</font>";
      $ss_out['innerHTML'] .= "</td></tr></table>";
   }
   
   return $ss_out;
}

function showUserFacilitiesInfo($listobject, $userid, $facilityid, $thisyear) {
   
   $results = array();
   $results['facility_ids'] = array();
   $results['facility_names'] = array();
   
   $listobject->querystring = "  select userid, ";
   $listobject->querystring .= " CASE ";
   $listobject->querystring .= "    WHEN ( facility is null) THEN ownname || ' (' || userid || ')' ";
   $listobject->querystring .= "    WHEN ( (ltrim(rtrim(facility)) = '') ) THEN ownname || ' (' || userid || ')' ";
   $listobject->querystring .= "    ELSE ownname || ' (' || userid || ')' ";
   $listobject->querystring .= " END as facname ";
   $listobject->querystring .= " from facilities where entity_id in ( ";
   $listobject->querystring .= "    select entity_id from vwuds_map_entity_user where userid = $userid ";
   $listobject->querystring .= " ) ";
   $listobject->querystring .= "    and ((subyra is null) or (subyra > $thisyear) ) ";
   $listobject->querystring .= " order by facname ";
   $listobject->performQuery();
   $results['debug'] = $listobject->querystring . "; <br>";
   $results['facility_rows'] = $listobject->queryrecords;
   $results['numfac'] = count($listobject->queryrecords);
   
   foreach ($results['facility_rows'] as $thiskey => $thisrow) {
      $fid = $thisrow['userid'];
      array_push($results['facility_ids'], $fid);
      $listobject->querystring = " select count(*) as numsub from vwuds_submittal where reporting_year = $thisyear and facility_id = '$fid' ";
      $results['debug'] = $listobject->querystring . "; <br>";
      $listobject->performQuery();
      $numsub = $listobject->getRecordValue(1,'numsub');
      if ($numsub > 0) {
         $substatus = '*';
      } else {
         $substatus = '';
      }
      $results['facility_names'][$thisrow['userid']] = $thisrow['facname'];
      $results['facility_rows'][$thiskey]['facname'] = $substatus . ' ' . $thisrow['facname'];
   }
   
   if (in_array($facilityid, $results['facility_ids'])) {
      $results['selected'] = $facilityid;
   } else {
      $results['selected'] = min($results['facility_ids']);
   }
   $results['facname'] = $results['facility_names'][$results['selected']];
   
   return $results;
}

function showSignSubmitForm($listobject, $facility_id, $reporting_year, $formValues, $content, $mindex) {

   global $adminsetuparray, $userid, $usergroupids, $debug;
   // $mindex - the starting number for the multi-form array elements
   // $edit_errors - contains data that we want to use instead of what we query, in case the user entered bad data
   // but we don't want to lose it all
   # get measuring point information
   $ss_out = array('debug'=>'','innerHTML'=>'');
   
   $adminname = 'vwuds_submittal';
   $adminsetup = $adminsetuparray[$adminname];
   $tblname = $adminsetup['table info']['tabledef'];

   $listobject->querystring = "  select * from $tblname where facility_id = '$facility_id' ";
   $listobject->querystring .= " and reporting_year = $reporting_year ";
   $listobject->querystring .= " and last_updated = (select max(last_updated) from $tblname ";
   $listobject->querystring .= "    where facility_id = '$facility_id' ";
   $listobject->querystring .= "    and reporting_year = $reporting_year ";
   $listobject->querystring .= " )";
   if ($debug) {
      $ss_out['debug'] .= $listobject->querystring . " ;<br>";
   }
   $listobject->performQuery();
   if (count($listobject->queryrecords) > 0) {
      $ssrec = $listobject->queryrecords[0];
      $submitted = 1;
   } else {
      $ssrec = array();
      $submitted = 0;
      foreach (array_keys($adminsetup['column info']) as $thiscol) {
         $ssrec[$thiscol] = '';
      }
      $ssrec['submittal_type'] = 1;// set the default of type Annual Reporting Record
   }
   $ssrec['reporting_year'] = $reporting_year;
   $ssrec['facility_id'] = $facility_id;
   $ssrec['data_typename'] = $adminname;
   if ($ssrec['acknowledgement']) {
      // we have someone returning, so we need to note that it has been submitted already, 
      // and if they need to change it, they should select 'Amended Annual Report' from the list
      $signer = $ssrec['signature'];
      $tstr = strtotime($ssrec['last_updated']);
      $signdate = date('m-d-Y',$tstr);
      $signtime = date('g:i a',$tstr);
      $message = "<b><font color='green'>Notice:</font></b> $signer has already signed and submitted this form on $signdate at $signtime, if you wish to amend the data for this reporting cycle, please select 'Amended Annual Report' in the 'Submittal Type' field, sign, and check the acknowledgement box again.<br>";
   }
   // each time we show this form, acknowledgement should be un-checked.
   $ssrec['acknowledgement'] = 0;
   $ss_out['innerHTML'] .= "<table>";
   $ss_out['innerHTML'] .= "<tr><td>";
   $ss_out['innerHTML'] .= "<div id='esig' width=480 >";
   $ss_out['innerHTML'] .= "<hr><b>Electronic Signature Acknowledgement</b><br>";
   $ss_out['innerHTML'] .= $message;
   // check for existing submittal in database
   // set value of hidden variable submittal_processed = 1 if this record has been submitted
   // test for this variable before browsing away to another facility or leaving the page.
   $sstext .= showHiddenField('submittal_processed', $submitted, 1);
   $sstext .= showCustomHTMLForm($listobject,$ssrec,$adminsetup, $content, 1, $mindex, 0, 0);
   $mindex++;
   $ss_out['mindex'] = $mindex;
   $ss_out['innerHTML'] .= $sstext;
   $ss_out['innerHTML'] .= "</div>";
   $ss_out['innerHTML'] .= "</td></tr>";
   $ss_out['innerHTML'] .= "</table>";
   //$ss_out['innerHTML'] .= print_r($ssrec,1) . "<br>";
   
   return $ss_out;
}

function processSignSubmitForm($listobject, $formValues ) {
   global $adminsetuparray, $userid, $usergroupids, $debug;
   
   // $mindex - the starting number for the multi-form array elements
   // $edit_errors - contains data that we want to use instead of what we query, in case the user entered bad data
   // but we don't want to lose it all
   # get measuring point information
   $ss_out = array('debug'=>'','resultHTML'=>'', 'errorMSG'=>'', 'error'=>0);
   $adminname = 'vwuds_submittal';
   $adminsetup = $adminsetuparray[$adminname];
   $tblname = $adminsetup['table info']['tabledef'];
   $adminsetup['column info']['reporting_year']['readonly'] = 0;
   $adminsetup['column info']['facility_id']['readonly'] = 0;
   $adminsetup['column info']['submittal_type']['readonly'] = 0;
   $facilityid = $formValues['userid'];
   $update_rec = processMultiFormVars($listobject,$formValues,$adminsetup,0,$debug, $nullpk = -1, $strictnull = 0);
   if (!$update_rec['error']) {
      $listobject->querystring = $update_rec['insertsql'];
      $listobject->performQuery();
      //$ss_out['resultHTML'] .= $listobject->querystring . "; <br>";
      $ss_out['resultHTML'] .= "<font color='green' size=+1>VWUDS Annual Reporting form for facility ID $facilityid submitted successfully. Thank You!</font> <br>";
   } else {
      $ss_out['error'] = 1;
      foreach ($update_rec['column_errors'] as $thiserror) {
         $ss_out['errorMSG'] .= $thiserror['error_msg'];
      }
      //$ss_out['errorMSG'] .= print_r($update_rec,1) . "<br>";
   }
   
   return $ss_out;
}


function processVWPExemptionForm($listobject, $formValues) {
   global $adminsetuparray;
   
   $response = array();
   $response['error'] = 0;
   $response['errorMSG'] = 0;
   $response['resultHTML'] = '';
   
   $form_type = array(
      5=>array('file'=>'./forms/vwp_exclusion_form-2.html', 'admin_name'=>'vwp_exemption_type5'),
      4=>array('file'=>'./forms/vwp_exclusion_form-1a.html', 'admin_name'=>'vwp_exemption_type4')
   );
   
   //$response['resultHTML'] .= print_r($formValues, 1) . "<br>";
   //$response['errorMSG'] .= print_r($formValues, 1) . "<br>";
   if (isset($formValues['userid']) and isset($formValues['mpid'])) {
      $aset = $adminsetuparray['vwp_exemption'];
      if (isset($formValues['exemption_id'])) {
         $mpid = $formValues['mpid'];
         $facilityid = $formValues['userid'];
         $ft = $formValues['permit_exemption'];
         $exid = $formValues['exemption_id'];
         $data = $formValues;

         $eform = $form_type[$ft]['file'];
         $ename = $form_type[$ft]['admin_name'];

         $aset = $adminsetuparray['vwp_exemption'];
         $cols = array_keys($aset['column info']);

         $options = array();
         $serializer = new XML_Serializer($options);
         // perform serialization
         $result = $serializer->serialize($data);
         if ($debug) {
            $response['debug'] = "Object serialized";
         }
         if ($result === true)
         {
            $debugHTML .= "Storing XML in database<br>";
            $thisxml = $serializer->getSerializedData();
         }

         $listobject->querystring = "  update vwp_exemption_info set exemption_xml = '$thisxml', ";
         $listobject->querystring .= "    last_modified = now() ";
         $listobject->querystring .= " where userid = '$facilityid' ";
         $listobject->querystring .= "    and mpid = '$mpid' ";
         $listobject->querystring .= "    and exemption_id = $exid ";
         //$response['resultHTML'] .= $listobject->querystring . "; <br>";
         
         //$response['errorMSG'] .= $listobject->querystring . "; <br>";
         $listobject->performQuery();
         if ($listobject->error) {
            $response['error'] = 1;
            $response['errorMSG'] .= "Error saving Exemption info for UID: $facilityid, MPID: $mpid " . $listobject->error . "<br>";
         } else {
            $response['resultHTML'] .= "VWP Exemption Info for MPID $mpid saved successfully. <br>";
         }
         
         // now, sync this form with the long columnar VWP table
         $syncres = syncVWPForms($listobject, $facilityid, $mpid);
         $response['resultHTML'] .= $syncres['innerHTML'];
      }
   }
   
   return $response;
   
}

function syncVWPForms($listobject, $facilityid, $mpid, $debug = 0) {
   global $adminsetuparray;
   // this will tke the raw XML data from the table vwp_exemption_info 
   // and place it in the columnar formatted table vwp_exemption_detail
   
   $result = array();
   $result['innerHTML'] = '';
   
   // admin setup info for this table
   $aset = $adminsetuparray['vwp_exemption_detail'];
   
   // get the records to operate on
   $listobject->querystring = "  select exemption_id, mpid, exemption_xml from vwp_exemption_info ";
   $listobject->querystring .= " where userid = '$facilityid' ";
   $listobject->querystring .= "    and (";
   $listobject->querystring .= "       ( mpid = '$mpid' ) ";
   $listobject->querystring .= "       or ( '$mpid' = '-1' ) ";
   $listobject->querystring .= "    )";
   if ($debug) {
      $result['innerHTML'] .= $listobject->querystring . "; <br>";
   }
   $listobject->performQuery();
   $erecs = $listobject->queryrecords;
   foreach ($erecs as $thisrec) {
      $eid = $thisrec['exemption_id'];
      $mpid = $thisrec['mpid'];
      $ef = showVWPExemptionForm($listobject, $facilityid, $thisrec, -1, $mpid);
      //$result['innerHTML'] .= print_r($ef['alldata'],1) . " <br>";
      foreach ($ef['alldata'] as $thisef) {
         // make sure these are set, in case there was no updated record in the XML of the base table
         $thisef['exemption_id'] = $eid;
         $thisef['userid'] = $facilityid;
         $thisef['mpid'] = $mpid;
            
         $listobject->querystring = " select detailid, count(*) as ecount from vwp_exemption_detail ";
         $listobject->querystring .= " where exemption_id = $eid group by detailid";
         //$result['innerHTML'] .= $listobject->querystring . "; <br>";
         $listobject->performQuery();
         
         $ecount = $listobject->getRecordValue(1,'ecount');
         
         if (count($listobject->queryrecords) > 0) {
            $detailid = $listobject->getRecordValue(1,'detailid');
         } else {
            $detailid = '';
         }
         $thisef['detailid'] = $detailid; // set a null PK so that the record will process
         $esres = processMultiFormVars($listobject,$thisef,$aset,0,$debug, -1, 1);
         //$result['innerHTML'] .= print_r($esres,1) . " <br>";
         
         if ($ecount > 0) {
            $listobject->querystring = $esres['updateintro'];
            $listobject->querystring .= $esres['updatequery'];
            $listobject->querystring .= " " . $esres['updateclause'];
         } else {
            $listobject->querystring = $esres['insertsql'];
         }
         if ($debug) {
            $result['innerHTML'] .= $listobject->querystring . "; <br>";
         }
         $listobject->performQuery();
      }
   }
   return $result;
   
}

function createVWPExemptionForm($listobject, $facilityid, $mpid, $data) {
   global $adminsetuparray;
   
   $data_xml = '';
   $options = array("complexType" => "array");
   $serializer = new XML_Serializer($options);
   // perform serialization
   $result = $serializer->serialize($data);
   if ($result === true)
   {
      $data_xml = $serializer->getSerializedData();
   }
   
   $response['innerHTML'] = '';
   
   $listobject->querystring = "  insert into vwp_exemption_info (userid, mpid, exemption_xml) ";
   $listobject->querystring .= " values ('$facilityid', '$mpid', '$data_xml') ";
   //$response['innerHTML'] .= $listobject->querystring . "; <br>";
   $listobject->performQuery();
   return $response;
}

function showVWPExemptionForm($listobject, $facilityid, $formValues, $mindex, $onempid = -1) {
   global $adminsetuparray;
   
   $response['innerHTML'] = '';
   $response['data'] = array(); // place to hold data column pertinent to ONLY the specific type of exemption form
   $response['alldata'] = array(); // place to hold the varaibles for ALL possible form entries
   $form_type = array(
      3=>array('file'=>'./forms/vwp_exclusion_form-3and5.html', 'admin_name'=>'vwp_exemption_type3and5'),
      5=>array('file'=>'./forms/vwp_exclusion_form-3and5.html', 'admin_name'=>'vwp_exemption_type3and5'),
      4=>array('file'=>'./forms/vwp_exclusion_form-1a.html', 'admin_name'=>'vwp_exemption_type4')
   );
   
   $allcontent = file_get_contents($form_type[5]['file']);
   // get the variables that are contained in all forms.  Form 3and5 essentially has all of the forms, so it is a 
   // good warehouse template for us
   $allvars = getCustomHTMLFormVars($allcontent);
   //$response['innerHTML'] .= print_r($allvars,1) . "<br>";

   // need to get a list of MPID's from this userid that NEED forms,
   // check to see if the forms exist, if not, create them
   $listobject->querystring = "  select \"MPID\", permit_exemption from vwuds_measuring_point "; 
   $listobject->querystring .= " where \"USERID\" = '$facilityid' "; 
   $listobject->querystring .= "    and permit_exemption in (3,4,5) "; 
   $listobject->querystring .= "    and \"MPID\" not in ("; 
   $listobject->querystring .= "       select mpid from vwp_exemption_info "; 
   $listobject->querystring .= "       where userid = '$facilityid' "; 
   $listobject->querystring .= "    )";
   //$response['innerHTML'] .= $listobject->querystring . "; <br>";
   $listobject->performQuery();
   
   $need_exrecs = $listobject->queryrecords;
   // create a form for every one that is missing, corresponding to the type of exemption code (3,4,5)
   foreach ($need_exrecs as $thisrec) {
      $ft = $thisrec['permit_exemption'];
      $content = file_get_contents($form_type[$ft]['file']);
      $formvars = getCustomHTMLFormVars($content);
      $thesevars = array();
      foreach ($formvars as $thisvar) {
         if (isset($thisvar['paramname'])) {
            $thesevars[$thisvar['paramname']] = '';
            //$response['innerHTML'] .= "Adding " . $thisvar['paramname'] . "<br>";
         }
      }
      $results = createVWPExemptionForm($listobject, $facilityid, $thisrec['MPID'], $thesevars);
      $response['innerHTML'] .= $results['innerHTML'];
   }
   
   // check to see if the forms exist, if not, create them
   $listobject->querystring = "  select b.exemption_id, b.exemption_xml, b.mpid, b.userid, a.permit_exemption, "; 
   $listobject->querystring .= "    a.\"SOURCE\" as source, c.year_of_max, c.max_annual "; 
   $listobject->querystring .= " from vwuds_measuring_point as a, vwp_exemption_info as b "; 
   $listobject->querystring .= "    left outer join vwuds_max_actionpost1999 as c "; 
   $listobject->querystring .= "    on ( "; 
   $listobject->querystring .= "           c.action = 'WL' "; 
   $listobject->querystring .= "           and b.userid = c.userid "; 
   $listobject->querystring .= "           and b.mpid = c.mpid "; 
   $listobject->querystring .= "    ) "; 
   $listobject->querystring .= " where b.userid = '$facilityid' "; 
   $listobject->querystring .= "    and a.permit_exemption in (3,4,5) "; 
   $listobject->querystring .= "    and b.mpid = a.\"MPID\" "; 
   $listobject->querystring .= "    and a.\"USERID\" = '$facilityid' "; 
   $listobject->querystring .= "    and a.\"ACTION\" = 'WL' "; 
   if ($onempid <> -1) {
      // this allows us to only fetch one
      $listobject->querystring .= "    and b.mpid = '$onempid' "; 
   }
   //$response['innerHTML'] .= $listobject->querystring . "; <br>";
   $listobject->performQuery();
   
   $xrecs = $listobject->queryrecords;
   
   foreach ($xrecs as $thisrec) {
      $xml = $thisrec['exemption_xml'];
      $ft = $thisrec['permit_exemption'];
      $mpid = $thisrec['mpid'];
      $content = file_get_contents($form_type[$ft]['file']);
      // get the variables that this form expects, in case we have changed forms for this entry
      // apply any existing variables that are shared between forms
      $formvars = getCustomHTMLFormVars($content);
      $thesevars = array();
      foreach ($formvars as $thisvar) {
         if (isset($thisvar['paramname'])) {
            $thesevars[$thisvar['paramname']] = '';
            //$response['innerHTML'] .= "Adding " . $thisvar['paramname'] . "<br>";
         }
      }
      $aset = $adminsetuparray[$form_type[$ft]['admin_name']];
      $options = array("complexType" => "array");
      $unserializer = new XML_Unserializer($options);
      // unserialize the object. Use "false" since this is not a document, "true" if it is a document
      $result = $unserializer->unserialize($xml, false);
      $data = $unserializer->getUnserializedData(); 
      
      foreach (array_keys($thesevars) as $thisvar) {
         if (isset($data[$thisvar])) {
            $thesevars[$thisvar] = $data[$thisvar];
            //$response['innerHTML'] .= "Adding " . $thisvar['paramname'] . "<br>";
         }
      }
      // store values in the all form
      $allthese = array();
      foreach ($allvars as $thisall) {
         if (isset($thisall['paramname'])) {
            $allthese[$thisall['paramname']] = '';
            if (isset($thesevars[$thisall['paramname']])) {
               $allthese[$thisall['paramname']] = $thesevars[$thisall['paramname']];
            }
         }
      }
            
      $thesevars['permit_exemption'] = $thisrec['permit_exemption'];
      $thesevars['data_typename'] = 'vwp_exclusion';
      $thesevars['userid'] = $facilityid;
      $thesevars['mpid'] = $mpid;
      $thesevars['source'] = $thisrec['source'];
      $thesevars['exemption_id'] = $thisrec['exemption_id'];
      // need to keep these in case a blank form has been saved. which is the default when creating these things
      if ($data['year_of_max'] == '') {
         $thesevars['year_of_max'] = $thisrec['year_of_max'];
      }
      if ($data['max_annual'] == '') {
         $thesevars['max_annual'] = $thisrec['max_annual'];
      }
      
      $response['innerHTML'] .= showCustomHTMLForm($listobject,$thesevars,$aset, $content, 1, $mindex, 0, 0);
      $response['innerHTML'] .= "<hr>";
      //$response['innerHTML'] .= "$ft 'admin_name':" . $form_type[$ft]['admin_name'] . "<br>";
      //$response['innerHTML'] .= print_r($data,1) . "<hr>";
      $response['data'][$mpid] = $thesevars;
      $response['alldata'][$mpid] = $allthese;
      $mindex++;
   }
   if (count($xrecs) == 0) {
      $response['innerHTML'] .= "There are no water withdrawal points for facility '$facilityid' that require VWP Exemption Certification.";
   }
   // update and return this variable so the application can keep track of multiple submissions.
   $response['mindex'] = $mindex;
   
   return $response;
}

function showMPAnnualForms($listobject, $thisyear, $facilityid, $content, $mindex, $edit_errors, $edit_defaults, $mpannual_msg) {
   global $adminsetuparray, $userid, $usergroupids, $debug;
   // $mindex - the starting number for the multi-form array elements
   // $edit_errors - contains data that we want to use instead of what we query, in case the user entered bad data
   // but we don't want to lose it all
   # get measuring point information
   $mpa_out = array('debug'=>'','dataforms'=>'','hotlist'=>'');
   
   $adminname = 'annual_data';
   $adminsetup = $adminsetuparray[$adminname];
   # set fields that are read-only in EDWrD view for annual data to RW for the external form
   $ro_2_rw = array('lat_flt','lon_flt','stcofips','SOURCE','abandoned','CAT_MP','GWPERMIT', 'VPDES', 'VDH_NUM','VWP_PERMIT', 'WELLNO', 'DEQ_WELL', 'SIC_MP', 'R_BASIN');
   foreach ($ro_2_rw as $rocol) {
      $adminsetup['column info'][$rocol]['readonly'] = 0;
   }
   $adminsetup['column info']['USERID']['readonly'] = 1;
   $adminsetup['column info']['USERID']['type'] = 1;
   $adminsetup['column info']['R_BASIN']['mandatory'] = 1;
   $adminsetup['column info']['SOURCE']['mandatory'] = 1;
   $adminsetup['column info']['SOURCE']['visible'] = 1;
   $adminsetup['column info']['CAT_MP']['mandatory'] = 1;

   $tblname = $adminsetup['table info']['tabledef'];
   $listobject->querystring = "  select * from vwuds_annual_mp_data where \"USERID\" = '$facilityid' ";
   //$listobject->querystring = "  select * from $tblname where \"USERID\" = '$facilityid' ";
   $listobject->querystring .= " and ( (\"SUBYR_MP\" is null) ";
   $listobject->querystring .= "    OR ( \"SUBYR_MP\" = '')  ";
   $listobject->querystring .= "    OR ( \"SUBYR_MP\" > '$thisyear' ) ";
   $listobject->querystring .= " ) ";
   $listobject->querystring .= " and \"YEAR\" = '$thisyear' order by \"SOURCE\", \"MPID\" ";

   //if ($debug) {
      $mpa_out['debug'] .= $listobject->querystring . " ;<br>";
   //}
   $listobject->performQuery();

   $mprecs = $listobject->queryrecords;

   $mpdatadiv = '';
   $mpheaderdiv = '';
   $mpscroll_list = array();
   foreach ($mprecs as $mprecord) {
      $mpid = $mprecord['MPID'];
      $record_id = $mprecord['record_id'];
      $recid = $mprecord['recid'];
      if (isset($edit_defaults[$recid])) {
         $mprecord = $edit_defaults[$recid];
      }
      $src = $mprecord['SOURCE'];
      $cat_mp = $mprecord['CAT_MP'];
      array_push($mpscroll_list, array('linkid'=>"record$mpid",'linktext'=>"$src (MP: $mpid)"));
      $perms = getVWUDSPerms($listobject, $adminsetup, $recid, $userid, $usergroupids, 1);
      $ap = $perms['rowperms'] & 2;
      $mpreadonly = 1;
      // we don't want table perms to override row perms, do we?
      //if ( ($perms['rowperms'] & 2) or ($perms['tableperms'] & 2)) {
      if ( ($perms['rowperms'] & 2) ) {
         $mpreadonly = 0;
      }
      if ($debug) {
         $mpa_out['debug'] .= print_r($perms,1) . " <br> MP ro - $mpreadonly;<br>";
      }

      $ismulti = 1;
      // screen out the sic codes, so that only the ones that show the select sub-types are shown
      // this saves much rendering time and bandwidth            
      if ($cat_mp <> '') {
         $sic_where = "\"CATEGORY\" = '$cat_mp'";
      } else {
         $sic_where = '';
      }
      // perform customizations to the display of each record
      $adminmod = $adminsetup;
      // check to see if we have been passed error messages, if so, we modify the comment field
      foreach ($edit_errors[$recid] as $error_column => $this_error) {
         $emsg = $this_error['error_msg'];
         $adminmod['column info'][$error_column]['comments'] = "<font color=red>* (" . $emsg . ")</font>";
         //$mpdatadiv .= $adminmod['column info'][$error_column]['comments'] . "<br>";
      }
      $adminmod['column info']['CAT_MP']['domid'] .= "select_catmp$mindex";
      $adminmod['column info']['CAT_MP']['onchange'] = "var cat_dom=document.getElementById(\"select_catmp$mindex\"); cat_mp=cat_dom.value; sic_domid=\"select_sicmp$mindex\"; xajax_updateSICList(sic_domid, cat_mp, $mindex); ";
      $adminmod['column info']['SIC_MP']['params'] .= $sic_where;
      $adminmod['column info']['SIC_MP']['domid'] .= "select_sicmp$mindex";
      //$mpdatadiv .= $adminmod['column info']['SIC_MP']['params'] . "<br>";
      // DONE - screening SIC codes
      //$mpdatadiv .= "<a name='record$mpid'></a>";
      // *************************************************************** //
      // ****   Get Historical Records to Provide Context           **** //
      // *************************************************************** //
      $numyears = 2;
      $action = $mprecord['ACTION'];
      $addrecs = getHistoricMonthly($listobject, $mpid, $facilityid, $action, $thisyear, $numyears);
      $addyri = 1;
      foreach ($addrecs as $thisrec) {
         foreach ($thisrec as $colkey => $colval) {
            switch ($colkey) {
               case 'YEAR':
                  $colname = "yearminus" . $addyri;
                  $coltemplate = 'YEAR';
               break;
               
               default:
                  $colname = "$colkey" . "minus" . $addyri;
                  $coltemplate = 'JANUARY';
               break;
            }
            $mprecord[$colname] = $colval;
            $adminmod['column info'][$colname] = $adminmod['column info'][$coltemplate];
            $adminmod['column info'][$colname]['readonly'] = 1;
         }
         $addyri++;
      }
      //$mpdatadiv .= print_r($addrecs,1) . "<br>";
      
      $mprecord['data_typename'] = 'annual_data';
      $mpdatadiv .= "<div id='record$mpid' name='record$mpid'>";
      $mpdatadiv .= showCustomHTMLForm($listobject,$mprecord,$adminmod, $content, $ismulti, $mindex, $debug = 0, $mpreadonly);
      $mpdatadiv .= "</div>";
      #$mpdatadiv .= showFormVars($listobject,$mprecord,$adminsetup,0, 1, $debug, 1, 1, 0, $fno, $mindex, 0);
      $mpdatadiv .= "<hr>";
      $mindex++;
   }
   $mpheaderdiv .= "<div id='mpheader' height=48>";
   $mpcount = count($mpscroll_list);
   $mpheaderdiv .= "<b>There are $mpcount active source's for this facility. </b><br>Select source from this list to jump to the desired reporting form.";
   # need to add a javascript to show the 'Measuring Point/Annual Data' panel before the showIt() routine is called
   # this will have the desired effect.
   //$onchange = "var ql=document.getElementById(\"mpquicklist\"); elid=ql.value; showIt(elid); ";
   $onchange = " show_next(\"facilitybased_data2\", \"facilitybased_2\", \"facilitybased\"); var ql=document.getElementById(\"mpquicklist\"); elid=ql.value; showAnchor(elid); xajax_showPanelInfo(\"./html/help_mpannual.html\",\"$mpannual_msg\"); ";
   $mpheaderdiv .= showActiveList($mpscroll_list, 'jumpmp', '', 'linktext','linkid', '','', $onchange, 'linktext', $debug, 1, 0, 'mpquicklist');
   $mpheaderdiv .= "</div>";
   $mpjumptext =  $mpheaderdiv;
   $mpa_out['mpcount'] = $mpcount;
   $mpa_out['mindex'] = $mindex;
   $mpa_out['hotlist'] = $mpheaderdiv;
   $mpa_out['last_record'] = $mprecord;
   $mpa_out['dataforms'] .= $mpdatadiv;
   
   return $mpa_out;
}

function getHistoricMonthly($listobject, $mpid, $userid, $action, $thisyear, $numyears) {
   
   $listobject->querystring = "  SELECT \"YEAR\", \"JANUARY\" as jan, ";
   $listobject->querystring .= "    \"FEBRUARY\" as feb, ";
   $listobject->querystring .= "    \"MARCH\" as mar, ";
   $listobject->querystring .= "    \"APRIL\" as apr, ";
   $listobject->querystring .= "    \"MAY\" as may, ";
   $listobject->querystring .= "    \"JUNE\" as jun, ";
   $listobject->querystring .= "    \"JULY\" as jul, ";
   $listobject->querystring .= "    \"AUGUST\" as aug, ";
   $listobject->querystring .= "    \"SEPTEMBER\" as sep, ";
   $listobject->querystring .= "    \"OCTOBER\" as oct, ";
   $listobject->querystring .= "    \"NOVEMBER\" as nov, ";
   $listobject->querystring .= "    \"DECEMBER\" as dec ";
   $listobject->querystring .= " FROM vwuds_annual_mp_data ";
   $listobject->querystring .= " WHERE \"MPID\" = '$mpid' ";
   $listobject->querystring .= "    AND \"USERID\" = '$userid' ";
   $listobject->querystring .= "    AND \"ACTION\" = '$action' ";
   $listobject->querystring .= "    AND \"YEAR\" < '$thisyear' ";
   $listobject->querystring .= " ORDER BY \"YEAR\" DESC ";
   $listobject->querystring .= " LIMIT $numyears ";
   //error_log($listobject->querystring);
   $listobject->performQuery();
   return $listobject->queryrecords;
   
}   

function showBlankMPAnnualForm($listobject, $blankrec, $facilityid, $content, $mindex, $blank_errors, $blank_defaults) {
   global $adminsetuparray, $userid, $usergroupids, $debug;
   $bmp_out = array('debug'=>'','dataforms'=>'');
   // add blank records form
   $blankrecdiv = '';
   $blankrecdiv .= "";
   $blankrecdiv .= "<div id='blankrec$mindex'>";
   // set all columns to no data
   $c = 0;
   //$omit = array('WELLNO','SOURCE');
   $omit = array();
   $keys_used = array();
   $adminname = 'annual_data';
   $adminsetup = $adminsetuparray[$adminname];

   // set a couple of defaults
   $blankrec['MPID'] = -1;
   $blankrec['USERID'] = $facilityid;
   $blankrec['abandoned'] = 0;
   $cat_mp = '';
   if (isset($blankrec['CAT_MP'])) {
      $cat_mp = $blankrec['CAT_MP'];
   }
   $blankrec['record_id'] = -1;
   $blankrec['recid'] = -1;
   // check for helpful defaults in previous record
   //$blankrecdiv .= print_r($blankrec,1) . "<br>";    
   if ($cat_mp <> '') {
      $sic_where = "\"CATEGORY\" = '$cat_mp'";
   } else {
      $sic_where = '';
   }
   # set fields that are read-only in EDWrD view for annual data to RW for the external form
   $ro_2_rw = array('lat_flt','lon_flt','stcofips','SOURCE','abandoned','CAT_MP','GWPERMIT', 'VPDES', 'VDH_NUM','VWP_PERMIT', 'WELLNO', 'DEQ_WELL', 'SIC_MP','TYPE', 'SUBTYPE','ACTION', 'R_BASIN');
   foreach ($ro_2_rw as $rocol) {
      $adminsetup['column info'][$rocol]['readonly'] = 0;
   }
   $adminsetup['column info']['USERID']['readonly'] = 1;
   $adminsetup['column info']['USERID']['type'] = 1;
   $adminsetup['column info']['R_BASIN']['mandatory'] = 1;
   $adminsetup['column info']['SOURCE']['mandatory'] = 1;
   $adminsetup['column info']['REGION']['mandatory'] = 0;
   $adminmod = $adminsetup;
   // check to see if we have been passed error messages, if so, we modify the comment field
   foreach ($blank_errors as $error_column => $this_error) {
      $emsg = $this_error['error_msg'];
      $adminmod['column info'][$error_column]['comments'] = "<font color=red>* (" . $emsg . ")</font>";
      //$mpdatadiv .= $adminmod['column info'][$error_column]['comments'] . "<br>";
   }
   $adminmod['column info']['CAT_MP']['readonly'] = 0;
   $adminmod['column info']['CAT_MP']['domid'] .= "select_catmp$mindex";
   $adminmod['column info']['CAT_MP']['onchange'] = "var cat_dom=document.getElementById(\"select_catmp$mindex\"); cat_mp=cat_dom.value; sic_domid=\"select_sicmp$mindex\"; xajax_updateSICList(sic_domid, cat_mp, $mindex); ";
   $adminmod['column info']['SIC_MP']['domid'] .= "select_sicmp$mindex";
   $adminmod['column info']['SIC_MP']['readonly'] = 0;
   $adminmod['column info']['SIC_MP']['params'] .= $sic_where;
   $adminmod['column info']['stcofips']['readonly'] = 0;
   $blankrec['data_typename'] = 'annual_data';

   $blankrecdiv .= showCustomHTMLForm($listobject,$blankrec,$adminmod, $content, 1, $mindex, $debug, 0);
   //$blankrecdiv .= showFormVars($listobject,$blankrec,$adminsetup,1, 0, $debug, 1, 1, 0, -1, $mindex, 0);
   $blankrecdiv .= "</div><br>";
   $blankrecdiv .= "";
   $mindex++;
   $bmp_out['mindex'] = $mindex;
   $bmp_out['dataforms'] .= $blankrecdiv;
   
   return $bmp_out;
}

function annualDataCreationForm($formValues) {
   global $listobject, $userid, $adminsetuparray, $usergroupids;

   $controlHTML = '';

   # check user permissions
   $aset = $adminsetuparray['annual_data'];
   $perms = getVWUDSPerms($listobject, $aset, $pkval, $userid, $usergroupids, 1);
   if ($debug) {
      $controlHTML .= print_r($perms, 1) . "<br>";
   }

   if ($perms['tableperms'] & 1) {
      $caninsert = 1;
   } else {
      $controlHTML .= "<b>Error:</b> You do not have permission to create blank reporting records.<br>";
      return $controlHTML;
   }

   if (isset($formValues['thisyear'])) {
      $thisyear = $formValues['thisyear'];
   } else {
      $thisyear = date('Y');
   }
   if (isset($formValues['selected_only'])) {
      $selected_only = $formValues['selected_only'];
   } else {
      $selected_only = 1;
   }
   if (isset($formValues['replace_existing'])) {
      $replace_existing = $formValues['replace_existing'];
   } else {
      $replace_existing = 0;
   }
   if (isset($formValues['fac_userid'])) {
      $fac_userid = $formValues['fac_userid'][0];
   } else {
      $fac_userid = array();
   }
   #error_reporting(E_ALL);

   $controlHTML .= "<form method=post action='' id=control>";
   $controlHTML .= "<b>Select Facility(s):</b><br>";
   ############################################################
   ###                        SEARCH FORM                   ###
   ############################################################
   $tablename = 'facilities';
   $aset = $adminsetuparray[$tablename];
   # call the search form routine.   This will take all of the variables that come in the search and interpret them,
   # returning the record of interest
   $searchobject = new listObjectSearchForm;
   $searchobject->listobject = $listobject;
   $searchobject->debug = FALSE;
   $searchobject->insertOK = 0;
   $searchobject->deleteOK = 0;
   $searchobject->adminsetup = $aset;
   $searchobject->readonly = 1;
   $searchobject->record_submit_script = '';
   $searchobject->search_submit_script = "xajax_showAnnualDataCreationForm(xajax.getFormValues(\"control\"));  ";
   $searchobject->page_submit_script = "";
   $controlHTML .= "<a class=\"mH\"";
   $controlHTML .= "onclick=\"toggleMenu('$divname" . "_search')\">+ Show/Hide Advanced Search Form</a>";
   $controlHTML .= "<div id=\"$divname" . "_search\" class=\"mL\"><ul>";
   # display the search form
   $searchForm = $searchobject->showSearchForm($formValues);
   $controlHTML .= $searchForm['formHTML'];
   $controlHTML .= "</div><br>";
   $subquery = "( select userid, ownname, facility, system from (" . $searchForm['query'] . " ) as foo ) as bar ";
   #$controlHTML .= $subquery . " ;<br>";
   $controlHTML .= "<br>";
   $controlHTML .= showGenericButton('search','Search', "xajax_showAnnualDataCreationForm(xajax.getFormValues(\"control\")); ", 1, $pd);
   $controlHTML .= "<hr>";

   ############################################################
   ###                    END SEARCH FORM                   ###
   ############################################################
   $controlHTML .= "<b>Select Facilities:</b><br>";
   $controlHTML .= showMultiList2($listobject, 'fac_userid', $subquery, 'userid', 'ownname, facility, system', $fac_userid, '', 'ownname, facility', 0, 8, 1, 0);
   $controlHTML .= "<b>Select Option(s):</b><br>";
   $controlHTML .= "<ul>";
   $controlHTML .= "<li>" . showWidthTextField('thisyear', $thisyear, 8, '', 1) . "Year to create</li>";
   $controlHTML .= "<li>" . showCheckBox('replace_existing',1,$replace_existing, '', 1) . "Overwrite Existing Records?</li>";
   $controlHTML .= "<li>" . showCheckBox('selected_only',1,$selected_only, '', 1) . "Only create records for selected facilities?</li>";
   $controlHTML .= "</ul>";
   $controlHTML  .= showGenericButton('createrecords','Create Blank Annual Records', "xajax_showAnnualDataCreationResult(xajax.getFormValues(\"control\")); ", 1, 0);
   $controlHTML .= "</form>";

   return $controlHTML;
}


function annualDataCreationResult($formValues) {
   global $listobject, $userid, $adminsetuparray, $usergroupids;

   # LIMITATIONS:
   # 1. This currently only allows access to records by facility USERID, which means that
   #    individual measuring points cannot be added and subtracted, only all the points by group

   $controlHTML = '';

   # check user permissions
   $aset = $adminsetuparray['annual_data'];
   $perms = getVWUDSPerms($listobject, $aset, $pkval, $userid, $usergroupids, 1);
   if ($debug) {
      $controlHTML .= print_r($perms, 1) . "<br>";
   }

   if ($perms['tableperms'] & 1) {
      $caninsert = 1;
   } else {
      $errorMSG .= "<b>Error:</b> You do not have permission to create blank reporting records.<br>";
      $controlHTML .= "<div id=errorinfo class='errorInfo'>" . $errorMSG . "</div>";
      return $controlHTML;
   }

   if (isset($formValues['thisyear'])) {
      $thisyear = $formValues['thisyear'];
   } else {
      $thisyear = date('Y');
   }
   if (isset($formValues['selected_only'])) {
      $selected_only = $formValues['selected_only'];
   } else {
      $selected_only = 1;
   }
   if (isset($formValues['replace_existing'])) {
      $replace_existing = $formValues['replace_existing'];
   } else {
      $replace_existing = 0;
   }
   if (isset($formValues['fac_userid'])) {
      $fac_userid = $formValues['fac_userid'][0];
   } else {
      $fac_userid = array();
   }

   # need to report on records that user tried to replace/delete that are locked (perms do not match)
   $numlocked = 0;
   if ( $replace_existing ) {
      $listobject->querystring = "  select count(*) as numlocked from annual_data ";
      $listobject->querystring .= " where \"YEAR\" = '$thisyear' ";
      $listobject->querystring .= " AND \"USERID\" in ( ";
      $listobject->querystring .= "    select \"USERID\" from annual_data ";
      $listobject->querystring .= "    where \"YEAR\" = '$thisyear' ";
      if ( $selected_only and (count($fac_userid) > 0)) {
         $listobject->querystring .= "       and \"USERID\" in ( '" . join("','", $fac_userid) . "')";
      }
      $listobject->querystring .= "  ) ";
      # verify that records are not locked
      $listobject->querystring .= "     AND NOT ((gperms & 1) = 1) ";
      if ($debug) {
         $controlHTML .= $listobject->querystring . " ; <br>";
      }
      $listobject->performQuery();
      $numlocked = $listobject->getRecordValue(1,'numlocked');
   }

   if ($numlocked > 0) {
      $errorMSG .= "<b>Error:</b> There were $numlocked records in the requested data set that were NOT replaced.<br>";
      $errorMSG .= "Please consult the system administrator if you need to unlock these records.<br>";
   }

   if ( $replace_existing ) {
      $controlHTML .= "<b>Notice: </b> Attempting to delete existing records for selected facilities in year $thisyear.<br>";
      $listobject->querystring = "  delete from annual_data ";
      $listobject->querystring .= " where \"YEAR\" = '$thisyear' ";
      $listobject->querystring .= " AND \"USERID\" in ( ";
      $listobject->querystring .= "    select \"USERID\" from annual_data ";
      $listobject->querystring .= "    where \"YEAR\" = '$thisyear' ";
      if ( $selected_only and (count($fac_userid) > 0)) {
         $listobject->querystring .= "       and \"USERID\" in ( '" . join("','", $fac_userid) . "')";
      }
      $listobject->querystring .= "  ) ";
      # verify that records are not locked
      $listobject->querystring .= "     AND ((gperms & 1) = 1) ";
      #if ($debug) {
         $controlHTML .= $listobject->querystring . " ; <br>";
      #}
      $listobject->performQuery();
   } else {
      $controlHTML .= "<b>Notice: </b> Will NOT overwrite any existing records for $thisyear.<br>";
   }

   $controlHTML .= "<b>Notice: </b> Attempting to insert blank records for selected facilities in year $thisyear.<br>";
   #error_reporting(E_ALL);
   $listobject->querystring = "  insert into annual_data (\"YEAR\", \"USERID\", \"ACTION\", \"MPID\", ";
   $listobject->querystring .= "    \"REGION\", source, ownerid ) ";
   # fails on missing region
   $listobject->querystring .= "  select thisyear, userid, \"ACTION\", mpmpid, \"REGION\", \"SOURCE\", ownerid ";
   $listobject->querystring .= " from (";
   $listobject->querystring .= "    select foo.thisyear, foo.userid, foo.\"ACTION\", foo.\"MPID\" as mpmpid, ";
   $listobject->querystring .= "       bar.\"MPID\" AS annual_mpid, foo.\"REGION\", foo.\"SOURCE\", foo.ownerid ";
   $listobject->querystring .= "    from ( ";
   $listobject->querystring .= "    select '$thisyear' as thisyear, b.userid, a.\"ACTION\", a.\"MPID\", ";
   $listobject->querystring .= "        a.\"REGION\", a.\"SOURCE\", c.ownerid ";
   $listobject->querystring .= "     from vwuds_measuring_point as a, facilities as b ";
   $listobject->querystring .= "     left outer join vwuds_deq_regions as c  ";
   $listobject->querystring .= "     on (b.region = c.reg_id) ";
   $listobject->querystring .= "     where a.\"USERID\" = b.userid  ";
   $listobject->querystring .= "        and  ";
   $listobject->querystring .= "           ( ( a.\"SUBYR_MP\" is null ) ";
   $listobject->querystring .= "           OR (a.\"SUBYR_MP\" = '' ) ";
   $listobject->querystring .= "           OR (a.\"SUBYR_MP\" > '$thisyear') ";
   $listobject->querystring .= "        ) ";
   # only get selected of all possible
   if ( $selected_only and (count($fac_userid) > 0)) {
      $listobject->querystring .= "   AND b.userid in ( '" . join("','", $fac_userid) . "')";
   }
   $listobject->querystring .= "    ) as foo left outer join annual_data as bar ";
   $listobject->querystring .= "    on (foo.userid = bar.\"USERID\" ";
   $listobject->querystring .= "        and foo.\"MPID\" = bar.\"MPID\" ";
   $listobject->querystring .= "        and foo.\"ACTION\" = bar.\"ACTION\" ";
   $listobject->querystring .= "        and bar.\"YEAR\" = '$thisyear'";
   $listobject->querystring .= "       ) ";
   # this outer join insures that any entry that is ALREADY IN the table WILL HAVE A Non-Null bar.MPID
   # if any of the three JOIN conditions, ACTION, MPID, or USERID do not match
   # if bar.MPID IS NULL, then it is OK to insert
   $listobject->querystring .= "    where bar.\"MPID\" is null ";
   $listobject->querystring .= "       and foo.\"MPID\" is not null and foo.\"MPID\" <> '' ";
   $listobject->querystring .= " ) as foobar ";
   #if ($debug) {
      $controlHTML .= $listobject->querystring . " ; <br>";
   #}
   $listobject->performQuery();

   $controlHTML .= "<div id=errorinfo class='errorInfo'>" . $errorMSG . "</div>";

   return $controlHTML;
}

function droughtIndicatorForm($formValues) {
   global $listobject;

   $controlHTML = '';

   if (isset($formValues['thismetric'])) {
      $thismetric = $formValues['thismetric'];
   }
   $projectid = $formValues['projectid'];
   $currentgroup = $formValues['currentgroup'];
   $lreditlist = $formValues['lreditlist'];
   $allgroups = $formValues['allgroups'];
   $startdate = $formValues['startdate'];
   $enddate = $formValues['enddate'];
   #$debug = 1;
   if ($startyear == '') { $startyear = Date('Y'); }
   if ($endyear == '') { $endyear = Date('Y'); }
   #print_r($allsegs);
   $controlHTML .= "<form id=control name=control>";
   $controlHTML .= showHiddenField('projectid', $projectid, 1);
   $controlHTML .= showHiddenField('currentgroup', $currentgroup, 1);
   $controlHTML .= showHiddenField('lreditlist', $lreditlist, 1);
   $controlHTML .= showCheckBox('allgroups', 1, $allgroups, $onclick='', 1);
   $controlHTML .= " <b>Show Stats for All Groups (default is active group only)</b>";
   $controlHTML .= "<br>";
   $controlHTML  .= "<b>Start Date: </b> " . showWidthTextField('startdate', $startdate, 8, '', 1);
   $controlHTML  .= "<b>End Date: </b> " . showWidthTextField('enddate', $enddate, 8, '', 1) . '<br>';
   /*
   $controlHTML  .= "<br><b>Select Summary Period:</b><br>";
   $disql = "  (select thismetric, min(startdate) || ' to ' || max(enddate) as thisrange ";
   $disql .= " from proj_group_stat ";
   $disql .= " where projectid = $projectid ";
   $disql .= "    and gid = $currentgroup ";
   $disql .= "    and ( ( thismetric like 'tmp_flow%' ) ";
   $disql .= "        or ( thismetric like 'roll365flow%' ) ";
   $disql .= "        or ( thismetric like 'rollwyflow%' ) ";
   $disql .= "    ) ";
   $disql .= " group by thismetric ) as foo ";
   $controlHTML  .= showMultiList2($listobject,'thisrange', $disql, 'thisrange', 'thisrange', $thesemetrics, '', 'thisrange DESC', $debug, 5, 1);
   */
   $metricarray[0]['thismetric'] = 'flow';
   $metricarray[0]['thislabel'] = 'Flow';
   $metricarray[1]['thismetric'] = 'gw';
   $metricarray[1]['thislabel'] = 'Grounwater Observation Well';
   $metricarray[2]['thismetric'] = 'lake';
   $metricarray[2]['thislabel'] = 'Reservoir Level';
   $metricarray[3]['thismetric'] = 'precip';
   $metricarray[3]['thislabel'] = 'Precipitation';
   $thesemetrics = join(',', $thismetric[0]);
   $controlHTML .= showMultiList2($metricarray,'thismetric', $disql, 'thismetric', 'thislabel', $thesemetrics, '', 'thislabel', $debug, 5, 1);
   $controlHTML  .= showGenericButton('showindicators','Show Indicators', "xajax_showDroughtIndicatorResult(xajax.getFormValues(\"control\"))", 1);
   $controlHTML .= "</form>";
   #print("<br>");
   #$debug = 1;

   return $controlHTML;
}

function droughtIndicatorResult($formValues) {
   global $listobject, $debug, $userid;

   $innerHTML = '';

   $innerHTML .= "<font class='heading1'>Drought Report</font><br>";

   $thesemetrics = $formValues['thismetric'][0];
   if (isset($formValues['thisrange'])) {
      $theseranges = $formValues['thisrange'][0];
   } else {
      # hardwire
      if (isset($formValues['startdate']) and isset($formValues['enddate'])) {
         $theseranges = array( $formValues['startdate'] . ' to ' . $formValues['enddate'] );
      } else {
         $theseranges = array('2007-10-01 to 2008-10-21');
      }
   }
   # hardwire
   #$thesemetrics = array('flow', 'gw', 'lake', 'precip');
   $currentgroup = $formValues['currentgroup'];
   $projectid = $formValues['projectid'];
   $allgroups = $formValues['allgroups'];

   #$debug = 1;
   if ($debug) {
      $innerHTML .= print_r($thesemetrics, 1);
      $innerHTML .= print_r($formValues, 1);
   }

   if ( ($currentgroup > 0) and (!($allgroups == 1)) ) {
      $agclause = "a.gid = $currentgroup ";
      $bgclause = "b.gid = $currentgroup ";
      $cgclause = "c.gid = $currentgroup ";
   } else {
      $agclause = "( 1 = 1)";
      $bgclause = "a.gid = b.gid ";
      $cgclause = "a.gid = c.gid ";
   }
   
   /*
   # this is disabled in order to use the speed of caching with mod_php - mapsxcript is incompatible with mod_php
   # first, show current aggregate map
   $aggmap = showAggregateMap($formValues, 'current');
   $agimg = $aggmap['image_url'];

   $innerHTML .= "<img src='$agimg'><br>";
   */
   $innerHTML .= "<table class=\"lineborder\">";
   $innerHTML .= "<tr><th colspan=2><b>Indicator Key:</b></th></tr>";
   $innerHTML .= "<tr>";
   $innerHTML .= "<td width=50%>GW</td><td width=50%>Precip</td>";
   $innerHTML .= "</tr><tr>";
   $innerHTML .= "<td width=50%>Rsvr</td><td width=50%>Flow</td>";
   $innerHTML .= "</tr></table><br>";

   foreach ($thesemetrics as $thismetric) {
      foreach ($theseranges as $thisrange) {
         list($startdate, $enddate) = split(' to ', $thisrange);
         # supresses output, stores it in an object property "outstring"
         $listobject->show = 0;
         if ($thismetric == 'precip') {
            # get precip metrics
            $listobject->querystring = "  SELECT extract(month from a.startdate) as thismo, ";
            $listobject->querystring .= "    extract(year from a.startdate) as thisyr, a.thismetric, ";
            $listobject->querystring .= "    max(a.startdate) as ed ";
            $listobject->querystring .= " FROM proj_group_stat as a ";
            $listobject->querystring .= " WHERE a.projectid = $projectid ";
            $listobject->querystring .= "    AND a.thismetric = 'daily_precip_obs' ";
            $listobject->querystring .= "    AND a.startdate >= '$startdate' ";
            $listobject->querystring .= "    AND a.startdate <= '$enddate' ";
            $listobject->querystring .= " GROUP BY thismo, thisyr, a.thismetric ";
            $listobject->querystring .= " ORDER BY thisyr DESC, thismo DESC";
            #if ($debug) {
               $innerHTML .= " $listobject->querystring <br>";
            #}
            $listobject->performQuery();
            $metricrecs = $listobject->queryrecords;
            # get precip metric data
            foreach ($metricrecs as $thisrec) {
               $ametric = $thisrec['thismetric'];
               # $startdate remains static, and we build a monthly cumulative
               # by changing the enddate to the end of each month returned
               # OR
               # enddate remains static, and we build a monthly cumulative
               # by changing the startdate to the beginning of each month returned
               //$enddate = $thisrec['ed'];
               $mostart = $thisrec['thisyr'] . '-' . str_pad($thisrec['thismo'],2,'0', STR_PAD_LEFT) . '-' . '01';
               $innerHTML .= "<b>Metric:</b> $ametric <br>";

               $innerHTML .= "<table><tr><td>";

               # try out new daily slice summary (realtime, super fast)
               #select period summary for a given seggroup
               $listobject->querystring = " select a.gid, a.groupname, a.thismetric, a.startdate, a.enddate, ";
               $listobject->querystring .= "    a.thisvalue as obs, b.thisvalue as nml,  ";
               $listobject->querystring .= "    a.thisvalue / b.thisvalue as pct, a.num_obs as numrecs, b.num_nml  ";
               $listobject->querystring .= " from (  ";
               $listobject->querystring .= "    select gid, groupname, thismetric, min(startdate) as startdate, ";
               $listobject->querystring .= "       max(startdate) as enddate, sum(thisvalue) as thisvalue, ";
               $listobject->querystring .= "       count(gid) as num_obs   ";
               $listobject->querystring .= "    from proj_group_stat  ";
               $listobject->querystring .= "    where thismetric = 'daily_precip_obs' ";
               $listobject->querystring .= "    and startdate >= '$mostart' ";
               $listobject->querystring .= "    and enddate <= '$enddate'  ";
               #make sure this is a single day entry
               $listobject->querystring .= "    and startdate = enddate ";
               $listobject->querystring .= "    AND gid in  ";
               $listobject->querystring .= "    (select gid from proj_seggroups  ";
               $listobject->querystring .= "     where ownerid = $userid  ";
               $listobject->querystring .= "        and projectid = $projectid ) ";
               $listobject->querystring .= "    group by gid, groupname, thismetric  ";
               $listobject->querystring .= " ) as a, (  ";
               $listobject->querystring .= "    select gid, avg(pct_cover) as pct_cover, sum(thisvalue) as thisvalue,  ";
               $listobject->querystring .= "       count(gid) as num_nml  ";
               $listobject->querystring .= "    from proj_group_stat  ";
               $listobject->querystring .= "    where thismetric = 'daily_precip_nml' ";
               $listobject->querystring .= "    and startdate >= '$mostart' ";
               $listobject->querystring .= "    and enddate <= '$enddate'  ";
               #make sure this is a single day entry
               $listobject->querystring .= "    and startdate = enddate ";
               $listobject->querystring .= "    AND gid in  ";
               $listobject->querystring .= "    (select gid from proj_seggroups  ";
               $listobject->querystring .= "     where ownerid = $userid  ";
               $listobject->querystring .= "        and projectid = $projectid ) ";
               $listobject->querystring .= "    group by gid  ";
               $listobject->querystring .= " ) as b  ";
               $listobject->querystring .= " where b.gid = a.gid ";
               $listobject->querystring .= " order by a.groupname ";
               $listobject->performQuery();
               $listobject->show = 0;
               $listobject->tablename = 'droughtprecip';
               $listobject->showList();
               #$innerHTML .= $listobject->querystring . "<br>";
               $innerHTML .= $listobject->outstring;

                # only needed when showing old and new method of calcualtion
               $innerHTML .= "</td></tr></table>";

            }


         } else {
            # get gw, flow, and reservoir metrics
            $listobject->querystring = "  SELECT min(a.startdate) as mindate, a.thismetric ";
            $listobject->querystring .= " FROM proj_group_stat as a ";
            $listobject->querystring .= " WHERE a.projectid = $projectid ";
            $listobject->querystring .= "    AND ( ";
            $listobject->querystring .= "            (a.thismetric like 'tmp_$thismetric%') ";
            $listobject->querystring .= "            or (a.thismetric like 'roll365$thismetric%') ";
            $listobject->querystring .= "            or (a.thismetric like 'rollwy$thismetric%') ";
            $listobject->querystring .= "            or (a.thismetric like 'last7days$thismetric%') ";
            $listobject->querystring .= "    ) ";
            $listobject->querystring .= "    AND a.thismetric not like '%_value' ";
            $listobject->querystring .= "    AND $agclause ";
            $listobject->querystring .= " GROUP BY a.thismetric ";
            $listobject->querystring .= " order by mindate DESC, a.thismetric ";
            /*
            # get gw, flow, and reservoir metrics
            $listobject->querystring = "  SELECT a.startdate, a.enddate, a.thismetric ";
            $listobject->querystring .= " FROM proj_group_stat as a ";
            $listobject->querystring .= " WHERE a.projectid = $projectid ";
            $listobject->querystring .= "    AND ( ";
            $listobject->querystring .= "            (a.thismetric like 'tmp_$thismetric%') ";
            $listobject->querystring .= "            or (a.thismetric like 'roll365$thismetric%') ";
            $listobject->querystring .= "            or (a.thismetric like 'rollwy$thismetric%') ";
            $listobject->querystring .= "            or (a.thismetric like 'last7days$thismetric%') ";
            $listobject->querystring .= "    ) ";
            $listobject->querystring .= "    AND a.thismetric not like '%_value' ";
            $listobject->querystring .= "    AND $agclause ";
            $listobject->querystring .= " GROUP BY a.startdate, a.enddate, a.thismetric ";
            $listobject->querystring .= " order by a.startdate DESC, a.enddate DESC, a.thismetric ";
            */
            if ($debug) {
               $innerHTML .= " $listobject->querystring <br>";
            }
            $listobject->performQuery();
            if ($debug) {
               $listobject->showList();
               $innerHTML .= $listobject->outstring;
            }
            $metricrecs = $listobject->queryrecords;
            # get gw, flow, and reservoir metric data
            foreach ($metricrecs as $thisrec) {
               $ametric = $thisrec['thismetric'];
               $innerHTML .= "<b>Metric:</b> $ametric <br>";
               $listobject->querystring = "  SELECT b.groupname, a.startdate, a.enddate, ";
               $listobject->querystring .= "    min(c.thisvalue) as minval, max(c.thisvalue) as maxval, ";
               $listobject->querystring .= "    min(a.thisvalue) as minpct, max(a.thisvalue) as maxpct ";
               # shows individuals
               #$listobject->querystring .= "    a.thisvalue as thispct, c.thisvalue as thisval ";
               $listobject->querystring .= " FROM proj_group_stat as a, proj_seggroups as b, proj_group_stat as c ";
               $listobject->querystring .= " WHERE a.projectid = $projectid ";
               $listobject->querystring .= "    AND a.thismetric = '$ametric' ";
               $listobject->querystring .= "    AND c.thismetric = '$ametric' || '_value' ";
               $listobject->querystring .= "    AND $agclause ";
               $listobject->querystring .= "    AND $bgclause ";
               $listobject->querystring .= "    AND $cgclause ";
               $listobject->querystring .= "    AND a.startdate = c.startdate ";
               $listobject->querystring .= "    AND a.enddate = c.enddate ";
               $listobject->querystring .= "    AND c.projectid = $projectid ";
               $listobject->querystring .= "    AND b.projectid = $projectid ";
               $listobject->querystring .= "    AND b.ownerid = $userid ";
               $listobject->querystring .= " group by b.groupname, a.startdate, a.enddate ";
               $listobject->querystring .= " order by a.startdate, b.groupname ";
               if ($debug) {
                  $innerHTML .= " $listobject->querystring <br>";
               }
               $listobject->performQuery();
               $listobject->tablename = 'droughtflowgwlake';
               $listobject->showList();
               $innerHTML .= $listobject->outstring;
            }
         }
      }
   }

   return $innerHTML;
}

function showAggregateMap($formValues, $startdate, $enddate = 'today') {
   global $listobject, $aggmapfile, $basedir, $debug;

   $end_obj = new DateTime($enddate);
   $endmo = $end_obj->format('m');

   $aggmap = array();

   if ($startdate == 'current') {
      # select beginning of water year
      if ($endmo >= 10) {
         $num_mos = $endmo - 10;
         $startyear = $thisyear;
      } else {
         $num_mos = $endmo + 2;
         $startyear = $thisyear - 1;
      }
      $start_obj = new DateTime("$startyear-10-01");
   } else {
      $start_obj = new DateTime($startdate);
   }

   $mapbuffer = 0.1;
   $initmap = 1;
   #$debug = 1;
   # manually set to html mode (no need for applet)
   $gbIsHTMLMode = 1;
   #print_r($_POST);
   $invars = $formValues;
   #print_r($invars);

   $projectid = $formValues['projectid'];
   $syear = $formValues['syear'];
   $eyear = $formValues['eyear'];
   $smonth = $formValues['smonth'];
   $emonth = $formValues['emonth'];
   $sday = $formValues['sday'];
   $eday = $formValues['eday'];
   $allgroups = $formValues['allgroups'];

   if ($debug) {
      $innerHTML .= "Creating map objects.<br>";
   }

   if ($initmap) {
      if ($debug) {
         $innerHTML .= "Creating map objects.<br>";
      }
      $amap = new ActiveMap;
      $amap->gbIsHTMLMode = 0;
      $amap->debug = $debug;
      if ($debug) { $innerHTML .= "Locating map file.<br>"; }
      $amap->setMap($basedir,$aggmapfile);
      #$HTTP_SESSION_VARS["amap"] = $amap;
   } else {
      $amap->debug = $debug;
      $amap->setMap($basedir,$panimapfile);
   }

   # zoom to selected extent
   if (isset($formValues['currentgroup'])) {
      if ($allgroups) {
         $gcond = '';
      } else {
         $gcond = $formValues['currentgroup'];
      }
      $coords = getGroupExtents($listobject, 'proj_seggroups', 'the_geom', 'gid', $gcond, " projectid = $projectid ", $mapbuffer, $debug );
      list($lox,$loy,$hix,$hiy) = split(',', $coords);
      $amap->quickView($lox,$loy,$hix,$hiy);
      if ($debug) {
         $innerHTML .= "Coords: $coords<br>";
      }
      $thislayer = $amap->map->getLayerByName('proj_seggroups');
      $thislayer->setFilter("gid = " . $formValues['currentgroup'] . " ");
   }

   # set the proper layer projectid's and metric names
   $thislayer = $amap->map->getLayerByName('proj_seggroups');
   $thislayer->setFilter("projectid = $projectid and agg_group <> 1");
   $thislayer = $amap->map->getLayerByName('sym_box');
   $thislayer->setFilter("projectid = $projectid and agg_group <> 1");
   $thislayer = $amap->map->getLayerByName('sym_flow');
   $thislayer->setFilter("projectid = $projectid and thismetric = 'last7daysflow'  and agg_group <> 1");
   $thislayer = $amap->map->getLayerByName('sym_res');
   $thislayer->setFilter("projectid = $projectid and thismetric = 'tmp_lake_mtd_4mos'  and agg_group <> 1");
   $thislayer = $amap->map->getLayerByName('sym_precip');
   $thislayer->setFilter("projectid = $projectid and thismetric = 'tmp_precip_4mos_dep_pct'  and agg_group <> 1");
   $thislayer = $amap->map->getLayerByName('sym_gw');
   $thislayer->setFilter("projectid = $projectid and thismetric = 'last7daysgw'  and agg_group <> 1");


   $image = $amap->map->draw();
   $image_url = $image->saveWebImage(MS_GIF,1,1,0);
   $file_path = $amap->map->web->imagepath
                    . substr(strrchr($image_url, "/"),1);
   $aggmap['image_url'] = $image_url;

   return $aggmap;
}


function withdrawalInfoForm($formValues) {
   global $listobject, $debug;

   $controlHTML = '';


   $startyear = $formValues['startyear'];
   $endyear = $formValues['endyear'];
   $projectid = $formValues['projectid'];
   $currentgroup = $formValues['currentgroup'];
   $lreditlist = $formValues['lreditlist'];
   if (isset($formValues['sourcetypes'])) {
      $sourcetypes = $formValues['sourcetypes'][0];
   } else {
      $sourcetypes = array();
   }

   $groups = getGroupWKT($formValues);
   $mpinfo = getUserMPIDsByWKT($listobject, $wktshape, $mptypes, $mpactions, $debug);

   if ($startyear == '') { $startyear = Date('Y'); }
   if ($endyear == '') { $endyear = Date('Y'); }
   #$controlHTML  .= print_r($sourcetypes, 1);
   $controlHTML .= "<form id=control name=control>";
   $controlHTML .= showHiddenField('projectid', $projectid, 1);
   $controlHTML .= showHiddenField('currentgroup', $currentgroup, 1);
   $controlHTML .= showHiddenField('lreditlist', $lreditlist, 1);
   $controlHTML  .= "<br><b>Select Starting year to Sum Water Use:</b>";
   $controlHTML  .= showWidthTextField('startyear', $startyear, 8, '', 1);
   $controlHTML  .= "<br><b>Select Ending year to Sum Water Use:</b>";
   $controlHTML  .= showWidthTextField('endyear', $endyear, 8, '', 1);
   $controlHTML .= "<br><b> Select Withdrawal Source Type:</b><br>";
   $controlHTML .= showMultiList2($listobject,'sourcetypes', 'watersourcetype', 'wsabbrev', 'wsname', $sourcetypes, '', 'wsname', $debug, 5, 1);
   $controlHTML  .= "<br>" . showGenericButton('showmps','Retrieve Measuring Points', "xajax_showWithdrawalInfoResult(xajax.getFormValues(\"control\"))", 1);
   $controlHTML .= "</form>";
   #print("<br>");
   #$debug = 1;

   return $controlHTML;

}

function withdrawalInfoResult($formValues) {
   global $listobject, $debug;

   $controlHTML = '';
   $controlHTML .= "<div style=\"border: 1px solid rgb(0 , 0, 0); border-style: dotted; overflow: auto; width: 600px; height: 600px\">";

   $groups = getGroupWKT($formValues);
   $mptypes = $formValues['sourcetypes'][0];
   $startyear = $formValues['startyear'];
   $endyear = $formValues['endyear'];

   $wktshape = $groups[0]['wktshape'];
   $mpinfo = getUserMPIDsByWKT($listobject, $wktshape, $mptypes, '', $debug);

   #$controlHTML .= $mpinfo['query'] . "<br>";
   #$controlHTML .= print_r($mpinfo, 1) ."<br>";
   $listobject->show = 0;
   $listobject->queryrecords = $mpinfo['records'];
   #$listobject->tablename = 'vwuds_monthly';
   $listobject->showList();
   $controlHTML .= $listobject->outstring;
   foreach ($mpinfo['records'] as $thisrec) {
      $userid = $thisrec['USERID'];
      $mpid = $thisrec['mpid'];
      $src = $thisrec['SOURCE'];
      $other = $thisrec['OTHER_MP'];
      $ownname = $thisrec['ownname'];
      $facility = $thisrec['facility'];
      $system = $thisrec['system'];
      $controlHTML .= "<hr><b>$ownname - $facility - $system</b><br>";
      $controlHTML .= "<b>Annual Records for $src - $other</b><br>";
      #$listobject->querystring = "  SELECT a.\"MPID\" as mpid, a.\"USERID\" as userid, ";
      #$listobject->querystring .= "   a.\"YEAR\" as thisyear, a.\"ANNUAL\" as annual ";
      #$listobject->querystring .= "   a.\"JANUARY\" as jan, a.\"FEBRUARY\" as feb ";
      $listobject->querystring = "  SELECT a.* ";
      $listobject->querystring .= " FROM annual_data AS a ";
      $listobject->querystring .= " WHERE a.\"USERID\" = '$userid' ";
      $listobject->querystring .= " and a.\"MPID\" = '$mpid' ";
      $listobject->querystring .= " and a.\"YEAR\" >=  $startyear  ";
      $listobject->querystring .= " and a.\"YEAR\" <=  $endyear  ";
      $listobject->querystring .= " and a.\"ACTION\" = 'WL' ";
      $listobject->querystring .= " ORDER BY a.\"MPID\", a.\"YEAR\" ";
      $listobject->performQuery();
      $listobject->showList();
      #$controlHTML .= $listobject->querystring;
      $controlHTML .= $listobject->outstring;

   }
   $controlHTML .= "</div>";
   return $controlHTML;

}

function withdrawalForm($formValues) {
   global $listobject;

   $controlHTML = '';


   $startyear = $formValues['startyear'];
   $endyear = $formValues['endyear'];
   $projectid = $formValues['projectid'];
   $currentgroup = $formValues['currentgroup'];
   $lreditlist = $formValues['lreditlist'];

   if ($startyear == '') { $startyear = Date('Y'); }
   if ($endyear == '') { $endyear = Date('Y'); }
   #print_r($allsegs);
   $controlHTML .= "<form id=control name=control>";
   $controlHTML  .= showHiddenField('projectid', $projectid, 1);
   $controlHTML  .= showHiddenField('currentgroup', $currentgroup, 1);
   $controlHTML  .= showHiddenField('lreditlist', $lreditlist, 1);
   $controlHTML  .= "<br><b>Select Starting year to Sum Water Use:</b>";
   $controlHTML  .= showWidthTextField('startyear', $startyear, 8, '', 1);
   $controlHTML  .= "<br><b>Select Ending year to Sum Water Use:</b>";
   $controlHTML  .= showWidthTextField('endyear', $endyear, 8, '', 1);
   #$controlHTML  .= "<br> $currentgroup - $lreditlist";
   $controlHTML  .= showGenericButton('showwithdrawals','Retrieve Withdrawals', "xajax_showWithdrawalResult(xajax.getFormValues(\"control\"))", 1);
   $controlHTML .= "</form>";
   #print("<br>");
   #$debug = 1;

   return $controlHTML;
}


function withdrawalResult($formValues) {
   global $listobject, $debug, $outdir, $outurl, $goutdir, $gouturl;

   $innerHTML = '';
   #$debug = 1;


   $startyear = $formValues['startyear'];
   $endyear = $formValues['endyear'];
   $projectid = $formValues['projectid'];
   $currentgroup = $formValues['currentgroup'];
   $lreditlist = $formValues['lreditlist'];

   if ($startyear == '') { $startyear = Date('Y'); }
   if ($endyear == '') { $endyear = Date('Y'); }
   #print("<br>");
   #$debug = 1;
   # supresses output, stores it in an object property "outstring"
   $listobject->show = 0;

   if (isset($formValues['showwithdrawals'])) {

      $groups = getGroupWKT($formValues);

      foreach ($groups as $thisgroup) {
        $gname = $thisgroup['groupname'];
        $wktshape = $thisgroup['wktshape'];
        $innerHTML  .= "<b>Summary for:</b> $gname <br>";
        $output = getTotalSurfaceWithdrawalByWKT($listobject, $startyear, $endyear, $wktshape, $debug);
        $totalwd = $output['totalannual'];
        $totalcon = $output['totalconsumptive'];
        $message = $output['message'];
        if ($debug) {
           $innerHTML .= $message;
        }
        $innerHTML  .= "<b>Total for $startyear-$endyear =</b> $totalwd ($totalcon consumptive)<br>";
        $listobject->queryrecords = $output['records'];
        $listobject->tablename = 'vwuds_monthly';
        $listobject->showList();
        $innerHTML .= "$listobject->outstring";
        if ($startyear <> $endyear) {
           $innerHTML  .= "Annual Totals:<br>";
           #$debug = 1;
           $output = getTotalAnnualSurfaceWithdrawalByWKT($listobject, $startyear, $endyear, $wktshape, $debug);
           $annuals = $output['maxdayrecs'];
           $message = $output['message'];
           if ($debug) {
              $innerHTML .= $message;
           }
           $listobject->queryrecords = $annuals;
           $listobject->tablename = 'vwuds_monthly';
           $listobject->showList();
           $innerHTML .= "$listobject->outstring";
           #$debug = 0;
        }
        $innerHTML  .= "<br>By Category:<br>";
        $output = getTotalSurfaceCATWithdrawalByWKT($listobject, $startyear, $endyear, $wktshape, $debug);
        $mpidrecs = $output['maxdayrecs'];
        $message = $output['message'];
        if ($debug) {
           $innerHTML .= $message;
        }
        $listobject->queryrecords = $mpidrecs;
        $listobject->tablename = 'vwuds_monthly';
        $listobject->showList();
        $innerHTML .= $listobject->outstring;
        # generate a pie chart of these mean annual category withdrawals
        $prefs = array(
           'showvalues'=>1,
           'margincolor'=>'white',
           'transparent'=>'white',
           'uselegend'=>1,
           'piescale'=>150,
           'piecenter'=>0.4
        );
        $prefix = 'verbose_';
        $verbosepie = showGenericNamedPie($listobject, $goutdir, $gouturl, $mpidrecs, 'category', 'totalannual', $title, 480, 480, "wu_pie.$projectid" . ".$startyear" . ".$endyear" , $prefs, $debug);
        $innerHTML .= "<img src='$verbosepie'><br>";
        if ($startyear <> $endyear) {
           $innerHTML  .= "<br>By Category, By Year:<br>";
           $output = getTotalAnnualSurfaceCATWithdrawalByWKT($listobject, $startyear, $endyear, $wktshape, $debug);
           $totalcatrecs = $output['totalcatrecs'];
           $message = $output['message'];
           if ($debug) {
              $innerHTML .= $message;
           }
           $targetyears = 2030;
           projectWaterUse($listobject, $totalcatrecs, $targetyears, $projectid, $debug);
           $bfimg = graphBestFitUse($listobject, $outdir, $outurl, $targetyears, $debug);
           $innerHTML .= "<br><img src='$bfimg'><br>";
           $listobject->queryrecords = $totalcatrecs;
           $listobject->tablename = 'vwuds_monthly';
           $listobject->showList();
           $innerHTML .= "$listobject->outstring";
        }
      }
   }

   return $innerHTML;
}

function flowZoneForm($formValues){

   global $listobject, $projectid;

   if (isset($formValues['days'])) {
      $days = $formValues['days'];
   } else {
      $days = 7;
   }

   $innerHTML = '';
   $controlHTML = '';

   # set up input form
   $controlHTML .= "<form id=control name=control>";
   $controlHTML .= "<b>Enter the number of days to analyze:</b>";
   $controlHTML .= showWidthTextField('days', $days, 6, '', 1);
   $controlHTML .= showHiddenField('projectid', $projectid, 1);
   $controlHTML .= "<br>";
   $controlHTML .= showGenericButton('showts', 'Show Flow Series', "xajax_showFlowZoneResult(xajax.getFormValues(\"control\"))", 1);
   $controlHTML .= "</form>";

   return $controlHTML;
}

function flowZoneResult($formValues){

   global $goutdir, $gouturl, $listobject;

   $dr_zones = array(
      'Watch'=>array('01633000'=>120, '01634000'=>150, '01632000'=>100),
      'Warning'=>array('01633000'=>75, '01634000'=>90, '01632000'=>60),
      'Emergency'=>array('01633000'=>30, '01634000'=>65, '01632000'=>25)
   );
   if (isset($formValues['days'])) {
      $days = $formValues['days'];
   } else {
      $days = 7;
   }

   $innerHTML = '';

   $stations = array('01632000'=>"NF Shenandoah at Coote's Store", '01633000'=>"NF Shenandoah at Mount Jackson", '01634000'=>"NF Shenandoah at Strasburg");
   $innerHTML .= "<table><tr>";
   $numstats = 0;
   foreach (array_keys($stations) as $staid) {
      $rname = $stations[$staid];
      $fzdata = createFlowZoneGraph($goutdir, $gouturl, $dr_zones, $staid, $days, 0, $debug);
      #$innerHTML .= join(',', array_keys($fzdata)) . join(',', array_values($fzdata));
      $area = number_format($fzdata['area'],2);
      $thisimg = $fzdata['imageurl'];
      $data = $fzdata['data'];
      $innerHTML .= "<td><center>$rname ($area sq. mi.)<br>";
      $innerHTML .= "<div style=' border:1px solid black; width:320px; height:100px; overflow:auto;'>";
      $innerHTML .= "<b>$days day flow:</b><br>";
      foreach ($data as $thisdata) {
         $thisdate = $thisdata['thisdate'];
         $Qinches = number_format($thisdata['Qinches'],4);
         $Qcfs = number_format($thisdata['Qout'],2);
         $innerHTML .= "$thisdate - $Qcfs cfs ($Qinches inch/day) <br>";
      }
      $innerHTML .= "</div>";
      $innerHTML .= "<img src='$thisimg'></center></td>";
      $numstats += 1;
   }
   $innerHTML .= "</tr></table>";

   return $innerHTML;
}

function showHSI($formValues){

   $objResponse = new xajaxResponse();
   $innerHTML = '';
   $controlHTML = '';

   # set up input form
   $controlHTML .= "<form id=control name=control>";
   $controlHTML .= "<b>Enter the number of days to analyze:</b>";

   $controlHTML .= "<br><b>Enter Start Date (YYYY MM DD):</b> ";
   $controlHTML .= showWidthTextField('syear', $syear, 8, '', 1);
   $controlHTML .= showWidthTextField('smonth', $smonth, 3, '', 1);
   $controlHTML .= showWidthTextField('sday', $sday, 3, '', 1);
   $controlHTML .= "<br> ";
   $controlHTML .= "<b>Enter End Date (YYYY MM DD):</b> ";
   $controlHTML .= showWidthTextField('eyear', $eyear, 8, '', 1);
   $controlHTML .= showWidthTextField('emonth', $emonth, 3, '', 1);
   $controlHTML .= showWidthTextField('eday', $eday, 3, '', 1);
   $controlHTML .= showHiddenField('actiontype', $actiontype, 1);
   $controlHTML .= "<br>";
   $controlHTML .= showGenericButton('showts', 'Show Flow Series', "xajax_showFlowZone(xajax.getFormValues(\"control\"))", 1);
   $controlHTML .= "</form>";

   $innerHTML = "<table><tr>";
   $innerHTML .= "<td align=center>";
   $innerHTML .= "<b>Habitat Suitability Model Estimates at Mount Jackson for Summer 2007 (Laurel Hill Site) </b><br>";
   $innerHTML .= "<img src='/html/hydro_object/out/am.658545adc485711c0c95bf7605561205.png'>";
   $innerHTML .= "</td></tr></table>";

   $objResponse->assign("controlpanel","innerHTML",$controlHTML);
   $objResponse->assign("workspace","innerHTML",$innerHTML);

   return $objResponse;
}

function showPrecipTrends($formValues){

   $objResponse = new xajaxResponse();

   $innerHTML = showPrecipTrendsForm($formValues);
   $objResponse->assign("controlpanel","innerHTML",$innerHTML);

   return $objResponse;
}

function showPrecipTrendsResult($formValues){

   $objResponse = new xajaxResponse();

   $innerHTML .= precipCumulativeMap($formValues);
   $innerHTML .= '<br>' . precipTrendsResult($formValues);
   $controlHTML = showPrecipTrendsForm($formValues);
   $objResponse->assign("controlpanel","innerHTML",$controlHTML);
   $objResponse->assign("workspace","innerHTML",$innerHTML);

   return $objResponse;
}

function showPrecipTrendsForm($formValues) {

   $controlHTML = '';

   $controlHTML .= "<form id=control name=control>";
   $controlHTML .= "<b>Enter Start Date (YYYY MM DD):</b> ";
   $today = new DateTime();
   $tm = $today->format('m');
   $td = $today->format('d');
   $ty = $today->format('Y');

   if (!(isset($formValues['syear']))) {
      $syear = $ty;
      $eyear = $ty;
      $smonth = $tm;
      $emonth = $tm;
      $sday = 1;
      $eday = $td;
   } else {
      $syear = $formValues['syear'];
      $eyear = $formValues['eyear'];
      $smonth = $formValues['smonth'];
      $emonth = $formValues['emonth'];
      $sday = $formValues['sday'];
      $eday = $formValues['eday'];
   }
   $startdate = $syear . str_pad($smonth, 0, 2, STR_PAD_LEFT) . str_pad($sday, 0, 2, STR_PAD_LEFT);
   $enddate = $syear . str_pad($emonth, 0, 2, STR_PAD_LEFT) . str_pad($eday, 0, 2, STR_PAD_LEFT);
   $currentgroup = $formValues['currentgroup'];
   $projectid = $formValues['projectid'];


   $controlHTML .= showWidthTextField('syear', $syear, 8, '', 1);
   $controlHTML .= showWidthTextField('smonth', $smonth, 3, '', 1);
   $controlHTML .= showWidthTextField('sday', $sday, 3, '', 1);
   $controlHTML .= "<br> ";
   $controlHTML .= "<b>Enter End Date (YYYY MM DD):</b> ";
   $controlHTML .= showWidthTextField('eyear', $eyear, 8, '', 1);
   $controlHTML .= showWidthTextField('emonth', $emonth, 3, '', 1);
   $controlHTML .= showWidthTextField('eday', $eday, 3, '', 1);
   $controlHTML .= showHiddenField('currentgroup', $currentgroup, 1);
   $controlHTML .= showHiddenField('projectid', $projectid, 1);
   $controlHTML .= "<br> ";
   $controlHTML .= showGenericButton('showts', 'Show Time Series', "xajax_showPrecipTrendsResult(xajax.getFormValues(\"control\"))", 1);

   return $controlHTML;
}

function precipCumulativeMap($formValues) {
   global $listobject, $panimapfile, $debug, $basedir, $libpath;
   #include("$libpath/module_activemap.php");
   $innerHTML = '';

   $today = new DateTime();
   $tm = $today->format('m');
   $td = $today->format('d');
   $ty = $today->format('Y');
   if (!(isset($formValues['syear']))) {
      $syear = $ty;
      $eyear = $ty;
      $smonth = $tm;
      $emonth = $tm;
      $sday = 1;
      $eday = $td;
   } else {
      $syear = $formValues['syear'];
      $eyear = $formValues['eyear'];
      $smonth = $formValues['smonth'];
      $emonth = $formValues['emonth'];
      $sday = $formValues['sday'];
      $eday = $formValues['eday'];
   }
   $startdate = $syear . '-' . str_pad($smonth, 0, 2, STR_PAD_LEFT) . '-' . str_pad($sday, 0, 2, STR_PAD_LEFT);
   $enddate = $syear . '-' . str_pad($emonth, 0, 2, STR_PAD_LEFT) . '-' . str_pad($eday, 0, 2, STR_PAD_LEFT);


   # shows precip cumulative map, if there is a formValue for "dataname" we use that, otherwise, we default to 'wy2date'
   # which stands for "water year to date"

   $initmap = 1;
   $mapbuffer = 0.1;
   #$debug = 1;
   # manually set to html mode (no need for applet)
   $gbIsHTMLMode = 1;
   #print_r($_POST);
   $invars = $formValues;
   #print_r($invars);

   if (isset($formValues['dataname'])) {
      $dataname = $formValues['dataname'];
   } else {
      $dataname = 'wy2date';
   }

   if ($startdate == $enddate) {
      # if these are set, then we have a non-singular dataname, otherwise, we assume dataname is singular
      $singular = 0;
   } else {
      $singular = 1;
   }

   # for now, we force a singular wy2date map
   $dataname = 'wy2date';
   $singular = 1;

   $innerHTML .= "Precip Map for $dataname ";

   $projectid = $formValues['projectid'];

   $amap = new ActiveMap;
   $amap->gbIsHTMLMode = 0;
   $amap->debug = $debug;
   if ($debug) { $innerHTML .= "Locating map file. $basedir,$panimapfile <br>"; }
   $amap->setMap($basedir,$panimapfile);
   #$debug = 1;
   /*
   if (!checkDate($smonth, $sday, $syear)) {
      $innerHTML .= "<b>Error:</b> Start Date, $syear-$smonth-$sday is not valid.";
      return $innerHTML;
   }

   # should break up the date and validate it here, or allow a date to
   $sdate = new DateTime("$syear-$smonth-$sday");

   if (!checkDate($emonth, $eday, $eyear)) {
      $innerHTML .= "<b>Error:</b> End Date, $eyear-$emonth-$eday is not valid.";
      return $innerHTML;
   }
   $edate = new DateTime("$eyear-$emonth-$eday");

   $su = $sdate->format('U');
   $eu = $edate->format('U');

   if (!( $eu >= $su)) {
      $innerHTML .= "<b>Error:</b>End Date must be >= start date.";
      return $innerHTML;
   }

   */


   # zoom to selected extent
   if (isset($formValues['currentgroup'])) {
      $coords = getGroupExtents($listobject, 'proj_seggroups', 'the_geom', 'gid', $formValues['currentgroup'], " projectid = $projectid ", $mapbuffer, 0 );
      list($lox,$loy,$hix,$hiy) = split(',', $coords);
      $amap->quickView($lox,$loy,$hix,$hiy);
      if ($debug) {
         $innerHTML .= "Coords: $coords<br>";
      }
      $gfilta = " projectid = $projectid ";
      $thislayer = $amap->map->getLayerByName('proj_seggroups');
      if ($formValues['currentgroup'] > 0) {
         $gfilta .= "AND gid = " . $formValues['currentgroup'] . " ";
      }
      $thislayer->setFilter($gfilta);
      $innerHTML .= "$filter <br>";
   }

   $preciplayer = $amap->map->getLayerByName('precip_period');
   $filter = " dataname = '$dataname' ";
   if (!$singular) {
      $filter .= " AND startdate = '$startdate' AND enddate = '$enddate' ";
   }
   $innerHTML .= "$filter <br>";
   $preciplayer->setFilter($filter);
   $preciplayer->set("status",MS_ON);

   /*
   # get quantiles for the data set
   $listobject->querystring = "  select r_quantile(array_accum(globvalue), 0.25) as q25, ";
   $listobject->querystring .= " r_quantile(array_accum(globvalue), 0.5) as q50,";
   $listobject->querystring .= " r_quantile(array_accum(globvalue), 0.75) as q75,";
   $listobject->querystring .= " from precip_gridded_period ";
   $listobject->querystring .= " where dataname = 'wy2date' ";
   $listobject->querystring .= "    and the_geom && (select setsrid(extent(the_geom),4326) ";
   $listobject->querystring .= "                     from proj_seggroups ";
   $listobject->querystring .= "                     where projectid = $projectid ";
   $listobject->querystring .= "    ) ";
   if (!$singular) {
      $listobject->querystring .= " AND startdate = \"$startdate\" AND enddate = \"$enddate\" ";
   }
   if (strlen(ltrim(rtrim($formValues['currentgroup']))) > 0) {
      $listobject->querystring .= " AND gid = " . $formValues['currentgroup'];
   }
   if ($debug) {
      $innerHTML .= $listobject->querystring;
   }
   $listobject->performQuery();
   $q25 = $listobject->getRecordValue(1,'q25');
   $q50 = $listobject->getRecordValue(1,'q50');
   $q75 = $listobject->getRecordValue(1,'q75');
   */
   $annotext = "Cumulative precip from $startdate to $enddate  ";
   $annotlayer = $amap->map->getLayerByName('copyright');
   $annotation = $annotlayer->getClass(0);
   $annotation->setText($annotext);
   $annotlayer->set("status",MS_ON);
   $image = $amap->map->draw();
   $image_url = $image->saveWebImage(MS_GIF,1,1,0);
   $innerHTML .= "<img src='$image_url'>";

   return $innerHTML;

}


function precipTrendsResult($formValues) {
   global $listobject, $panimapfile, $debug, $basedir, $libpath;
   #include("$libpath/module_activemap.php");
   $innerHTML = '';

   $today = new DateTime();
   $tm = $today->format('m');
   $td = $today->format('d');
   $ty = $today->format('Y');
   if (!(isset($formValues['syear']))) {
      $syear = $ty;
      $eyear = $ty;
      $smonth = $tm;
      $emonth = $tm;
      $sday = 1;
      $eday = $td;
   } else {
      $syear = $formValues['syear'];
      $eyear = $formValues['eyear'];
      $smonth = $formValues['smonth'];
      $emonth = $formValues['emonth'];
      $sday = $formValues['sday'];
      $eday = $formValues['eday'];
   }
   $startdate = $syear . '-' . str_pad($smonth, 0, 2, STR_PAD_LEFT) . '-' . str_pad($sday, 0, 2, STR_PAD_LEFT);
   $enddate = $syear . '-' . str_pad($emonth, 0, 2, STR_PAD_LEFT) . '-' . str_pad($eday, 0, 2, STR_PAD_LEFT);

   $timedelay = 60;
   #$anim_gif_cmd = '"C:\Program Files\Apache Group\Apache2\cgi-bin\gifsicle" -l -d 100 -O2 ';
   $anim_gif_cmd = "gifsicle -l -d $timedelay -O2 ";
   $initmap = 1;
   $mapbuffer = 0.1;
   #$debug = 1;
   # manually set to html mode (no need for applet)
   $gbIsHTMLMode = 1;
   #print_r($_POST);
   $invars = $formValues;
   #print_r($invars);

   $projectid = $formValues['projectid'];
   $syear = $formValues['syear'];
   $eyear = $formValues['eyear'];
   $smonth = $formValues['smonth'];
   $emonth = $formValues['emonth'];
   $sday = $formValues['sday'];
   $eday = $formValues['eday'];

   if ($initmap) {
      if ($debug) {
         $innerHTML .= "Creating map objects.<br>";
      }
      $amap = new ActiveMap;
      $amap->gbIsHTMLMode = 0;
      $amap->debug = 0;
      if ($debug) { $innerHTML .= "Locating map file.<br>"; }
      $amap->setMap($basedir,$panimapfile);
      #$HTTP_SESSION_VARS["amap"] = $amap;
   } else {
      $amap->debug = $debug;
      $amap->setMap($basedir,$panimapfile);
   }

   $amap->img_type = MS_GIF;

   if (!checkDate($smonth, $sday, $syear)) {
      $innerHTML .= "<b>Error:</b> Start Date, $syear-$smonth-$sday is not valid.";
      return $innerHTML;
   }
   $sdate = new DateTime("$syear-$smonth-$sday");

   if (!checkDate($emonth, $eday, $eyear)) {
      $innerHTML .= "<b>Error:</b> End Date, $eyear-$emonth-$eday is not valid.";
      return $innerHTML;
   }
   $edate = new DateTime("$eyear-$emonth-$eday");

   $su = $sdate->format('U');
   $eu = $edate->format('U');

   if (!( $eu >= $su)) {
      $innerHTML .= "<b>Error:</b>End Date must be >= start date.";
      return $innerHTML;
   }


   # zoom to selected extent
   if (isset($formValues['currentgroup'])) {
      $coords = getGroupExtents($listobject, 'proj_seggroups', 'the_geom', 'gid', $formValues['currentgroup'], " projectid = $projectid ", $mapbuffer, 0 );
      list($lox,$loy,$hix,$hiy) = split(',', $coords);
      $amap->quickView($lox,$loy,$hix,$hiy);
      if ($debug) {
         $innerHTML .= "Coords: $coords<br>";
      }
      $gfilta = " projectid = $projectid ";
      $thislayer = $amap->map->getLayerByName('proj_seggroups');
      if ($formValues['currentgroup'] > 0) {
         $gfilta .= "AND gid = " . $formValues['currentgroup'] . " ";
      }
      $thislayer->setFilter($gfilta);
      $innerHTML .= "$gfilta <br>";
   }

   #print("$su - $eu <br>");
   $gifmaps = array();
   while ($su <= $eu) {
      array_push($gifmaps, $sdate->format('Y-m-d'));
      $sdate->modify("+1 day");
      $su = $sdate->format('U');
      #print("$su / $eu ");
   }

   $i = 1;

   if ($debug) {
      $innerHTML .= "Adding";
   }
   $thislayer = $amap->map->getLayerByName('poli_bounds');
   $thislayer->setFilter(" projectid = $projectid ");
   foreach ($gifmaps as $thisdate) {
      if ($debug) {
         $innerHTML .= " ... $thisdate ";
      }
      $thislayer = $amap->map->getLayerByName('precip_obs');
      $filter = " thisdate = '$thisdate' ";
      $listobject->querystring = "  select thisdate, count(*) as numrecs ";
      $listobject->querystring .= " from precip_gridded ";
      $listobject->querystring .= " where $filter ";
      $listobject->querystring .= " group by thisdate ";
      $listobject->performQuery();
      $numrecs = $listobject->getRecordValue(1,'numrecs');
      $annotlayer = $amap->map->getLayerByName('copyright');
      $oPoint = ms_newPointObj();
      $oPoint->setXY(150,180);
      $x = $oPoint->x;
      $y = $oPoint->y;
      if ($debug) {
         $innerHTML .= "Point coords are: $x, $y <br>";
      }
      $annotation = $annotlayer->getClass(0);
      if ($numrecs > 0) {
         $thislayer->setFilter($filter);
         $thislayer->set("status",MS_ON);
         $annotlayer->set("status",MS_ON);
         #$annotation->setText("Precipitation for $thisdate");
         $image[$i] = $amap->map->draw();
         #$annotlayer->set("status",MS_ON);
         #$pres = $oPoint->draw($amap->map, $annotlayer, $image[$i], 0, "Test text");
         #if( $pres == MS_SUCCESS ) {
         #   if ($debug) {
         #      $innerHTML .= "Point Drawn: $pres.<br>";
         #   }
         #}
         #$image[$i] = $amap->map->draw();
         #$image_url[$i] = $image[$i]->saveWebImage(MS_GIF,1,1,0);
         $image_url[$i] = $image[$i]->saveWebImage();
         $file_path[$i] = $amap->map->web->imagepath
                          . substr(strrchr($image_url[$i], "/"),1);
         $anim_files   = $anim_files . '"' . $file_path[$i] . '"' . " ";
         $i++;
         if ($debug) {
            $innerHTML .= " Adding <i>$filter</i>, $image_url[$i] <br>";
         }
      }
   }

   // Create a unique filename and URL for the animated GIF output
   $anim_name = "anim".substr(strrchr($image_url[1], '/'),1);
   $anim_path = '"' . $amap->map->web->imagepath . $anim_name .'"';
   $anim_url = $amap->map->web->imageurl . $anim_name;

   if ($debug) {
      $innerHTML .= "Creating $anim_path <br>";
   }
   $cmd = $anim_gif_cmd . " -o " . $anim_path . " " .  $anim_files;
   #if ($debug) {
      $innerHTML .= "Using: $cmd <br>";
   #}

   system($cmd);

   $innerHTML .= "<img src='$anim_url'>";
   #$amap->map->legend->set('width', 128);
   $amap->drawLegend();
   $legendurl = $amap->legend_url;
   $innerHTML .= "<img src='$legendurl'>";

   #$innerHTML .= showPrecipStat($formValues, $amap);
   #$innerHTML .= showFlowStat($formValues, $amap);
   #$innerHTML .= showGWStat($formValues, $amap);

   return $innerHTML;

}

function showPrecipStat($formValues, $amap) {
   global $listobject, $projectid, $panimapfile, $debug, $basedir, $libpath;

   $currentgroup = $formValues['currentgroup'];
   if ( ($currentgroup > 0) ) {
      $gids = $currentgroup;
   } else {
      $gids = " select gid from proj_seggroups where projectid = $projectid ";
   }
   # should set this in an object some where
   if ($projectid == 2) {
      $gids = '19,20,21';
   }
   $timeperiods = array(0,1,2,'rollwyprecip');

   $thislayer = $amap->map->getLayerByName('poli_bounds');
   $thislayer->set("status",MS_ON);
   $thislayer->setFilter("projectid = $projectid");

   $thislayer = $amap->map->getLayerByName('precip_obs');
   $thislayer->set("status",MS_OFF);
   $thislayer = $amap->map->getLayerByName('gw_stat');
   $thislayer->set("status",MS_OFF);
   $thislayer = $amap->map->getLayerByName('flow_stat');
   $thislayer->set("status",MS_OFF);
   $thislayer = $amap->map->getLayerByName('proj_seggroups');
   $filter = " gid in ($gids) ";
   $thislayer->setFilter($filter);
   $thislayer->set("status",MS_OFF);
   foreach ($timeperiods as $thisperiod) {
      if ($thisperiod == 0) {
         $annotext = "Month to date precipitation";
      } else {
         $annotext = "Month to date +$thisperiod months precipitation";
      }
      if (is_string($thisperiod)) {
         $obsmetric = "'$thisperiod" . "_obs'";
         $pctmetric = "'$thisperiod" . "_dep_pct'";
         $annotext = "Previous Water Year to date precipitation";
      } else {
         $obsmetric = "'tmp_precip_$thisperiod" . "mos_obs'";
         $pctmetric = "'tmp_precip_$thisperiod" . "mos_dep_pct'";
      }
      $listobject->querystring = "  select initcap(a.groupname) as groupname, a.startdate, a.enddate, ";
      $listobject->querystring .= "    a.thisvalue as pct, b.thisvalue as observed ";
      $listobject->querystring .= " from proj_group_stat as a left outer join proj_group_stat as b ";
      $listobject->querystring .= "    on ( b.projectid = a.projectid ";
      $listobject->querystring .= "    and a.gid = b.gid ";
      $listobject->querystring .= "    and b.thismetric = $obsmetric ";
      $listobject->querystring .= "    ) ";
      $listobject->querystring .= " where a.projectid = $projectid ";
      $listobject->querystring .= "    and a.gid in ($gids) ";
      $listobject->querystring .= "    and a.thismetric = $pctmetric ";
      $listobject->querystring .= " order by a.groupname ";
      $listobject->performQuery();

      $innerHTML .= "<table>";
      $innerHTML .= "$listobject->querystring ; <br>";
      $innerHTML .= "<tr><td><center><b>$annotext</b><br>";
      $innerHTML .= "<div style=' border:1px solid black; width:480px; height:100px; overflow:auto;'>";
      $innerHTML .= "<table><tr><td>";
      foreach ($listobject->queryrecords as $thisdata) {
         $startdate = date('m-d-Y',strtotime($thisdata['startdate']));
         $enddate = date('m-d-Y',strtotime($thisdata['enddate']));
         $groupname = $thisdata['groupname'];
         $pct = number_format(100.0 * $thisdata['pct'],2);
         $observed = number_format($thisdata['observed'],2);
         $innerHTML .= "$groupname, $startdate to $enddate: $observed in ($pct %) <br>";
      }
      $innerHTML .= "</td><td>";

      # try out new daily slice summary (realtime, super fast)
      #select period summary for a given seggroup
      $listobject->querystring .= " select a.gid, a.groupname, a.thismetric, a.thisvalue as obs, b.thisvalue as norm,  ";
      $listobject->querystring .= "    a.thisvalue / b.thisvalue as pct, a.num_obs, b.num_nml  ";
      $listobject->querystring .= " from (  ";
      $listobject->querystring .= "    select gid, groupname, thismetric, sum(thisvalue) as thisvalue, count(gid) as num_obs   ";
      $listobject->querystring .= "    from proj_group_stat  ";
      $listobject->querystring .= "    where thismetric = 'daily_precip_obs' ";
      $listobject->querystring .= "    and startdate >= '$startdate' ";
      $listobject->querystring .= "    and enddate <= '$enddate'  ";
      #make sure this is a single day entry
      $listobject->querystring .= "    and startdate = enddate ";
      $listobject->querystring .= "    and gid in ($gids) ";
      $listobject->querystring .= "    group by gid, groupname, thismetric  ";
      $listobject->querystring .= " ) as a, (  ";
      $listobject->querystring .= "    select gid, sum(thisvalue) as thisvalue, count(gid) as num_nml  ";
      $listobject->querystring .= "    from proj_group_stat  ";
      $listobject->querystring .= "    where thismetric = 'daily_precip_nml' ";
      $listobject->querystring .= "    and startdate >= '$startdate' ";
      $listobject->querystring .= "    and enddate <= '$enddate'  ";
      #make sure this is a single day entry
      $listobject->querystring .= "    and startdate = enddate ";
      $listobject->querystring .= "    and gid in ($gids) ";
      $listobject->querystring .= "    group by gid  ";
      $listobject->querystring .= " ) as b  ";
      $listobject->querystring .= " where b.gid = a.gid; ";
      $listobject->performQuery();
      $listobject->show = 0;
      $listobject->showList();
      $innerHTML .= $listobject->querystring;
      $innerHTML .= $listobject->outstring;

      $innerHTML .= "</td></tr></table>";
      $innerHTML .= "</div></center></td></tr>";
      $thislayer = $amap->map->getLayerByName('precip_stat');
      $filter = " thismetric = $pctmetric and gid in ($gids) ";
      $thislayer->setFilter($filter);
      $thislayer->set("status",MS_ON);
      $annotlayer = $amap->map->getLayerByName('copyright');
      $annotation = $annotlayer->getClass(0);
      $annotlayer->set("status",MS_ON);
      $annotation->setText($annotext);
      $image = $amap->map->draw();
      $image_url = $image->saveWebImage(MS_GIF,1,1,0);
      $innerHTML .= "<img src='$image_url'>";
   }
   $amap->drawLegend();
   $legendurl = $amap->legend_url;
   $innerHTML .= "<img src='$legendurl'>";

   return $innerHTML;


}

function showFlowStat($formValues, $amap) {
   global $listobject, $projectid, $panimapfile, $debug, $basedir, $libpath;

   # should set this in an object some where
   $currentgroup = $formValues['currentgroup'];
   if ( ($currentgroup > 0) ) {
      $gids = $currentgroup;
   } else {
      $gids = " select gid from proj_seggroups where projectid = $projectid ";
   }
   # should set this in an object some where
   if ($projectid == 2) {
      $gids = '19,20,21';
   }

   $timeperiods = array(0,1,2,'rollwyflow');

   $thislayer = $amap->map->getLayerByName('poli_bounds');
   $thislayer->set("status",MS_ON);
   $thislayer->setFilter("projectid = $projectid");

   # layers to turn off
   $thislayer = $amap->map->getLayerByName('precip_stat');
   $thislayer->set("status",MS_OFF);
   $thislayer = $amap->map->getLayerByName('precip_obs');
   $thislayer->set("status",MS_OFF);
   $thislayer = $amap->map->getLayerByName('gw_stat');
   $thislayer->set("status",MS_OFF);

   # label layer
   $thislayer = $amap->map->getLayerByName('proj_seggroups');
   $filter = " gid in ($gids) ";
   $thislayer->setFilter($filter);
   $thislayer->set("status",MS_OFF);
   foreach ($timeperiods as $thisperiod) {
      if ($thisperiod == 0) {
         $annotext = "Month to date flow";
      } else {
         $annotext = "Month to date +$thisperiod months flow";
      }

      if (is_string($thisperiod)) {
         $obsmetric = "'$thisperiod" . "_value'";
         $pctmetric = "'$thisperiod'";
         $annotext = "Previous Water Year to date flow";
      } else {
         $obsmetric = "'tmp_flow_mtd_$thisperiod" . "mos_value'";
         $pctmetric = "'tmp_flow_mtd_$thisperiod" . "mos'";
      }
      $listobject->querystring = "  select initcap(a.groupname) as groupname, a.startdate, a.enddate, ";
      $listobject->querystring .= "    a.thisvalue as pct, b.thisvalue as observed ";
      $listobject->querystring .= " from proj_group_stat as a left outer join proj_group_stat as b ";
      $listobject->querystring .= "    on ( b.projectid = a.projectid ";
      $listobject->querystring .= "    and a.gid = b.gid ";
      $listobject->querystring .= "    and b.thismetric = $obsmetric ";
      $listobject->querystring .= "    ) ";
      $listobject->querystring .= " where a.projectid = $projectid ";
      $listobject->querystring .= "    and a.gid in ($gids) ";
      $listobject->querystring .= "    and a.thismetric = $pctmetric ";
      $listobject->querystring .= " order by a.groupname ";
      $listobject->performQuery();

      $innerHTML .= "<table>";
      #$innerHTML .= "$listobject->querystring ; <br>";
      $innerHTML .= "<tr><td><center>$annotext<br>";
      $innerHTML .= "<div style=' border:1px solid black; width:480px; height:100px; overflow:auto;'>";
      foreach ($listobject->queryrecords as $thisdata) {
         $startdate = $thisdata['startdate'];
         $enddate = $thisdata['enddate'];
         $groupname = $thisdata['groupname'];
         $pct = number_format(100.0 * $thisdata['pct'],2);
         $observed = number_format($thisdata['observed'],2);
         $innerHTML .= "$groupname, $startdate - $enddate: $observed cfs ($pct %) <br>";
      }
      $innerHTML .= "</div></td></tr>";
      $thislayer = $amap->map->getLayerByName('flow_stat');
      $filter = " thismetric = $pctmetric and gid in ($gids) ";
      $thislayer->setFilter($filter);
      $thislayer->set("status",MS_ON);
      $annotlayer = $amap->map->getLayerByName('copyright');
      $annotation = $annotlayer->getClass(0);
      $annotlayer->set("status",MS_ON);
      $annotation->setText($annotext);
      $image = $amap->map->draw();
      $image_url = $image->saveWebImage(MS_GIF,1,1,0);
      $innerHTML .= "<tr><td><img src='$image_url'></td></tr>";
      $innerHTML .= "</table>";
   }
   $amap->drawLegend();
   $legendurl = $amap->legend_url;
   $innerHTML .= "<img src='$legendurl'>";

   return $innerHTML;


}

function showGWStat($formValues, $amap) {
   global $listobject, $projectid, $panimapfile, $debug, $basedir, $libpath;

   # should set this in an object some where

   $currentgroup = $formValues['currentgroup'];
   if ( ($currentgroup > 0) ) {
      $gids = $currentgroup;
   } else {
      $gids = " select gid from proj_seggroups where projectid = $projectid ";
   }
   # should set this in an object some where
   if ($projectid == 2) {
      $gids = '19,20,21';
   }
   $timeperiods = array(0,1,2,'rollwygw');

   $thislayer = $amap->map->getLayerByName('poli_bounds');
   $thislayer->set("status",MS_ON);
   $thislayer->setFilter("projectid = $projectid");

   # layers to turn off
   $thislayer = $amap->map->getLayerByName('precip_stat');
   $thislayer->set("status",MS_OFF);
   $thislayer = $amap->map->getLayerByName('precip_obs');
   $thislayer->set("status",MS_OFF);

   # label layer
   $thislayer = $amap->map->getLayerByName('proj_seggroups');
   $filter = " gid in ($gids) ";
   $thislayer->setFilter($filter);
   $thislayer->set("status",MS_OFF);
   foreach ($timeperiods as $thisperiod) {
      if ($thisperiod == 0) {
         $annotext = "Month to date groundwater";
      } else {
         $annotext = "Month to date +$thisperiod months groundwater";
      }
      if (is_string($thisperiod)) {
         $obsmetric = "'$thisperiod" . "_value'";
         $pctmetric = "'$thisperiod'";
         $annotext = "Previous Water Year to date groundwater";
      } else {
         $obsmetric = "'tmp_gw_mtd_$thisperiod" . "mos_value'";
         $pctmetric = "'tmp_gw_mtd_$thisperiod" . "mos'";
      }
      $listobject->querystring = "  select initcap(a.groupname) as groupname, a.startdate, a.enddate, ";
      $listobject->querystring .= "    a.thisvalue as pct, b.thisvalue as observed ";
      $listobject->querystring .= " from proj_group_stat as a left outer join proj_group_stat as b ";
      $listobject->querystring .= "    on ( b.projectid = a.projectid ";
      $listobject->querystring .= "    and a.gid = b.gid ";
      $listobject->querystring .= "    and b.thismetric = $obsmetric ";
      $listobject->querystring .= "    ) ";
      $listobject->querystring .= " where a.projectid = $projectid ";
      $listobject->querystring .= "    and a.gid in ($gids) ";
      $listobject->querystring .= "    and a.thismetric = $pctmetric ";
      $listobject->querystring .= " order by a.groupname ";
      $listobject->performQuery();

      $innerHTML .= "<table>";
      #$innerHTML .= "$listobject->querystring ; <br>";
      $innerHTML .= "<tr><td><center>$annotext<br>";
      $innerHTML .= "<div style=' border:1px solid black; width:480px; height:100px; overflow:auto;'>";
      foreach ($listobject->queryrecords as $thisdata) {
         $startdate = $thisdata['startdate'];
         $enddate = $thisdata['enddate'];
         $groupname = $thisdata['groupname'];
         $pct = number_format(100.0 * $thisdata['pct'],2);
         $observed = number_format($thisdata['observed'],2);
         $innerHTML .= "$groupname, $startdate - $enddate: $observed ft ($pct %) <br>";
      }
      $innerHTML .= "</div></td></tr>";
      $thislayer = $amap->map->getLayerByName('flow_stat');
      $filter = " thismetric = $pctmetric and gid in ($gids) ";
      $thislayer->setFilter($filter);
      $thislayer->set("status",MS_ON);
      $annotlayer = $amap->map->getLayerByName('copyright');
      $annotation = $annotlayer->getClass(0);
      $annotlayer->set("status",MS_ON);
      $annotation->setText($annotext);
      $image = $amap->map->draw();
      $image_url = $image->saveWebImage(MS_GIF,1,1,0);
      $innerHTML .= "<img src='$image_url'>";
   }
   $amap->drawLegend();
   $legendurl = $amap->legend_url;
   $innerHTML .= "<img src='$legendurl'>";

   return $innerHTML;


}

function showWaterPlanList($listobject, $projectid, $userid, $elementid) {
   global $debug;
   $foosql = "  ( select elementid, elemname ";
   $foosql .= "   from proj_element ";
   $foosql .= "   where elemtype = 'wsplan' ";
   $foosql .= "      and projectid = $projectid and ( (ownerid = $userid  and operms >= 4) ";
   $foosql .= "      or ( groupid in (select groupid from mapusergroups where userid = $userid) and gperms >= 4 ) ";
   $foosql .= "      or (pperms >= 4) ) ";
   $foosql .= "  ) as foo ";
   if ($debug) {
      $controlHTML .= "$foosql ; <br>";
   }
   $controlHTML .= showActiveList($listobject, 'loadelement', $foosql, 'elemname', 'elementid', '', $elementid, 'document.forms["planningform"].elements.actiontype.value="loadelement"; xajax_showPlanningForm(xajax.getFormValues("planningform"))', 'elemname', $debug, 1);

   return $controlHTML;
}

function showInfoWindow() {
   $controlHTML = "<div id=\"window1\">";
   $controlHTML .= "   <div class=\"floatingWindowContent\">";
   $controlHTML .= "   This is a window where I have disabled the scrollbar at the right. If you try to resize it, you will see that some of this text will be hidden";
   $controlHTML .= "   below the bottom edge of the window.<br><br>";
   $controlHTML .= "   I have sent removed the close button from the window.";
   $controlHTML .= "   </div>";
   $controlHTML .= "   <div class=\"floatingWindowContent\">";
   $controlHTML .= "   This script is based on simple ordinary div tags. This makes it very easy to set up. Put in your HTML content and call a javascript function to initialize the window.  ";
   $controlHTML .= "   </div>";
   $controlHTML .= "   <div class=\"floatingWindowContent\">";
   $controlHTML .= "   Content 3   ";
   $controlHTML .= "   </div>";
   $controlHTML .= "</div> ";

   return $controlHTML;
}

function planningForm($formValues) {
   global $listobject, $projectid, $scenarioid, $adminsetuparray, $planpages, $userid, $usergroupids, $defaultgroupid;

   $controlHTML = '';

   $controlHTML .= "<form id='planningform' name='planningform'>";


   $elementid = '';

   if (isset($formValues['elementid'])) {
      $elementid = $formValues['elementid'];
   }

   #$controlHTML .= '<br>Form Values: <br>' . print_r($formValues, 1);
   if (isset($formValues['loadelement'])) {
      $elementid = $formValues['loadelement'];
      $seglist = $formValues['seglist'];
   }
   if ($elementid > 0) {
      $elemperms = getProjElementPerms($listobject, $projectid, $elementid, $userid, $usergroupids, $debug);
      if ( !($elemperms & 2) ) {
         $disabled = 1;
      } else {
         $disabled = 0;
      }
   }
   if (isset($formValues['seglist'])) {
      $seglist = $formValues['seglist'];
   }
   # set up blank plan information
   $template = $adminsetuparray['watersupply_plan']['column info'];
   $plandata = array();
   foreach (array_keys($template) as $plancol) {
      $plandata[$plancol] = '';
      if ($debug) {
         $controlHTML .= " $plancol set to '' ";
      }
   }
   $options = array(XML_SERIALIZER_OPTION_MODE => XML_SERIALIZER_MODE_SIMPLEXML);
   $serializer = new XML_Serializer($options);
   $unserializer = new XML_Unserializer($options);

   $saved_date = array();
   #$controlHTML .= '<br>XML Values: <br>' . print_r($plandata, 1);

   # check to see if we are loading/saving a plan
   if ($elementid >= 1) {
      # load the most recent information into an XML object
      $listobject->querystring = " select elem_xml from proj_element where elementid = $elementid";
      if ($debug) {
         $controlHTML .= "$listobject->querystring ; <br>";
      }
      $listobject->performQuery();
      $elem_xml = $listobject->getRecordValue(1,'elem_xml');
      $result = $unserializer->unserialize($elem_xml, false);
      $saved_data = $unserializer->getUnserializedData();

      if ($result === true) {
         # overwrite template info with saved data
         foreach (array_keys($plandata) as $thiscol) {
            $plandata[$thiscol] = $saved_data[$thiscol];
            if ($debug) {
               $controlHTML .= "setting $thiscol = $saved_data[$thiscol] <br>";
            }
         }
      }
   }
   #$controlHTML .= '<br>XML Values: <br>' . print_r($plandata, 1);
   #$controlHTML .= '<br>XML Values: <br>' . print_r($plandata['resources_recreation'], 1);
   #$controlHTML .= '<br>Form Values: <br>' . print_r($formValues['gw_sourcename'], 1);
   #$controlHTML .= '<br>Form Values: <br>' . print_r($formValues, 1);
   if (isset($formValues['actiontype'])) {
      $actiontype = $formValues['actiontype'];
      switch ($actiontype) {
         case 'updateplan':
         # we came from our form, save any changes
         #$controlHTML .= '<br>Form Values: <br>' . print_r($formValues, 1);

         # first, check permissions
         #$controlHTML .= "Element Permissions: $elemperms <br> ";
         if ( !($elemperms & 2) ) {
            $controlHTML .= "<b>Notice:</b> You do not have edit permissions on this plan. <br>";
         } else {
            foreach ($planpages[$formValues['activepage']]['components'] as $thiscomp) {
               $colinfo = $adminsetuparray[$thiscomp]['column info'];
               # check for data type, multi y/n
               if ($planpages[$formValues['activepage']]['multi']) {
                  # multi-dimensional data
                  $colnames = array_keys($colinfo);
                  $n = count($formValues[$colnames[0]]);
                  $c = 0;
                  $plantemp = array();
                  for ($j = 0; $j < $n; $j++) {
                     $planrec = array();
                     foreach (array_keys($colinfo) as $thiscol) {
                        $formplandata = array_shift($formValues[$thiscol]);
                        $planrec[$thiscol] = $formplandata;
                        #$controlHTML .= "shifting $thiscol #$j<br> ";
                     }
                     $planreclength = strlen(join('',array_values_recursive($planrec)));
                     #$controlHTML .= " $planreclength length<br> ";
                     if ($planreclength > 0) {
                        $plantemp[$c] = $planrec;
                        #$controlHTML .= "Record $c Added<br> ";
                        $c++;
                     }
                  }
                  $plandata[$thiscomp] = $plantemp;
                  #$controlHTML .= "Record " . print_r($plandata[$thiscomp],1) . "<br> ";
               } else {
                  # uni-dimensional data
                  foreach (array_keys($colinfo) as $thiscol) {
                     $plandata[$thiscol] = $formValues[$thiscol];
                     #$controlHTML .= "setting $thiscol = $formValues[$thiscol] <br> ";
                  }
               }
            }

            #$controlHTML .= '<br>XML Values: <br>' . print_r($plandata, 1);
            $result = $serializer->serialize($plandata);
            $elem_xml = $serializer->getSerializedData();
            $elemname = $plandata['planname'];
            $listobject->querystring = "  update proj_element set elem_xml = '$elem_xml', elemname = '$elemname' ";
            $listobject->querystring .= " where elementid = $elementid ";
            if ($debug) {
               $controlHTML .= "$listobject->querystring ; <br>";
            }
            $listobject->performQuery();
         }
         break;

         case 'createplan':
         # insert new plan
         #$debug = 1;
         $listobject->querystring = "  insert into proj_element(projectid, ownerid, groupid, elemtype) ";
         $listobject->querystring .= "  values ($projectid, $userid, $defaultgroupid, 'wsplan') ";
         if ($debug) {
            $controlHTML .= "$listobject->querystring ; <br>";
         }
         $listobject->performQuery();
         $listobject->querystring = "  select max(elementid) as elementid from proj_element ";
         $listobject->querystring .= " where projectid = $projectid ";
         $listobject->querystring .= " and ownerid = $userid ";
         $listobject->querystring .= " and groupid = $defaultgroupid ";
         $listobject->querystring .= " and elemtype = 'wsplan' ";
         if ($debug) {
            $controlHTML .= "$listobject->querystring ; <br>";
         }
         $listobject->performQuery();
         $elementid = $listobject->getRecordValue(1,'elementid');
         $listobject->querystring = " select elem_xml from proj_element where elementid = $elementid";
         if ($debug) {
            $controlHTML .= "$listobject->querystring ; <br>";
         }
         $listobject->performQuery();
         $elem_xml = $listobject->getRecordValue(1,'elem_xml');
         $result = $unserializer->unserialize($elem_xml, false);
         $saved_data = $unserializer->getUnserializedData();

         if ($result === true) {
            # overwrite template info with saved data
            foreach (array_keys($plandata) as $thiscol) {
               $plandata[$thiscol] = $saved_data[$thiscol];
            }
         }
         #$debug = 0;
         break;
      }
   }

   # show list of users/groups plans
   $controlHTML .= '<b>Plan:</b>';
   $controlHTML .= showWaterPlanList($listobject, $projectid, $userid, $elementid);

   $controlHTML .= "<a class='mE' onclick=\"document.forms['planningform'].elements.actiontype.value='createplan'; ";
   $controlHTML .= "xajax_showPlanningForm(xajax.getFormValues('planningform'))\"> New Plan </a>";

   if ($debug) {
      $controlHTML .= '<br>Form Values: <br>' . print_r($plandata['element_seggroup'], 1);
   }
   # refreshes the adminsetup file
   include("adminsetup.php");
   $activepage = '';
   if (isset($formValues['gotopage'])) {
      $activepage = $formValues['gotopage'];
      #$controlHTML .= $activepage;
   }
   #$elementid = $formValues['elementid'];

   if (strlen($activepage) == 0) {
      $pagenames = array_keys($planpages);
      $activepage = $pagenames[0];
   }

   $controlHTML .= showHiddenField('currentgroup', $currentgroup, 1);
   $controlHTML .= showHiddenField('scenarioid', $scenarioid, 1);
   $controlHTML .= showHiddenField('projectid', $projectid, 1);
   $controlHTML .= showHiddenField('activepage', $activepage, 1);
   $controlHTML .= showHiddenField('gotopage', $activepage, 1);
   $controlHTML .= showHiddenField('actiontype', 'updateplan', 1);
   $controlHTML .= showHiddenField('elementid', $elementid, 1);
   $controlHTML .= showHiddenField('seglist', $seglist, 1);
   $controlHTML .= "<ul id='tabmenu'>";
   foreach ($planpages as $thispage) {

      $tab_text = $thispage['tab_text'];
      $title = $thispage['title'];
      $formatname = $thispage['formatname'];
      if ($activepage == $formatname) {
         $class = "class='active'";
      } else {
         $class = '';
      }
      $controlHTML .= "<li><a $class onclick=\"document.forms['planningform'].elements.gotopage.value='$formatname'; ";
      $controlHTML .= "xajax_showPlanningForm(xajax.getFormValues('planningform'))\"> $tab_text </a>";
   }
   $controlHTML .= "</ul>";

   $pagetitle = $planpages[$activepage]['title'];
   $multiform = $planpages[$activepage]['multi'];
   $controlHTML .= "<font class='heading1'>$pagetitle </font><br>";
   if ($elementid > 0) {
      # we have a plan selected, or recently created, show the form
      foreach ($planpages[$activepage]['components'] as $thiscomp) {
         #$controlHTML .= "Loading $thiscomp <br>";
         $controlHTML .= "<div style=\"border: 1px solid rgb(0 , 0, 0);\">";
         if ($multiform) {
            $comptitle = $adminsetuparray['watersupply_plan']['column info'][$thiscomp]['label'];
            $controlHTML .= "<font class='heading2'>$comptitle:</font><br>";
            $showlabels = 1;
            $blankrow = array();
            $colnames = array_keys($adminsetuparray[$thiscomp]['column info']);
            # set up blank row
            foreach ($colnames as $thiscolname) {
               # add a blank row
               $blankrow[$thiscolname] = '';
            }
            $controlHTML .= "<table>";
            $i = 0;
            # add a key
            $blank = 0;
            foreach ($plandata[$thiscomp] as $thisdataline) {
               $blank = 1;
               $rowcontents = join('', $thisdataline);
               if (strlen(ltrim(rtrim($rowcontents))) > 0) {
                  $blank = 0;
                  #$controlHTML .= "<tr><td>row is not blank " . print_r($thisdataline,1) . "</td></tr>";
               }
               # add numeric key column for display
               $thisdataline['numkey'] = $i;
               if ($i > 0) {
                  # no header
                  $showlabels = 0;
                  $adminsetuparray[$thiscomp]['table info']['valign'] = 'top';
               }
               /*
               if ($thiscomp == 'existing_gw_sources') {
                  $debug = 1;

                  $controlHTML .= "values retrieved " . print_r($thisdataline,1) . "<br>";
               }
               */
               $controlHTML .= showFormVars($listobject,$thisdataline,$adminsetuparray[$thiscomp],$showlabels, 0, $debug, $multiform, 1, $disabled);
               $i++;
               /*
               if ($thiscomp == 'existing_gw_sources') {
                  $debug = 0;
               }
               */
            }

            if (!$blank) {
               # insert two blank rows at the end
               #$blankrow['numkey'] = $i;
               if ($i == 0) {
                  $showlabels = 1;
               } else {
                  $showlabels = 0;
               }
               $controlHTML .= showFormVars($listobject,$blankrow,$adminsetuparray[$thiscomp],$showlabels, 0, $debug, $multiform, 1, $disabled);
               $i++;
               $showlabels = 0;
               $blankrow['numkey'] = $i;
               $controlHTML .= showFormVars($listobject,$blankrow,$adminsetuparray[$thiscomp],$showlabels, 0, $debug, $multiform, 1, $disabled);
               $i++;
               $blankrow['numkey'] = $i;
               $controlHTML .= showFormVars($listobject,$blankrow,$adminsetuparray[$thiscomp],$showlabels, 0, $debug, $multiform, 1, $disabled);
            }
            if (isset($adminsetuparray['watersupply_plan']['column info'][$thiscomp]['comment'])) {
               $numcols = count($blankrow);
               $thiscomment = $adminsetuparray['watersupply_plan']['column info'][$thiscomp]['comment'];
               $controlHTML .= "<tr><td colspan=$numcols class='tablecomment'>$thiscomment</td></tr>";
            }
            $controlHTML .= "</table>";
         } else {
            $controlHTML .= showFormVars($listobject,$plandata,$adminsetuparray[$thiscomp],1, 0, $debug, $multiform, 1, $disabled);
         }
         $controlHTML .= "</div>";
      }

      $controlHTML .= showGenericButton('savevalues', 'Save Values', "xajax_showPlanningForm(xajax.getFormValues(\"planningform\"))", 1, $disabled);
   } else {
      $controlHTML .= "<i>No plan selected. Please select a plan from the drop-down menu, or click on 'New Plan' to create a new plan.</i>";
   }
   $controlHTML .= "</form>";

   return $controlHTML;
}

function mergeEntityByFacility($dbobj, $facilities, $entity_id = -1) {
   // this takes a list of facility IDs and makes sure that they share a single entity_id
   // if no entity_id is given, it defaults to the lowest number entity ID associated with any of the 
   // facilities.  If there are no valid entity_ids with any of the facilities, it creates one
   if (is_array($facilities)) {
      $facility_list = "'" . join("','", $facilities) . "'";
   } else {
      $facility_list = $facilities;
   }
   if ( !($entity_id > 0) ) {
      // find the lowest entity 
      if (!verifyEntity($dbobj,$facilities)) {
         // have to generate an entity
         createEntity($dbobj, $facility_list);
      }
      $dbobj->querystring = "  update facilities set entity_id = a.min_entity ";
      $dbobj->querystring .= " from (";
      $dbobj->querystring .= "    select min(entity_id) as min_entity ";
      $dbobj->querystring .= "    from vwuds_entity where entity_id in (";
      $dbobj->querystring .= "       select entity_id ";
      $dbobj->querystring .= "       from facilities ";
      $dbobj->querystring .= "       where userid in ($facility_list)";
      $dbobj->querystring .= "    ) ";
      $dbobj->querystring .= " ) as a ";
      $dbobj->querystring .= " where facilities.userid in ($facility_list) ";
      print("$dbobj->querystring ; <br>\n");
      $dbobj->performQuery();
   }
   // synch entity_id on measuring_points, annual_data from facilities 
   $dbobj->querystring = "  update vwuds_measuring_point set entity_id = a.entity_id ";
   $dbobj->querystring .= " from facilities as a ";
   $dbobj->querystring .= " where vwuds_measuring_point.\"USERID\" = a.userid ";
   $dbobj->querystring .= " AND a.userid in ($facility_list) ";
   print("$dbobj->querystring ; <br>\n");
   $dbobj->performQuery();
   $dbobj->querystring = "  update annual_data set entity_id = a.entity_id ";
   $dbobj->querystring .= " from facilities as a ";
   $dbobj->querystring .= " where annual_data.\"USERID\" = a.userid ";
   $dbobj->querystring .= " AND a.userid in ($facility_list) ";
   print("$dbobj->querystring ; <br>\n");
   $dbobj->performQuery();
}

function createEntity($dbobj, $facility_list) {
   
}

function verifyEntity($dbobj, $facility_list) {
   return true;
}
?>

<?php

# xajax based library - watersupply
require("xajax_watersupply.common.php");

if (!$noajax) {
   $xajax->processRequest();
}

function showPlanningForm($formValues) {
   global $libpath, $projectid, $adminsetuparray, $planpages, $userid;
   if (strlen($formValues['seglist']) > 0) {
      $seglist = $formValues['seglist'];
   } else {
      $seglist = 'NULL';
   }
   #$subseglist = '1000';
   include("adminsetup.php");
   $objResponse = new xajaxResponse();
   $controlHTML = planningForm($formValues);
   $objResponse->assign("controlpanel","innerHTML",$controlHTML);
   return $objResponse;
}

function showDroughtIndicatorForm($formValues) {
   $objResponse = new xajaxResponse();
   $controlHTML = droughtIndicatorForm($formValues);
   $objResponse->assign("controlpanel","innerHTML",$controlHTML);
   return $objResponse;
}

function showDroughtIndicatorResult($formValues) {
   $objResponse = new xajaxResponse();
   $controlHTML = droughtIndicatorForm($formValues);
   $innerHTML = droughtIndicatorResult($formValues);
   $objResponse->assign("controlpanel","innerHTML",$controlHTML);
   $objResponse->assign("workspace","innerHTML",$innerHTML);
   return $objResponse;
}

function showFlowZoneForm($formValues) {
   $objResponse = new xajaxResponse();
   $controlHTML = flowZoneForm($formValues);
   $objResponse->assign("controlpanel","innerHTML",$controlHTML);
   return $objResponse;
}

function showFlowZoneResult($formValues) {
   $objResponse = new xajaxResponse();
   $innerHTML = flowZoneResult($formValues);
   $controlHTML = flowZoneForm($formValues);
   $objResponse->assign("controlpanel","innerHTML",$controlHTML);
   $objResponse->assign("workspace","innerHTML",$innerHTML);
   return $objResponse;
}

function showCreateFlowForm($formValues) {
   # synthetic hydrograph method
   include_once('./xajax_watersupply.synthflow.php');
   $objResponse = new xajaxResponse();
   $controlHTML = flowCreateForm($formValues);
   $objResponse->assign("controlpanel","innerHTML",$controlHTML);
   $objResponse->assign("workspace","innerHTML",'');
   return $objResponse;
}

function doCreateFlow($formValues) {
   include_once('./xajax_watersupply.synthflow.php');
   $objResponse = new xajaxResponse();
   $innerHTML = createSyntheticFlow($formValues);
   $controlHTML = flowCreateForm($formValues);
   $objResponse->assign("controlpanel","innerHTML",$controlHTML);
   $objResponse->assign("workspace","innerHTML",$innerHTML);
   return $objResponse;
}

function showAnnualReportingForm($formValues) {
   $objResponse = new xajaxResponse();
   $controlHTML = annualReportingForm($formValues);
   $objResponse->assign("controlpanel","innerHTML",$controlHTML);
   return $objResponse;
}

function showSingleAnnualReportingForm($formValues) {
   $objResponse = new xajaxResponse();
   $controlHTML = annualReportingForm($formValues);
   $objResponse->assign("controlpanel","innerHTML",$controlHTML);
   return $objResponse;
}

function showAnnualReportingFormResult($formValues) {
   global $basedir;
   $objResponse = new xajaxResponse();
   //$innerHTML = annualReportingFormResult($formValues);
   $innerHTML = annualReportingFormResult2($formValues);
   $controlHTML = annualReportingForm($formValues);
   $objResponse->assign("controlpanel","innerHTML",$controlHTML);
   $objResponse->assign("workspace","innerHTML",$innerHTML);
   return $objResponse;
}

function showAnnualDataCreationForm($formValues) {
   $objResponse = new xajaxResponse();
   $controlHTML = annualDataCreationForm($formValues);
   $objResponse->assign("controlpanel","innerHTML",$controlHTML);
   return $objResponse;
}

function showAnnualDataCreationResult($formValues) {
   global $basedir;
   $objResponse = new xajaxResponse();
   $innerHTML = annualDataCreationResult($formValues);
   $controlHTML = annualDataCreationForm($formValues);
   $objResponse->assign("controlpanel","innerHTML",$controlHTML);
   $objResponse->assign("workspace","innerHTML",$innerHTML);
   return $objResponse;
}

function showWithdrawalForm($formValues) {
   $objResponse = new xajaxResponse();
   $controlHTML = withdrawalForm($formValues);
   $objResponse->assign("controlpanel","innerHTML",$controlHTML);
   return $objResponse;
}

function showWithdrawalResult($formValues) {
   $objResponse = new xajaxResponse();
   $innerHTML = withdrawalResult($formValues);
   $controlHTML = withdrawalForm($formValues);
   $objResponse->assign("controlpanel","innerHTML",$controlHTML);
   $objResponse->assign("workspace","innerHTML",$innerHTML);
   return $objResponse;
}

function showWithdrawalInfoForm($formValues) {
   $objResponse = new xajaxResponse();
   $controlHTML = withdrawalInfoForm($formValues);
   $objResponse->assign("controlpanel","innerHTML",$controlHTML);
   return $objResponse;
}

function showWithdrawalInfoResult($formValues) {
   $objResponse = new xajaxResponse();
   $innerHTML = withdrawalInfoResult($formValues);
   $controlHTML = withdrawalInfoForm($formValues);
   $objResponse->assign("controlpanel","innerHTML",$controlHTML);
   $objResponse->assign("workspace","innerHTML",$innerHTML);
   return $objResponse;
}

function showMeasuringPointForm($formValues) {
   $objResponse = new xajaxResponse();
   $controlHTML = measuringPointForm($formValues);
   $objResponse->assign("controlpanel","innerHTML",$controlHTML);
   return $objResponse;
}

function showMeasuringPointResult($formValues) {
   $objResponse = new xajaxResponse();
   $innerHTML = measuringPointResult($formValues);
   $controlHTML = measuringPointForm($formValues);
   $objResponse->assign("controlpanel","innerHTML",$controlHTML);
   $objResponse->assign("workspace","innerHTML",$innerHTML);
   return $objResponse;
}

function showVWUDSForm($formValues) {
   $objResponse = new xajaxResponse();
   $controlHTML = VWUDSForm($formValues);
   $objResponse->assign("controlpanel","innerHTML",$controlHTML);
   return $objResponse;
}

function showPanelInfo($infofile, $extraHTML) {
   $objResponse = new xajaxResponse();
   $controlHTML = file_get_contents($infofile);
   if (strlen($extraHTML) > 0) {
      $controlHTML .= "<br>" . $extraHTML;
   }
   $objResponse->assign("infopanel","innerHTML",$controlHTML);
   return $objResponse;
}

function showFacilityViewForm($formValues) {
   $objResponse = new xajaxResponse();
   //$controlHTML = facilityViewForm2($formValues);
   // this is for internal users
   $controlHTML = facilityViewForm($formValues);
   $objResponse->assign("controlpanel","innerHTML",$controlHTML);
   return $objResponse;
}

function showVWUDSWebUserForm($formValues) {
   $objResponse = new xajaxResponse();
   // this is for remote non-DEQ users (or DEQ users on the vwuds reporting interface)
   $controlHTML = facilityViewForm2($formValues);
   //$controlHTML = facilityViewForm($formValues);
   $objResponse->assign("controlpanel","innerHTML",$controlHTML);
   return $objResponse;
}

function updateSICList($sic_domid, $cat_mp, $mindex) {
   global $adminsetuparray, $listobject;
   $objResponse = new xajaxResponse();
   $aset = $adminsetuparray['annual_data'];
   
   // replicate basic select list handling functions here
   $thisparams = $aset['column info']['SIC_MP']['params'];
   list($listtable, $listpkcol, $listcols, $sortcol, $slabels, $extrawhere) = array_pad(split(':', $thisparams),6,''); 
   $listarray = split(",", $listtable);

   $keyvaltest = split("\|", $listarray[0]);
   if (count($keyvaltest) > 1) {
      $listtable = array();
      $k = 0;
      foreach($listarray as $thispair) {
         list($key, $value) = split("\|", $thispair);
         $listtable[$k][$listpkcol] = $key;
         $listtable[$k][$listcols] = $value;
         $k++;
      }
   }
   // done basic select list functions
   
   // now, determine if we can screen for cat_mp type
   if ($cat_mp <> '') {
      $sic_where = "\"CATEGORY\" = '$cat_mp'";
   } else {
      $sic_where = '';
   }
   $thiscol = "SIC_MP[$mindex]";
   //$controlHTML .= $sic_where . "<br>";
   $aset['column info']['SIC_MP']['params'] .= $sic_where;
   $aset['column info']['SIC_MP']['domid'] .= "select_sicmp$mindex";
   $thisonchange = $aset['column info']['SIC_MP']['onchange'];
   $siconly = array('SIC_MP'=>'');
   $controlHTML .= showActiveList($listobject, $thiscol, $listtable, $listcols, $listpkcol, $sic_where, '', $thisonchange, $sortcol, $debug, 1, 0, $sic_domid, 0, 1);
   error_log("Command: showActiveList(listobject, $thiscol, $listtable, $listcols, $listpkcol, $extrawhere, '', $thisonchange, $sortcol, $debug, 1, 0, $sic_domid, 0, 1)");
   //error_log("Form var: " . $controlHTML);
   $objResponse->assign($sic_domid,"innerHTML",$controlHTML);
   return $objResponse;
}

?>

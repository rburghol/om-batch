<?php

include('./xajax_watersupply.php');
error_reporting(E_ALL);

$facilities = array('0817','0818','0819','0816','0820');

print("Merging " . print_r($facilities,1) . "<br>\n");
mergeEntityByFacility($listobject, $facilities);
?>
<?php

// lib_vpdes.php
// routines for interfacing with the VPDES database
// most of these are for contacting the copy of VPDES that is dumped to the WSP databases


function getUserVPDESIDsByWKT($listobject, $wktshape, $oftypes = '', $debug) {
   
   if (is_array($oftypes)) {
      if (count($oftypes) > 0) {
         $oftypes = "'" . join("','", $oftypes) . "'";
      }
   }
   
   if ( (strlen($oftypes) > 0) and ($oftypes <> -1)) {
      $oftypecond = " vpdes_type in ($oftypes) ";
   } else {
      $oftypecond = " ( 1 = 1) ";
   }

     
   $retvals = array();
   $retvals['debug'] = '';
   $listobject->querystring = "  select vpid, vpdes_permit_no, outfall_no, vpdes_type, facility_name ";
   $listobject->querystring .= " from vpdes_one_location ";
   $listobject->querystring .= " WHERE $oftypecond ";
   $listobject->querystring .= "    and contains(geomFromText('$wktshape', 4326), the_geom) ";
   $listobject->querystring .= " GROUP BY vpid, vpdes_permit_no, outfall_no, vpdes_type, facility_name ";
   $listobject->querystring .= " ORDER BY vpdes_permit_no, outfall_no ";
   $retvals['query'] .= " $listobject->querystring ; <br>";
   $listobject->performQuery();
   $retvals['records'] = $listobject->queryrecords;
   
   return $retvals;   
}



?>
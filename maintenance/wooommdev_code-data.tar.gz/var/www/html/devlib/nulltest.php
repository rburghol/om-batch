<?php


$o = 5.0 * 10.0;
print("5.0 * 10.0 = $o ");
$o = 5.0 * NULL;
print("5.0 * NULL = $o ");
$o = 5.0 + NULL;
print("5.0 + NULL = $o ");

?>
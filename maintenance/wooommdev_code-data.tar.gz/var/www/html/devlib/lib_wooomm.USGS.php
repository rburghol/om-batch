<?php

// ********************************************* //
// ***      lib_wooomm.USGS.php                *** //

if (!class_exists('modelSubObject')) {
   include_once('./lib_hydrology.php');
}
if (!class_exists('Equation')) {
   include_once('./lib_equation2.php');
}

class USGSArima extends modelSubObject {
   // needs to store the date, select the temporal resolution of the data storage
   // resolution options:
   // year, month, day, hour
   // format the date according to the desired resolution
   
   // this is a general purpose class for a simple flow-by
   // other, more complicated flow-bys will inherit this class
   
   var $var_prefix = 'q';
   var $q_var = 'Qout';
   var $flow_calc = 0.0;
   var $arima_eqn = 0.0;
   var $name = 'Qarima';
   var $num_vars = 6;
   var $init_vals = 0;
   var $arima_states = array();
   var $lastday = '';

   function showEditForm($formname, $disabled=0) {
      if (is_object($this->listobject)) {

         $returnInfo = array();
         $returnInfo['name'] = $this->name;
         $returnInfo['description'] = $this->description;
         $returnInfo['debug'] = '';
         $returnInfo['elemtype'] = get_class($this);
         $returnInfo['innerHTML'] = '';

         //$props = (array)$this;
         $innerHTML = '';

         # set up div to contain each seperate multi-parameter block
         $aset = $this->listobject->adminsetuparray[get_class($this)];
         foreach (array_keys($aset['column info']) as $tc) {
            $props[$tc] = $this->getProp($tc);
         }
         $formatted = showFormVars($this->listobject,$props,$aset,0, 1, 0, 0, 1, 0, -1, NULL, 1);
         
         $innerHTML .= "<table><tr>";
         $innerHTML .= $this->showFormHeader($formatted,$formname);
         $innerHTML .= "<hr> ";
         $innerHTML .= $this->showFormBody($formatted,$formname);
         $innerHTML .= "<hr> ";
         $innerHTML .= $this->showFormFooter($formatted,$formname);
         $innerHTML .= "</tr></table>";
         
         // show the formatted matrix
         //$this->formatMatrix();
         //$innerHTML .= print_r($this->matrix_formatted,1) . "<br>";

         $returnInfo['innerHTML'] = $innerHTML;

         return $returnInfo;

      }
   }
   
   function init() {
      parent::init();
      $this->result = 0;
      $arima_eqn = new Equation;
      $arima_eqn->equation = $this->arima_eqn;
      $arima_eqn->debug = $this->debug;
      $this->addOperator('flow_calc', $arima_eqn, 0);
      for ($i = 0;$i < $this->num_vars; $i++) {
         $this->setStateVar($this->var_prefix . $i, $this->init_vals);
         $this->arima_states[$i] = $this->init_vals;
         if ($this->debug) {
            $this->logDebug("Setting state var " . $this->var_prefix . "$i = $this->init_vals <br>");
         }
      }
      $this->lastdate = $this->timer->thistime->format('Y-m-d');
   }
   
   function step() {
      parent::step();
      // get the date, format it to desired resolution
      $today = $this->timer->thistime->format('Y-m-d');
      if ($today <> $this->lastdate) {
         // pop a value off the back of the storage array and push this on the front,
         // otherwise, accumulate it in the current [0] entry
         $this->currentvals = array();
         array_unshift($this->arima_states,0);
         array_pop($this->arima_states);
         $this->lastdate = $today;
      }
      if ($this->debug) {
         $this->logDebug("thuis -> state at timestep beginning: " . print_r($this->state,1) . "<br>");
         $this->logDebug("Values (currentvals): " . print_r($this->currentvals,1) . "<br>");
         $this->logDebug("States (states): " . print_r($this->arima_states,1) . "<br>");
         $this->logDebug("Parent Data State (datastate): " . $this->parentobject->datastate . "<br>");
      }
      // add the most recent seed value to the variable list
      // unless the parent object has exhausted its values, then we are in full prediction mode
      if ($this->parentobject->datastate == 2) {
         $this->currentvals[] = $this->state['flow_calc'];
         if ($this->debug) {
            $this->logDebug("Parent data-state = 2, using ARIMA value " . $this->state->result . " for variable seed <br>");
         }
      } else {
         $this->currentvals[] = $this->arData[$this->q_var];
         if ($this->debug) {
            $this->logDebug("Parent still has time series values, using $this->q_var (" . $this->arData[$this->q_var] . ") for variable seed <br>");
         }
      }
      foreach ($this->currentvals as $thisval) {
         $sum += $thisval;
      }
      // stash in an array
      $this->arima_states[0] = $sum / count($this->currentvals);
      // create entries in the arData input matrix for the variables
      for ($i = 0;$i < $this->num_vars; $i++) {
         $this->setStateVar($this->var_prefix . $i, $this->arima_states[$i]);
         if ($this->debug) {
            $this->logDebug("Setting object state array [ " . $this->var_prefix . $i . "] to " . $this->arima_states[$i] . "<br>");
         }
      }
      if ($this->debug) {
         $this->logDebug("Final state array: " . print_r($this->state, 1) . "<br>");
      }
   }
   
   function evaluate() {
      
      // flow_calc has already been set
      $this->result = $this->state['flow_calc'];
      if ($this->debug) {
         $this->logDebug("evaluate() called - returning result of ARIMA model: $this->result <br>");
      }
   }
   
   function showFormHeader($formatted,$formname) {
      $innerHTML .= "<b>Name:</b> " . $formatted->formpieces['fields']['name'] . " | ";
      $innerHTML .= "<b>Debug Mode?:</b> " . $formatted->formpieces['fields']['debug'] . " | ";
      $innerHTML .= "<b>Exec. Rank:</b> " . $formatted->formpieces['fields']['exec_hierarch'] . "<BR>";
      $innerHTML .= "<b>Description:</b> " . $formatted->formpieces['fields']['description'];
      return $innerHTML;
   }
   
   function showFormBody($formatted,$formname) {
      $innerHTML .= " Flow Variable to Use as Equation Input" . $formatted->formpieces['fields']['q_var'] . "<br>";
      $innerHTML .= "<b># of days values to store (q0 (=t-0), q1, q2, ... q#-1):</b> " . $formatted->formpieces['fields']['num_vars'] . "<BR>";
      $innerHTML .= "<b>ARIMA Equation:</b> " . $formatted->formpieces['fields']['arima_eqn'] . "<br>";
      $innerHTML .= "<b>Initial Value:</b> " . $formatted->formpieces['fields']['init_vals'] . "<BR>";
      return $innerHTML;
   }
   
   function showFormFooter($formatted,$formname) {
      $innerHTML = '';
      return $innerHTML;
   }
   
}

?>

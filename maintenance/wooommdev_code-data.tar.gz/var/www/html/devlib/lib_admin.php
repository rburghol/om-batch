<?php


# user management

function addUser($listobject, $username, $firstname, $lastname, $userpass, $usertype, $groupid, $defaultproject, $newuseremail, $debug) {

   $listobject->querystring = " insert into users (username, firstname, lastname, userpass, usertype, defaultproject, email) ";
   $listobject->querystring .= " values ('$username', '$firstname', '$lastname', '$userpass', $usertype, $defaultproject, '$newuseremail') ";
   if ($debug) { print("$listobject->querystring ; "); }
   $listobject->performQuery();

   $listobject->querystring = " select userid from users where username = '$username' ";
   if ($debug) { print("$listobject->querystring ; "); }
   $listobject->performQuery();
   $userid = $listobject->getRecordValue(1,'userid');

   if ($userid > 0) {
      $listobject->querystring = " insert into mapusergroups (userid, groupid) ";
      $listobject->querystring .= " values ($userid, $groupid) ";
      if ($debug) { print("$listobject->querystring ; "); }
      $listobject->performQuery();
   }

   return $userid;

}

function copyGroups($listobject, $projectid, $srcuserid, $destuserid, $gids, $debug) {

   $listobject->querystring = " insert into proj_seggroups (projectid, the_geom, area, groupname, ownerid) ";
   $listobject->querystring .= " select projectid, the_geom, area, groupname, $destuserid ";
   $listobject->querystring .= " from proj_seggroups ";
   $listobject->querystring .= " where ownerid = $srcuserid ";
   $listobject->querystring .= "    and projectid = $projectid ";
   $listobject->querystring .= "    and ( (gid in ($gids)) ";
   if (count(split(',', $gids)) <= 1) {
      $listobject->querystring .= "       or ($gids = -1) ";
   }
   $listobject->querystring .= "    ) ";
   if ($debug) { print("$listobject->querystring ; "); }
   $listobject->performQuery();

}



function getScenarioPerms($listobject, $scenarioid, $userid, $usergroupids, $debug) {

   $listobject->querystring = "  select groupid, ownerid, gperms, operms, pperms ";
   $listobject->querystring .= " from scenario ";
   $listobject->querystring .= " where scenarioid = $scenarioid ";
   if ($debug) {
      print("DEBUG: $listobject->querystring ; <br>");
   }
   $listobject->performQuery();
   $srow = $listobject->queryrecords[0];

   # check permissions
   $ownerid = $srow["ownerid"];
   $usergroup = $srow["groupid"];
   $groupperms = $srow["gperms"];
   $ownerperms = $srow["operms"];
   $publicperms = $srow["pperms"];

   # Perm Sub-routine
   $perms = 0;
   if ($userid == $ownerid) {
      # owner perms
      $perms = $perms | $ownerperms;
   }
   if (in_array($usergroup, split(',', $usergroupids)) ) {
      $perms = $perms | $groupperms;
   }
   $perms = $perms | $publicperms;

  # print_r($srow);

   return $perms;
}


function getProjElementPerms($listobject, $projectid, $elementid, $userid, $usergroupids, $debug) {

   $listobject->querystring = "  select groupid, ownerid, gperms, operms, pperms ";
   $listobject->querystring .= " from proj_element ";
   $listobject->querystring .= " where projectid = $projectid ";
   $listobject->querystring .= "    and elementid = $elementid ";
   #return $listobject->querystring;
   #if ($debug) {
   #   print("DEBUG: $listobject->querystring ; <br>");
   #}
   $listobject->performQuery();
   $srow = $listobject->queryrecords[0];

   # check permissions
   $ownerid = $srow["ownerid"];
   $usergroup = $srow["groupid"];
   $groupperms = $srow["gperms"];
   $ownerperms = $srow["operms"];
   $publicperms = $srow["pperms"];

   # Perm Sub-routine
   $perms = 0;
   if ($userid == $ownerid) {
      # owner perms
      $perms = $perms | $ownerperms;
   }
   if (in_array($usergroup, split(',', $usergroupids)) ) {
      $perms = $perms | $groupperms;
   }
   $perms = $perms | $publicperms;

  # print_r($srow);

   return $perms;
}

function getScenElementPerms($listobject, $elementid, $userid, $usergroupids, $debug) {

   $listobject->querystring = "  select groupid, ownerid, gperms, operms, pperms ";
   $listobject->querystring .= " from scen_model_element ";
   $listobject->querystring .= " where elementid = $elementid ";
   if ($debug) {
      error_log("DEBUG: $listobject->querystring ; <br>");
   }
   #return $listobject->querystring;
   $listobject->performQuery();
   $srow = $listobject->queryrecords[0];
   #error_log("DEBUG: Perms : " . print_r($srow,1));

   # check permissions
   $ownerid = $srow["ownerid"];
   $usergroup = $srow["groupid"];
   $groupperms = $srow["gperms"];
   $ownerperms = $srow["operms"];
   $publicperms = $srow["pperms"];

   # Perm Sub-routine
   $perms = 0;
   if ($userid == $ownerid) {
      # owner perms
      $perms = $perms | $ownerperms;
   }
   #return "User id $userid, Owner Perms = $perms";
   #error_log("User id $userid, Owner Perms = $perms");
   
   if (in_array($usergroup, split(',', $usergroupids)) ) {
      $perms = $perms | $groupperms;
      #error_log("Group id $usergroup, Group Perms = $groupperms");
   }
   $perms = $perms | $publicperms;
   
   #error_log("Public Perms = $publicperms, Final Perms: $perms");

  # print_r($srow);

   return $perms;
}

/*
function createProject($userid, $projname, $basinfile = '', $groupfile = '', $pointfile = '') {
   # check the users group, can they create a new project?
   # add entry to project table
   # create a copy of the proj_mapN.map for the new project
   
}
*/
   
?>
<?php

class modelObject {
   var $name = '';
   var $componentid = 0; # to be set by a model container at run-time to provide a unique numerical identifier
   var $parentobject = -1; # link to parent, if this object is contained by another (for use by operators only)
   var $description = '';
   var $objectname = '';
   var $disabled = 0;
   var $vars = array();
   var $timer; /* Time Keeping object */
   var $exectime = 0; // cumulative list of time to execute this component
   var $meanexectime = 0; // cumulative divided by # of timesteps (done at finish() routine)
   var $stepstart = 0; // pointer for calculating $exectime
   var $thisdate = '';
   var $inputs = array(); /* array containing object references for upland entities */
   var $tsin = array(); /* array containing time series inputs */
   var $logtable = array();
   var $log_geom = 0; # save space in the log by NOT logging the geometry column
   var $lookups = array();
   var $processors = array();
   var $execlist = array();
   var $loglist = array();
   var $data_cols = array(); // this will be used to populate the log list
   var $arData = array(); # subs for state array in other objects (parent object)
   # names of publicly accessible variables, to speed querying without having to reinstantiate the entire object
   var $compnames = array();
   var $inputnames = array();
   var $procnames = array();
   var $propnames = array();
   # end publicly accessible variables
   var $defaultval = 0;
   # permissions
   var $groupid = 2;
   var $operms = 7;
   var $gperms = 4;
   var $pperms = 0;
   # end permissions
   var $nullvalue = NULL;
   var $debug = 0;
   var $debugmode = 0; # 0-store in string, 1-print debugging info to stderr, 2-print out to stdout, 3-spool to file
   var $debugfile = '';
   var $maxdebugfile = 20971520; // max size of 20Mb
   var $cascadedebug = 0;
   var $component_type = 1;
   var $outdir = '.';
   var $outurl = '';
   var $imgurl = '';
   var $logfile = '';
   var $cache_log = 1; # store variable state log in an external file?  Defaults to 1 for graph and report objects, 0 for others
   var $logLoaded = 0; # set after logging begins, or after log is restored from file/db
   var $goutdir = '';
   var $gouturl = '';
   var $fileformat = 'unix';
   var $strform = '"%s"';
   var $numform = '%10.5f';
   var $delimiter = ',';
   var $logging = 1;
   var $intmethod = 0; # interpolation method - 0 = linear, 1 - stair step
   var $units = 2; # Units 1 - SI, 2 - EE
   var $state = array(); /* holder for state variables */
   var $the_geom = ''; # geography holder
   var $geomtype = 1; # 1 - point, 2 - line, 3 - polygon
   var $geomformat = 0; # 0 - WKT, 1 - WKB, 2 - file, 3 - KML
   var $geomx = 0; # longitude
   var $geomy = 0; # longitude
   # date information for lookups, other conditional entities
   var $year = 1970;
   var $month = 1;
   var $day = 1;
   var $hour = 1;
   var $weekday = 1;
   var $dt = 60.0;
   var $logerrors = 1;
   var $errorstring = '';
   var $errorfile = '';
   var $debugstring = '';
   var $outstring = '';
   var $graphstring = '';
   var $loggable = 0; // is this an entity with "loggable" data?  Only really relevant for sub-components
   // set this to 0 if it is something like a QueryWizardComponent which has no data to log
   var $strict_log = 1;
   # this is only valid currently for the modelContainer, but may later be used for other types of modelObjects
   var $components = array();
   var $compexeclist = array();
   # a db connection
   var $listobject = -1;
   var $dbtblname = '';
   var $tblprefix = 'tmp_';
   var $dbcolumntypes = array();
   var $logformats = array();
   var $log2db = 1; # 0 - store log in memory, 1 - store log in temp db table (should save memory, but may slow things down due to frequent db writes)
   # equation execution hierarchy, if conflict
   # 0 is default, least favored, unlimited number
   var $log_headers_sent = 0; // always zero at the beginning of the model run
   var $bufferlog = 0; # allow list object to buffer log data sent during a run (1 will increase performance)
   var $logRetrieved = 0; # this gets set to 1 after a retrieval from db to avoid redundant retrievals
   var $exec_hierarch = 0;
   # filenice object
   var $fno = -1;
   # temp file stuff
   var $platform = 'unix'; # valid values are 'dos', 'unix'
   var $tmpdir = '/tmp'; # path to the temporary dir writeable by this process
   var $basedir = '';
   var $tmp_files = array();
   var $shellcopy = 'cp'; # the copy command to be used in the shell
   var $sessionid = 0; # variable to use to set data for separate model runs, will be set to the id of the containing model
   var $startdate = '';
   var $enddate = '';
   var $restrictdates = 0;
   var $iscontainer = 0; # only true for objects of type "model container" or it's subclasses
   # indicator of which variabels are to be serialized/unserialized when model is awakened/saved (CSV format)
   var $serialist = '';
   var $reportstring = '';
   // property descriptions for viewing/editing components
   var $prop_desc = array();
   var $multivar = 0; // this is for sub-components, is the variable a "multivar", in other words, does it create more than one?
   var $multivarnames = array(); // for use if multivar
   var $run_mode = 0; // for modelControl broadcast, or linear linkage
   var $cacheable = 1; 

   function init() {
      if ($this->debug) {
         $this->logDebug("Initializing $this->name <br>");
      }
      $this->setState();
      # set up state variables for any public vars that are not already instantiated
      foreach ($this->getPublicProps() as $thisvar) {
         if (!in_array($thisvar, array_keys($this->state))) {
            if ($this->debug) {
               $this->logDebug("Adding $thisvar to viewable state variables.<br>");
            }
            $this->state[$thisvar] = $this->$thisvar;
         }
      }
      if ($this->debug) {
         $this->logDebug("PublicProps values initialized on $this->name: " . print_r($this->state,1) . " <br>");
         $this->logDebug("Initializing processors on $this->name <br>");
      }
      
      // set this before we initialize the processors, since they will rely upon it
      // they wil call it transparently
      $this->childHub = new broadCastHub;
      $this->childHub->parentname = $this->name;
      
      foreach ($this->processors as $thisproc) {
         # set state vars for this proc, so that it knows what it will be able to gain access to
         $thisproc->arData = $this->state;
         $thisproc->init();
         # experiment
      }
      if (!is_object($this->parentobject)) {
         // only do this for standalone objects, not sub-components
         $mem_use = (memory_get_usage(true) / (1024.0 * 1024.0));
         $mem_use_malloc = (memory_get_usage(false) / (1024.0 * 1024.0));
         //error_log("Memory Use after init() on $this->name = $mem_use ( $mem_use_malloc )<br>\n");
      }

      # set up data type for dbexpropt
      # set a name for the temp table that will not hose the db
      $targ = array(' ',':','-','.');
      $repl = array('_', '_', '_', '_');
      $this->tblprefix = str_replace($targ, $repl, "tmp$this->componentid" . "_");
      $this->dbtblname = $this->tblprefix . 'datalog';
      $this->setDataColumnTypes();

      # order all operations on this entity
      $this->orderOperations();
      

   }
   function setPropDesc() {
   }
   
   function evaluate() {
   }
   
   function systemLog($mesg, $status_flag = 1) {
      if (is_object($this->parentobject)) {
         $this->parentobject->systemLog($mesg, $status_flag);
      }
   }
      
   function cleanUp() {
      # remove all the temp tables associated with this object
      if (is_object($this->listobject)) {
         if ($this->listobject->tableExists($this->dbtblname)) {
            $this->listobject->querystring = "  drop table $this->dbtblname ";
            $this->listobject->performQuery();
         }
      }
      
      foreach ($this->processors as $thisproc) {
         # clean up processors if they have the method
         if (is_object($thisproc)) {
            if (method_exists($thisproc, 'cleanUp')) {
               $thisproc->cleanUp();
               unset($thisproc);
            }
         }
      }
   }

   function setSingleDataColumnType($thiscol, $thistype = 'float8', $defval = NULL) {

      # set up column formats for appropriate outputs to database
      if ( (!isset($this->dbcolumntypes)) or (!is_array($this->dbcolumntypes)) ) {
         $this->dbcolumntypes = array();
      }
      if ( (!isset($this->logformats)) or (!is_array($this->logformats)) ) {
         $this->logformats = array();
      }
      if ( (!isset($this->data_cols)) or (!is_array($this->data_cols)) ) {
         $this->data_cols = array();
      }
      
      $this->dbcolumntypes[$thiscol] = $thistype;
      $this->data_cols[] = $thiscol;
      $this->state[$thiscol] = $defval;
   }
   
   function addDataColumnType($colname, $samplevalue = 0, $overwrite = 0, $forcetype = '') {
      if (in_array($colname, $thisdbcolumntypes)) {
         $exists = 1;
      } else {
         $exists = 0;
      }
      
      if ($exists and !$overwrite) {
         return;
      }
      
      if (strlen($forcetype) > 0) {
         // we have been given a type to make this, so do not guess
         $type = $forcetype;
      } else {
         $type = 'varchar';
      }
      
      $this->dbcolumntypes[$colname] = $type;
      $this->data_cols[] = $colname;
      $this->logformats[$colname] = '%s';
   }
      

   function setDataColumnTypes() {

      # set up column formats for appropriate outputs to database
      if ( (!isset($this->dbcolumntypes)) or (!is_array($this->dbcolumntypes)) ) {
         $this->dbcolumntypes = array();
      }
      if ( (!isset($this->logformats)) or (!is_array($this->logformats)) ) {
         $this->logformats = array();
      }

      $basetypes = array(
               'name'=>'varchar(' . intval(2.0 * strlen($this->name) + 1) . ')',
               'description'=>'varchar(' . intval(2.0 * strlen($this->description) + 1) . ')',
               'objectname'=>'varchar(' . intval(2.0 * strlen($this->objectname) + 1) . ')',
               'componentid'=>'varchar(128)',
               'subshedid'=>'varchar(128)',
               'dt'=>'float8',
               'month'=>'float8',
               'day'=>'float8',
               'year'=>'float8',
               'thisdate'=>'date',
               'time'=>'timestamp',
               'timestamp'=>'bigint',
               'run_mode'=>'float8'
      );
      $dcs = array('thisdate', 'month', 'day', 'year', 'week', 'timestamp', 'run_mode');
      foreach ($dcs as $thisdc) {
         $this->data_cols[] = $thisdc;
      }
      
      //if ($this->debug) {
      //   $this->logDebug("DB Columns merging: " . print_r($this->dbcolumntypes,1) . " <br> and: " . print_r($basetypes,1) . "<br>");
      //}
      //$thisarray = array_unique(array_merge($this->dbcolumntypes, $basetypes));
      foreach($basetypes as $key=>$val) {   
         $this->dbcolumntypes[$key] = $val;
      } 
      if ($this->debug) {
         $this->logDebug("MERGE RESULT: " . print_r(array_merge($this->dbcolumntypes, $basetypes),1) . " <br>");
         $this->logDebug("UNIQUE RESULT: " . print_r($thisarray,1) . " <br>");
      }

      //$this->dbcolumntypes = $thisarray;

      $logtypes = array(
               'name'=>'%s',
               'description'=>'%s',
               'objectname'=>'%s',
               'componentid'=>'%u',
               'dt'=>'%u',
               'month'=>'%u',
               'day'=>'%u',
               'year'=>'%u',
               'thisdate'=>'%s',
               'time'=>'%s',
               'timestamp'=>'%s',
               'run_mode'=>'%u'
      );
      
      // now, go through and see if any sub-components have db types set
      foreach ($this->processors as $thisproc) {
         if (property_exists($thisproc, 'value_dbcolumntype')) {
            $logtypes[$thisproc->name] = $thisproc->value_dbcolumntype;
         }
         
         if (!($thisproc->loggable === 0)) {
            $this->data_cols[] = $thisproc->name;
         }
      }
      $thisarray = array_unique(array_merge($this->logformats, $logtypes));

      $this->logformats = $thisarray;
      # log to postgres if connection is set
      if (is_object($this->listobject) and ($this->log2db == 1)) {
         if ($this->listobject->tableExists($this->dbtblname)) {
            $this->listobject->querystring = "  drop table $this->dbtblname ";
            $this->listobject->performQuery();
         }
      }
   }

   function finish() {
      # add post-processing functions here
      
      # iterate through each sub-processor stored in this object
      if (is_array($this->processors)) {
         foreach ($this->processors as $thisproc) {
            if ($this->debug) {
               $this->logDebug("Finishing $thisproc->name<br>\n");
            }
            if (is_object($thisproc)) {
               if (method_exists($thisproc, 'finish')) {
                  $thisproc->finish();
               }
            }
            # show component output reports
            if (strlen($thisproc->reportstring) > 0) {
               $this->reportstring .= "<b>Reports for: </b>" . $thisproc->name . '<br>';
               $this->reportstring .= $thisproc->description . "<br>" . $thisproc->reportstring . "<br>";
               $thisproc->reportstring = '';
            }
            # show component error reports
            if (strlen($thisproc->errorstring) > 0) {
               $this->errorstring .= "<b>Errors for: </b>" . $thisproc->name . '<br>';
               $this->errorstring .= $thisproc->description . "<br>" . $thisproc->errorstring . "<br>";
               $thisproc->errorstring = '';
            }
         }
         unset($thisproc);
      }

      if ($this->cache_log) {
        # error_log("Ouputting log values to file for $this->name");
         $this->log2file();
      }
      $this->logDebug("Finished $this->name");
      if ($this->debugmode == 3) {
         $this->debugstring .= "</body></html>";
         $this->flushDebugToFile();
         $this->debugstring = "<b>Debug File for $this->name:</b> <a href=" . $this->outurl . '/' . $this->debugfile . ">Click Here</a><br>";
      }
      if (is_object($this->timer)) {
         $this->meanexectime = $this->exectime / $this->timer->steps;
      }

   }

   function wake() {
      if (!isset($this->processors)) {
         $this->processors = array();
      } else {
         // if this thing is already an array, we may be re-awakening, in which case we should NOT overwrite its contents
         if (!is_array($this->processors)) {
            $this->processors = array();
         } else {
            // should we call re-awakening on sub-components?
            /*
            foreach ($this->processors as $thisproc) {
               $thisproc->wake();
            }
            */
         }
      }
      $this->state = array();
      $this->execlist = array();
      $this->compexeclist = array();
      $this->inputs = array();
      $this->vars = array();
      $this->logtable = array();
      $this->lookups = array();
      $this->loglist = array();
      // set up property descriptions
      $this->prop_desc = array();
      $this->setPropDesc();
      // end prop descriptions
      $this->dbcolumntypes = array();
      $this->data_cols = array();
      $this->logLoaded = 0;
      # things to do before this goes away, or gets stored
      $ser = split(',', $this->serialist);
      foreach ($ser as $thisvar) {
         if (property_exists($this, $thisvar)) {
            if (!is_array($this->$thisvar) and !is_object($this->$thisvar)) {
               if (strlen($this->$thisvar) > 0) {
                  $uvar = unserialize($this->$thisvar);
                  $this->$thisvar = $uvar;
                  if ($this->debug) {
                     $this->logDebug("$thisvar unserialized to : " . print_r($uvar,1));
                  }
                  //error_log("$thisvar unserialized to : " . print_r($uvar,1));
               }
            }
         }
      }
      $this->setState();
   }

   function preProcess() {
      # do nothing here, this is sub-classed where necessary
      foreach ($this->processors as $thisproc) {
         # set state vars for this proc, so that it knows what it will be able to gain access to
         $thisproc->arData = $this->state;
         $thisproc->preProcess();
      }
   }

   function create() {
      # things to do when this object is first created
      # it must be called AFTER the wake() method, but prior to the init() method
   }

   function reCreate() {
      # things to do if something on this object has changed and the user wishes to re-run the create routine
      # defauls to simply calling the classes own create() method, but could perform other house-keeping functions
      $this->create();
   }

   function sleep() {
      # things to do before this goes away, or gets stored
      $ser = split(',', $this->serialist);
      foreach ($ser as $thisvar) {
         if (property_exists($this, $thisvar)) {
            $this->$thisvar = serialize($this->$thisvar);
         }
      }
      # blank out components and processors
      $this->processors = array();
      $this->components = array();
      $this->inputs = array();
      $this->errorstring = '';
      $this->debugstring = '';
   }

   function setDebug($thisdebug, $thisdebugmode = -1) {
      $this->debug = $thisdebug;
      if ($thisdebugmode <> -1) {
         $this->debugmode = $thisdebugmode;
      }
      if ($this->cascadedebug) {
         foreach($this->processors as $thisproc) {
            $thisproc->setDebug($this->debug, $this->debugmode);
         }
      }
   }

   function setBuffer($bufferlog) {
      $this->bufferlog = $bufferlog;
      foreach($this->processors as $thisproc) {
         $thisproc->setBuffer($this->bufferlog);
      }
   }

   function setSimTimer($thistimer) {
      $this->timer = $thistimer;
      $this->dt = $thistimer->dt;
      $this->startdate = $thistimer->thistime->format('Y-m-d');
      $this->enddate = $thistimer->endtime->format('Y-m-d');
      // properly format start and end time
      $this->starttime = $thistimer->thistime->format('Y-m-d H:i:s');
      $this->endtime = $thistimer->endtime->format('Y-m-d H:i:s');
      
      if ($this->debug) {
         $this->logDebug("Setting Timer for $this->name <br>");
         #$this->logDebug($this->timer);
         #$this->logDebug($thistimer);
      }
      #$this->logDebug("<br>");
      $this->logDebug("Setting Timer for processors $this->name <br>");
      #$this->logDebug($this->processors);
      #$this->logDebug("<br>");
      if (is_array($this->processors)) {
         foreach ($this->processors as $thisop) {
            $thisop->setSimTimer($thistimer);
         }
      }
      if (is_array($this->components)) {
         foreach ($this->components as $thisop) {
            $thisop->setSimTimer($thistimer);
         }
      }
   }

   function setCompID($thisid) {
      $this->componentid = $thisid;
      # set a name for the temp table that will not hose the db
      $targ = array(' ',':','-','.');
      $repl = array('_', '_', '_', '_');
      $this->tblprefix = str_replace($targ, $repl, "tmp$this->componentid" . "_");
      $this->dbtblname = $this->tblprefix . 'datalog';
   }

   function setState() {
      # initialize the state array
      # any object properties that are to be visible to other components, or even to 
      # sub-components on this object must be initialized in the state variable here
      # unless they are explicitly set in a sub-component processor, otherwise, they will 
      # be invisible and result as null
      $this->state = array();

      if (is_array($this->processors)) {
         foreach (array_keys($this->processors) as $thisop) {
            $this->state[$thisop] = $this->processors[$thisop]->defaultval;
         }
      } else {
         $this->processors = array();
      }
      if (is_array($this->inputs)) {
         foreach (array_keys($this->inputs) as $thisop) {
            $this->state[$thisop] = @$this->$thisop;
         }
      } else {
         $this->inputs = array();
      }
   }

   function setStateVar($varname, $varvalue) {
      # sets a specific state variable to a specific value
      $this->state[$varname] = $varvalue;
   }
   

   function appendStateVar($varname, $varvalues, $action = 'append', $method = 'guess') {
      
      if (!is_array($varvalues)) {
         $varvalues = array($varvalues);
      }
      
      if (!isset($this->state[$varname])) {
         $this->state[$varname] = NULL;
      }
      
      switch ($action) {
         case 'refresh':
            // means that we want to start with only the values passed at this time, so clear previous values
            if (is_numeric($varvalues[0])) {
               $this->state[$varname] = 0.0;
            } else {
               $this->state[$varname] = '';
            }
         break;
      }
      
      // default method is ADD if numeric, replace if string
      // user can set methods in function call
      foreach ($varvalues as $inval) {
         // the following cases assume that all variables are scalar.  
         // we need to adjust this to work with array type variables as well.
         // 
         if (!($inval === NULL)) {
            if ($method == 'guess') {
               if (is_numeric($inval)) {
                  $this->state[$varname] += $inval;
               } else {
                  $this->state[$varname] = $inval;
               }
            } else {
               switch ($method) {
                  case 'replace':
                     $this->state[$varname] = $inval;
                  break;
                  
                  case 'stringappend':
                     $this->state[$varname] .= $inval;
                  break;
                  
                  case 'numappend':
                     $this->state[$varname] += $inval;
                  break;
               }
            }
         }
         if ($this->debug) {
            if (strlen($this->state[$varname]) < 200) {
               $this->logDebug("updated $varname = " . $this->state[$varname] . " Appended from Inputs: " . print_r($varvalues,1) . "<br>\n");
            }
         }
      }
   }

   function setProp($propname, $propvalue) {
      # sets a specific state variable to a specific value
      #error_log("Trying to set $propname to $propvalue on " . $this->name);
      if (property_exists(get_class($this), $propname)) {
         $this->$propname = $propvalue;
         #error_log("Setting $propname to $propvalue on " . $this->name);
      }
   }

   function getProp($propname) {
      # sets a specific state variable to a specific value
      #error_log("Trying to set $propname to $propvalue on " . $this->name);
      if (property_exists(get_class($this), $propname)) {
         return $this->$propname;
         #error_log("Setting $propname to $propvalue on " . $this->name);
      } else {
         return FALSE;
      }
   }

   function getLog($startdate = '', $enddate = '', $variables = array(), $scenario = -1) {
      # gets all log values
      
      switch ($this->log2db) {
         
         case 0:
         // do nothing, since the logtable is already there
         break;
         
         case 1:
         if (!$this->logRetrieved) {
            // if logRetrieved is false, we have to actually grab it from the database log
            // we also should check here for a desired scenario, and also specific variables
            # must retrieve log from data table to array
            $qs = " select * from $this->dbtblname ";
            $this->logtable = array();
            if ($this->restrictdates) {
               # use only a narrow date field, also must have valid start and end dates set
               if ( (strlen($this->startdate) > 0) and (strlen($this->enddate) > 0) ) {
                  $qs .= " where thisdate >= '$this->startdate' and thisdate <= '$this->enddate' ";
               }
            }
            if (is_object($this->listobject)) {
               if ($this->listobject->tableExists($this->dbtblname)) {
                  $this->listobject->querystring = $qs;
                  if ($this->debug) {
                     $this->logDebug($qs);
                  }
                  $this->listobject->performQuery();
                  // sets 
                  $this->logtable = $this->listobject->queryrecords;
               }
            }
            $this->logRetrieved = 1;
         }
         break;
         
         case 2:
         // flush the remnants of the memory log to the file, then retrieve the file
         $this->flushMemoryLog2file();
         $this->logFromFile();
         $this->logRetrieved = 1;
         break;
      }

      return $this->logtable;
   }

   function openTempFile($filename, $mode = 'a', $ftype = 'file', $platform='') {
      if (strlen($filename) > 0) {

         if ($platform == '') {
            $platform = $this->platform;
         }
         $handle = fopen($filename, $mode);
         $this->tmp_files[$filename]['filename'] = $filename;
         $this->tmp_files[$filename]['handle'] = $handle;
         $this->tmp_files[$filename]['type'] = $ftype;
         $this->tmp_files[$filename]['platform'] = $platform;

      }

      return $handle;

   }

   function generateTempFileName($basename = 'tmp', $ext = 'tmp', $min = 0, $max = 32768) {

      # generic routine to try to generate a random file and test to see if it is indeed unique in the temp directory
      $filenum = rand($min, $max);
      $filename = $this->tmpdir . "/$basename$filenum" . ".$ext";
      if ($this->debug) {
         $this->logDebug("Checking to see if random file exists: $filename <br>");
      }
      while (file_exists($filename)) {
         $filenum = rand($min, $max);
         $filename = $this->tmpdir . "/$filenum" . ".$ext";
         if ($this->debug) {
            $this->logDebug("Checking next random name: $filename <br>");
         }
      }
      return $filename;
   }

   function copy2TempFile($filename, $tmpfilename = '', $platform='', $isPerm=0) {

      if (strlen($platform) == 0) {
         $platform = $this->platform;
      }
      if ($this->debug) {
         $this->logDebug("Exporting $filename <br>");
      }
      # generate a tmp file name if there is none supplied
      if (strlen($tmpfilename) == 0) {
         if ($this->debug) {
            $this->logDebug("No destination file given, generating one. <br>");
         }
         # if this is a dos platform, we need to try to keep a
         $tmpfilename = $this->generateTempFileName();
         if ($this->debug) {
            $this->logDebug("Generated file name: $tmpfilename <br>");
         }
      }

      if ( (strlen($filename) > 0) ) {
         $result = copy($filename, $tmpfilename);
         if ($this->debug) {
            $this->logDebug("Trying: copy($filename $tmpfilename) <br>");
         }
         

         if ($this->debug) {
            $this->logDebug("Result: $result <br>");
         }
         if (!$isPerm) {
            // stash it for later clean up unles we have been instructed to make it permananent
            $this->tmp_files[$tmpfilename]['filename'] = $tmpfilename;
            $this->tmp_files[$tmpfilename]['handle'] = -1;
            $this->tmp_files[$tmpfilename]['type'] = 'file';
            $this->tmp_files[$tmpfilename]['platform'] = $platform;
            $this->tmp_files[$tmpfilename]['result'] = $result;
         }
      }
      return $tmpfilename;
   }

   function closeTempFile($filename) {
      if ( in_array($filename, array_keys($this->tmp_files)) ) {
         $handle = $this->tmp_files[$filename]['handle'];
         if ($handle <> -1) {
            fclose($handle);
         }
         $this->tmp_files[$filename]['handle'] = -1;
      }
   }

   function clearTempFiles($filenames = array()) {
      # close and delete any temp files that have been opened in this sesion
      # files to close
      $files_to_close = array();
      if (!is_array($filenames)) {
         # make sure this is a valid file name
         if (in_array($filenames, array_keys($this->tmp_files))) {
            $files_to_close[$filenames] = $this->tmp_files[$filenames];
         }
      } else {
         foreach ($filenames as $thisname) {
            # make sure this is a valid file name
            if (in_array($thisname, array_keys($this->tmp_files))) {
               $files_to_close[$thisname] = $this->tmp_files[$thisname];
            }
         }
      }
      foreach ($this->tmp_files as $thisfile) {
         $handle = $thisfile['handle'];
         $fname = $thisfile['filename'];
         $ftype = $thisfile['type']; # currently unused, but later may allow us to treat local files and streams robustly
         if (file_exists($fname)) {
            # close it if the file handle is still set (indicating that it is open)
            if ($handle <> -1) {
               fclose($handle);
            }
            # now, remove the file
            shell_exec("rm $fname");
            #print("rm $fname<br>");
         }
      }
   }

   function getPropertyClass($propclass) {
      # $propclass - array containing any of the following:
      #              'publicprops', 'publicprocs', 'publicinputs', 'publicomps',
      #              'privateprops', 'privateprocs', 'privateinputs', 'privatecomps'
      # Sub-classing this function can add additional property classes to retrieve
      # See example in HSPFContainer for plotgen, and wdm properties
      $returnprops = array();
      foreach ($propclass as $thisclass) {

         switch ($thisclass) {

            case 'publicprops':
            $returnprops = array_unique(array_merge($returnprops, $this->getPublicProps()));
            break;

            case 'publicprocs':
            $returnprops = array_unique(array_merge($returnprops, $this->getPublicProcs()));
            break;

            case 'publicinputs':
            $returnprops = array_unique(array_merge($returnprops, $this->getPublicInputs()));
            break;

            case 'publiccomps':
            $returnprops = array_unique(array_merge($returnprops, $this->getPublicComps()));
            break;

            case 'publicvars':
            $returnprops = array_unique(array_merge($returnprops, $this->getPublicVars()));
            break;

            case 'privatevars':
            $returnprops = array_unique(array_merge($returnprops, $this->getPrivateProps()));
            break;

         }
      }
      return $returnprops;
   }

   function getPublicVars() {
      # gets all viewable variables
      $publix = array_unique(array_merge(array_keys($this->state), $this->getPublicProps(), $this->getPublicProcs(), $this->getPublicInputs()));

      return $publix;
   }

   function getLocalVars() {
      # gets all viewable variables
      $publix = array_unique(array_merge(array_keys($this->state), $this->getPublicProps(), $this->getPublicProcs(), $this->getPublicInputs()));

      return $publix;
   }

   function getPublicProps() {
      # gets only properties that are visible (must be manually defined for now, could allow this to be set later)
      $publix = array('name','objectname','description','componentid', 'startdate', 'enddate', 'dt', 'month', 'day', 'year', 'thisdate', 'the_geom', 'weekday', 'week', 'hour', 'run_mode');

      return $publix;
   }

   function getPublicProcs() {
      # gets all viewable processors
      $retarr = array();
      if (is_array($this->procnames)) {
         #$this->logDebug("Procs for $this->name: " . print_r($this->procnames,1));
         foreach ($this->procnames as $pn) {
            $retarr[] = $pn;
            // check for vars on proc, if set add names to the array to return
            if (isset($this->processors[$pn])) {
               if (is_object($this->processors[$pn])) {
                  if (isset($this->processors[$pn]->vars)) {
                     if (count($this->processors[$pn]->vars) > 0) {
                        foreach ($this->processors[$pn]->vars as $procvar) {
                           if (!in_array($procvar, $retarr)) {
                              $retarr[] = $procvar;
                           }
                        }
                     }
                  }
               }
            }
         }
      }
      
      return $retarr;
   }

   function getPublicInputs() {
      # gets all viewable variables
      if (is_array($this->inputnames)) {
         return $this->inputnames;
      } else {
         return array();
      }
   }

   function getPublicComponents() {
      # gets all viewable variables
      if (is_array($this->compnames)) {
         return $this->compnames;
      } else {
         return array();
      }
   }

   function getPrivateProps() {
      # gets all viewable variables in the local context only
      $privitz = array();

      return $privitz;
   }
   
   function setStateTimerVars() {

      if (is_object($this->timer)) {
         $this->state['thisdate'] = $this->timer->thistime->format('Y-m-d');
         $this->state['year'] = $this->timer->thistime->format('Y');
         $this->state['month'] = $this->timer->thistime->format('n');
         $this->state['day'] = $this->timer->thistime->format('j');
         $this->state['weekday'] = $this->timer->thistime->format('N');
         $this->state['week'] = $this->timer->thistime->format('W');
         $this->state['hour'] = $this->timer->thistime->format('G');
      } else {
         if ($this->debug) {
            $this->logDebug("<b>Error: </b>$this->name timer is NOT an object <br>\n");
         }
         $this->logError("<b>Error: </b>$this->name timer is NOT an object <br>\n");
      }
      if ($this->debug) {
         $this->logDebug("<b>$this->name step() method called at hour " . $this->state['hour'] . " on " . $this->state['thisdate'] . " week " . $this->state['week'] . " month " . $this->state['month'] . ".</b><br>\n");
      }
      $this->timer->timeSplit();
      $this->stepstart = $this->timer->timestart;
   }
   
   function readParentBroadCasts() {
      if ($this->debug) {
         $this->logDebug("Checking for parent read broadCastObjects on $this->name<br>\n");
      }
      # iterate through each equation stored in this object
      foreach (array_values($this->execlist) as $thisvar) {
         if (is_object($this->processors[$thisvar])) {
            if (get_class($this->processors[$thisvar]) == 'broadCastObject') {
               if ( ($this->processors[$thisvar]->broadcast_mode == 'read') 
                  and ($this->processors[$thisvar]->broadcast_hub == 'parent')
               ) {
                  # set all required inputs for the equation
                  $this->processors[$thisvar]->arData = $this->state;
                  # calls processor step method
                  if (method_exists($this->processors[$thisvar], 'step')) {
                     $this->processors[$thisvar]->step();
                  }
                  if ($this->processors[$thisvar]->debug) {
                     $this->logDebug($this->processors[$thisvar]->debugstring);
                     $this->logDebug("<br>\n");
                     # reset debugging string for processor, since it is appended here
                     $this->processors[$thisvar]->debugstring = '';
                  }
                  # evaluate the equation
                  if ($this->debug) {
                     $this->logDebug("Finished Evaluating $thisvar, parent read<br>\n");
                  }
               } // end is parent read
            } // end get_class == broadCastObject
            
         } // end is_object()
      }
   }
   
   function sendParentBroadCasts() {
      if ($this->debug) {
         $this->logDebug("Checking for parent send broadCastObjects on $this->name<br>\n");
      }
      # iterate through each equation stored in this object
      foreach (array_values($this->execlist) as $thisvar) {
         if (is_object($this->processors[$thisvar])) {
            if (get_class($this->processors[$thisvar]) == 'broadCastObject') {
               if ( ($this->processors[$thisvar]->broadcast_mode == 'cast') 
                  and ($this->processors[$thisvar]->broadcast_hub == 'parent')
               ) {
                  # set all required inputs for the equation
                  $this->processors[$thisvar]->arData = $this->state;
                  # calls processor step method
                  if (method_exists($this->processors[$thisvar], 'step')) {
                     $this->processors[$thisvar]->step();
                  }
                  # evaluate the equation
                  if ($this->debug) {
                     $this->logDebug("Finished Evaluating $thisvar, parent send<br>\n");
                  }
               } // end is parent read
            } // end get_class == broadCastObject
            
         } // end is_object()
      }
   }
   
   function readChildBroadCasts() {
      if ($this->debug) {
         $this->logDebug("Checking for child read broadCastObjects on $this->name<br>\n");
      }
      # iterate through each equation stored in this object
      foreach (array_values($this->execlist) as $thisvar) {
         if (is_object($this->processors[$thisvar])) {
            if (get_class($this->processors[$thisvar]) == 'broadCastObject') {
               if ( ($this->processors[$thisvar]->broadcast_mode == 'read') 
                  and ($this->processors[$thisvar]->broadcast_hub == 'child')
               ) {
                  # set all required inputs for the equation
                  $this->processors[$thisvar]->arData = $this->state;
                  # calls processor step method
                  if (method_exists($this->processors[$thisvar], 'step')) {
                     $this->processors[$thisvar]->step();
                  }
                  if ($this->processors[$thisvar]->debug) {
                     $this->logDebug($this->processors[$thisvar]->debugstring);
                     $this->logDebug("<br>\n");
                     # reset debugging string for processor, since it is appended here
                     $this->processors[$thisvar]->debugstring = '';
                  }
                  # evaluate the equation
                  if ($this->debug) {
                     $this->logDebug("Finished Evaluating $thisvar, child read<br>\n");
                  }
               } // end is parent read
            } // end get_class == broadCastObject
            
         } // end is_object()
      }
   }
   
   function sendChildBroadCasts() {
      # iterate through each equation stored in this object
      if ($this->debug) {
         $this->logDebug("Checking for child send broadCastObjects on $this->name<br>\n");
      }
      foreach (array_values($this->execlist) as $thisvar) {
         if (is_object($this->processors[$thisvar])) {
            if (get_class($this->processors[$thisvar]) == 'broadCastObject') {
               if ($this->debug) {
                  $this->logDebug("Broadcast object $thisvar is mode= " . $this->processors[$thisvar]->broadcast_mode . " and hub= " . $this->processors[$thisvar]->broadcast_hub . "<br>\n");
               }
               if ( ($this->processors[$thisvar]->broadcast_mode == 'cast') 
                  and ($this->processors[$thisvar]->broadcast_hub == 'child')
               ) {
                  # set all required inputs for the equation
                  $this->processors[$thisvar]->arData = $this->state;
                  # calls processor step method
                  if (method_exists($this->processors[$thisvar], 'step')) {
                     $this->processors[$thisvar]->step();
                  }
                  # evaluate the equation
                  if ($this->debug) {
                     $this->logDebug("Finished Evaluating $thisvar, child send<br>\n");
                  }
               } // end is parent read
            } // end get_class == broadCastObject
            
         } // end is_object()
      }
   }
   
   function preStep() {
      $this->setStateTimerVars();
      # data aquisition first
      $this->readParentBroadCasts();
      // hard wired inputs override broadcasts
      $this->getInputs();
      $this->sendChildBroadCasts();
   }
   
   function postStep() {
      $this->sendParentBroadCasts();
      $this->logstate();
      $this->timer->timeSplit();
      $this->exectime += ($this->timer->timeend - $this->stepstart);
   }

   function step() {
      // many object classes will subclass this method.  
      // all step methods MUST call preStep(),execProcessors(), postStep()
      $this->preStep();
      if ($this->debug) {
         $this->logDebug("$this->name Inputs obtained. thisdate = " . $this->state['thisdate']);
      }
      // execute sub-components
      $this->execProcessors();
      
      // log the results
      if ($this->debug) {
         $this->logDebug("$this->name Calling Logstate() thisdate = ");
      }
      
      $this->postStep();
   }

   function getCurrentValue($thisvar) {
      # returns the current value of any state variable
      return $this->state[$thisvar];
   }

   function getValue($thistime, $thisvar) {
      # currrently, does nothing with the time, assumes that the input time is
      # equal to the current modeled time and returns the current value
      if ($this->debug) {
         $sv = $this->state;
         if (isset($sv['the_geom'])) {
            $sv['the_geom'] = 'HIDDEN';
         }
         $this->logDebug("Variable $thisvar requested from $this->name, returning " . $sv[$thisvar] . " from " . print_r($sv,1) );
      }
     #error_log("Variable $thisvar requested from $this->name, returning " . $this->state[$thisvar] . " from " . print_r($this->state,1) );
      if (in_array($thisvar, array_keys($this->state))) {
         return $this->state[$thisvar];
      } else {
         return NULL;
      }
   }
   
   function setLogFileName() {
      if (strlen($this->logfile) == 0) {
         $this->logfile = 'objectlog.' . $this->sessionid . '.' . $this->componentid . '.log';
         $log_headers_sent = false; // log headers can not have been sent if we don't have a file name yet
      }
   }

   function log2file() {
      # output the log to a text file
      if (strlen($this->logfile) == 0) {
         $this->setLogFileName();
      }
//error_log("log2File() called on $this->name <br>\n");
      # get log from postgres if connection is set
      if (is_object($this->listobject) and ($this->log2db == 1)) {
         if ($this->listobject->tableExists($this->dbtblname)) {
            $this->listobject->querystring = " select * from $this->dbtblname order by thisdate";
            if ($this->debug) {
               $this->logDebug("Retrieving log from db: " . $this->listobject->querystring . " <br>");
            }
            $this->listobject->performQuery();
            $this->logtable = $this->listobject->queryrecords;
            if ($this->debug) {
               $this->logDebug("Retrieved " . count($this->logtable) . " records. <br>");
            }

            # create a serial file
            $serialfile = $this->outdir . '/' . $this->logfile . ".serial";
            $open = fopen($serialfile, 'w');
            fwrite($open, serialize($this->logtable));
            fclose($open);
         }
      }
      
      // now, send the logtable to a file
      $filename = $this->flushMemoryLog2file();
      // create a second copy of the file as most recent run for this object
      $lastlog = $this->outdir . '/' . 'lastlog' . $this->componentid . '.log';
      // if we give the copy2tempfile routine a file name, it will NOT put the name in the list of files to be cleaned up later
      $this->copy2tempFile($filename, $lastlog, $this->platform, 1);


   }

   function flushMemoryLog2file() {
      # output the log to a text file -- appending to the file, and emptying the log array
      if (strlen($this->logfile) == 0) {
         $this->setLogFileName();
      }
      $filename = $this->outdir . '/' . $this->logfile;

      # format for output
      if ($this->debug) {
         $this->logDebug("Flushing Log to File: $this->outdir / $this->logfile <br>");
      }
      //error_log("Flushing Log to File: $this->outdir / $this->logfile <br>");
      
      if (!$this->log_headers_sent) {
         #$this->logDebug($outarr);
         $colnames = array(array_keys($this->logtable[0]));
         putDelimitedFile("$filename",$colnames,$this->translateDelim($this->delimiter),1,$this->fileformat);
         $this->log_headers_sent = true;
      }
      
      if (count($this->logtable) > 0) {
         $outarr = $this->formatLogData();
         // append the data to the file, then close the file
         putArrayToFilePlatform("$filename", $outarr,0,$this->fileformat);
         # clear log from memory 
      }
      $this->logtable = array();
      $this->logRetrieved = 0;
      return $filename;
   }

   function translateDelim($delimtext) {
      switch ($delimtext) {
         case 0:
            $d = ',';
         break;
         case 1:
            $d = "\t";
         break;
         
         case 2:
            $d = ' ';
         break;
         
         case ',':
            $d = ',';
         break;
         
         case "\t":
            $d = "\t";
         break;
         
         case '|':
            $d = '|';
         break;
         
         default:
         # by making the default a non-translation, we should preserve backward compatibility with the previous version
            $d = $delimtext;
         break;
      }
      
      return $d;
         
   }
   
   function formatLogData() {
      $fdel = '';
      $outform = '';
      foreach (array_keys($this->logtable[0]) as $thiskey) {
         if (in_array($thiskey, array_keys($this->logformats))) {
            # get the log file format from here, if it is set
            if ($this->debug) {
               $this->logDebug("Getting format for log table " . $thiskey . "\n");
            }
            $outform .= $fdel . $this->logformats[$thiskey];
         } else {
            if (is_numeric($this->logtable[0][$thiskey])) {
               //$outform .= $fdel . $this->numform;
               $outform .= $fdel . $this->strform;
            } else {
               $outform .= $fdel . $this->strform;
            }
         }
         $fdel = ',';
      }
      $outarr = nestArraySprintf($outform, $this->logtable);
      return $outarr;
   }

   function logFromFile() {
      # check for a file, if set, use it to populate the log table
      if ($this->debug) {
         $this->logDebug("logFromFile method called on $this->name<br>");
      }
      if (strlen($this->logfile) == 0) {
         $this->setLogFileName();
      }
      $filename = $this->outdir . '/' . $this->logfile;
      if ($this->debug) {
         $this->logDebug("Checking for $filename for object $this->name<br>");
      }
      if (file_exists($filename)) {
         if ($this->debug) {
            $this->logDebug("Loading data from $filename <br>");
         }
         # since this is from a log file that we generated, we can assume that it has the column headers
         $tsvalues = readDelimitedFile($filename, $this->translateDelim($this->delimiter), 1);
         $tcount = 0;
         #$this->logDebug($tsvalues);
         foreach ($tsvalues as $thisline) {
            if (isset($thisline['thisdate'])) {
               $this->logstate($thisline);
               #$this->logDebug("Adding Line");
               #$this->logDebug($thisline);
            } else {
               if ($this->debug) {
                  # only log this once
                  if ($tcount == 0) {
                     $this->logDebug("Date column not found in $this->logfile.<br>");
                  }
                  $tcount++;
               }
            }
         }
      } else {
         if ($this->debug) {
            $this->logDebug("Can not find log file $this->logfile <br>");
         }
      }
      $this->logLoaded = 1;
   }

   function log2listobject($columns = array()) {
      if ($this->listobject > 0) {
         # format for output
         if ($this->debug) {
            $this->logDebug("Outputting Time Series to db: $tblname <br>");
         }
         $this->listobject->array2tmpTable($this->logtable, $this->dbtblname, $columns, $this->dbcolumntypes, 1, $this->bufferlog);
      } else {
         $this->logDebug("List object not set.<br>");
      }
   }

   function list2file($listrecs, $filename='') {

      if (strlen($filename) == 0) {
         $filename = 'datafile.' . $this->componentid . '.csv';
      }

      $datafile = $this->outdir . '/' . $filename;
      $colnames = array(array_keys($listrecs[0]));
      putDelimitedFile($datafile,$colnames,$this->translateDelim($this->delimiter),1,'unix');

      if (count($listrecs) > 0) {
         if ($this->debug) {
            logDebug("Appending values to monthly $datafile<br>");
         }
         $fdel = '';
         $outform = '';
         foreach (array_keys($listrecs[0]) as $thiskey) {
            if (in_array($thiskey, array_keys($this->logformats))) {
               # get the log file format from here, if it is set
               if ($this->debug) {
                  $this->logDebug("Getting format for log table " . $thiskey . "\n");
               }
               $outform .= $fdel . $this->logformats[$thiskey];
            } else {
               if (is_numeric($listrecs[0][$thiskey])) {
                  $outform .= $fdel . $this->numform;
               } else {
                  $outform .= $fdel . $this->strform;
               }
            }
            $fdel = $this->translateDelim($this->delimiter);
         }
         # format for output if records exist for each year in the dataset
         $outarr = nestArraySprintf($outform, $listrecs);
         putArrayToFilePlatform("$datafile", $outarr,0,'unix');
         #print_r($outarr);

      }

      return $filename;
   }


   function logstate($logvalues = array()) {

      $thislog = array();

      $logsrc = array();

      # if an array of values is passed in, use these instead of our state array (used to pass child info upstream)
      if (count($logvalues) > 0) {
         $logsrc = $logvalues;
      } else {
         $logsrc = $this->state;
      }

      if (!isset($logsrc['thisdate'])) {
         $logsrc['thisdate'] = $this->timer->thistime->format('Y-m-d');
      }
      if (!isset($logsrc['time'])) {
         $logsrc['time'] = $this->timer->thistime->format('r');
      }
      if (!isset($logsrc['month'])) {
         $logsrc['month'] = $this->timer->thistime->format('m');
      }
      if (!isset($logsrc['day'])) {
         $logsrc['day'] = $this->timer->thistime->format('d');
      }
      if (!isset($logsrc['year'])) {
         $logsrc['year'] = $this->timer->thistime->format('Y');
      }
      if (!isset($logsrc['week'])) {
         $logsrc['week'] = $this->timer->thistime->format('W');
      }
      if (!isset($logsrc['timestamp'])) {
         $logsrc['timestamp'] = $this->timer->thistime->format('U');
      } else {
         if ($logsrc['timestamp'] == '') {
            $logsrc['timestamp'] = $this->timer->thistime->format('U');
         }
      }

      if (count($this->loglist) > 0) {
         $logvars = $this->loglist;
      } else {
         $logvars = array_keys($logsrc);
      }
      
      if ($this->strict_log and (count($this->data_cols) > 0)) {
         if ($this->debug) {
            if ($this->timer->steps <= 2) {
               $this->logDebug("Using data_cols to restrict log variables. ");
            }
         }
         $logvars = array_unique($this->data_cols);
      }

      foreach ($logvars as $thisvar) {
         # eleminate the geometry column if log_geom is set to 0 (default)
         if ( (strlen($thisvar) > 0) and ( ($this->log_geom == 1) or ($thisvar <> 'the_geom') ) ) {
            $thislog[$thisvar] = $logsrc[$thisvar];
         }
      }

      if ($this->debug) {
         $this->logDebug("$this->name Logging Output at time-step " . $this->timer->steps . "<br>");
         if ($this->timer->steps <= 2) {
            $this->logDebug("DB Column formats: " . print_r($this->dbcolumntypes,1) . "<br>");
            $this->logDebug("Logged Columns and Values: " . print_r($thislog,1) . "<br>");
         }
      }
      
      switch ($this->log2db) {

         
         case 0:
         array_push($this->logtable, $thislog);
         break;
         
         case 1:
         # log to db object if connection is set
         if (is_object($this->listobject)) {
            if ($this->debug) {
               $this->logDebug("$this->name Logging Output at time-step " . $this->timer->steps . "<br>");
               if ($this->timer->steps <= 2) {
                  $olddebug = $this->listobject->debug;
                  // un-comment this to turn on debugging in listobject temporarily
                  //$this->listobject->debug = 1;
                  $this->logDebug("DB Column formats: " . print_r($this->dbcolumntypes,1));
                  $this->logDebug("Logged Columns and Values: " . print_r($thislog,1));
               }
            }

            $this->listobject->array2tmpTable(array($thislog), $this->dbtblname, array_keys($thislog), $this->dbcolumntypes, 1, $this->bufferlog);

            if ($this->debug) {
               if ($this->timer->steps <= 1) {
                  $this->listobject->debug = $olddebug;
               }
            }
         } else {
            // log to db requested, but no valid db object is set
            if ($this->timer->steps <= 1) {
               $this->logError("<b>Error: </b> Object $this->name log to db requested, but no valid db object is set.<br>\n");
            }
         }
         break;

         case 2:
         // log to file
         // if memory is at 85% of limit flush the log to the log file
         // use the timer object to store the maximum memory value since all objects share access to the timer
         array_push($this->logtable, $thislog);
         if ($this->debug) {
            $this->logDebug("Log Flush Requested <br>");
            $this->logDebug("Log Flush Parameters: " . $this->timer->max_memory_mb . " * " . $this->timer->max_memory_pct . " <br>");
         }
         $mem_use = (memory_get_usage(true) / (1024.0 * 1024.0));
         $mem_use_malloc = (memory_get_usage(false) / (1024.0 * 1024.0));
         $tstep = $this->timer->steps;
         if ( ($this->timer->max_memory_mb * $this->timer->max_memory_pct) <= $mem_use ) {
            if ($this->debug) {
               $this->logDebug("Flush requested at $tstep on $this->name because memory usage is $mem_use ($mem_use_malloc)<br>\n");
            }
            //error_log("Flush requested at $tstep on $this->name because memory usage is $mem_use ($mem_use_malloc)<br>\n");
            $this->flushMemoryLog2file();
         }
         
         break;

         default:
         array_push($this->logtable, $thislog);
         break;
      }
 
      $this->logLoaded = 1;
   }

   function logDebug($debuginfo) {
      if (is_array($debuginfo)) {
         $debuginfo = print_r($debuginfo,1);
      }

      switch ($this->debugmode) {
         case -1:
            // ignore all calls to log errors
         break;
         
         case 0:
         # store in a string unless the log is too big, then put it in a file
         $this->debugstring .= $debuginfo;
         if (strlen($this->debugstring) > (1024 * 1024 * 5))  {
            $this->flushDebugToFile();
            $this->debugmode = 3;
         }
         break;

         case 1:
         # print to stderr - apache error log bites it if we give it too much data, so we truncate this if debug model is 1
         if (strlen($debuginfo) > 512) {
            $debuginfo = substr($debuginfo, 0, 511);
         }
         error_log($debuginfo);
         break;

         case 2:
         # print to stdout
         print($debuginfo);
         break;

         case 3:
         # spool to a file
         $this->debugstring .= $debuginfo;
         // spool to file in 5Mb increments to keep write frequency low
         if (strlen($this->debugstring) > (1024 * 1024 * 5))  {
            $this->flushDebugToFile();
         }
         break;
      }
   }
   
   function flushDebugToFile() {
      if ($this->debugfile == '') {
         $this->setDebugFile();
      }
      if (filesize($this->outdir . "/" . $this->debugfile) >= $this->maxdebugfile) {
         $this->debugstring .= "<br>Max debug file size of $this->maxdebugfile exceeded.  Debugging suspended.<br>";
         $this->debug = 0;
      }
      $dfp = fopen($this->outdir . "/" . $this->debugfile,'a');
      fwrite($dfp, $this->debugstring);
      $this->debugstring = '';
      fclose($dfp);
   }
   
   function setDebugFile() {
      $this->debugfile = 'debuglog.' . $this->sessionid . '.' . $this->componentid . '.log';
      $dfp = fopen($this->outdir . "/" . $this->debugfile,'w');
      fwrite($dfp,"<html><body>");
      fclose($dfp);
   }

   function logError($errorstring) {
      if ($this->logerrors) {
         if (is_array($errorstring)) {
            $errorstring = print_r($errorstring,1);
         }
         $this->errorstring .= $errorstring;
         // spool to file in 5Mb increments to keep write frequency low
         if (strlen($this->errorstring) > (1024 * 1024 * 5))  {
            $this->flushErrorToFile();
         }
      }
   }

   function flushErrorToFile() {
      if ($this->errorfile == '') {
         $this->setErrorFile();
      }
      if (filesize($this->outdir . "/" . $this->errorfile) >= $this->maxdebugfile) {
         $this->errorstring .= "<br>Max error file size of $this->maxdebugfile exceeded.  Error logging suspended.<br>";
         $this->logerrors = 0;
      }
      $dfp = fopen($this->outdir . "/" . $this->errorfile,'a');
      fwrite($dfp, $this->errorstring);
      $this->errorstring = '';
      fclose($dfp);
   }
   
   function setErrorFile() {
      $this->errorfile = 'errorlog.' . $this->sessionid . '.' . $this->componentid . '.log';
      $dfp = fopen($this->outdir . "/" . $this->debugfile,'w');
      fwrite($dfp,"<html><body>");
      fclose($dfp);
   }

   function execProcessors() {

      if ($this->debug) {
         $this->logDebug("Going through processors for $this->name.<br>\n");
      }
      # iterate through each equation stored in this object
      foreach (array_values($this->execlist) as $thisvar) {
         if (is_object($this->processors[$thisvar])) {
            // broadcast components get executed in the preStep() and postStep() methods
            if ( !(get_class($this->processors[$thisvar]) == 'broadCastObject') ) {
               # set all required inputs for the equation
               // if this is a sub-comp on a sub-comp, we need to merge arData arrays
               if (is_array($this->arData)) {
                  if ($this->processors[$thisvar]->debug) {
                     $this->logDebug("Merging array this -> arData with internal state array <br>\n");
                  }
                  $statearr = array_merge($this->state,$this->arData);
               } else {
                  if ($this->processors[$thisvar]->debug) {
                     $this->logDebug("this -> arData not an array - using internal state array only <br>\n");
                  }
                  $statearr = $this->state;
               }
               $this->processors[$thisvar]->arData = $statearr;
               if ($this->processors[$thisvar]->debug) {
                  $this->logDebug("Setting child state to: " . print_r($statearr,1) . " <br>\n");
               }
               # calls processor step method
               if (method_exists($this->processors[$thisvar], 'step')) {
                  $this->processors[$thisvar]->step();
               }
               # evaluate the equation
               if ($this->debug) {
                  $this->logDebug("Evaluating $thisvar<br>\n");
               }
               # if this processor is not transparent, it will evaluate and return a value, otherwise,
               # we assume that it does not set a value
               if (method_exists($this->processors[$thisvar], 'evaluate')) {
                  $this->processors[$thisvar]->evaluate();
                  if ($this->processors[$thisvar]->debug) {
                     $this->logDebug($this->processors[$thisvar]->debugstring);
                     $this->logDebug("<br>\n");
                     # reset debugging string for processor, since it is appended here
                     $this->processors[$thisvar]->debugstring = '';
                  }
                  if ($this->debug) {
                     $sv = $this->state;
                     if (isset($sv['the_geom'])) {
                        $sv['the_geom'] = 'HIDDEN';
                     }
                     $this->logDebug($sv);
                     $this->logDebug("<br>\n");
                  }
                  # set the state variable with the equation result
                  switch ($processors[$thisvar]->multivar) {
                     case 0:
                        $this->state[$thisvar] = $this->processors[$thisvar]->result;
                     break;

                     case 1:
                        foreach ($this->processors[$thisvar]->multivarnames as $mvname) {
                           $this->state[$mvname] = $this->processors[$thisvar]->state[$mvname];
                        }
                     break;

                     default:
                        $this->state[$thisvar] = $this->processors[$thisvar]->result;
                     break;
                  }
               }
               # evaluate the equation
               if ($this->debug) {
                  $this->logDebug("Finished Evaluating $thisvar, Result = " . $this->state[$thisvar] . "<br>\n");
               }
            }
         }
      }
   }

   function orderOperations() {

      $dependents = array();
      $independents = array();
      $execlist = array();
      # compile a list of independent and dependent variables
      foreach (array_keys($this->processors) as $thisinput) {
         $independents = array_merge($independents, $this->processors[$thisinput]->vars);
         array_push($dependents, $thisinput);
      }
      if ($this->debug) {
         $this->logDebug("<b>Ordering Operations</b><br> ");
      }
      # now check the list of independent variables for each processor,
      # if none of the variables are in the current list of dependent variables
      # put it into the execution stack, remove from queue
      $queue = $dependents;
      $i = 0;
      while (count($queue) > 0) {
         $thisdepend = array_shift($queue);
         $pvars = $this->processors[$thisdepend]->vars;
         if ($this->debug) {
            $this->logDebug("Checking $thisdepend variables ");
            $this->logDebug($pvars);
            $this->logDebug(" <br>\nin ");
            $this->logDebug($queue);
            $this->logDebug("<br>\n");
         }
         $numdepend = $this->array_in_array($pvars, $queue);
         if (!$numdepend) {
            array_push($execlist, $thisdepend);
            $i = 0;
            if ($this->debug) {
               $this->logDebug("Not found, adding $thisdepend to execlist.<br>\n");
            }
         } else {
            # put it back on the end of the stack
            if ($this->debug) {
               $this->logDebug("Found.<br>\n");
            }
            array_push($queue, $thisdepend);
         }
         $i++;
         # should try to sort them out by the number of unsatisfied dependencies,
         # adding those with 1 dependency first
         if ( ($i > count($queue)) and (count($queue) > 0)) {
            # we have reached an impasse, since we cannot currently
            # solve simultaneous variables, we just put all remaining on the
            # execlist and hope for the best
            # a more robust approach would be to determine which elements are in a circle,
            # and therefore producing a bottleneck, as other variables may not be in a circle
            # themselves, but may depend on the output of objects that are in a circle
            # then, if we add the circular variables to the queue, we may be able to continue
            # trying to order the remaining variables

            # first, create a list of execution hierarchies and compids
            $hierarchy = array();
            foreach ($queue as $thisel) {
               $hierarchy[$thisel] = $this->processors[$thisel]->exec_hierarch;
            }
            # sort in reverse order of hierarchy
            # then, look at exec_hierarch property, if the first element is higher priority than the lowest in the stack
            # pop it off the list, and add it to the queue
            # then, after doing that, we can go back, set $i = 0, and try to loop through again,
            arsort($hierarchy);
            $keyar = array_keys($hierarchy);
            if ($this->debug) {
               $this->logDebug("Cannot determine sequence of remaining variables, searching manual execution hierarchy setting.<br>\n");
            }
            $firstid = $keyar[0];
            $fh = $hierarchy[$firstid];
            $mh = min(array_values($hierarchy));
            if ($this->debug) {
               $this->logDebug("Highest hierarchy value = $fh, Lowest = $mh.<br>\n");
            }
            if ($fh > $mh) {
               # pop off and resume trying to sort them out
               $newqueue = array_diff($queue, array($firstid) );
               array_push($execlist, $firstid);
               $i = 0;
               if ($this->debug) {
                  $this->logDebug("Elelemt " . $firstid . ", with hierarchy " . $hierarchy[$firstid] . " added to execlist.<br>\n");
               }
               $queue = $newqueue;
            } else {

               if ($this->debug) {
                  $this->logDebug("Can not determine linear sequence for the remaining variables. <br>\n");
                  $this->logDebug($queue);
                  $this->logDebug("<br>\nDefaulting to order by number of unsatisfied dependencies.<br>\n");
                  $this->logDebug("<br>\nHoping their execution order does not matter!.<br>\n");
               }
               foreach ($queue as $lastcheck) {
                  $pvars = $this->processors[$lastcheck]->vars;
                  $numdepend = $this->array_in_array($pvars, $queue);
                  $dependsort[$lastcheck] = $numdepend;
               }
               asort($dependsort);
               if ($this->debug) {
                  $this->logDebug("Remaining variable sort order: \n");
                  $this->logDebug($dependsort);
               }
               $numdepend = $this->array_in_array($pvars, array_keys($dependsort));
               $newexeclist = array_merge($execlist, $queue);
               $execlist = $newexeclist;
               break;
            }
         }
      }
      $this->execlist = $execlist;
      if ($this->debug) {
         $this->logDebug("<br>\nExecution list: ");
         $this->logDebug($this->execlist);
         $this->logDebug("<br>\n");
      }
   }

   function array_in_array($needle, $haystack) {
       //Make sure $needle is an array for foreach
       if(!is_array($needle)) $needle = array($needle);
       $count = 0;
       //For each value in $needle, return TRUE if in $haystack
       foreach($needle as $pin)
           //if(in_array($pin, $haystack)) return TRUE;
           if(in_array($pin, $haystack)) $count++;
       //Return FALSE if none of the values from $needle are found in $haystack
       //return FALSE;
       return $count;
   }

   function interpValue($thiskey, $lowkey, $lowvalue, $highkey, $highvalue) {

      switch ($this->intmethod) {
         case 0:
            $retval = $lowvalue + ($highvalue - $lowvalue) * ( ($thiskey - $lowkey) / ($highkey - $lowkey) );
         break;

         case 1:
            $retval = $tv;
         break;

      }
      return $retval;
   }

   function addLookup($thisinput, $srcparam, $lutype, $lookuptable, $defaultval) {
      # stashes the lookup table
      $this->lookups[$thisinput]['default'] = $defaultval;
      $this->lookups[$thisinput]['table'] = $lookuptable;
      $this->lookups[$thisinput]['lutype'] = $lutype;
      $this->lookups[$thisinput]['srcparam'] = $srcparam;
      $this->lookups[$thisinput]['debug'] = 0;
   }

   function addOperator($statevar, $operator, $initval) {
      if (!in_array($statevar, array_keys($this->state))) {
         if ($this->debug) {
            $this->errorstring .= "Adding state variable $statevar <br>\n";
         }
         # need to add this named input
         $this->state[$statevar] = $initval;
      }
      $operator->name = $statevar;
      # set link to operators parent (i.e., this containing object)
      $operator->parentobject = $this;
      $this->processors[$statevar] = $operator;
      if ($this->debug) {
         $this->errorstring .= "Adding operator <br>\n";
      }
      # add to exec list in order of creation, may later order by precedence with the
      # function orderOperations()
      array_push($this->execlist, $statevar);
      $this->procnames = array_keys($this->processors);
   }

   function addInput($thisinput, $inputparam, $input_obj, $input_type = 'float8') {
      $inkeys = array();
      if (is_array($this->inputs)) {
         $inkeys = array_keys($this->inputs);
      }
      if (!in_array($thisinput, $inkeys)) {
         if ($this->debug) {
            $this->logDebug("New Input $thisinput added. ");
            #$this->logDebug(array_keys($this->inputs));
         }
         # need to add this named input
         $this->inputs[$thisinput] = array();
         # add db column setup info
         if (strlen($input_type) > 0) {
            $this->dbcolumntypes[$thisinput] = $input_type;
            #error_log(print_r($this->dbcolumntypes,1));
         }
      }
      array_push($this->inputs[$thisinput], array('param'=>$inputparam, 'objectname'=>$input_obj->name, 'object'=>$input_obj, 'value'=>NULL));
      $iname = $input_obj->name;
      $myname = $this->name;
      if (!(isset($this->state[$thisinput]))) {
         $this->state[$thisinput] = 0.0;
      }
      if ($this->debug) {
         $this->logDebug("Adding $iname to $myname <br>\n");
      }
      $this->inputnames = array_keys($this->inputs);
      // add this to the loggable columns data_cols if we use strict logging
      if ($this->debug) {
         $this->logDebug("Adding $thisinput to loggable variables $myname <br>\n");
      }
      $this->data_cols[] = $thisinput;
   }

   function getInputs() {
      if ($this->debug) {
         $this->logDebug("Getting Inputs for $this->name <br>");
         $sv = $this->state;
         if (isset($sv['the_geom'])) {
            $sv['the_geom'] = 'HIDDEN';
         }
         $this->logDebug("Inputs Beginning State array: " . print_r($sv,1) . "\n<br>");
      }
      
      // *****************************
      // BEGIN - get Hard Wired Inputs
      // *****************************
      foreach (array_keys($this->inputs) as $varname) {
         if ($this->debug) {
            $this->logDebug("Getting Input $varname for $this->name <br>");
         }
         # reset each input param to 0.0 for the beginning of the timestep
         $this->state[$varname] = 0.0;

         $k = 0;
         foreach ($this->inputs[$varname] as $thisin) {
            $outparam = $thisin['param'];
            $inobject = $thisin['object'];
            $lv = $thisin['value'];
            if ($this->debug) {
               $iname = $inobject->name;
               if ($varname <> 'the_geom') {
                  $this->logDebug("Searching $iname ($outparam) for $varname - last value = $lv... ");
               }
            }
            # accumulate inputs if they are numeric,
            # since we may input to the same input multiple sources
            $inval = $inobject->getValue($this->timer->timeseconds, $outparam);
            $this->inputs[$varname][$k]['value'] = $inval;
            # if the child object returns NULL, we don't use it
            if (!($inval === NULL)) {
               if (is_numeric($inval)) {
                  $this->state[$varname] += $inval;
               } else {
                  $this->state[$varname] = $inval;
               }
               if ($this->debug) {
                  $iname = $inobject->name;
                  if ($varname <> 'the_geom') {
                     $this->logDebug("updated with $outparam = $inval from Input: $iname, input total = " . $this->state[$varname] . "<br>\n");
                  }
               }
            }
            $thisin['value'] = $inval;
            $k++;
         }
      }
      // *****************************
      // END - get Hard Wired Inputs
      // *****************************
      
      if ($this->debug) {
         $sv = $this->state;
         if (isset($sv['the_geom'])) {
            $sv['the_geom'] = 'HIDDEN';
         }
         $this->logDebug("Inputs gathered. State array: " . print_r($sv,1) . "\n<br>");
      }
      # now, process lookups, replaces lookup key with value in state variable
      $this->doLookups();
      if ($this->debug) {
         $this->logDebug("Lookups calculated. State array: " . print_r($sv,1) . "\n<br>");
      }

   }

   function doLookups() {
      foreach(array_keys($this->lookups) as $thisl) {
         $thistab = $this->lookups[$thisl]['table'];
         $defval = $this->lookups[$thisl]['default'];
         $lutype = $this->lookups[$thisl]['lutype'];
         $srcparam = $this->lookups[$thisl]['srcparam'];
         $curval = $this->state[$srcparam];
         $luval = '';
         switch ($lutype) {
            case 0:
            # exact match lookup table
            if (in_array($curval, array_keys($thistab))) {
               $luval = $thistab[$curval];
            } else {
               $luval = $defval;
            }
            if ($thisl->debug) {
               $this->logDebug("$thisl: $curval, def: $defval, lookup: $luval <br>\n");
               $this->logDebug($thistab);
               $this->logDebug("<br>\n");
            }
            break;

            case 1:
            # interpolated lookup table
            $lukeys = array_keys($thistab);
            $luval = $defval;
            for ($i=0; $i < (count($lukeys) - 1); $i++) {
               $lokey = $lukeys[$i];
               $hikey = $lukeys[$i+1];
               $loval = $thistab[$lokey];
               $hival = $thistab[$hikey];
               $minkey = min(array($lokey,$hikey));
               $maxkey = max(array($lokey,$hikey));
               if ( ($minkey <= $curval) and ($maxkey >= $curval) ) {
                  $luval = $this->interpValue($curval, $lokey, $loval, $hikey, $hival);
                  if ($this->lookups[$thisl]['debug']) {
                     $sv = $this->state;
                     if (isset($sv['the_geom'])) {
                        $sv['the_geom'] = 'HIDDEN';
                     }
                     $this->logDebug($sv);
                     $this->logDebug("<br>\nLow: $lokey, Value: $curval, Hi: $hikey = $luval <br>\n");
                  }
               }
            }
            break;

         }
         $this->state[$thisl] = $luval;
      }
   }

   function showHTMLInfo() {
      # prints out information about this object.  Should sub-class to get in depth report

      $props = $this->getPublicVars();
      $HTMLInfo = '';
      
      // do those in prop_desc first, then those that are sub-components (and hence have a desc)
      // then finally, those that do not have a description
      $subs = array_keys($this->processors);
      sort($subs);
      
      $HTMLInfo .= "<h3>Internal Properties:</h3><br>";
      foreach ($this->prop_desc as $varname => $desc) {
         if (!in_array($varname, $subs)) {
            // will assume that it has been sub-classed if it is set as a user-defined property
            $HTMLInfo .= "<b>$varname</b> - $desc <br> ";
         }
      }
      $HTMLInfo .= "Un-described: ";
      foreach ($props as $thisprop) {
         if ( (!(in_array($thisprop, array_keys($this->prop_desc)))) and (!(in_array($thisprop, $subs))) ) {
            $HTMLInfo .= "$thisprop ";
         }
      }
      $HTMLInfo .= "<hr>";
      $HTMLInfo .= "<h3>User-defined Sub-components:</h3><br>";
      $undesc = '';
      foreach ($subs as $thisproc) {
         if (property_exists($this->processors[$thisproc], 'description')) {
            if (strlen(trim($this->processors[$thisproc]->description)) > 0) {
               $HTMLInfo .= "<b>$thisproc</b> - " . $this->processors[$thisproc]->description . " <br> ";
            } else {
               $undesc .= "$thisproc ";
            }
         } else {
            $undesc .= "$thisproc ";
         }
      }
      $HTMLInfo .= "Un-described: $undesc";

      return $HTMLInfo;

   }

}

class modelSubObject extends modelObject {
   
   function logState() {
   
      // logging will be done by the parent, so no need to waste memory and time with this
   
   }
}
   

class broadCastObject extends modelSubObject {
   // HUB object communication entities
   var $parentHub; // the "up-link" for peer-broadcast sharing in this container space
   var $childHub; // the hub space for this objects contained children (their parentHub - if they exist)
   var $broadcast_params = array(); 
   var $read_vars = array();
   var $cast_vars = array();
   // in form 'groupName'=>array(
   //            'cast_parent'=>1, // send messages to the HUB on parent?
   //            'read_parent'=>0, // read messages on the parent HUB?
   //            'cast_child'=>0,  // send messages to the child HUB (actually located on the object FOR its children)
   //            'read_child'=>1,  // read messages on the child HUB
   // in general, casting/reading settings should be unique to an object class, but might be specific for a given entity 
   // as well.  Right now, there is no facility for making them unique to each parameter, but that could be added later
   // also, these are NOT settable by the client for now.  maybe this should ALL be done in sub-components, which would 
   // make this a bit easier to manage.
   //            'params'=>array('Qout','drainarea_sqmi')
   //         );  
   var $broadcast_class = '';
   var $local_varname = array();
   var $broadcast_varname = array();
   var $broadcast_hub = 'parent'; // parent or child
   var $broadcast_mode = 'cast'; // either cast or read
   var $multivar = 1; // this is a multi-var entity
   var $loggable = 0; 
   var $exclude_my_broadcasts = 0; // don't READ values from this objects broadcasts to hub
   
   function getInputs() {
      // has an entirely different approach to getting inputs
      // only do something on getInputs() if this is a reader
      // if this is a broadcaster, we do something on step()
      switch ($this->broadcast_mode) {
         case 'read':
            $this->broadRead();
         break;
      }
   }
   
   function init() {
      parent::init();
      // has an entirely different approach to getting inputs
      $this->parentHub = $this->parentobject->parentHub;
      $this->childHub = $this->parentobject->childHub;
      switch ($this->broadcast_hub) {
         case 'parent':
            $target = $this->parentHub;
         break;
         
         case 'child':
            $target = $this->childHub;
         break;
      }
      switch ($this->broadcast_mode) {
         case 'cast':
            // if this is a cast, then we will be pushing local variables, and NOT be mnodifying them on the parent
            $this->multivarnames = array();
         break;
         
         case 'read':
            // if this is a read, then we will be pulling local variables, and therefore modifying them on the parent
            $this->multivarnames = $this->local_varname;
            // now, if this is a read, set variables types for parent data logging of these input variables
            for ($i = 0; $i < count($this->local_varname); $i++) {
               $local = $this->local_varname[$i];
               if ($this->debug) {
                  $this->logDebug("Setting parent log type for variable $local <br>\n");
               }
               // later, we may allow the interface to provide settings for variable type and default value
               // for now, we just force them all to float8, and 0.0
               // we don't initialize variables if this broadcast hub does not exist, for example, if a the top-most
               // parent is calling the runs, there will be no ParentHub for it to read from
               if (is_object($target)) {
                  $this->parentobject->setSingleDataColumnType($local, 'float8', 0.0);
                  if (!in_array($local, $this->vars)) {
                     array_push($this->vars,$local);
                  }
               }
            }
         break;
         
         default:
            // if this is a cast, then we will be pulling local variables, and NOT be mnodifying them on the parent
            $this->multivarnames = array();
         break;         
      }
      
   }
   
   function evaluate() {
   }
   
   function step() {
      parent::step();
      $this->stepBroadcast();
   }
   
   function stepBroadcast() {
      // only do something on step() if this is a broadcaster
      // if this is a reader, we do something on getInputs()
      switch ($this->broadcast_mode) {
         case 'cast':
            $this->broadCast();
         break;
      }
   }
   
   function broadCast() {
      // send my broadcast variables (if any) to the broadcast hub
      // The broadcast HUB is an object with few methods, just a message passer
      // the broadcast hub is usually located in the parent object, but for a non-contained model container (i.e., that 
      // which initiated the model run) there would be no broadcast hub for it to send data to.  
      // var $parentHub; // the "up-link" for peer-broadcast sharing in this container space
      // var $childHub; // the hub space for this objects contained children (their parentHub)
      
      // iterate through each broadcast type and send the variables
      // also, the broadcast sub-components will do a broadcast call, but not via this method, rather, via their own calls
      // the the broadcast method -- maybe we think of creating subcomponents to handle all broadcasts, ???  not for now though
      switch ($this->broadcast_hub) {
         case 'parent':
            $target = $this->parentHub;
         break;
         
         case 'child':
            $target = $this->childHub;
         break;
      }
      
      // this is the broadcast hub itself, give all variables on the broadcast hub
      if (!is_object($target)) {
         $this->logError("<b>Error:</b> Selected hub for $this->name is not an object <br>");
         return;
      }
      if (!method_exists($target, 'broadCast')) {
         $this->logError("<b>Error:</b> No broadCast method on hub for $this->name <br>");
         return;
      }
      
      if ($this->debug) {
         if (is_object($this->childHub)) {
            $this->logDebug("Child Hub Contents: <br>" . print_r($this->childHub->hub_data,1) . "<br>");
         }
         if (is_object($this->parentHub)) {
            $this->logDebug("Parent Hub Contents: <br>" . print_r($this->parentHub->hub_data,1) . "<br>");
         }
      }
      
      if ($this->debug) {
         $this->logDebug("Broadcasting to $this->broadcast_hub for $this->name : <br>");
         $this->logDebug("Local info : " . print_r($this->arData,1) . "<br>");
      }
      for ($i = 0; $i < count($this->local_varname); $i++) {
         $remote = $this->broadcast_varname[$i];
         $local = $this->local_varname[$i];
         $target->broadCast($this->broadcast_class, $remote, $this->componentid, $this->arData[$local]);
         $this->logDebug("Broadcasting $this->broadcast_class, $remote, $this->componentid, " . $this->arData[$local] . "<br>");
      }
   }
   
   function wake() {
      parent::wake();
      $this->initBroadCast();
   }
   
   function initBroadCast() {
      // broadcast set-up
      // make sure these are ready to be stored and iterated through if there is ony a single entry.
      if ($this->debug) {
         $this->logDebug("Local vars: " . print_r($this->local_varname, 1) . " and broadcast vars " . print_r($this->broadcast_varname, 1) . "<br>");
      }
      if (!is_array($this->broadcast_varname)) {
         $this->broadcast_varname = array($this->broadcast_varname);
      }
      if (!is_array($this->local_varname)) {
         $this->local_varname = array($this->local_varname);
      }
      if ($this->debug) {
         $this->logDebug("Local vars: " . print_r($this->local_varname, 1) . " and broadcast vars " . print_r($this->broadcast_varname, 1) . "<br>");
      }
      
      if ($this->broadcast_mode == 'read') {
         // add readable vars to local procs
         for ($i = 0; $i < count($this->local_varname); $i++) {
            $local = $this->local_varname[$i];
            if (!in_array($local, $this->vars)) {
               array_push($this->vars,$local);
            }
         }
      }
   }
   
   function broadRead() {
      
      switch ($this->broadcast_hub) {
         case 'parent':
            $target = $this->parentHub;
         break;
         
         case 'child':
            $target = $this->childHub;
         break;
      }
      
      // this is the broadcast hub itself, give all variables on the broadcast hub
      if (!is_object($target)) {
         $this->logError("<b>Error:</b> Selected hub for $this->name is not an object <br>");
         $this->logDebug("<b>Error:</b> Selected hub for $this->name is not an object <br>");
         return;
      }
      if (!method_exists($target, 'read')) {
         $this->logError("<b>Error:</b> No read method on hub for $this->name <br>");
         return;
      }
      
      // get the raw hub data
      if ($this->debug) {
         $this->logDebug("Reading $this->broadcast_class for " . $this->name . "<br>");
      }
      
      //$hub_data = $target->read(array('dataClass'=>$this->broadcast_class));
      $hub_data = $target->read();
      if ($this->debug) {
         $this->logDebug("Data Retrieved from $target->parentname :" . print_r($hub_data,1) . "<br>");
      }
      
      if (!isset($hub_data[$this->broadcast_class])) {
         if ($this->debug) {
            $this->logDebug("$this->broadcast_class does not exist on target hub $target->parentname <br>");
         }
      } else {
         if ($this->debug) {
            $this->logDebug("Iterating through local Inputs: " . print_r($this->local_varname,1) . "<br>\n");
         }
         $thisclass = $hub_data[$this->broadcast_class];
         if ($this->debug) {
            $this->logDebug("In data set: " . print_r($thisclass,1) . "<br>\n");
         }
         for ($i = 0; $i < count($this->local_varname); $i++) {
            $remote = $this->broadcast_varname[$i];
            if ($this->debug) {
               $this->logDebug("Looking for remote variable $remote <br>\n");
            }
            $local = $this->local_varname[$i];
            $remote_array = $thisclass[$remote];
            if ($this->debug) {
               $this->logDebug("Found " . print_r($remote_array, 1) . "<br>\n");
            }
            $remote_vals = array();
            foreach ($remote_array as $thiskey => $thisrecord) {
               if (isset($thisrecord['value'])) {
                  if ( (!$this->exclude_my_broadcasts) or ($this->componentid <> $thiskey)) {
                     if ($this->debug) {
                        $this->logDebug("Reading from Comp $thiskey (my ID: $this->componentid)<br>\n");
                     }
                     $remote_vals[] = $thisrecord['value'];
                  }
               }
            }
            if ($this->debug) {
               $this->logDebug("Trying to append $local with Inputs: " . print_r($remote_vals,1) . "<br>\n");
            }
            if (count($remote_vals) > 0) {
               $this->parentobject->appendStateVar($local, $remote_vals, 'refresh');
               if ($this->debug) {
                  $this->logDebug("Parent variable $local = " . $this->parentobject->state[$local] . "<br>\n");
               }
            } else {
               if ($this->debug) {
                  $this->logDebug("No values retrieved for $remote <br>\n");
               }
            }
         }
         
      }

   }

   function showEditForm($formname, $disabled=0) {
      if (is_object($this->listobject)) {

         $returnInfo = array();
         $returnInfo['name'] = $this->name;
         $returnInfo['description'] = $this->description;
         $returnInfo['debug'] = '';
         $returnInfo['elemtype'] = get_class($this);

         $i = 0;

         $aset = $this->listobject->adminsetuparray['broadCastObject'];
         $aset['column info']['broadcast_mode']['onchange'] = "xajax_showOperatorEditResult(xajax.getFormValues(\"$formname\"));";
         foreach (array_keys($aset['column info']) as $tc) {
            $props[$tc] = $this->getProp($tc);
         }
         //$props = array('matrix'=>$this->matrix, 'name'=>$this->name);
         $formatted = showFormVars($this->listobject,$props,$aset,0, 1, 0, 0, 1, 0, -1, NULL, 1);

         $innerHTML .= "<b>Name:</b> " . $formatted->formpieces['fields']['name'] . "<BR>";
         $innerHTML .= "<b>Description:</b> " . $formatted->formpieces['fields']['description'] . "<BR>";
         $innerHTML .= "<b>Broadcast Class Name:</b> " . $formatted->formpieces['fields']['broadcast_class'] . "<BR>";
         $innerHTML .= "<b>Broadcast Hub:</b> " . $formatted->formpieces['fields']['broadcast_hub'] . "<BR>";
         $innerHTML .= "<b>Broadcast Mode:</b> " . $formatted->formpieces['fields']['broadcast_mode'] . "<BR>";
         $innerHTML .= "<b>Execution Hierarchy:</b> " . $formatted->formpieces['fields']['exec_hierarch'] . "<BR>";
         $aset['table info']['formName'] = $formname;
         $parentname = "broadvars_$formname";
         $aset['table info']['parentname'] = $parentname;
         $childname = "onebroadvar_$formname";;
         $aset['table info']['childname'] = $childname . '[]';
         $innerHTML .= showHiddenField("xajax_removeitem", -1, 1);
         
         if (is_array($this->matrix)) {
         } else {
            $this->matrix = array($this->matrix);
         }
         $numcols = intval(count($this->matrix) / $this->numrows);
         //$innerHTML .= "<table id='broadvars_$formname'>";
         $innerHTML .= "<div id='$parentname' name='$parentname'>";
         $mindex = 0;
         for ($i = 0; $i < count($this->local_varname); $i++) {
            
            $innerHTML .= "<div name='$childname"."[]' id='$childname"."[]'>";
            // now, if this is a read call, we let the user create variable names (text field), and hub names
            // if it is a WRITE call, we make a select list for the local param, and a text field for the remote
            switch ($this->broadcast_mode) {
               case 'read':
                  $aset['column info']['local_varname']['type'] = 1;
                  $aset['column info']['broadcast_varname']['type'] = 1;
               break;
               
               default:
                  $aset['column info']['local_varname']['type'] = 3;
                  $aset['column info']['broadcast_varname']['type'] = 1;
               break;
            }
            // just create a record object with the two columns used here, and tell the showformvars routine to 
            // supress missing variables
            $thisrecord = array('broadcast_varname'=>$this->broadcast_varname[$i], 'local_varname'=>$this->local_varname[$i]);
            $innerHTML .= showFormVars($this->listobject,$thisrecord,$aset,1, 0, 0, 1, 1, $disabled, -1, $multiformindex = '',0);
            
            $innerHTML .= "</div>";
         }
         $innerHTML .= "</div>";
         
         $innerHTML .= "<br><b>Debug Mode?:</b> " . $formatted->formpieces['fields']['debug'];
         
         $returnInfo['innerHTML'] = $innerHTML;

         return $returnInfo;
      }
   }
}


class broadCastHub {
   // this is a bare-bones class for passing messages in broadcast form.
   // broadcast data packets have the following attributes:
      // dataClass
      // dataName
      // sourceID (unique to the component that sent it)
      // efficient storage would be to key things by their sourceID, 
      //    since all packets from a single sourceID would come in at once
      // efficient RETRIEVAL would be to key things by their infoClass, 
      //   since retrieval would be expected to go by class
   var $hub_data = array();
   var $parentname = '';
   var $loggable = 0;
   
   function broadCast($dataClass, $dataName, $sourceID, $dataValue) {
      $this->hub_data[$dataClass][$dataName][$sourceID]['value'] = $dataValue;
   }
   
   // will allow a detailed read to get source object id's as well
   // we could pass all sorts of ancillary information keyed to the object ID, such as geography, and name
   // this would allow for a robust reporting facility, keyed by object ID
   
   function read($dataParams=array()) {
      // this would be in the form:
      // of an array of criteria that may have at least the dataClass, and any of the following:
      // dataClass, dataName, sourceID
      // Ex:
      // array('dataClass'=>'hydroObject', 'dataName'=>'Qout');
      $retarr = array();
      if (count($dataParams) == 0) {
         // just send it all
         return $this->hub_data;
      } else {
         if (isset($dataParams['dataClass'])) {
            // we can proceed, otherwise we would just get all data
            if (isset($this->hub_data[$dataParams['dataClass']])) {
               $retarr[$dataParams['dataClass']] = $this->hub_data[$dataParams['dataClass']];
            }
            // for now we do not allow finer querying, but we can in the future
            /*
            $dn = '';
            if (isset($thisparam['dataName'])) {
               // screen on variable name
               $id = '';
               if (isset($thisparam['sourceID']) {
               }
            }
            */
         }
      }
   }
   
}

class modelContainer extends modelObject {
   # Model Container
   # Acts as an container to other modeling object components
   # Calculates the run time order of each component
   # Supplies the timer object to each component
   # Executes the step() call for each component
   # Keeps a log of modeling operations, and the status of each component (if there is an error value)
   var $starttime = '1999-01-01';
   var $endtime = '1999-12-31';
   var $modelhost = 'localhost';
   var $nextid = 0;
   var $dt = 86400; # time-step seconds (1 hour = 3600, 1 day = 86400)
   var $component_type = 2;
   var $outputinterval = 1;
   var $outstring = '';
   var $graphstring = '';  # stores images urls after model runs
   var $iscontainer = 1; # only true for objects of type "model container" or it's subclasses
   var $systemlog_obj = -1; // listobject for system log (may differ from model listobject)
   var $syslogrec = -1; # a flag to tell the container if a syslog record is existing for this object
   var $runid = -1; # a flag to tell the container if a syslog record is existing for this object
   var $compexectimes = array();
   var $standalone = 1; // can this container be run as standalone?  
                        // This is useful for "tree" based running schemas, where we will run
                        // different model components simultaneously to take advantage of multiple processors
   function wake() {
      parent::wake();
      // make sure that time is properly 
      $this->setModelTime($this->starttime, $this->endtime);
   }
   
   function setModelTime($starttime, $endtime = '') {
      // this sets and properly formats time, to allow for using offest/relative times (like "+7 days" and "-7 days"
      $conv_time = new DateTime($starttime);
      $this->starttime = $conv_time->format('Y-m-d H:i:s');
      if ($endtime <> '') {
         $conv_time = new DateTime($endtime);
         $this->endtime = $conv_time->format('Y-m-d H:i:s');
      } else {
         $this->endtime = $this->starttime;
      }
   }
   
   function init() {
      parent::init();
      $this->setSessionID();
      $this->orderOperations();
      $this->orderComponents();
      if ($this->debug) {
         $this->logDebug("Initializing components<br>");
      }
      $this->outstring .= "<b>Components included in model run:</b><ul>";
      foreach($this->compexeclist as $thiscompid) {
         $thiscomp = $this->components[$thiscompid];
         if ($this->debug) {
            $this->logDebug($this->name . " Initializing component $thiscomp->name <br>");
         }
         $this->systemLog(" Initializing component $thiscomp->name <br>");
         $this->outstring .= "<li> $thiscomp->name </li>";
         $thiscomp->setProp('sessionid', $this->sessionid);
         $thiscomp->parentHub = $this->childHub;
         $thiscomp->init();
      }
      $this->outstring .= "</ul>";
      $this->syslogrec = -1;
      $this->compexectimes = array();
   }
   
   function setSessionID() {
      if ($this->sessionid == 0) {
         $this->sessionid = $this->componentid;
      }
   }

   function step() {
      // many object classes will subclass this method.  
      // all step methods MUST call preStep(),execProcessors(), postStep()
      $this->preStep();
      
      if ($this->debug) {
         $this->logDebug("<b>$this->name step() method called at hour " . $this->state['hour'] . " on " . $this->state['thisdate'] . ".</b><br>\n");
      }
      if ($this->debug) {
         $this->logDebug("$this->name Inputs obtained. thisdate = " . $this->state['thisdate']);
      }

      # data aquisition first - should this be opposite for container? i.e., should they get their inputs After their
      # components are executed?  Will this assist in the lag time phenomenon?
      # or should we do it twice?  With the second one only inputs from objects that are contained by this one, 
      # getContainedInputs() method?

      # then process calculations
      $this->execComponents();
      // we have just executed our children and gotten the results from their broadcasts
      // now we will execute our local sub-comps to process any data obtained from children via broadcast
      $this->execProcessors();
      // refresh inputs from contained objects, in order to communicate with other objects that link to this object
      // via a cross-container linkage
      // we also implicitly update child broadcasts by reading them at the end of execComponents
      $this->getInputs();
      $this->postStep();

   }


   function getContainedInputs() {
      if ($this->debug) {
         $this->logDebug("Getting Inputs for $this->name <br>");
      }
      foreach (array_keys($this->inputs) as $varname) {
         if ($this->debug) {
            $this->logDebug("Getting Input $varname for $this->name <br>");
         }
         # reset each input param to 0.0 for the beginning of the timestep
         $this->state[$varname] = 0.0;

         $k = 0;
         foreach ($this->inputs[$varname] as $thisin) {
            $outparam = $thisin['param'];
            $inobject = $thisin['object'];
            $lv = $thisin['value'];
            if ($this->debug) {
               $iname = $inobject->name;
               if ($varname <> 'the_geom') {
                  $this->logDebug("Searching $iname ($outparam) for $varname - last value = $lv... ");
               }
            }
            # accumulate inputs if they are numeric,
            # since we may input to the same input multiple sources
            $inval = $inobject->getValue($this->timer->timeseconds, $outparam);
            $this->inputs[$varname][$k]['value'] = $inval;
            # if the child object returns NULL, we don't use it
            if (!($inval === NULL)) {
               if (is_numeric($inval)) {
                  $this->state[$varname] += $inval;
               } else {
                  $this->state[$varname] = $inval;
               }
               if ($this->debug) {
                  $iname = $inobject->name;
                  if ($varname <> 'the_geom') {
                     $this->logDebug("updated with $outparam = $inval from Input: $iname, input total = " . $this->state[$varname] . "<br>\n");
                  }
               }
            }
            $thisin['value'] = $inval;
            $k++;
         }
      }
      if ($this->debug) {
         $sv = $this->state;
         if (isset($sv['the_geom'])) {
            $sv['the_geom'] = 'HIDDEN';
         }
         $this->logDebug("Inputs gathered. State array: " . print_r($sv,1) . "\n<br>");
      }
      # now, process lookups, replaces lookup key with value in state variable
      $this->doLookups();
      if ($this->debug) {
         $this->logDebug("Lookups calculated. State array: " . print_r($sv,1) . "\n<br>");
      }

   }

   function systemLog($mesg, $status_flag=1) {
      $pid = getmypid();
      if (is_object($this->systemlog_obj)) {
         setStatus($this->systemlog_obj, $this->sessionid, $mesg, $this->modelhost, $status_flag, $this->runid);
         /*
         if ($this->syslogrec <= 0) {
            $this->systemlog_obj->querystring = " select count(*) as numrecs from system_status ";
            $this->systemlog_obj->querystring .= " where element_name = 'model_run' ";
            $this->systemlog_obj->querystring .= "    and element_key = $this->sessionid  ";
            $this->systemlog_obj->querystring .= "    and host = '$this->modelhost'  ";
            $this->systemlog_obj->performQuery();
            $this->syslogrec = $this->systemlog_obj->getRecordValue(1,'numrecs');
         }
         if ($this->syslogrec == 0) {
            $this->systemlog_obj->querystring = " insert into system_status (element_name, element_key, ";
            $this->systemlog_obj->querystring .= "    status_mesg, status_flag, pid, last_updated, host ) ";
            $this->systemlog_obj->querystring .= " values ('model_run', $this->sessionid, '$mesg', $status_flag, $pid, now(), '$this->modelhost') ";
            $this->systemlog_obj->performQuery();
         } else {
            $this->systemlog_obj->querystring = " update system_status ";
            $this->systemlog_obj->querystring .= " set status_mesg = '$mesg', ";
            $this->systemlog_obj->querystring .= "    status_flag = $status_flag, ";
            $this->systemlog_obj->querystring .= "    pid = $pid, ";
            $this->systemlog_obj->querystring .= "    last_updated = now() ";
            $this->systemlog_obj->querystring .= " where element_name = 'model_run' ";
            $this->systemlog_obj->querystring .= "    and element_key = $this->sessionid ";
            $this->systemlog_obj->querystring .= "    and host = '$this->modelhost'  ";
            if ($this->bufferlog) {
               $this->systemlog_obj->bufferQuery();
            } else {
               $this->systemlog_obj->performQuery();
            }
         }
         */
         //error_log($this->systemlog_obj->querystring);
      } else {
         if (is_object($this->parentobject)) {
            $this->parentobject->systemLog($mesg, $status_flag);
         }
      }
   }
   
   function cleanUp() {
      # remove all the temp tables associated with this object
      if (is_object($this->listobject)) {
         if ($this->listobject->tableExists($this->dbtblname)) {
            $this->listobject->querystring = "  drop table $this->dbtblname ";
            $this->listobject->performQuery();
         }
      }
      # iterate through each equation stored in this object
      foreach ($this->compexeclist as $thiscomp) {
         # evaluate the equation
         if ($this->debug) {
            $this->logDebug("Cleaning Up $thiscomp<br>\n");
         }
         $outmesg = "Cleaning Up $thiscomp<br>\n";
         //error_log($outmesg);
         $this->systemLog($outmesg);

         # set all required inputs for the equation
         if (is_object($this->components[$thiscomp])) {
            if (method_exists($this->components[$thiscomp], 'cleanUp')) {
               $this->components[$thiscomp]->cleanUp();
               unset($this->components[$thiscomp]);
            }
         }
      }
      parent::cleanUp();
   }

   function finish() {
      $max_used = memory_get_usage(true) / (1024.0 * 1024.0);
      $this->outstring .= " Memory use at simulation end: $max_used Mb / Flush Parameters: " . $this->timer->max_memory_mb . " * " . $this->timer->max_memory_pct . " <br>\n";
      $outmesg = "Calling finish() Method on contained model components.";
      //error_log($outmesg);
      $this->systemLog($outmesg);
      parent::finish();
      $outmesg = "Gathering info and error reports for model components.";
      //error_log($outmesg);
      $this->systemLog($outmesg);
      # iterate through each sub-processor stored in this object
      if (is_array($this->processors)) {
         foreach ($this->processors as $thisproc) {
            if ($this->debug) {
               $this->logDebug("Finishing $thisproc->name<br>\n");
            }
            if (is_object($thisproc)) {
               if (method_exists($thisproc, 'finish')) {
                  $thisproc->finish();
               }
            }
            # show component output reports
            if (strlen($thisproc->reportstring) > 0) {
               $this->reportstring .= "<b>Reports for: </b>" . $thisproc->name . '<br>';
               $this->reportstring .= $thisproc->description . "<br>" . $thisproc->reportstring . "<br>";
               $thisproc->reportstring = '';
            }
            # show component error reports
            if (strlen($thisproc->errorstring) > 0) {
               $this->errorstring .= "<b>Errors for: </b>" . $thisproc->name . '<br>';
               $this->errorstring .= $thisproc->description . "<br>" . $thisproc->errorstring . "<br>";
               $thisproc->errorstring = '';
            }
         }
         unset($thisproc);
      }

      # iterate through each contained object in this model run
      foreach ($this->compexeclist as $thiscomp) {
         # evaluate the equation
         if ($this->debug) {
            $this->logDebug("Finishing $thiscomp<br>\n");
         }
         $outmesg = "Finishing $thiscomp<br>\n";
         //error_log($outmesg);
         $this->systemLog($outmesg);
         $thisname = $this->components[$thiscomp]->name;

         # set all required inputs for the equation
         $this->components[$thiscomp]->finish();
         // stash the report of average time of execution in the outstring on this parent object
         //$avgexec = $this->compexectimes[$thiscomp] / $this->timer->steps;
         $avgexec = $this->components[$thiscomp]->meanexectime;
         $this->outstring .= "Component $thisname ($thiscomp) avg. exec time: $avgexec <br>";

         # now get reporting data from any contained components
         # check for report files
         if ( (strlen($this->components[$thiscomp]->logfile) > 0) and (file_exists($this->components[$thiscomp]->outdir . '/' . $this->components[$thiscomp]->logfile)) ) {
            $this->reportstring .= "For log click here: <a href='" . $this->components[$thiscomp]->outurl;
            $this->reportstring .= '/' . $this->components[$thiscomp]->logfile . "' target=_new>";
            $this->reportstring .= $thisname . ' log file';
            $this->reportstring .= '</a>';
         }
         # check for debugging info
         if ( (strlen($this->components[$thiscomp]->debugstring) > 0) ) {
            $this->debugstring .= "<b>Debug info for: </b>" . $thisname . '<br>';
            $this->debugstring .= $this->components[$thiscomp]->debugstring . '<br>';
            # CLEAN UP to save memory, keep it from ballooning out
            $this->components[$thiscomp]->debugstring = ''. '<br>';
         }

         # get comp graphs
         $outmesg = "Getting graphs on $thiscomp<br>\n";
         $this->getCompGraphs($this->components[$thiscomp]);

         # show component output reports
         if (strlen($this->components[$thiscomp]->reportstring) > 0) {
            $this->reportstring .= "<b>Reports for: </b>" . $thisname . '<br>';
            $this->reportstring .= $this->components[$thiscomp]->description . "<br>";
            $this->reportstring .= $this->components[$thiscomp]->reportstring . "<br>";
            # CLEAN UP to save memory, keep it from ballooning out
            $this->components[$thiscomp]->reportstring = ''. '<br>';
         }
         # show component output reports
         if (strlen($this->components[$thiscomp]->errorstring) > 0) {
            $this->errorstring .= "<b>Errors for: </b>" . $thisname . '<br>';
            $this->errorstring .= $this->components[$thiscomp]->description . "<br>";
            $this->errorstring .= $this->components[$thiscomp]->errorstring . "<br>";
            # CLEAN UP to save memory, keep it from ballooning out
            $this->components[$thiscomp]->errorstring = ''. '<br>';
         }
         unset($this->components[$thiscomp]);
      }

      $this->reportstring .= "Finished Model run for $this->name.<br>";

   }

   function reDraw() {

      if ($this->debug) {
         $this->logDebug("Trying to redraw children<br>\n");
      }
      if ($this->sessionid == 0) {
         $this->sessionid = $this->componentid;
      }
      # iterate through each contained object
      foreach ($this->compexeclist as $thiscomp) {
         # evaluate the equation
         if ($this->debug) {
            $this->logDebug("Checking for reDraw() on $thiscomp<br>\n");
         }
         # set all required inputs for the equation
         if (method_exists($this->components[$thiscomp], 'reDraw')) {
            if ($this->debug) {
               $this->logDebug("Redrawing $thiscomp<br>\n");
            }
            $this->components[$thiscomp]->setProp('sessionid', $this->sessionid);
            $this->components[$thiscomp]->reDraw();
            $this->getCompGraphs($this->components[$thiscomp]);
         }
      }

   }

   function getCompGraphs($thiscomp) {

      # check for formatted graph output (overrides a URL)
      if (strlen($thiscomp->graphstring) > 0) {
         $this->graphstring .= $thiscomp->graphstring . "<br>";
      } else {
         # check for graph output in the form of a URL
         if (strlen($thiscomp->imgurl) > 0) {
            //$this->graphstring .= "<img src='" . $thiscomp->imgurl . "'><br>";
            $this->graphstring .= "<a class='mH' onClick='document[\"image_screen\"].src = \"" . $thiscomp->imgurl . "\"; '>$thiscomp->name - $thiscomp->title</a> | ";
            $this->graphstring .= "<a href='" . $thiscomp->imgurl . "' target='_new'>View Image in New Window</a><br>";
         }
     }
   }


   function runModel() {
      error_log("<b>Beginning Model Run<br>");
      $this->logDebug("<b>Error info for ModelContainer: </b>" . $this->name . '<br>');
      $this->systemLog("<b>Beginning Model Run<br>");
      if ($this->debug) {
         $this->logDebug("<b>Beginning Model Run</b><br>");
         $this->logDebug("<b>Time of Run Start:</b> " . date('r') . "<br>");
         #$this->logDebug($this->timer);
      }
      //error_log("<b>Creating Timer<br>");
      $newtimer = new simTimer;
      //error_log("<b>Initializing Timer properties<br>");
      $newtimer->setStep($this->dt);
      $newtimer->setTime($this->starttime, $this->endtime);
      $this->starttime = $newtimer->thistime->format('Y-m-d H:i:s');
      $this->endtime = $newtimer->endtime->format('Y-m-d H:i:s');
      #$this->logDebug($newtimer);
      //error_log("<b>Setting Timer<br>");
      $this->setSimTimer( $newtimer);
      $this->outstring .= "<b>Beginning Model Run at:</b> " . date('r') . "<br>";
      $this->outstring .= "<b>Model Time Span Set:</b> " . $this->starttime . " to " . $this->endtime . "<br>";
      $this->outstring .= "<b>Setting Component Session ID to:</b> " . $this->sessionid . "<br>";
      if ($this->cascadedebug) {
         //error_log("<b>Setting Debug Mode on all children<br>");
         foreach($this->components as $thiscomp) {
            $thiscomp->setDebug($this->debug, $this->debugmode);
         }
      }
      //error_log("<b>Initializing components<br>");
      $this->setSessionID();
      $this->systemLog("<b>Initializing components<br>");
      $this->outstring .= "<b>Initializing model components at:</b> " . date('r') . "<br>";
      $this->init();
      $i = 0;

      if ($this->bufferlog == 1) {
         $this->setBuffer(1);
         //error_log("Database log queries will be sent asynchronously (buffered).");
      } else {
         $this->setBuffer(0);
         //error_log("Database log queries will be sent synchronously (non-buffered).");
      }
      $this->outstring .= "<b>Stepping through model execution at:</b> " . date('r') . "<br>";
      error_log("<b>Iterating through timesteps<br>");
      while (!$this->timer->finished) {
         if (intval($i / $this->outputinterval) == ($i / $this->outputinterval)) {
            $ts = $this->timer->thistime->format('r');
            $outmesg = "Executing step $i @ time: $ts";
            $this->outstring .= $outmesg . "<br>";
            $this->systemLog($outmesg);
         }
         $this->timer->step();
         $this->step();
         $i++;
      }
      $outmesg = "<b>Finished model interations -- starting post processing<br>";
      error_log($outmesg);
      $this->systemLog($outmesg,1);
      
      # make sure that all pending log queries have been processed
      if (is_object($this->listobject)) {
         $this->listobject->flushQueryBuffer();
      }
    

      # now, do any post-processing
      $outmesg = "<b>Post-processing model components at:</b> " . date('r') . "<br>";
      $this->outstring .= $outmesg;
      $this->systemLog($outmesg);
      $this->finish();
      $outmesg = "<b>Finished post-processing. model run ended.<br>";
      error_log($outmesg);
      $this->systemLog($outmesg,0);
   }

   function addComponent($thiscomp, $componentid = '') {
      # add a modeling component to this global model container
      if ($componentid == '') {
         $componentid = $thiscomp->componentid;
      }
      if (!is_array($this->components)) {
         $this->components = array();
      }
      if ( !( in_array($componentid, array_keys($this->components)) ) ) {

         $this->components[$componentid] = $thiscomp;
         if ($this->cascadedebug) {
            $this->components[$componentid]->debug = $this->debug;
         }
         #$this->components['comp' . $this->nextid]->setCompID('comp' . $this->nextid);
         array_push($this->compexeclist, $componentid);
         $this->compexectimes[$componentid] = 0.0; // initialize the timer 
         #$this->nextid++;
         if ($this->debug) {
            #error_log("Adding component " . $thiscomp->name . ' ID: ' . $thiscomp->componentid);
            $this->logDebug("Container " . $this->name . " is adding component " . $thiscomp->name . "(" . $componentid . ")<br>\n");
         }
         # add to exec list in order of creation, may later order by precedence with the
         # function orderOperations()
      } else {
         if ($this->debug) {
            #error_log("Adding component " . $thiscomp->name . ' ID: ' . $thiscomp->componentid);
            $this->logDebug("<b>Error: </b>Component named " . $thiscomp->name . " (" . $componentid . ") already exists in container " . $this->name . ".  Cannot Add.<br>\n");
         }
      }

      return $thiscomp;

   }


   function execComponents() {

      if ($this->debug) {
         $this->logDebug("Going through components for $this->name.<br>\n");
         #error_log("Going through components for $this->name.");
      }
      # iterate through each equation stored in this object
      foreach ($this->compexeclist as $thiscomp) {
         # evaluate the equation
         if ($this->debug) {
            $this->logDebug("Executing $thiscomp<br>\n");
            #error_log("Executing $thiscomp .");
         }
         # set all required inputs for the equation
         if (method_exists($this->components[$thiscomp], 'step' )) {
            $this->components[$thiscomp]->step();
            if ($this->debug) {
               $this->logDebug("$thiscomp Finished ($et seconds). <br>\n");
               #error_log("$thiscomp Finished ($et seconds). <br>\n");
               #error_log("$thiscomp Finished.");
            }
         } else {
            if ($this->debug) {
               $arr = get_class_methods(get_class($this->components[$thiscomp]));
               $this->logDebug("Method step() on $thiscomp is undefined - skipping. ( Defined methods: "  . print_r($arr,1) . ") \n<br>");
               #Qerror_log("Method step() on $thiscomp is undefined - skipping. ( Defined methods: "  . print_r($arr,1) . ") ");
            }
         }
      }
      $this->readChildBroadCasts();
   }

   function orderComponents() {

      $dependents = array();
      $execlist = array();

      # compile a list of independent and dependent variables
      foreach ($this->components as $thiscomp) {
         if (!in_array($thiscomp->componentid, array_keys($dependents))) {
            if ($this->debug) {
               $cn = $thiscomp->name;
               $ci = $thiscomp->componentid;
               $this->logDebug("<br>Adding component $cn ($ci) to queue <br>\n");
            }
            # need to add this named input
            $dependents[$thiscomp->componentid] = array('compid'=>$thiscomp->componentid, 'invars'=>array(), 'object'=>$thiscomp);
         }
         if ($this->debug) {
            $this->logDebug("<br>This components inputs:<br>");
            $this->logDebug(array_keys($thiscomp->inputs));
            $this->logDebug("<br>");
         }
         foreach (array_keys($thiscomp->inputs) as $thisinputname) {
            if ($this->debug) {
               $this->logDebug("Checking $thisinputname ");
            }
            foreach ($thiscomp->inputs[$thisinputname] as $thisinput) {
               $thisinobj = $thisinput['object'];
               if ($this->debug) {
                 # $this->logDebug("This input object: <br>");
                  #$this->logDebug($thisinobj) ;
                  #$this->logDebug("<br>");
               }
               if ( !in_array($thisinobj->componentid, $dependents[$thiscomp->componentid]['invars']) ) {
                  if ($this->debug) {
                     $ci = $thisinobj->componentid;
                     $this->logDebug(".. Adding $ci ");
                  }
                  array_push($dependents[$thiscomp->componentid]['invars'], $thisinobj->componentid );
               }
            }
            if ($this->debug) {
               $this->logDebug("<br>Finished checking $thisinputname <br>");
            }
         }
      }
      # now check the list of independent variables for each processor,
      # if none of the variables are in the current list of dependent variables
      # put it into the execution stack, remove from queue
      if ($this->debug) {
         $this->logDebug("<br>Initial Queue:<br>");
         $this->logDebug(array_keys($dependents));
         foreach ($dependents as $thisdep) {
            $dn = $thisdep['compid'];
            $dvars = $thisdep['invars'];
            $this->logDebug("$dn = ");
            $this->logDebug($dvars);
            $this->logDebug("<br>");
         }
         $this->logDebug("<br>");
      }
      $queue = $dependents;
      $i = 0;
      while (count($queue) > 0) {
         $thisdepend = array_shift($queue);
         $newqueue = array();
         # array shift resets the keys, destroying our link by compid, thus, we need to
         # restore this after shifting
         foreach ($queue as $thisel) {
            $newqueue[$thisel['compid']] = $thisel;
         }
         $queue = $newqueue;
         $pvars = $thisdepend['invars'];
         $thiscompid = $thisdepend['compid'];
         if ($this->debug) {
            $this->logDebug("Checking $thiscompid variables ");
            $this->logDebug($pvars);
            $this->logDebug(" <br>\nin ");
            $this->logDebug(array_keys($queue));
            $this->logDebug("<br>\n");
         }
         if (!$this->array_in_array($pvars, array_keys($queue))) {
            array_push($execlist, $thiscompid);
            $i = 0;
            if ($this->debug) {
               $this->logDebug("Not found, adding $thiscompid to execlist.<br>\n");
            }
         } else {
            # put it back on the end of the stack
            if ($this->debug) {
               $this->logDebug("Found.<br>\n");
            }
            $queue[$thiscompid] = $thisdepend;
         }
         $i++;
         if ( ($i > count($queue)) and (count($queue) > 0)) {
            # we have reached an impasse, since we cannot currently
            # solve simultaneous variables, we just put all remaining on the
            # execlist and hope for the best
            # a more robust approach would be to determine which elements are in a circle,
            # and therefore producing a bottleneck, as other variables may not be in a circle
            # themselves, but may depend on the output of objects that are in a circle
            # then, if we add the circular variables to the queue, we may be able to continue
            # trying to order the remaining variables

            # first, create a list of execution hierarchies and compids
            $hierarchy = array();
            foreach ($queue as $thisel) {
               $hierarchy[$thisel['compid']] = $thisel['object']->exec_hierarch;
            }
            # sort in reverse order of hierarchy
            # then, look at exec_hierarch property, if the first element is higher priority than the lowest in the stack
            # pop it off the list, and add it to the queue
            # then, after doing that, we can go back, set $i = 0, and try to loop through again,
            arsort($hierarchy);
            $keyar = array_keys($hierarchy);
            if ($this->debug) {
               $this->logDebug("Cannot determine sequence of remaining variables, searching manual execution hierarchy setting.<br>\n");
            }
            $firstid = $keyar[0];
            $fh = $hierarchy[$firstid];
            $mh = min(array_values($hierarchy));
            if ($this->debug) {
               $this->logDebug("Highest hierarchy value = $fh, Lowest = $mh.<br>\n");
            }
            if ($fh > $mh) {
               # pop off and resume trying to sort them out
               $newqueue = array_diff_assoc($queue, array($firstid => $queue[$firstid]) );
               array_push($execlist, $firstid);
               $i = 0;
               if ($this->debug) {
                  $this->logDebug("Elelemt " . $queue[$firstid]['object']->name . ", with hierarchy " . $hierarchy[$firstid] . " added to execlist.<br>\n");
               }
               $queue = $newqueue;
            } else {

               # otherwise, we will add the rest to the list by numb3er of dependents, and then break
               if ($this->debug) {
                  $this->logDebug("Can not determine linear sequence for the remaining components. <br>\n");
                  //$this->logDebug(print_r($queue,1));
                  $this->logDebug("<br>\nHoping their execution order does not matter!.<br>\n");
               }
               $newexeclist = array_merge($execlist, array_keys($queue));
               $execlist = $newexeclist;
               break;
            }
         }
      }
      $this->compexeclist = $execlist;
      if ($this->debug) {
         $this->logDebug("<br>\nExecution list: ");
         $this->logDebug($this->compexeclist);
         $this->logDebug("<br>\n");
      }
   }

}

class simTimer {

   var $thistime;
   var $endtime;
   var $timeseconds;
   var $year;
   var $month;
   var $day;
   var $hour;
   var $modays;
   var $finished = 0;
   var $dt = 60.0;
   var $listobject = -1;
   var $log2db = 0;
   var $max_memory_mb = 2048; // megabytes
   var $max_memory_pct = 0.85; // percentage of max memory at which to initiate flushing of log tables
   var $steps = 0;
   var $timestamp;
   # simple time functions
   var $timestart = 0;
   var $timeend = 0;
   var $splittime = -1;

   function init() {
      $this->thistime = new DateTime();
      $this->endtime = $this->thistime;
      $this->modays = $this->thistime->format('t');
      $this->year = $this->thistime->format('Y');
      $this->month = $this->thistime->format('n');
      $this->day = $this->thistime->format('j');
      $this->hour = $this->thistime->format('G');
      $this->timeseconds = $this->thistime->format('U');
      $this->timestamp = $this->thistime->format('r');
      $this->finished = 0;

      $this->dbtblname = $this->tblprefix . 'datalog';
   }
   
   
   function microtime_float()
   {
      list($usec, $sec) = explode(" ", microtime());
      return ((float)$usec + (float)$sec);
   }

   function timeSplit()
   # starts, or takes a split
   {
      $this->timeend = $this->microtime_float();
      $this->splittime = $this->timeend - $this->timestart;
      $this->timestart = $this->microtime_float();
      $split = 0;
      if ($this->splittime > 0) {
         $split = $this->splittime;
      }
         return $split;
   }

   function setStep($dt) {
      $this->dt = $dt;
   }

   function setTime($starttime, $endtime='') {
      $this->thistime = new DateTime($starttime);
      if ($endtime <> '') {
         $this->endtime = new DateTime($endtime);
      }
   }

   function step() {
      $this->thistime->modify("$this->dt seconds");
      $this->modays = $this->thistime->format('t');
      $this->year = $this->thistime->format('Y');
      $this->month = $this->thistime->format('n');
      $this->day = $this->thistime->format('j');
      $this->hour = $this->thistime->format('G');
      $this->timeseconds = $this->thistime->format('U');
      $this->timestamp = $this->thistime->format('r');
      $this->state['thisdate'] = $this->thistime->format('Y-m-d');
      if ($this->debug) {
         $this->logDebug("<br><b>$this->name step() method called at hour " . $this->state['hour'] . " on " . $this->state['thisdate'] . ".</b><br>\n");
      }
      if ($this->thistime->format('U') > $this->endtime->format('U')) {
         $this->finished = 1;
      } else {
         $this->finished = 0;
      }
      $this->steps++;
   }
}

class dataMatrix extends modelSubObject {
   # this is a general purpose class to provide a multi-dimensional data array sub-component
   # it can be used directly or subclassed to contain the parameter tables from model files such as HSPF UCI's
   # or can possibly be used to hold geographic points, and act as a database or spreadsheet.
   
   // this class may function in one of three ways:
   // 1) as an array variable, returning an array of values in response to getValue method
   // 2) as a 1-column lookup, using the first column as the key, and returning all subsquent column in that row
   //    in response to getValue method - if there are only 2 columns, it will return a scalar value for 2nd column
   // 3) as a 2-column lookup, using two variable inputs to select from a single matching row-column value, 
   //    returns scalar ALWAYS
   
   // additionally, the return values may be variable references
   
   var $valuetype = 0; // 0 - returns entire array (normal), 1 - single column lookup (col), 2 - 2 column lookup (col & row)
   var $keycol1 = ''; // key for 1st lookup variable
   var $lutype1 = 0; // lookup type for first lookup variable: 0 - exact match; 1 - interpolate values; 2 - stair step
   var $keycol2 = ''; // key for 2nd lookup variable
   var $lutype2 = 0; // lookup type for second lookup variable
   var $matrix = array();
   var $matrix_formatted = array();
   var $matrix_rowcol = array();
   // if this is set to true, the first row will be ignored in data requests, assuming that these are labels only
   var $firstrow_colnames = 0;
   // if this is set to true, the first column values will be ignored, assuming that these are labels only
   var $firstcol_keys = 0;
   var $numrows = 1;
   var $numcols = 1;
   var $rownames = array();
   var $colnames = array();
   var $serialist = 'matrix'; # tells routines to serialize this before storing in XML
   var $cellsize = 4;
   var $fixed_cols = 0; # whether or not to restrict the number of rows or columns
   var $fixed_rows = 0;
   var $loggable = 1; // can log the value in a data table
   var $text2table = ''; // text to derive columns
   var $delimiter = 0; // 0|Comma,1|Tab,2|pipe,3|Space

   function showEditForm($formname, $disabled=0) {
      if (is_object($this->listobject)) {

         $returnInfo = array();
         $returnInfo['name'] = $this->name;
         $returnInfo['description'] = $this->description;
         $returnInfo['debug'] = '';
         $returnInfo['elemtype'] = get_class($this);
         if (is_array($this->matrix)) {
         } else {
            $this->matrix = array($this->matrix);
         }
         # set up div to contain each seperate multi-parameter block
         $aset = $this->listobject->adminsetuparray['dataMatrix'];
         foreach (array_keys($aset['column info']) as $tc) {
            $props[$tc] = $this->getProp($tc);
         }
         // get form variables in formatted HTML input fields
         $formatted = showFormVars($this->listobject,$props,$aset,0, 1, 0, 0, 1, 0, -1, NULL, 1);

         //$props = (array)$this;
         $innerHTML = '';
         $innerHTML .= $this->showFormHeader($formatted, $formname, $disabled);
         $innerHTML .= "<hr>";
         $innerHTML .= $this->showFormBody($formatted, $formname, $disabled);
         $innerHTML .= $this->showFormFooter($formatted, $formname, $disabled);
         
         
         
         // show the formatted matrix
         //$this->formatMatrix();
         //$innerHTML .= print_r($this->matrix_formatted,1) . "<br>";

         $returnInfo['innerHTML'] = $innerHTML;

         return $returnInfo;

      }
   }
   
   function showFormHeader($formatted, $formname, $disabled = 0) {
      $innerHTML = '';
      $innerHTML .= "<b>Name:</b> " . $formatted->formpieces['fields']['name'] . " | ";
      $innerHTML .= "<b>Debug Mode?:</b> " . $formatted->formpieces['fields']['debug'] . " | ";
      $innerHTML .= "<b>Exec. Rank:</b> " . $formatted->formpieces['fields']['exec_hierarch'] . "<BR>";
      $innerHTML .= "<b>Description:</b> " . $formatted->formpieces['fields']['description'] . "<BR>";
      $innerHTML .= "<b>Value Type:</b> " . $formatted->formpieces['fields']['valuetype'] . " | ";
      $innerHTML .= "<b>Default Value:</b> " . $formatted->formpieces['fields']['defaultval'] . "<br>";
      $innerHTML .= " <b>Row Key:</b> " . $formatted->formpieces['fields']['keycol1'];
      $innerHTML .= " <b>Type:</b>" . $formatted->formpieces['fields']['lutype1'] ;
      $innerHTML .= " <b>Col Key:</b> (2-d) " . $formatted->formpieces['fields']['keycol2'];
      $innerHTML .= " <b>Type:</b>" . $formatted->formpieces['fields']['lutype2'];
      return $innerHTML;
   }
   
   function showFormBody($formatted, $formname, $disabled = 0) {
      $innerHTML = '';
      $innerHTML .= showHiddenField("numrows", $this->numrows, 1);
      $numcols = intval( count($this->matrix) / $this->numrows);
      if ($this->debug) {
         $innerHTML .= "<br>Rows = $this->numrows , Cols = $this->numcols , derived cols: $numcols<br>";
      }
      // Value Type Array / 1-column Lookup / 2-column Lookup  --  1st Lookup (matches 1st Column), 2nd Lookup (Matches 1st Row Values)
      if ($this->debug) {
         $innerHTML .= "Creating table named - 'matrix_$formname'<br>";
      }
      // BEGIN - text2table functions and data
      if ($this->debug) {
         $innerHTML .= "Form variables = " . print_r($formatted->values,1) . "<br>";
      }
      $toggleText = " style=\"display: none\"";
      $innerHTML .= "<a class='mH' id='$formname t2tbutton' ";
      $innerHTML .= "onclick=\"toggleMenu('$formname t2t')\" title='Click to Expand/Hide'>click to Show Text 2 Table </a>";
      $innerHTML .= "<div id='$formname t2t' class='mProp' $toggleText>";
      $innerHTML .= showTextArea('text2table', $this->text2table, 80, 8, '', 1, $disabled, -1, '');
      $innerHTML .= "<br>" . "<b>Delimeter:</b> " . $formatted->formpieces['fields']['delimiter'] . "<br>";
      $innerHTML .= showGenericButton('docreate', 'Text to Table', "document.forms[\"$formname\"].elements.callcreate.value = 1; xajax_showOperatorEditResult(xajax.getFormValues(\"$formname\"))", 1);
      $innerHTML .= "</div><hr>";
      // END - text2table section
      $innerHTML .= "<table id='matrix_$formname'>";
      $mindex = 0;
      $colwidths = $this->getColumnWidths();
      if ($this->debug) {
         $this->logDebug("Column widths = " . print_r($colwidths,1) . "<br>");
         $innerHTML .= "Column widths = " . print_r($colwidths,1) . "<br>";
      }
      for ($i = 0; $i < $this->numrows; $i++) {
         $innerHTML .= "<tr>";
         for ($j = 1; $j <= $numcols; $j++) {
            $style_str = '';
            if (isset($colwidths[$j])) {
               $cw = $colwidths[$j];
            } else {
               $cw = $this->cellsize;
            }
            switch ($this->valuetype) {
               case 0:
               //nothing to do, all columns are value
               break;

               case 1:
               // grey the first column of each row to indicate that these are your key columns
                  if ($j == 1) {
                     $style_str = "style='background-color: #BEBEBE'";
                  }
               break;

               case 2:
               // grey the first column of each row to indicate that these are your key columns
                  if ( ($j == 1) or ($i == 0)) {
                     $style_str = "style='background-color: #BEBEBE'";
                  }
               break;
            }

            $innerHTML .= "<td><input type=text $style_str SIZE=" . $cw . " name=matrix[] value=\"" . $this->matrix[$mindex] . "\"></td>";
            $mindex++;
         }
         $innerHTML .= "</tr>";
      }
      $innerHTML .= "</table>";
      if (!$this->fixed_cols) {
         $innerHTML .= "<input type=\"button\" onclick=\"addColumn('$formname','matrix_$formname','<input type=text SIZE=" . $this->cellsize . " name=matrix[]>')\" value=\"Add column\">";
      }
      if (!$this->fixed_rows) {
         $innerHTML .= "<input type=\"button\" onclick=\"addRow('$formname','matrix_$formname','<input type=text SIZE=" . $this->cellsize . " name=matrix[]>'); incrementFormField('$formname', 'numrows', 1) ; \" value=\"Add row\">";
      }
      return $innerHTML;
   }
   
   function showFormFooter($formatted,$formname, $disabled = 0) {
      $innerHTML = '';
      return $innerHTML;
   }
   
   function getColumnWidths() {
      $mindex = 0;
      $maxwidth = array();
      $numcols = intval(count($this->matrix) / $this->numrows);
      for ($i = 0; $i < $this->numrows; $i++) {
         for ($j = 1; $j <= $numcols; $j++) {
            if (!isset($maxwidth[$j])) {
               $maxwidth[$j] = $this->cellsize;
            }
            $cw = strlen($this->matrix[$mindex]);
            if ($cw > $maxwidth[$j]) {
               $maxwidth[$j] = $cw;
            }
            $mindex++;
         }
      }
      return $maxwidth;
   }
   
   function init() {
      parent::init();
      $this->formatMatrix();
      $this->recordInvars();
   }
   
   function create() {
      parent::create();
      // check to see if the text2table field has anything in it
      // if so, parse the text appropriately
      if (strlen($this->text2table) > 0) {
         if ($this->debug) {
            $this->logDebug("Calling tableFromText($this->text2table, $this->delimiter)");
         }
         $this->tableFromText($this->text2table, $this->delimiter);
      }
   }
   
   function tableFromText($text, $delimiter=0) {
      // split by line-breaks
      // split by column-delimiter
      $lines = explode("\n",$text);
      $tdel = $this->translateDelim($delimiter);
      if ($this->debug) {
         $this->logDebug("Delimiter = $tdel ($delimiter)");
      }
      $this->matrix = array();
      if (count($lines) > 0) {
         $this->numrows = count($lines);
         if ($this->debug) {
            $this->logDebug("Function tableFromText() found $this->rows rows");
         }
         $i = 0;
         foreach ($lines as $thisline) {
            $args = explode($tdel, $thisline);
            if ($i == 0) {
               $this->numcols = count($args);
               if ($this->debug) {
                  $this->logDebug("Function tableFromText() found $this->cols columns ");
               }
            }
            foreach ($args as $thisarg) {
               $this->matrix[] = $thisarg;
            }
            $i++;
         }
      }      
   }
   
   function recordInvars() {
      // sets up the list of inputs and variable references used in this, so that we can be ordered properly

      $mindex = 0;
      $numcols = intval(count($this->matrix) / $this->numrows);
      $skeys = array_keys($this->arData);
      for ($i = 0; $i < $this->numrows; $i++) {
         for ($j = 0; $j < $numcols; $j++) {
            $thisvar = $this->matrix[$mindex];
            if (in_array($thisvar, $skeys)) {
               if ($this->debug) {
                  $this->logDebug("Checking $thisname = $thisval in lookup table<br>");
               }
               # stash in var table to help with processor hierarchy
               array_push($this->vars, $thisvar);
            }
            $mindex++;
         }
      }
      // now also add the keys that we are using to evaluate this object if it is a lookup
      switch ($this->valuetype) {
         case 1:
            array_push($this->vars, $this->keycol1);
         break;
         
         case 2:
            array_push($this->vars, $this->keycol1);
            array_push($this->vars, $this->keycol2);
         break;
      }
   }
   
   function evalMatrixVar($thisvar) {
      // this checks to see if a value is a variable reference, string, or a number
      $skeys = array_keys($this->arData);
      if(trim($thisvar,"'\"") <> $thisvar) {
         // this is a string variable, as indicated by ' or "
         $thisval = trim($thisvar,"'\"");
      } else {
         if (in_array($thisvar, $skeys)) {
            $thisval = $this->arData[$thisvar];
         } else {
            $thisval = $thisvar;
         }
      }
      //$this->logDebug("Checking Lookup Key: $thisvar , value: $thisval ");
      //error_log("Checking Lookup Key: $thisvar , value: $thisval ");
      //error_log("In State Vars: " . print_r($this->arData,1));
      return $thisval;
   }
   
   function step() {
      parent::step();
      $this->formatMatrix();
   }
   
   function formatMatrix() {
      // need to put our matrix into a formatted matrix
      // start by storing in a strict row-column format, if we are doing lookups, we will use this as the basis
      // for the latter re-formatting
      $matrix_formatted = array();
      $matrix_rowcol = array();
      $mindex = 0;
      $numcols = intval(count($this->matrix) / $this->numrows);
      for ($i = 0; $i < $this->numrows; $i++) {
         for ($j = 0; $j < $numcols; $j++) {
            // old - did not consider if a value was a variable or not
            //$matrix_rowcol[$i][$j] = $this->matrix[$mindex];
            $matrix_rowcol[$i][$j] = $this->evalMatrixVar($this->matrix[$mindex]);
            $mindex++;
         }
      }
      switch ($this->valuetype) {
         case 0:
            // keep in row-col format, so do no further transformation
            $matrix_formatted = $matrix_rowcol;
         break;
         
         case 1:
            // put it in a single dimensional key-value relationship, with the first column being the keys
            for ($i = 0; $i < $this->numrows; $i++) {
               $key = $matrix_rowcol[$i][0];
               
               if ($numcols == 1) {
                  $values = $this->defaultval;
               } else {
                  $values = array();
                  for ($j = 1; $j < $numcols; $j++) {
                     $values[$j-1] = $matrix_rowcol[$i][$j];
                  }
                  // make it scalar if there is only one entry
                  if (count($values) == 1) {
                     $values = $values[0];
                  }
               }
               $matrix_formatted[$key] = $values;
            }
         break;
         
         case 2:
            // put it in a multi-dimensional key-value relationship, with the first column being the keys
            // the first column first row, however, will be a throw-away, 
            for ($i = 1; $i < $this->numrows; $i++) {
               $key = $matrix_rowcol[$i][0];
               
               if ($numcols == 1) {
                  $values = $this->defaultval;
               } else {
                  $values = array();
                  for ($j = 1; $j < $numcols; $j++) {
                     // set the key to be the first (0th) row entry for this column, the value to be the 
                     // value of this column in the current row
                     $values[$matrix_rowcol[0][$j]] = $matrix_rowcol[$i][$j];
                  }
               }
               $matrix_formatted[$key] = $values;
            }
         break;
      }
            
      $this->matrix_formatted = $matrix_formatted;
      $this->matrix_rowcol = $matrix_rowcol;
   }
   
   function evaluate() {
      
      $key1 = $this->arData[$this->keycol1];
      $key2 = $this->arData[$this->keycol2];
      if ($this->debug) {
         $this->logDebug("Matrix Parent Values: " . print_r($this->arData,1) . "<br>");
      }
      // make sure that all variable values are set
      $this->formatMatrix();
      $this->result = $this->evaluateMatrix($key1, $key2);
      
   }
   
   function checkSumCols() {
      if (is_array($this->matrix_formatted)) {
         $sums = array();
         foreach ($this->matrix_formatted as $thisrow) {
            $sums = array_mesh($thisrow, $sums);
         }
      }
      return $sums;
   }
            
   
   function evaluateMatrix($key1 = '', $key2 = '') {
      // this routine assumes that the formatMatrix() routine has been called since any updates to state variables
      // has occured.  This happens automatically when the step() method is called, as well as the evaluate() method,
      // so it will occur during any reasonable invocation.  Other methods that call this dynamically, need to make sure 
      // that step() or evaluate(), or formatMatrix() has been called before calling evaluateMatrix()
      
      if ($this->debug) {
         //error_log("evaluateMatrix() called on $this->name <br>");
         $this->logDebug("evaluateMatrix() called on $this->name with keys: '$key1' and '$key2' <br>");
         // go through the matrix rows, assign column names for each piece of data
         // column names will be the contents of the first row if a 2-column lookup, 
         // or will be numerical indices if 1-column or no lookup.
         // adminsetup option to not show column names will be set if 1 or no column lookup
         $this->listobject->queryrecords = $this->printFormat();
         //$this->listobject->showlabels = 0;
         $this->listobject->adminsetup = 'raw';
         // make it silent, outputted to listobject->outstring
         $this->listobject->show = 0;
         $this->listobject->showList();
         //$this->logDebug($this->listobject->outstring . "<br>");
      }
            
            
      // need to see if this is a normal array, 1 or 2 column lookup
      switch ($this->valuetype) {
         case 0:
         // normal array, just return it
            $luval = $this->matrix_formatted;
         break;
         
         case 1:
         // 1-column lookup
            $luval = arrayLookup($this->matrix_formatted, $key1, $this->lutype1, $this->defaultval);
            if ($this->debug) {
               $this->logDebug("Matrix = " . print_r($this->matrix_formatted,1) . "<br>");
               $this->logDebug("Key = " . $key1 . " - Value: $luval<br>");
            }
         break;
         
         case 2:
            // this will interpolate in both directions
            // first get the matching row array, or interpolated row array that fits the row key
            $rowvals = arrayLookup($this->matrix_formatted, $key1, $this->lutype1, $this->defaultval);
            if ($this->debug) {
               $this->logDebug("Rowvals Matrix = " . print_r($rowvals,1) . "<br>");
            }
            // now perform the column lookup in the selected/interpolated row
            $luval = arrayLookup($rowvals, $key2, $this->lutype2, $this->defaultval);
            if ($this->debug) {
               $this->logDebug("Final Matrix = " . print_r($this->matrix_formatted,1) . "<br>");
               $this->logDebug("Key 1 = $key1, Key 2 = $key2 - Value: $luval<br>");
            }
         break;
      }
      
      return $luval;

   }
   
   function printFormat() {
      $this->formatMatrix();
      // formats the matrix data for printing in a listobject 
      // this also makes it suitable for import to a new SQL table since it is an associate array using:
      // array2Table($values, $tablename, $colnames, $valuetypes, $forcelower, $buffer, $isPerm);
      switch ($this->valuetype) {
         case 0:
            $printformatted = $this->matrix_rowcol;
         break;

         case 1:
            $printformatted = $this->matrix_rowcol;
         break;

         case 2:
            $printformatted = array();
            $keys = array_values($this->matrix_rowcol[0]);
            $cols = array_keys($this->matrix_rowcol[0]);
            for ($u = 1; $u < count($this->matrix_rowcol); $u++) {
               foreach ($keys as $col => $key) {
                  $printformatted[$u][$key] = $this->matrix_rowcol[$u][$col];
               }
            }
         break;
      }
      
      return $printformatted;
   }
   
   function showHTMLInfo() {
      #$this->init();
      $HTMLInfo = parent::showHTMLInfo();
      $matrixprint = $this->printFormat();
      //$matrixprint = $this->matrix_rowcol;
      $this->listobject->queryrecords = $matrixprint;
      //$this->listobject->showlabels = 0;
      $this->listobject->adminsetup = 'raw';
      $this->listobject->tablename = '';
      // make it silent, outputted to listobject->outstring
      $this->listobject->show = 0;
      $this->listobject->showList();
      $HTMLInfo .= $this->name . "Matrix values:<br>" . $this->listobject->outstring . "<br>";
      //$HTMLInfo .= print_r($matrixprint,1) . "<br>";
      return $HTMLInfo;
   }
   
   function appendToMatrix($thisarray = array(), $sort=0) {
      $orig = $this->formatMatrix();
   
   }
   
   function deleteFromMatrix($key1, $key2='') {
   
   
   }
   
   function assocArrayToMatrix($thisarray = array()) {
      // sets this objects matric to the input matrix
      $this->matrix = array();
      if (count($thisarray) > 0) {
         if (count($thisarray[0]) > 0) {
            $this->numcols = count($thisarray[0]);
            // add a row for the header line
            $this->numrows = count($thisarray) + 1;
            // since these are stored as a single dimensioned array, regardless of their lookup type 
            // (for compatibility with single dimensional HTML form variables)
            // we set alternating values representing the 2 columns (luname - acreage)
            foreach (array_keys($thisarray[0]) as $colname) {
               $this->matrix[] = $colname;
            }
            foreach($thisarray as $thisline) {
               foreach ($thisline as $key => $value) {
                  $this->matrix[] = $value;
               }
            }
         }
      }
   }
   
   function oneDimArrayToMatrix($thisarray = array()) {
      // sets this objects matric to the input matrix
      $this->matrix = array();
      if (count($thisarray) > 0) {
         $this->numcols = 2;
         // add a row for the header line
         $this->numrows = count($thisarray);
         // since these are stored as a single dimensioned array, regardless of their lookup type 
         // (for compatibility with single dimensional HTML form variables)
         // we set alternating values representing the 2 columns (luname - acreage)
         foreach ($thisarray as $key=>$value) {
            $this->matrix[] = $key;
            $this->matrix[] = $value;
         }
      }
   }
   
}

class matrixAccessor extends modelSubObject {
   var $targetmatrix;
   var $keycol1;
   var $keycol2;
   var $coltype1;
   var $coltype2;
   
   function init() {
      parent::init();
      if ($this->coltype1 == 1) {
         $key1_calc = new Equation;
         $key1_calc->equation = $this->keycol1;
         $key1_calc->debug = $this->debug;
         $this->addOperator('key1_calc', $key1_calc, 0);
      } else {
         $this->state['key1_calc'] = $this->keycol1;
      }
      if ($this->coltype2 == 1) {
         $key2_calc = new Equation;
         $key2_calc->equation = $this->keycol1;
         $key2_calc->debug = $this->debug;
         $this->addOperator('key2_calc', $key2_calc, 0);
      } else {
         $this->state['key2_calc'] = $this->keycol2;
      }
   }
   
   function evaluate() {
      
      // flowby has already been set
      $key1 = $this->state['key1_calc'];
      $key2 = $this->state['key2_calc'];
      
      // each evaluation field should be an equation
      if (isset($this->parentobject->processors[$this->targetmatrix])) {
         if ($this->debug) {
            $this->logDebug("Evaluating Matrix Lookup on matrix $this->targetmatrix with $key1 and $key2 <br>");
         }
         $this->result = $this->parentobject->processors[$this->targetmatrix]->evaluateMatrix($key1, $key2);
         if ($this->debug) {
            $this->logDebug(" Matrix Evaluation = $this->result <br>");
         }
      } else {      
         if ($this->debug) {
            $this->logDebug("<b>Error: </b> $this->targetmatrix not set on parent <br>");
         }
         $this->result = $this->nullvalue;
      }
   }

   function showEditForm($formname, $disabled=0) {
      if (is_object($this->listobject)) {

         $returnInfo = array();
         $returnInfo['name'] = $this->name;
         $returnInfo['description'] = $this->description;
         $returnInfo['debug'] = '';
         $returnInfo['elemtype'] = get_class($this);
         # set up div to contain each seperate multi-parameter block
         $aset = $this->listobject->adminsetuparray['matrixAccessor'];
         foreach (array_keys($aset['column info']) as $tc) {
            $props[$tc] = $this->getProp($tc);
         }
         // get form variables in formatted HTML input fields
         $formatted = showFormVars($this->listobject,$props,$aset,0, 1, 0, 0, 1, 0, -1, NULL, 1);

         //$props = (array)$this;
         $innerHTML = '';
         $innerHTML .= $this->showFormHeader($formatted, $formname, $disabled);
         $innerHTML .= "<hr>";
         $innerHTML .= $this->showFormBody($formatted, $formname, $disabled);
         $innerHTML .= $this->showFormFooter($formatted, $formname, $disabled);
         
         
         
         // show the formatted matrix
         //$this->formatMatrix();
         //$innerHTML .= print_r($this->matrix_formatted,1) . "<br>";

         $returnInfo['innerHTML'] = $innerHTML;

         return $returnInfo;

      }
   }
   
   function showFormHeader($formatted, $formname, $disabled = 0) {
      $innerHTML = '';
      $innerHTML .= "<b>Name:</b> " . $formatted->formpieces['fields']['name'] . " | ";
      $innerHTML .= "<b>Debug Mode?:</b> " . $formatted->formpieces['fields']['debug'] . " | ";
      $innerHTML .= "<b>Exec. Rank:</b> " . $formatted->formpieces['fields']['exec_hierarch'] . "<BR>";
      $innerHTML .= "<b>Description:</b> " . $formatted->formpieces['fields']['description'] . "<BR>";
      $innerHTML .= "<b>Default Value:</b> " . $formatted->formpieces['fields']['defaultval'];
      return $innerHTML;
   }
   
   function showFormBody($formatted, $formname, $disabled = 0) {
      $innerHTML = '';
      $innerHTML .= " <b>Target Matrix:</b> " . $formatted->formpieces['fields']['targetmatrix'] . "<br>";
      $innerHTML .= " <b>Row Expression:</b> " . $formatted->formpieces['fields']['keycol1'];
      $innerHTML .= " <b>Type:</b>" . $formatted->formpieces['fields']['coltype1'] . "<br>" ;
      $innerHTML .= " <b>Col Expression:</b> " . $formatted->formpieces['fields']['keycol2'];
      $innerHTML .= " <b>Type:</b>" . $formatted->formpieces['fields']['coltype2'];
      return $innerHTML;
   }
   
   function showFormFooter($formatted,$formname, $disabled = 0) {
      $innerHTML = '';
      return $innerHTML;
   }
   
}

class lookupObject extends modelSubObject {
   var $table = array();
   var $defval = 0.0;
   var $lutype = 1; # 0 - exact match; 1 - interpolate values; 2 - stair step
   var $valtype = 0; # 0 - numeric; 1 - alphanumeric; 2 - variable reference
   var $state = array();
   var $luval = 0.0;
   var $input = '';
   var $vars = array();
   var $filepath = ''; # optional, derives lookup table from a CSV file
   var $component_type = 3;
   var $lucsv = ''; # comma seperated value lookup list
   var $arData = array(); # subs for state array in other objects (parent object)
   var $dateranges = array();
   # date variables, if they are set, it sets them in the date array on init()
   # so, this way, the functions can be instantiated two ways,
   #   the old way "setUp()", and
   #   the new way, set the properties manually, and then call init()
   var $startyear = '';
   var $endyear = '';
   var $startmonth = '';
   var $endmonth = '';
   var $startday = '';
   var $endday = '';
   var $startweekday = '';
   var $endweekday = '';
   var $starthour = '';
   var $endhour = '';
   # place to stash lookup value variable reference names
   var $luVars = array();
   # an associative array that can contain any of the following keys, with a valid value:
   # startyear, endyear, startmonth, endmonth, startday, endday, startweekday, endweekday, starthour, endhour
   var $datekeypairs = array(
      'year' => array('lo'=>'startyear', 'hi'=>'endyear', 'format'=>'Y', 'minkey'=>'', 'maxkey'=>''),
      'month' => array('lo'=>'startmonth', 'hi'=>'endmonth', 'format'=>'n', 'minkey'=>1, 'maxkey'=>12),
      'day' => array('lo'=>'startday', 'hi'=>'endday', 'format'=>'j', 'minkey'=>1, 'maxkey'=>31),
      'weekday' => array('lo'=>'startweekday', 'hi'=>'endweekday', 'format'=>'N', 'minkey'=>1, 'maxkey'=>7),
      'hour' => array('lo'=>'starthour', 'hi'=>'endhour', 'format'=>'G', 'minkey'=>0, 'maxkey'=>23)
   );
   # weekday constraints are 1-7, corresponding to Monday-Sunday
   var $loggable = 1; // can log the value in a data table

   function init() {
      parent::init();
      if ($this->debug) {
         $this->logDebug("Scanning $this->lucsv for valid entries<br>");
      }
      $this->dateranges = array();
      # check for properties, which would override the datevalues
      foreach (array('startyear', 'endyear', 'startmonth', 'endmonth', 'startday', 'endday', 'startweekday', 'endweekday', 'starthour','endhour') as $thisprop) {
         if (strlen(ltrim(rtrim($this->$thisprop))) > 0) {
            $this->dateranges[$thisprop] = $this->$thisprop;
         }
      }
      #$this->logDebug("date ranges array = " . $this->logDebug($this->dateranges,1) . "<br>");

      if ($this->debug) {
         $this->logDebug("Scanning $this->lucsv for valid entries<br>");
      }

      # check for a file, if set, use it to populate the lookup table, otherwise, use the CSV string
      if (strlen($this->filepath) > 0) {
         if (file_exists($this->filepath)) {
            $flowwua = readDelimitedFile($this->filepath);
            $wua = array();
            foreach($flowwua as $thiswua) {
               $key = $thiswua[0];
               $value = $thiswua[1];
               $this->table[ltrim(rtrim("$key"))] = ltrim(rtrim($value));
            }
         }
      } else {
         $this->parseLUTable();
      }

      # set the input variable to be in the vars array so that this can be evaluated in the processor hierarchy
      $this->vars = array($this->input);

      # now, check for variable references in the lookup value fields for names in the arData array,
      # if there exists name references, then stash them
      $arNames = array_keys($this->arData);
      $this->luVars = array();
      foreach ($this->table as $thisname => $thisval) {
         if (in_array($thisval, $arNames)) {
            if ($this->debug) {
               $this->logDebug("Checking $thisname = $thisval in lookup table<br>");
            }
            $this->luVars[$thisname] = $thisval;
            # stash in var table to help with processor hierarchy
            array_push($this->vars, $thisval);
         }
      }

   }
   
   function parseLUTable() {
      if (strlen($this->lucsv) > 0) {
         # we have a csv of the lookup, over-ride other values
         $pairs = split(",", $this->lucsv);
         foreach ($pairs as $thispair) {
            list($key, $value) = split(':', $thispair);
            $this->table[ltrim(rtrim("$key"))] = ltrim(rtrim($value));
            if ($this->debug) {
               $this->logDebug("Adding $key = $value to lookup table from csv<br>");
            }
         }
      }
   }

   function setState() {
      parent::setState();
      $this->datekeypairs = array(
            'year' => array('lo'=>'startyear', 'hi'=>'endyear', 'format'=>'Y', 'minkey'=>'', 'maxkey'=>''),
            'month' => array('lo'=>'startmonth', 'hi'=>'endmonth', 'format'=>'n', 'minkey'=>1, 'maxkey'=>12),
            'day' => array('lo'=>'startday', 'hi'=>'endday', 'format'=>'j', 'minkey'=>1, 'maxkey'=>31),
            'weekday' => array('lo'=>'startweekday', 'hi'=>'endweekday', 'format'=>'N', 'minkey'=>1, 'maxkey'=>7),
            'hour' => array('lo'=>'starthour', 'hi'=>'endhour', 'format'=>'G', 'minkey'=>0, 'maxkey'=>23)
      );
   }


   # deprecated function, should no longer be called
   function setUp($input, $lutype, $table, $defval, $nullval=0.0, $dateranges=array()) {
      $this->table = $table;
      $this->defval = $defval;
      $this->state[$input] = $defval;
      $this->input = $input;
      $this->lutype = $lutype;
      $this->nullvalue = $nullval;
      if (count($dateranges) > 0) {
         $this->dateranges = $dateranges;
      }
      array_push($this->vars, $input);
   }

   function step() {
      parent::step();

      if ($this->debug) {
         $this->logDebug("Checking for variable references in lookup value fields.<br>\n");
         $this->logDebug(print_r($this->luVars, 1));
      }
      foreach ($this->luVars as $thiskey => $thisvar) {
         $this->table[$thiskey] = $this->arData[$thisvar];
         if ($this->debug) {
            $this->logDebug("Evaluating lookup object.<br>\n");
         }
      }

   }

   function evaluate() {
      #$this->step();
      if ($this->debug) {
         $this->logDebug("Evaluating lookup object.<br>\n");
      }
      $thistab = $this->table;
      if (is_string($this->defval) and in_array($this->defval,array_keys($this->arData))) {
         # use a variable reference for default value
         $defval = $arData[$this->defval];
         if ($this->debug) {
            $this->logDebug("Setting default value to variable reference $this->defval = $defval.<br>\n");
         }
      } else {
         $defval = $this->defval;
         if ($this->debug) {
            $this->logDebug("Setting default value to static default value = $defval.<br>\n");
         }
      }
      $lutype = $this->lutype;
      $dateranges = $this->dateranges;
      $curval = $this->arData[$this->input];
      $luval = '';
      # evaluate date validity
      if ($this->debug) {
         $this->logDebug("Checking Date Validity.<br>\n");
      }
      $disabled = 0; # assume it is not disabled, check date
      if (count(array_keys($dateranges)) > 0) {
         if ($this->debug) {
            $drc = count($dateranges);
            $this->logDebug("$drc Date constraints submitted.<br>\n");
            $this->logDebug($dateranges);
            $this->logDebug(array_keys($dateranges));
         }
         # set the max for day of month wrap-around to the max day in this month
         $this->datekeypairs['day']['maxkey'] = $this->timer->thistime->format('t');
         # check the keys
         $inkeys = array_keys($dateranges);
         foreach ($this->datekeypairs as $thispair) {
            $lokey = $thispair['lo'];
            $hikey = $thispair['hi'];
            if (in_array($lokey, $inkeys) or in_array($hikey, $inkeys)) {
               $fstr = $thispair['format'];
               $minkey = $thispair['minkey'];
               $maxkey = $thispair['maxkey'];
               $dateval = $this->timer->thistime->format($fstr);
               if (!in_array($lokey, $inkeys)) {
                  $loval = $dateval;
               } else {
                  $loval = $dateranges[$lokey];
               }
               if ($maxkey == '') {
                  $maxkey = max(array($dateval,$loval));
               }
               if ($minkey == '') {
                  $minkey = $loval;
               }
               if (!in_array($hikey, $inkeys)) {
                  $hival = max(array($dateval,$maxkey));
               } else {
                  $hival = $dateranges[$hikey];
               }
               /*
               if ($maxkey <> '') {
                  # evaluate as wraparound
                  if ($loval > $hival) {
                     $hival += $maxkey - $lokey;
                     $dateval += $maxkey - $lokey;
                  }
               }
               */
               # calculated distance of bounded range
               if (($hival - $loval) <> 0) {
                  $f = ( ($maxkey - $loval) + ($hival - $minkey + 1) ) * ( ($hival - $loval) - abs($hival - $loval)) / (2 * ($hival - $loval));
               } else {
                  $f = 0;
               }
               $b = ( ($hival - $loval) + abs($hival - $loval) ) / 2.0;
               $rangemin = $loval;
               $rangemax = $rangemin + $f + $b;
               # calculated distance from lo value to given value
               if (($dateval - $loval) <> 0) {
                  $fz = ( ($maxkey - $loval) + ($dateval - $minkey + 1) ) * ( ($dateval - $loval) - abs($dateval - $loval)) / (2 * ($dateval - $loval));
               } else {
                  $fz = 0;
               }
               $bz = ( ($dateval - $loval) + abs($dateval - $loval) ) / 2.0;
               $rangeval = $rangemin + $fz + $bz;

               if ($this->debug) {
                  $this->logDebug("Date value ($lokey - $minkey/$hikey - $maxkey): $dateval, Low Bound: $loval, High Bound: $hival <br>");
                  $this->logDebug("Range Distance $f (forward) + $b (backward) <br>");
                  $this->logDebug("Distance from date to low bound: $fz (forward) + $bz (backward) <br>");
               }

               if ( ($rangemin > $rangeval) or ($rangeval > $rangemax) ) {
                  $disabled = 1;
                  if ($this->debug) {
                     $this->logDebug(" Disabled.<br>");
                  }
               }
            } else {
               if ($this->debug) {
                  $this->logDebug("Date value ($lokey/$hikey) not specified <br>");
               }
            }
         }
      }

      if ($disabled) {
         if ($this->debug) {
            $this->logDebug("Lookup disabled due to date constraint. Value = $this->nullvalue <br>");
         }
         $luval = $this->nullvalue;
      } else {

         if ($this->debug) {
            $this->logDebug("Searching for $curval in <br>" . $this->logDebug($thistab,1));
         }
         switch ($lutype) {
            case 0:
            # exact match lookup table
            if (in_array($curval, array_keys($thistab))) {
               $luval = $thistab[$curval];
            } else {
               $luval = $defval;
            }
            if ($this->debug) {
               $this->logDebug("Exact match: $thisl: $curval, def: $defval, lookup: $luval <br>\n");
               $this->logDebug($thistab);
               $this->logDebug("<br>\n");
            }
            break;

            case 1:
            # interpolated lookup table
            $lukeys = array_keys($thistab);
            $luval = $defval;
            for ($i=0; $i < (count($lukeys) - 1); $i++) {
               $lokey = $lukeys[$i];
               $hikey = $lukeys[$i+1];
               $loval = $thistab[$lokey];
               $hival = $thistab[$hikey];
               $minkey = min(array($lokey,$hikey));
               $maxkey = max(array($lokey,$hikey));
               if ( ($minkey <= $curval) and ($maxkey >= $curval) ) {
                  $luval = $this->interpValue($curval, $lokey, $loval, $hikey, $hival);
                  if ($this->debug) {
                     $this->logDebug("Low: $lokey, Value: $curval, Hi: $hikey = $luval <br>\n");
                  }
               }
            }
            break;

            case 2:
            # stair-step lookup table
            $lukeys = array_keys($thistab);
            if ($this->debug) {
               $this->logDebug("Searching table:");
               $this->logDebug($thistab);
               $this->logDebug("<br>");
            }
            $luval = $defval;
            $lastkey = 'N/A';
            for ($i=0; $i <= (count($lukeys) - 1); $i++) {
               $lokey = $lukeys[$i];
               $loval = $thistab[$lokey];
               if ( ((float)$lokey <= $curval) ) {
                  $luval = $loval;
                  $lastkey = $lokey;
               }
            }
            if ($this->debug) {
               $this->logDebug("Stair Step Value: $curval, key: $lastkey, = $luval <br>\n");
            }
            break;

            default:
            # exact match lookup table
            if (in_array($curval, array_keys($thistab))) {
               $luval = $thistab[$curval];
            } else {
               $luval = $defval;
            }
            if ($this->debug) {
               $this->logDebug("Exact match: $thisl: $curval, def: $defval, lookup: $luval <br>\n");
               $this->logDebug($thistab);
               $this->logDebug("<br>\n");
            }
            break;

         }

         switch ($this->valtype) {
            # decides how to handle the value, if this is a variable lookup, we get the value from the variable,
            # otherwise, we return whatever the value is
            case 3:
               # variable reference
               if (in_array($luval, array_keys($this->arData))) {
                  $luval = $this->arData[$luval];
               }
            break;

            default:
            # do nothing
            break;
         }
      }
      if ($this->debug) {
         $this->logDebug("Lookup Value: $luval <br>\n");
      }

      $this->result = $luval;
   }

}

class hydroObject extends modelContainer {
   var $Qin = 0.0;
   var $Qout = 0.0;
   var $Iold = 0.0; /* last inflow */
   var $depth = 0.0;
   var $tol = 0.0001;
   var $Storage;
   var $n = 0.025; /* Mannings N - roughness coefficient */
   var $slope = 0.01; /* slope */
   var $slength = 100.0; /* slope length */
   var $area = 0;
   var $drainarea_sqmi = 0;
   var $totalflow = 0;
   var $totalinflow = 0;
   
   function wake() {
      parent::wake();
      $this->prop_desc['area'] = 'Local drainage area, capable of producing runoff into this object from Qafps inputs (sqmi).';
   }

   function setState() {
      parent::setState();
      $this->state['Qin'] = 0.0;
      $this->state['Qout'] = 0.0;
      $this->state['Iold'] = 0.0;
      $this->state['Vout'] = 0.0;
      $this->state['depth'] = 0.0;
      $this->state['Storage'] = 0.0;
      $this->state['demand'] = 0.0;
      $this->state['area'] = $this->area;
      $this->state['slope'] = $this->slope;
      $this->state['slength'] = $this->slength;
   }
   
   function setDataColumnTypes() {
      parent::setDataColumnTypes();
      
      $statenums = array('Qin','Qout','Iold','Vout','depth','Storage','demand','area','slope','slength');
      foreach ($statenums as $thiscol) {
         $this->dbcolumntypes[$thiscol] = 'float8';
         $this->data_cols[] = $thiscol;
      }
      
   }

   function preStep() {
      # Iold is used by storage routing routines, so stash a copy before getting inputs
      $this->Iold = $this->state['Qin'];
      $this->state['Qin'] = 0.0;
      $this->state['Iold'] = $this->Iold;

      # now proceed with the gathering of inputs
      parent::preStep();
   }

   function getPublicProps() {
      # gets only properties that are visible (must be manually defined)
      $publix = parent::getPublicProps();

      array_push($publix, 'Storage');
      array_push($publix, 'depth');
      array_push($publix, 'maxcapacity');
      array_push($publix, 'Qout');
      array_push($publix, 'Qin');
      array_push($publix, 'area');
      array_push($publix, 'unusable_storage');

      return $publix;
   }
}

class hydroContainer extends modelContainer {
   var $Qin = 0.0;
   var $Qout = 0.0;
   var $Iold = 0.0; /* last inflow */
   var $depth = 0.0;
   var $tol = 0.0001;
   var $Storage;
   var $n = 0.025; /* Mannings N - roughness coefficient */
   var $slope = 0.01; /* slope */
   var $slength = 100.0; /* slope length */
   var $area = 0;
   var $totalflow = 0;
   var $totalinflow = 0;

   function setState() {
      parent::setState();
      $this->state['Uin'] = 0.0;
      $this->state['Uout'] = 0.0;
      $this->state['Qin'] = 0.0;
      $this->state['Qout'] = 0.0;
      $this->state['Iold'] = 0.0;
      $this->state['Vout'] = 0.0;
      $this->state['depth'] = 0.0;
      $this->state['Storage'] = 0.0;
      $this->state['demand'] = 0.0;
   }
   
   function setDataColumnTypes() {
      parent::setDataColumnTypes();
      
      $statenums = array('Uin','Uout','Qin','Qout','Iold','Vout','depth','Storage','demand');
      foreach ($statenums as $thiscol) {
         $this->dbcolumntypes[$thiscol] = 'float8';
         $this->data_cols[] = $thiscol;
      }
      
   }
   
   function preStep() {
      # Iold is used by storage routing routines, so stash a copy before getting inputs
      $this->Iold = $this->state['Qin'];
      $this->state['Qin'] = 0.0;
      $this->state['Iold'] = $this->Iold;

      # now proceed with the gathering of inputs
      parent::preStep();
   }

   function getPublicProps() {
      # gets only properties that are visible (must be manually defined)
      $publix = parent::getPublicProps();

      array_push($publix, 'Storage');
      array_push($publix, 'depth');
      array_push($publix, 'maxcapacity');
      array_push($publix, 'Qout');
      array_push($publix, 'Qin');
      array_push($publix, 'unusable_storage');

      return $publix;
   }
}

class timeSeriesInput extends modelObject {
   var $tsvalues = array();
   var $nullflag = -99999; # a data flag to tell the object that the corresponding data value
                           # is not good
   var $intflag = 0; # 0 - always interpolate, 1 - never interpolate,
                       # 2 - interpolate up to a distance of ilimit seconds
   var $intmethod = 0; # 0 - linear, 1 - previous value,
                       # 2 - next value, 3 - period mean, 4 - period min, 5 - period max, 6 - period sum
   var $ilimit = 432000.0; # default ilimit = 5 days
   var $extflag = 2; # 0 - always extrapolate, 1 - never extrapolate,
                       # 2 - extrapolate up to a distance of elimit seconds
   var $elimit = 432000.0; # default elimit = 5 days
   var $extmethod = 1; # 0 - linear, 1 - closest value
   var $datastate = 0; // 0 - within data series, 1 - pre-data series, 2 - reached end of data
   var $nullvalue = NULL; # value to use if intmethod says to flag nulls
   var $lasttimeslot = 0; # integer pointing to position in time series array
   var $lasttimesec = 0; # the time in seconds corresponding to the last position in the time series
   var $delimiter = ',';
   var $cache_ts = 0; # whether or not to store the time series array in a file at the end of a run
   var $tsfile = ''; # name of the file to store our time series in
   var $ts_enabled = 1; // can turn this off if we retieved no data for this TS
   var $filepath = '';
   var $db_cache_name = ''; # name of an auxiliary table to hold the time series if we need to save memory
   var $max_memory_values = -1; # setting this to greater than zero results in cacheing
   var $cache_create_sql = ''; // place to hold the create statement for debugging purposes
   var $tscount = 0;

   function addValue($thistime, $thisvar, $thisvalue = 0) {
      $datetime = new DateTime(date('r', strtotime($thistime)));
      $tsecs = $datetime->format("U");
      $tr = $datetime->format("r");
      $td = $datetime->format("Y-m-d");
      if ($this->debug) {
         if (count($this->tsvalues) < 10) {
            $this->logDebug("Adding " . print_r($thisvar,1) . " at time $tr, $td, $tsecs <br>");
         }
      }
      if (is_array($thisvar)) {
         # assume we are being passed an associative array
         foreach ($thisvar as $key => $value) {
            $this->tsvalues[$tsecs][$key] = $value;
            # set intial values for this variable to NULL
            if (strlen($key) > 0) {
               if (!isset($this->state[$key])) {
                  $this->setStateVar($key, 'NULL');
               }
            }
         }
      } else {
         # otherwise, just put in a single pair
         $this->tsvalues[$tsecs][$thisvar] = $thisvalue;
         # set intial values for this variable to NULL
         if (strlen($thisvar) > 0) {
            if (!isset($this->state[$thisvar])) {
               $this->setStateVar($thisvar, 'NULL');
            }
         }
      }
      $this->tsvalues[$tsecs]['timestamp'] = $tsecs;
      
      if (!in_array('thisdate',$this->tsvalues[$tsecs])) {
         $this->tsvalues[$tsecs]['thisdate'] = $td;
      }
      $this->tscount++;
   }

   function setDBCacheName() {
      # set a name for the temp table that will not hose the db
      $targ = array(' ',':','-','.');
      $repl = array('_', '_', '_', '_');
      $this->tblprefix = str_replace($targ, $repl, "tmp$this->sessionid" . "_" . $this->componentid . "_");
      $this->db_cache_name = $this->tblprefix . '_cache';
      //error_log("DSN $this->name set to $this->db_cache_name ");
   }

   function init() {
      parent::init();
      $this->tsvalues = array();
      $this->lasttimesec = 0;
      $this->tscount = 0;
      if ($this->cache_ts) {
         if ($this->debug) {
            $this->logDebug("Obtaining values from file <br>\n");
         }
         $this->tsvaluesFromLogFile();
      } else {
         if ($this->debug) {
            $this->logDebug("No value file specified. <br>\n");
         }
      }
      $this->setDBCacheName();
      ksort($this->tsvalues);
      // only do this for standalone objects, not sub-components
      $mem_use = (memory_get_usage(true) / (1024.0 * 1024.0));
      $mem_use_malloc = (memory_get_usage(false) / (1024.0 * 1024.0));
      //error_log("Memory Use after init() on $this->name = $mem_use ( $mem_use_malloc )<br>\n");
         
      if ( (count($this->tsvalues) > $this->max_memory_values) and ($this->max_memory_values > 0)) {
         $this->logDebug("tsvalues cacheing enabled on $this->name - max # of recs in memory: $this->max_memory_values <br>\n");
         //error_log("tsvalues cacheing enabled on $this->name");
         $this->tsvalues2listobject();
         $this->getCurrentDataSlice();
         $mem_use = (memory_get_usage(true) / (1024.0 * 1024.0));
         $mem_use_malloc = (memory_get_usage(false) / (1024.0 * 1024.0));
         //error_log("Memory Use after caching timeseries data on $this->name = $mem_use ( $mem_use_malloc )<br>\n");
      }
      // disabled the time series search and retrieval if there is nothing to retrieve
      //if ($this->tscount == 0) {
      //   $this->ts_enabled = 0;
      //}
   }
   
   function cleanUp() {
      # remove all the temp tables associated with this object
      if (is_object($this->listobject)) {
         if ($this->listobject->tableExists($this->db_cache_name)) {
            $this->listobject->querystring = "  drop table $this->db_cache_name ";
            //error_log("Dropping db cache for $this->name ");
            $this->listobject->performQuery();
         }
      }
      parent::cleanUp();
   }
   
   function getCurrentDataSlice() {
      # need to get a certain, sensible number of values that match two criteria:
      #   1) do not exceed the max_memory_values
      #  OR
      #   2) only get enough to encompass the current dt
      # hmmm... would a query do this?
      # how about
      # select count(*) numts from table where timestamp >= $currenttime and timestamp <= $currenttime + dt
      # then, if numts > max_memory_values set LIMIT = numts
      # select * from table where timestamp >= $currenttime and timestamp <= $currenttime + dt LIMIT numts
      $current_time = $this->timer->thistime->format("U");
      $dt = $this->dt;
      if ($this->listobject->tableExists($this->db_cache_name)) {
      
         $this->listobject->querystring = "  select count(*) as numts ";
         $this->listobject->querystring .= " from  " . $this->db_cache_name;
         $this->listobject->querystring .= " where \"timestamp\" > $this->lasttimesec and \"timestamp\" <= ($current_time + $dt) ";
         if ($this->debug) {
            $this->logDebug($this->listobject->querystring);
         }
         $this->listobject->performQuery();
         $numts = $this->listobject->getRecordValue(1,'numts');
         if ($this->debug) {
            $this->logDebug("$numts values remaining in cache\n");
         }
         if ($numts > $this->max_memory_values) {
            $limit = $numts;
         } else {
            $limit = $this->max_memory_values;
         }
         $this->listobject->querystring = "  SELECT * ";
         $this->listobject->querystring .= " FROM  " . $this->db_cache_name;
         $this->listobject->querystring .= " WHERE \"timestamp\" > $this->lasttimesec LIMIT $limit ";
         if ($this->debug) {
            $this->logDebug($this->listobject->querystring);
         }
         $this->listobject->performQuery();
         $tvs = $this->listobject->queryrecords;
         $this->tsvalues = array();
         foreach ($tvs as $thistv) {
            $ts = $thistv['timestamp'];
            $this->tsvalues[$ts] = $thistv;
            $keys = array_keys($thistv);
            $firstkey = $keys[0];
            //error_log("At Timestamp $ts adding: $firstkey = " . $thistv[$firstkey]);
         }
      }
      
      if ($this->debug) {
         $this->logDebug("$this->name getCurrentDataSlice() added " . count($this->tsvalues) . " to tsvalues array");
      }
   }

   function finish() {
      if ($this->cache_ts) {
         $this->tsvalues2file();
      }
      parent::finish();
      # free up this memory
      $this->tsvalues = array();
   }

   function orderValues() {
      ksort($this->tsvalues);
   }


   function tsvaluesFromLogFile($infile='') {
      # check for a file, if set, use it to populate the lookup table, otherwise, use the CSV string
      if (!(strlen($infile) > 0)) {
         if (strlen($this->tsfile) == 0) {
            $this->tsfile = 'tsvalues.' . $this->componentid . '.csv';
            $filename = $this->outdir . '/' . $this->tsfile;
         } else {
            $filename = $this->tsfile;
         }
      } else {
         $filename = $infile;
      }

      $fe = fopen($filename,'r');
      if ($fe) {
         fclose($fe);
         # since this is from a log file that we generated, we can assume that it has the column headers
         $tsvalues = readDelimitedFile($filename, $this->translateDelim($this->delimiter), 1);
         $lc = count($tsvalues);
         if ($this->debug) {
            $tdel = $this->translateDelim($this->delimiter);
            $this->logDebug("$lc lines found. delimiter is '$tdel'.<br>");
         }
         $k = 0;
         foreach ($tsvalues as $thisline) {
            if ($k == 0) {
               if ($this->debug) {
                  $this->logDebug("Column names:" . print_r(array_keys($thisline),1) . "<br>");
               }
            }
            if (isset($thisline['timestamp'])) {
               $ts = intval($thisline['timestamp']);
               $this->tsvalues[$ts] = $thisline;
            } else {
               if (isset($thisline['thisdate'])) {
                  $ts = strtotime($thisline['thisdate']);
                  $this->tsvalues[$ts] = $thisline;
                  if ($this->debug) {
                     if ($k == 0) {
                        $this->logDebug($thisline['thisdate'] . " converted to Timestamp $ts <br>");
                     }
                  }
               } else {
                  if ($this->debug) {
                     $this->logDebug("Timestamp column not found.<br>");
                  }
               }
            }
            $k++;
         }
      } else {
         $this->logDebug("File $filename Does Not exist.<br>");
      }
   }

   function tsvalues2file() {
      if (strlen($this->tsfile) == 0) {
         $this->tsfile = 'tsvalues.' . $this->componentid . '.csv';
         $filename = $this->outdir . '/' . $this->tsfile;
      } else {
         $filename = $this->tsfile;
      }
      # format for output
      $fdel = '';
      $outform = '';
      if ($this->debug) {
         $this->logDebug("Outputting Time Series to file: $this->logfile <br>");
      }
      if (count($this->tsvalues) > 0) {
         $minkey = min(array_keys($this->tsvalues));
         if ($this->debug) {
            $this->logDebug("Time Series Start (seconds): $minkey <br> Exporting Columns");
            $this->logDebug(array_keys($this->tsvalues[$minkey]));
         }

         foreach (array_keys($this->tsvalues[$minkey]) as $thiskey) {
            if (in_array($thiskey, array_keys($this->logformats))) {
               # get the log file format from here, if it is set
               if ($this->debug) {
                  $this->logDebug("Getting format for log table " . $thiskey . "\n");
               }
               $outform .= $fdel . $this->logformats[$thiskey];
            } else {
               if ($this->debug) {
                  $this->logDebug("Guessing format for log table " . $thiskey . "\n");
               }
               if (is_numeric($this->tsvalues[$minkey][$thiskey])) {
                  $outform .= $fdel . $this->numform;
               } else {
                  $outform .= $fdel . $this->strform;
               }
            }
            $fdel = ',';
         }
         if ($this->debug) {
            $this->logDebug("Using format string: $outform <br>");
         }
         $outarr = nestArraySprintf($outform, $this->tsvalues);
         #$this->logDebug($outarr);
         $colnames = array(array_keys($this->tsvalues[$minkey]));
         if ($this->debug) {
            $colcsv = join(',', $colnames);
            $this->logDebug("Columns: $colcsv <br>");
         }

         if ($this->debug) {
            $numlines = count($this->tsvalues);
            $this->logDebug("Outputting: $numlines lines <br>");
         }

         putDelimitedFile("$filename",$colnames,$this->translateDelim($this->delimiter),1,$this->fileformat);

         putArrayToFilePlatform("$filename", $outarr,0,$this->fileformat);
      }
   }

   function tsvalues2listobject($columns = array()) {
      //error_log("tsvalues2listobject called.");
      if (is_object($this->listobject)) {
         //error_log("list object set, adding records: " . count($this->tsvalues));
         $this->setDBCacheName();
         # format for output
         $fdel = '';
         $outform = '';
         
         if ($this->debug) {
            $this->logDebug("Outputting Time Series to db: $this->dbtblname <br>");
         }
         //$this->listobject->debug = 1;
         $this->cache_create_sql = $this->listobject->array2tmpTable($this->tsvalues, $this->db_cache_name, $columns, $this->dbcolumntypes, 1, $this->bufferlog);
         //$this->listobject->debug = 0;
      } else {
         $this->logDebug("List object not set.<br>");
      }
   }

   function step() {
      # search for this time in seconds in the keys to the tsvalues array
      parent::step();
   }

   function getValue($thistime, $thisvar) {
      # search for this time in seconds in the keys to the tsvalues array
      if ($this->debug) {
         $sv = $this->state;
         if (isset($sv['the_geom'])) {
            $sv['the_geom'] = 'HIDDEN';
         }
         $this->logDebug($sv);
      }
      if (in_array($thisvar,array_keys($this->state)) ) {
         if ($this->debug) {
            $varval = $this->state[$thisvar];
            $this->logDebug("Returning $thisvar = $varval ");
         }
         return $this->state[$thisvar];
      } else {
         return NULL;
      }
   }

   function getInputs() {

      parent::getInputs();

      if ($this->ts_enabled) {
         $tvals = $this->searchTimeSeries();
         if ($this->debug) {
            $this->logDebug(" TS variable list = " . print_r(array_keys($tvals),1) . " <br>");
         }
         // forbidden to overwrite the following:
         $forbidden = array('thisdate','month','day','year');
         foreach(array_keys($tvals) as $tkey) {
            if (!in_array($tkey, $forbidden)) {
               if (isset($tvals[$tkey])) {
                  $this->state[$tkey] = $tvals[$tkey];
                  if ($this->debug) {
                     $this->logDebug(" State variable $tkey = " . $tvals[$tkey] . " <br>");
                  }
               } else {
                  // this state variable does not get retrieved from the time series
                  if ($this->debug) {
                     $this->logDebug(" State variable $tkey not a piece of time-series data <br>");
                  }
               }
            }
         }
      } else {
         if ($this->debug) {
            $this->logDebug(" $this->name time series disabled (ts_enabled = $this->ts_enabled )<br>");
         }
      }
         
      if ($this->debug) {
         $sv = $this->state;
         if (isset($sv['the_geom'])) {
            $sv['the_geom'] = 'HIDDEN';
         }
         $this->logDebug($sv);
      }
   }

   function searchTimeSeries($searchtime = -99999, $starttime = -99999) {
      # returns an array of values that corresponds to the state array at the given time
      # alows the user to specify a start time, if not passed in (-99999)
      # assumes that the starting point is the current timer value
      # alows the user to specify a start time, if not passed in (-99999) default to min value of
      # tsvalues array
      if ($searchtime == -99999) {
         $thistime = $this->timer->thistime->format("U");
         $prevtime = $this->timer->thistime->format("U") - ($this->timer->dt/2.0);
         $nexttime = $this->timer->thistime->format("U") + ($this->timer->dt/2.0);
      } else {
         $intime = new DateTime($searchtime);
         $thistime = $intime->format("U");
         $prevtime = $intime->format("U") - ($this->timer->dt/2.0);
         $nexttime = $intime->format("U") + ($this->timer->dt/2.0);
      }
      $retarr = array();

      if ($this->debug) {
         $this->logDebug("Searching for time series values at: $thistime <br>\n");
      }
      # get an array of the timeslotes, which are indexed by seconds (integer) and index them from 0 - count(timeslots)
      $timeslots = array_keys($this->tsvalues);
      # check to see if we are storing our timeseries in a database to enhance speed and limit memory consumption
      if ( (count($timeslots) <= 3) or ($nexttime > max($timeslots)) ) {
         # check to see if we can get cached values
         if ( $this->max_memory_values > 0) {
            $this->getCurrentDataSlice();
            # refresh timeslot array
            $timeslots = array_keys($this->tsvalues);
            if ($this->debug) {
               $this->logDebug("After getCurrentDataSlice() " . count($timeslots) . " timeslots available.");
            }
         }
      }
      
      
      //error_log (print_r($timeslots, 1));

      if (count($timeslots) > 0) {
         # check for exact match, if there, no further action necessary
         if (in_array($thistime, $timeslots) and (!(($this->intmethod > 2) and ($this->intmethod <= 6))) ) {
            $retarr = $this->tsvalues[$thistime];
            if ($this->debug) {
               $this->logDebug("Exact match Found at time: $thistime <br>\n");
               $this->logDebug($retarr);
            }
            $this->lasttimesec = $thistime;
            $akey = array_search($thistime, $timeslots);
            if (is_array($akey)) {
               $akey = $akey[0];
            }
            $this->removePastValues($i, $akey, $thistime);
            $this->datastate = 0;
            return $retarr;
         }

         # if not an exact match, we check to see if we are outside of our data range (require extrap)
         # or inside of our data range (require interpolation).
         # we also check the rules to see if we are allowed to interpolate or extrapolate
         if ( ($thistime < min($timeslots)) or ($thistime > max($timeslots)) ) {
            if ($thistime < min($timeslots)) {
               // we are interpolating
               $this->datastate = 1;
            } else {
               // we must be extrapolating
               $this->datastate = 2;
            }
            # we need to extrapolate
            if ($this->debug) {
               $this->logDebug("Need to extrapolate.<br>");
            }
            switch ($this->extflag) {
               case 1: # never extrapolate
               if ($this->debug) {
                  $this->logDebug("Extrapolation disabled.<br>");
               }
               $firstts = array_keys($this->tsvalues);
               foreach (array_keys($this->tsvalues[$firstts[0]]) as $thisvar) {
                  $retarr[$thisvar] = NULL;
                  if ($this->debug) {
                     $this->logDebug("$thisvar set to NULL<br>");
                  }
               }
               break;

               case 0: # always extrapolate
                  switch ($this->extmethod) {
                     case 0:
                     # linear

                     break;

                     case 1:
                     if ($this->debug) {
                        $this->logDebug("Entering extrapolation mode.<br>\n");
                     }
                     if ($thistime < min($timeslots)) {
                        $retarr = $this->tsvalues[0];
                        $this->lasttimeslot = 0;
                     } else {
                        $this->lasttimeslot = count($this->tsvalues) - 1;
                        $retarr = $this->tsvalues[$this->lasttimeslot];
                     }

                     default:
                     if ($thistime < min($timeslots)) {
                        $retarr = $this->tsvalues[$timeslots[0]];
                        $this->lasttimeslot = 0;
                     } else {
                        $this->lasttimeslot = count($this->tsvalues) - 1;
                        $retarr = $this->tsvalues[$timeslots[$this->lasttimeslot]];
                     }
                  }
               break;
               
               default: # never extrapolate
               if ($this->debug) {
                  $this->logDebug("Extrapolation disabled.<br>");
               }
               $firstts = array_keys($this->tsvalues);
               foreach (array_keys($this->tsvalues[$firstts[0]]) as $thisvar) {
                  $retarr[$thisvar] = NULL;
                  if ($this->debug) {
                     $this->logDebug("$thisvar set to NULL<br>");
                  }
               }
               break;
            }

            return $retarr;
         }
 
         # otherwise, we search to interpolate, unless we  are never to interpolate
         if ($this->intflag == 1) {
            if ($this->debug) {
               $this->logDebug("Interpolation disabled - returning NULL.<br>\n");
            }
            # never interpolate
            foreach (array_keys($this->tsvalues[0]) as $thisvar) {
               $retarr[$thisvar] = NULL;
            }
            $this->datastate = 0;
           return $retarr;
         }
         # otherwise, proceed along
         if ($starttime == -99999) {
            $lasttimeslot = $this->lasttimeslot;
         } else {
            $searchtime = new DateTime($starttime);
            $searchsecs = $searchtime->format("U");
            $spos = array_search($searchsecs, $timeslots);
            if ($spos <> FALSE) {
               $lasttimeslot = 0;
            }
         }
         $dt = $this->timer->dt; # returns time increment in seconds
         $retval = 0;
         $found = 0;
         $cachedist = 0; # for use with mean/min/max span values
         $storei = 0;
         $spanvals = array();
         for ($i = $lasttimeslot; $i <= (count($this->tsvalues) - 2); $i++) {
            $ts = $timeslots[$i];
            $nts = $timeslots[$i + 1];
            $vars = array_keys($this->tsvalues[$ts]);
            #$this->logDebug($this->tsvalues[$ts]);
            foreach ($vars as $thisvar) {
               $tv = $this->tsvalues[$ts][$thisvar];
               $ntv = $this->tsvalues[$nts][$thisvar];
               if ($this->debug) {
                  $this->logDebug("Searching for $thisvar time-slot $i in $ts to $nts, time = $thistime <br>\n");
               }
               //error_log("Searching for time-slot $i in $ts to $nts, time = $thistime <br>\n");
               # do a mean, min, max or sum value for the period between the preceding, and next time step
               if ( ($this->intmethod > 2) and ($this->intmethod <= 6) ) {
                  if ( ($ts >= $prevtime) and ($ts <= $nexttime) ) {
                     if (!isset($spanvals[$thisvar])) {
                        # initialize storage space if need be
                        $spanvals[$thisvar] = array();
                     }
                     array_push($spanvals[$thisvar], $tv);
                  }
                  if ( ($prevtime > $ts) and ($nexttime < $nts) ) {
                     # we have a time step that is too narrow to obtain
                     # valid values for this method, thus we default to using the interpolating value
                     # get single interpolated value
                     if ( ($ts < $thistime) and ($nts > $thistime) ) {
                        # between values, interpolate
                        $savemethod = $this->intmethod;
                        $this->intmethod = 0;
                        $varout = $this->interpValue($thistime, $ts, $tv, $nts, $ntv);
                        $this->intmethod = $savemethod;
                        $spanvals[$thisvar] = array($varout);
                        if ($this->debug) {
                           $this->logDebug("<br>\nInterpolating $thisvar: [t+dt]: $thistime, [t]: $ts, Value[t]: $tv, [t+1]: $nts, Value[t+1]: $ntv, Value[t+dt]: $varout <br>\n");
                        }
                        $found = 1;
                     }
                  }
                  if ( ($ts < $nexttime) and ($nts > $thistime) ) {
                     # store the value of i for searching again
                     $tdist = $ts - $thistime;
                     if ( ($tdist > 0) and ($tdist <= $cachedist) ) {
                        $cachedist = $tdist;
                        $storei = $i;
                     }
                  }
                  if ($ts > $nexttime) {
                     # we have exceeded the span
                     $found = 1;
                     # decrement $i so that we don't lose previous values
                     if ($i > 0) {
                        $i += -1;
                     }
                  }
               } else {
                  # get single interpolated value, or previous value
                  if ( ($ts < $thistime) and ($nts > $thistime) ) {
                     # between values, interpolate or previous value
                     switch ($this->intmethod) {
                        case 0:
                        $varout = $this->interpValue($thistime, $ts, $tv, $nts, $ntv);
                        $retarr[$thisvar] = $varout;
                        if ($this->debug) {
                           $this->logDebug("<br>\nInterpolating $thisvar: [t+dt]: $thistime, [t]: $ts, Value[t]: $tv, [t+1]: $nts, Value[t+1]: $ntv, Value[t+dt]: $varout <br>\n");
                        }
                        $found = 1;
                        break;
                        
                        case 1:
                        # previous value
                        $retarr[$thisvar] = $tv;
                        if ($this->debug) {
                           $this->logDebug("<br>\nUsing Previous Value for $thisvar: $tv <br>\n");
                        }
                        $found = 1;
                        break;
                        
                        case 2:
                        # next value
                        $retarr[$thisvar] = $ntv;
                        if ($this->debug) {
                           $this->logDebug("<br>\nUsing Next Value for $thisvar: $ntv <br>\n");
                        }
                        $found = 1;
                        break;
                     }
                     
                  }
               }
            }
            if ($found) {
               break;
            }
         }
         $lasti = $i;
         if ( ($this->intmethod > 2) and ($this->intmethod <= 6) ) {
            if ($this->debug) {
               $this->logDebug("Using time span summary, mean/min/max.<br>");
            }
            $i = $storei;
            # create holders for aggregating this data span
            $meanarr = array();
            $sumarr = array();
            $retarr = array();
            $sp = 0;
            #$this->logDebug($spanvals);
            #$this->logDebug("<br>");
            foreach($vars as $thisvar) {
               $meanarr[$thisvar] = 0;
            }
            foreach(array_keys($spanvals) as $thisspan) {
               $meanarr[$thisspan] = 0;
               $sumarr[$thisspan] = 0;
               foreach ($spanvals[$thisspan] as $spanv) {
                  $meanarr[$thisspan] += $spanv;
                  $sumarr[$thisspan] += $spanv;
               }
               $sp = count($spanvals[$thisspan]);
               if ($sp > 0) {
                  $meanarr[$thisspan] = $meanarr[$thisspan] / $sp;
               }
            }
            #$this->logDebug($meanarr);
            #$this->logDebug("<br>");
            switch($this->intmethod) {
               case 3:
               # mean value
               $retarr = $meanarr;
               break;

               case 4:
               # min value
               foreach (array_keys($spanvals) as $spankey) {
                  $retarr[$spankey] = min($spanvals[$spankey]);
               }
               break;

               case 5:
               # max value
               foreach (array_keys($spanvals) as $spankey) {
                  $retarr[$spankey] = max($spanvals[$spankey]);
               }
               break;

               case 6:
               # sum of values
                  $retarr = $sumarr;
               break;
            }

         }
         # speed up execution by removing values that predate the currently used values
         $this->removePastValues($i, $lasti, $ts);
         //error_log($this->name . " has " . count($this->tsvalues) . " entries after slicing ");
         $this->datastate = 0;
      
         return $retarr;
      }
   }
   
   function removePastValues($i, $lasti, $ts) {
      # always set to zero, since the timeslots array is shortened as the tsvalues array is shortened
      $this->lasttimeslot = 0;
      # stash the model time in seconds
      $this->lasttimesec = $ts;
      //error_log("last time values is $ts ,i = $i and lasti = $lasti");
      $new_ta = array_slice($this->tsvalues, $lasti, count($this->tsvalues) - $lasti + 1, true);
      $this->tsvalues = $new_ta;
   }
   
   function getCurrentTSValues($searchtime = -99999, $starttime = -99999) {
      # returns an array of values that corresponds to the state array at the given time
      # alows the user to specify a start time, if not passed in (-99999)
      # assumes that the starting point is the current timer value
      # alows the user to specify a start time, if not passed in (-99999) default to min value of
      # tsvalues array
      if ($searchtime == -99999) {
         $thistime = $this->timer->thistime->format("U");
         $prevtime = $this->timer->thistime->format("U") - ($this->timer->dt/2.0);
         $nexttime = $this->timer->thistime->format("U") + ($this->timer->dt/2.0);
      } else {
         $intime = new DateTime($searchtime);
         $thistime = $intime->format("U");
         $prevtime = $intime->format("U") - ($this->timer->dt/2.0);
         $nexttime = $intime->format("U") + ($this->timer->dt/2.0);
      }
      $retarr = array();
      
      // pull values from the front of the stack until we are >= the desired time
         // stash values in a mini stack while pulling them off
         // refresh the current in memory TS stack if we have gotten to the end of it before the desired timestep
      // perform the desired matching, interpolation, aggregating or extrapolating depending on the 
      // data set 
      // return the values
   }

   function interpValue($thistime, $ts, $tv, $nts, $ntv) {

      if ($this->intflag == 2) {
         # places a limit on how long we can interpolate
         if ( abs($nts - $ts) > $this->ilimit ) {
            return NULL;
         }
      }
      switch ($this->intmethod) {
         case 0:
            // mean value
            $retval = $tv + ($ntv - $tv) * ( ($thistime - $ts) / ($nts - $ts) );
         break;

         case 1:
            // previous value
            $retval = $tv;
         break;

         case 2:
            // next value
            $retval = $ntv;
         break;

      }
      return $retval;
   }
}

class timeSeriesFile extends timeSeriesInput {
   // a static read-only file with time series values
   var $cache_ts = 1;

   function wake() {
      parent::wake();
      $fe = fopen($this->filepath,'r');
      if ($fe) {
         fclose($fe);
         $this->logDebug("Obtaining values from file: $this->filepath \n");
         $this->tsVarsFromFile();
      }
   }
   
   function init() {
      #$debug = 1;
      $this->cache_ts = 1;
      $fe = fopen($this->filepath,'r');
      if ($fe) {
         $this->tsfile = $this->filepath;
         fclose($fe);
      }
      parent::init();
   }

   function finish() {
      # disable this since we assume this is a read-only file
      $this->cache_ts = 0;
      parent::finish();
   }

   function tsVarsFromFile() {
      # get the header line with variable names and the first line of values.
      # 
      if ($this->debug) {
         $this->logDebug("calling readDelimitedFile($this->filepath,$this->delimiter, 0, 2); <br>");
      }
      $first2lines = readDelimitedFile($this->filepath,$this->translateDelim($this->delimiter), 0, 2);
      foreach ($first2lines[0] as $thiskey => $thisvar) {
         $this->state[$thisvar] = $first2lines[1][$thiskey];
         if ($this->debug) {
            $this->logDebug("Column $thisvar found.<br>\n");
         }
      }
   }


}

class pumpObject extends hydroObject {

   var $criteria; # reference to the quantity to compare against, i.e. 'Qout' or 'Storage'
   var $priority; # order of execution if multiple withdrawals, 0 is highest priority
   var $withdrawals = array(); # array of pairs 'criteria_value'=>'withdrawal_value'
   var $currentdemand = 0.0;
   
   function setDataColumnTypes() {
      parent::setDataColumnTypes();
      
      $statenums = array('Qin','Qout','currentdemand');
      foreach ($statenums as $thiscol) {
         $this->dbcolumntypes[$thiscol] = 'float8';
         $this->data_cols[] = $thiscol;
      }
      
   }

   function getDemand($statear = 0) {
      # allows the user to pass in a custom state array if desired
      if ($statear == 0) {
         $statear = $this->state;
      }
      $demand = 0.0;
      $criteria_name = $this->criteria;
      #$this->logDebug($statear);
      if ($this->debug) {
         $this->logDebug("Criteria found: $criteria_name <br>\n");
      }
      if (in_array($criteria_name, array_keys($statear))) {
         ksort($this->withdrawals);
         #$this->logDebug($this->withdrawals);
         foreach (array_keys($this->withdrawals) as $drawlevel) {
            $cval = $statear[$criteria_name];
            if ($this->debug) {
               $this->logDebug("Comparing $criteria_name ( $cval ) to $drawlevel <br>\n");
            }
            if ($cval >= $drawlevel) {
               $demand = $this->withdrawals["$drawlevel"];
            }
         }
      }
      $this->currentdemand = $demand;
      $this->state['Qin'] = $demand;
      $this->state['Qout'] = $demand;
      return $demand;
   }
}

class pumpPctObject extends pumpObject {
   var $default_pct = 0.1;

   # makes pumps based on a percentage of flow rather than an absolute flow value
   function init() {
      # calls the parent routine
      parent::init();
      # check the array of withdrawals to make sure that none are greater than 1.0
      foreach (array_keys($this->withdrawals) as $thisc) {
         if ($this->withdrawals[$thisc] > 1.0) {
            $this->withdrawals[$thisc] = $this->default_pct;
         }
      }
   }


   function getDemand($statear = 0) {
      # allows the user to pass in a custom state array if desired
      if ($statear == 0) {
         $statear = $this->state;
      }
      $demand = 0.0;
      $criteria_name = $this->criteria;
      #$this->logDebug($statear);
      if ($this->debug) {
         $this->logDebug("Criteria found: $criteria_name <br>\n");
      }
      if (in_array($criteria_name, array_keys($statear))) {
         ksort($this->withdrawals);
         #$this->logDebug($this->withdrawals);
         foreach (array_keys($this->withdrawals) as $drawlevel) {
            $cval = $statear[$criteria_name];
            if ($this->debug) {
               $this->logDebug("Comparing $criteria_name ( $cval ) to $drawlevel <br>\n");
            }
            if ($cval >= $drawlevel) {
               $demand = $this->withdrawals["$drawlevel"] * $cval;
            }
         }
      }
      $this->currentdemand = $demand;
      $this->state['Qin'] = $demand;
      $this->state['Qout'] = $demand;
      return $demand;
   }
}


class USGSSyntheticRecord extends modelObject {
   # power function representation of a stream gage, may have multiple relationships types eventually
   var $m = 1.0; /* m in ( y = bx^m) */
   var $b = 1.0; /* b in ( y = bx^m) */
   // Upper Confidence interval
   var $mup = ''; /* m in ( y = bx^m) */
   var $bup = ''; /* b in ( y = bx^m) */
   // Lower Confidence interval
   var $mlow = ''; /* m in ( y = bx^m) */
   var $blow = ''; /* b in ( y = bx^m) */
   var $Q = 0.0;
   var $Qgage = 0.0;
   var $equationtype = 0; // 0 - power bx^m, 1 - linear = mx + b

   function init() {
      parent::init();
      $this->dbcolumntypes['m'] = 'float8';
      $this->dbcolumntypes['b'] = 'float8';
      $this->dbcolumntypes['Q'] = 'float8';
      $this->dbcolumntypes['mup'] = 'float8';
      $this->dbcolumntypes['bup'] = 'float8';
      $this->dbcolumntypes['Qup'] = 'float8';
      $this->dbcolumntypes['mlow'] = 'float8';
      $this->dbcolumntypes['blow'] = 'float8';
      $this->dbcolumntypes['Qlow'] = 'float8';
      $this->dbcolumntypes['Qgage'] = 'float8';
   }
   
   function setDataColumnTypes() {
      parent::setDataColumnTypes();
      
      $statenums = array('m','b','Q','mup','bup','Qup','mlow','blow','Qlow','Qgage');
      foreach ($statenums as $thiscol) {
         $this->dbcolumntypes[$thiscol] = 'float8';
         $this->data_cols[] = $thiscol;
      }
      
   }

   function setState() {
      parent::setState();
      $this->state['b'] = $this->b;
      $this->state['m'] = $this->m;
      $this->state['Q'] = $this->Q;
      $this->state['bup'] = $this->bup;
      $this->state['mup'] = $this->mup;
      $this->state['Qup'] = $this->Qup;
      $this->state['blow'] = $this->blow;
      $this->state['mlow'] = $this->mlow;
      $this->state['Qlow'] = $this->Qlow;
      $this->state['Qgage'] = $this->Qgage;
   }
   
   function step() { 
      // all step methods MUST call preStep(),execProcessors(), postStep()
      $this->preStep();
      if ($this->debug) {
         $this->logDebug("$this->name Inputs obtained. thisdate = " . $this->state['thisdate']);
      }
      // execute sub-components
      $this->execProcessors();
      
      $Qgage = $this->state['Qgage'];
      
      # perform local functions
      $Q = $this->solveFlowEquation($Qgage, $this->b, $this->m);
      $this->state['Q'] = $Q;
      if ( ($this->mup <> '') and ($this->bup <> '') ) {
         //$Qup = $this->bup * pow($Qgage, $this->mup);
         $Qup = $this->solveFlowEquation($Qgage, $this->bup, $this->mup);
         $this->state['Qup'] = $Qup;
      } else {
         $this->state['Qup'] = $Q;
      }
      if ( ($this->mlow <> '') and ($this->blow <> '') ) {
         //$Qlow = $this->blow * pow($Qgage, $this->mlow);
         $Qup = $this->solveFlowEquation($Qgage, $this->blow, $this->mlow);
         $this->state['Qlow'] = $Qlow;
      } else {
         $this->state['Qlow'] = $Q;
      }
      # END - local functions

      if ($this->debug) {
         $this->logDebug("$this->name Calling Logstate() thisdate = ");
      }
      $this->postStep();
   }
   
   function solveFlowEquation($Qgage, $b, $m) {
      if ($this->debug) {
         $this->logDebug("Solving for Q = ");
      }
      switch ($this->equationtype) {
         case 0:
         $Q = $b * pow($Qgage, $m);
         if ($this->debug) {
            $this->logDebug("$b * pow($Qgage, $m) <br>");
         }
         break;
         
         case 1:
         $inter = $b + $m * log10($Qgage);
         $Q = pow(10.0, $inter);
         if ($this->debug) {
            $this->logDebug("$b + $m * log($Qgage); <br>");
            $this->logDebug("pow(10.0, $inter ); <br>");
         }
         break;
         
      }
      if ($this->debug) {
         $this->logDebug("Preliminary Q = $Q <br>");
      }
      if ($Q < 0) {
         $Q = 0.0;
         if ($this->debug) {
            $this->logDebug("can not have negative value - Q = 0.0 <br>");
         }
      }
      return $Q;
   }
}

class channelObject extends hydroObject {
   var $base = 1.0; /* base width of channel */
   var $Z = 1.0; /* side slope ratio */
   var $length = 5000.0;
   var $pdepth = 0.5; # mean pool depth below channel bottom
   var $substrateclass = 'C';  # A, B, C, D
   var $channeltype = 2; # only trapezoidal channels (type 2) are currently supported
   var $totalwithdrawn = 0.0;
   var $storageinitialized = 0; # is storage initialized at beginning of run? If 0, this will cause the storage estimation to run
                                # this should only occur once per simulation, as the flag wil be set to 1 after running
   var $tol = 0.01;
   # key is name, values are:
   #     priority (0 is highest priority),
   #     criteria - the name of the state variable that the criteria is based on
   #     withdrawals = array(criteriavalue, amount (volume per hour))

   function init() {
      parent::init();
   }
   
   function wake() {
      parent::wake();
      $this->prop_desc['Qin'] = 'Upstream, or tributary inflows to this stream (cfs).  This will be combined with any local Runoff flows.';
      $this->prop_desc['Rin'] = 'Local Runoff in-flows (cfs).';
      $this->prop_desc['Qafps'] = 'Area weighted local inflows (acre-ft / sec).  This will be combined with any pre-weighted or upstream flows.';
      $this->prop_desc['length'] = 'Channel mainstem length (ft).';
      $this->prop_desc['demand'] = 'Withdrawal of water from this reach (cfs).';
      $this->prop_desc['last_demand'] = 'Withdrawal of water from this reach during last time step (cfs).';
      $this->prop_desc['discharge'] = 'Discharge of water into this reach (MGD).';
      $this->prop_desc['last_discharge'] = 'Discharge of water into this reach during last timestep (MGD).';
   }


   function setState() {
      parent::setState();
      $this->state['base'] = $this->base;
      $this->state['Z'] = $this->Z;
      $this->state['length'] = $this->length;
      $this->state['substrateclass'] = $this->substrateclass;
      $this->state['Qout'] = 0.0;
      $this->state['Qin'] = 0.0;
      $this->state['Rin'] = 0.0;
      $this->state['depth'] = 0.0;
      $this->state['Vout'] = 0.0;
      $this->state['Storage'] = 0.0;
      $this->state['T'] = 0.0; // temperature
      $this->state['U'] = 0.0; // Heat (in BTU or Kcal) - expects Uin to be set (heat in)
      $this->state['Uout'] = 0.0; // Heat leaving (in BTU or Kcal)
      $this->state['demand'] = 0.0; // this replaces the object based withdrawals
      $this->state['last_demand'] = 0.0; // this replaces the object based withdrawals
      $this->state['discharge'] = 0.0; // point source flows into this watershed - these could be routed as Qin, but by 
      // putting them in as discharge, they are combined with Qin for the calculations, but recorded separately in the run data
      $this->state['last_discharge'] = 0.0; // point source flows into this channel during last timestep 
      $this->state['pdepth'] = $this->pdepth;
   }
   
   function setDataColumnTypes() {
      parent::setDataColumnTypes();
      
      $statenums = array('slope','base','Z','length','substrateclass', 'Qout', 'depth', 'Vout', 'Storage', 'T', 'U', 'Uout','demand', 'pdepth', 'Rin', 'discharge', 'last_discharge', 'last_demand', 'imp_off');
      foreach ($statenums as $thiscol) {
         $this->dbcolumntypes[$thiscol] = 'float8';
         $this->data_cols[] = $thiscol;
      }
      $this->dbcolumntypes['substrateclass'] = 'varchar(2)';
      
      // set log formats
      $this->logformats['runoff_in'] = '%s';
      
   }
   
   function step() {
      // all step methods MUST call preStep(),execProcessors(), postStep()
      $this->preStep();
      if ($this->debug) {
         $this->logDebug("$this->name Inputs obtained. thisdate = " . $this->state['thisdate']);
      }
      // execute sub-components
      // execute child components (since this is a model container)
      $this->execComponents();
      # now execute any operations
      $this->execProcessors();

      $this->state['year'] = $this->timer->thistime->format('Y');
      $this->state['month'] = $this->timer->thistime->format('n');
      $this->state['day'] = $this->timer->thistime->format('j');
      $this->state['weekday'] = $this->timer->thistime->format('N');
      $this->state['week'] = $this->timer->thistime->format('W');
      $this->state['hour'] = $this->timer->thistime->format('G');
      $this->state['thisdate'] = $this->timer->thistime->format('Y-m-d');
      if ($this->debug) {
         $this->logDebug("<b>$this->name step() method called at hour " . $this->state['hour'] . " on " . $this->state['thisdate'] . ".</b><br>\n");
      }
      
      $Uin = $this->state['Uin']; // heat in
      $U0 = $this->state['U']; // heat in BTU/Kcal at previous timestep
      $T = $this->state['T']; // Temp at previous timestep
      $area = $this->state['area'];
      $Qafps = $this->state['Qafps'];
      $Rin = $this->state['Rin'];
      $discharge = $this->state['discharge']; // get any point source discharges into this water body (MGD)
      $Qlocal = 0.0;
      if ( ($area > 0) and ($Qafps > 0)) {
         $Qlocal = $Qafps * $area * 640.0 * 43560.0;
      }
      if ( ($Rin > 0)) {
         $Qlocal += $Rin;
      }
      $I2 = $this->state['Qin'] + $Qlocal + $discharge * 1.547;
      if ($this->debug) {
         $this->logDebug("Final Inflows I2 : $I2 = " . $this->state['Qin'] . " + $Qlocal + $discharge <br>\n");
      }
      $I1 = $this->state['Iold'];
      $O1 = $this->state['Qout'];
      $S1 = $this->state['Storage'];
      $initialStorage = $this->state['Storage'];
      $depth = $this->state['depth'];

      if ($this->storageinitialized == 0) {
         # first time, need to estimate initial storage,
         # assuems that we are in steady state, that is,
         # the initial and final Q, and S are equivalent
         $I1 = $I2;
         $O1 = $I2;
         if ($this->debug) {
            $this->logDebug("Estimating initial storage, calling: storageroutingInitS($I2, $this->base, $this->Z, $this->channeltype, $this->length, $this->slope, $dt, $this->n, $this->units, 0)");
         }
         $S1 = storageroutingInitS($I2, $this->base, $this->Z, $this->channeltype, $this->length, $this->slope, $dt, $this->n, $this->units, 0);
         if ($this->debug) {
            $this->logDebug("Initial storage estimated as $S1 <br>\n");
         }
         $this->storageinitialized = 1;
      }

      # get time step from timer object
      $dt = $this->timer->dt;

      if($this->debug) {
         $dtime = $this->timer->thistime->format('r');
         $this->logDebug("Calculating flow at time $dtime <br>\n");
         $this->logDebug("Iold = $I1, Qin = $I2, Last Qout = $O1, base = $this->base, Z = $this->Z, type = 2, Storage = $S1, length = $this->length, slope = $this->slope, $dt, n = $this->n <br>\n");
         #die;
      }
      
      $this->state['depth'] = $depth;
      $this->state['Storage'] = $Storage;
      $demand = $this->state['demand'];
      $this->state['Qin'] = $I2;

      # now execute any operations
      #$this->execProcessors();
      # re-calculate the channel flow parameters, if any other operations have altered the flow:
      list($Vout, $Qout, $depth, $Storage) = storagerouting($I1, $I2, $O1, $demand, $this->base, $this->Z, $this->channeltype, $S1, $this->length, $this->slope, $dt, $this->n, $this->units, 0);
      if ( ($I1 > 0) and ($I2 > 0) and ($demand < $I1) and ($demand < $I2) and ($Qout == 0) ) {
         // numerical error, adjust
         $Qout = (($I1 + $I2) / 2.0) - $demand;
      }
      $this->state['Vout'] = $Vout;
      $this->state['Qout'] = $Qout;
      $this->state['depth'] = $depth;
      $this->state['Storage'] = $Storage;
      $this->state['last_demand'] = $demand;
      $this->state['last_discharge'] = $discharge;

      if($this->debug) {
         $this->logDebug("Qout = $Qout <br>\n");
      }
      
      // now calculate heat flux
      // O1 is outflow at last time step, 
      $U = ($Storage * ($U0 + $Uin)) / ( $Qout * $dt + $Storage);
      switch ($this->units) {
         case 1:
         // SI
         $T = $U / $Storage; // this is NOT right, don't know what units for storage would be in SI, since this is not really implemented
         break;
         
         case 2:
         // EE
         $T = 32.0 + ($U / ($Storage * 7.4805)) * (1.0 / 8.34); // Storage - cubic feet, 7.4805 gal/ft^3
         break;
      }
      // let's also assume that the water isn't frozen, so we limit this to zero
      if ($T < 0) {
         $T = 0;
      }
      $Uout = $U0 + $Uin - $U;
      $this->state['U'] = floatval($U);
      $this->state['Uout'] = floatval($Uout);
      $this->state['T'] = floatval($T);
         
      $this->postStep();
      $this->totalflow += floatval($Qout * $dt);
      $this->totalinflow += floatval($I2 * $dt);
      $this->totalwithdrawn += floatval($demand * $dt);
   }

   function getPublicProps() {
      # gets only properties that are visible (must be manually defined)
      $publix = parent::getPublicProps();

      array_push($publix, 'Vout');
      array_push($publix, 'depth');
      array_push($publix, 'length');
      array_push($publix, 'Z');
      array_push($publix, 'pdepth');
      array_push($publix, 'demand');

      return $publix;
   }
}

class USGSChannelGeomObject extends channelObject {
   # an object that employs the USGS physiographic province based methodology to estimate channel geometry
   # user must input channel length and drainage area
   var $province = 1; 
      # 1 - Appalachian Plateau
      # 2 - Valley and Ridge
      # 3 - Piedmont
      # 4 - Coastal Plain
   var $drainage_area = 100.0; # given in square miles - this is the entire drainage area above the outlet

   function setState() {
      parent::setState();
      $this->state['drainage_area'] = $this->drainage_area;
   }
   
   function wake() {
      
      # set channel geometries
      $this->setChannelGeom();
      
      # now call parent channel routing routine
      parent::wake();
      $this->prop_desc['drainage_area'] = 'The entire drainage area above the outlet. (sqmi)';
      $this->prop_desc['demand'] = 'Withdrawal of water from this reach (cfs).';
      $this->prop_desc['discharge'] = 'Discharge of water into this reach (MGD).';
   }
   
   function sleep() {
      
      # set channel geometries
      $this->setChannelGeom();
      
      # now call parent channel routing routine
      parent::sleep();
   }
   
   function init() {
      
      # set channel geometries
      $this->setChannelGeom();
      
      # now call parent channel routing routine
      parent::init();
   }

   function getPublicProps() {
      # gets only properties that are visible (must be manually defined)
      $publix = parent::getPublicProps();

      array_push($publix, 'drainage_area');

      return $publix;
   }
   
   function setChannelGeom() {
      
      switch ($this->province) {
         
         case 1:
            # Appalachian Plateau
            # bank full stage
            $hc = 2.030;
            $he = 0.2310;
            # bank full width
            $bfc = 12.175;
            $bfe = 0.4711;
            # base width
            $bc = 5.389;
            $be = 0.5349;
            $n = 0.036; # these are mannings N, using only the median numbers from USGS study,
                        # later we should incorporate the changing N as it is for high median and low flows
         break;
         case 2:
            # Valley and Ridge
            $hc = 1.435;
            $he = 0.2830;
            $bfc = 13.216;
            $bfe = 0.4532;
            $bc = 4.667;
            $be = 0.5489;
            $n = 0.038;
         break;
         case 3:
            # Piedmont
            $hc = 2.137;
            $he = 0.2561;
            $bfc = 14.135;
            $bfe = 0.4111;
            $bc = 6.393;
            $be = 0.4604;
            $n = 0.095;
         break;
         case 4:
            # Coastal Plain
            $hc = 2.820;
            $he = 0.2000;
            $bfc = 15.791;
            $bfe = 0.3758;
            $bc = 6.440;
            $be = 0.4442;
            $n = 0.040;
         break;
         
         default:
            $hc = 2.030;
            $he = 0.2000;
            $bfc = 12.175;
            $bfe = 0.4711;
            $bc = 5.389;
            $be = 0.5349;
            $n = 0.036;
         break;
      }
         
      $h = $hc * pow($this->drainage_area, $he);
      $bf = $bfc * pow($this->drainage_area, $bfe);
      $b = $bc * pow($this->drainage_area, $be);
      $z = 0.5 * ($bf - $b) / $h; 
         # since Z is increase slope of a single side, 
         # the top width increases (relative to the bottom) at a rate of (2 * Z * h)
      # only use these derived values if they are non-zero, otherwise, use defaults
      if ($z > 0) {
         $this->Z = $z;
      } else {
         $this->logError("Calculated Z value from (0.5 * ($bf - $b) / $h) less than zero, using default " . $this->Z . "<br>");
      }
      if ($b > 0) {
         $this->base = $b;
      } else {
         $this->logError("Calculated base value from ($bc * pow($this->drainage_area, $be)) less than zero, using default " . $this->base . "<br>");
      }
      $this->logError("Calculated base value from ($bc * pow($this->drainage_area, $be)), = $b / " . $this->base . " Province: $this->province <br>");
      $this->n = $n;

      return;

   }
}

class storageObject extends modelObject {
   # a generic object, needs a depth/storage table
   var $maxcapacity = 1000.0;
   var $unusable_storage = 100.0;
   var $max_usable = 100.0;
   var $depth = 10.0;
   var $fulldepth = 10.0;
   var $initstorage = 100.0;
   var $Qout = 0.0;
   var $Qin = 0.0;
   
   function wake() {
      parent::wake();
      $this->prop_desc['Qin'] = 'Inflows to this impoundment (cfs).';
      $this->prop_desc['Qout'] = 'Total outflows from this impoundment includes spillage and flow-bys (cfs).';
      $this->prop_desc['initstorage'] = 'Initial impoundment storage (acre-feet).';
      $this->prop_desc['maxcapacity'] = 'Maximum impoundment storage (acre-feet).';
      $this->prop_desc['unusable_storage'] = 'Unusable impoundment storage (acre-feet).';
   }

   function init() {
      parent::init();
      /*
      $inames = array_keys($this->inputs);
      // this should form the basis of an automated way of going through all of a model components 
      // internal properties, looking to see if there is an input for them, and setting the property to the value
      // of that input.  Or not???
      if (in_array('initstorage',$inames)) {
         if (isset($this->inputs['initstorage'][0])) {
            if (is_object($this->inputs['initstorage'][0]['object'])) {
               $this->initstorage = $this->inputs['initstorage'][0]['object']->value;
            }
         }
      } 
      
      if (in_array('unusable_storage',$inames)) {
         if (isset($this->inputs['unusable_storage'][0])) {
            if (is_object($this->inputs['unusable_storage'][0]['object'])) {
               $this->unusable_storage = $this->inputs['unusable_storage'][0]['object']->value;
            }
         }
      } 
      
      if (in_array('maxcapacity',$inames)) {
         if (isset($this->inputs['maxcapacity'][0])) {
            if (is_object($this->inputs['maxcapacity'][0]['object'])) {
               $this->maxcapacity = $this->inputs['maxcapacity'][0]['object']->value;
            }
         }
      }
      */
      
      $this->Storage = $this->initstorage;
      $this->state['Storage'] = $this->initstorage;
      $this->state['unusable_storage'] = $this->unusable_storage;
      $this->state['maxcapacity'] = $this->maxcapacity;      
      $this->state['max_usable'] = $this->maxcapacity - $this->unusable_storage;
      $this->state['fulldepth'] = $this->fulldepth;
      $this->state['Qin'] = $this->Qin;
      $this->state['Qout'] = $this->Qout;
   }

   function setState() {
      parent::setState();
      $this->state['maxcapacity'] = $this->maxcapacity;
      $this->state['initstorage'] = $this->initstorage;
      $this->state['unusable_storage'] = $this->unusable_storage;
      $this->state['max_usable'] = $this->maxcapacity - $this->unusable_storage;
      $this->state['fulldepth'] = $this->fulldepth;
      $this->state['Qin'] = $this->Qin;
      $this->state['Qout'] = $this->Qout;
   }
   
   function getPublicProps() {
      # gets only properties that are visible (must be manually defined)
      $publix = parent::getPublicProps();

      array_push($publix, 'Storage');
      array_push($publix, 'depth');
      array_push($publix, 'maxcapacity');
      array_push($publix, 'max_usable');
      array_push($publix, 'initstorage');
      array_push($publix, 'Qout');
      array_push($publix, 'Qin');
      array_push($publix, 'unusable_storage');

      return $publix;
   }
}

class hydroImpoundment extends hydroObject {
   # a generic object, needs a depth/storage/area table
   var $maxcapacity = 1000.0;
   var $unusable_storage = 100.0;
   var $max_usable = 100.0;
   var $depth = 10.0;
   var $fulldepth = 10.0;
   var $initstorage = 100.0;
   var $Qout = 0.0;
   var $Qin = 0.0;
   var $full_surface_area = 0.0;
   
   function wake() {
      parent::wake();
      $this->prop_desc['Qin'] = 'Inflows to this impoundment (cfs).';
      $this->prop_desc['Qout'] = 'Total outflows from this impoundment includes spillage and flow-bys (cfs).';
      $this->prop_desc['initstorage'] = 'Initial impoundment storage (acre-feet).';
      $this->prop_desc['maxcapacity'] = 'Maximum impoundment storage (acre-feet).';
      $this->prop_desc['demand'] = 'Rate of Water Withdrawal (MGD).';
      $this->prop_desc['unusable_storage'] = 'Unusable impoundment storage (acre-feet).';
      $this->prop_desc['flowby'] = 'Minimum flow to be maintained below the spillway (cfs).';
      $this->prop_desc['evap_acfts'] = 'Evaporation Rate (ac-ft/s).';
      $this->prop_desc['refill_full_mgd'] = 'Rate to refill in a single timestep (MGD).';
      $this->prop_desc['refill'] = 'Current rate of refill into storage (MGD).';
      $this->prop_desc['discharge'] = 'Discharge of water into this impoundment (MGD).';
      $this->prop_desc['lake_elev'] = 'Elevation (feet ASL) of water surface.';
      $this->prop_desc['pct_use_remain'] = 'Percent of Usable Storage Remaining.';
      $this->prop_desc['et_in'] = 'Evapotrasnpiration Input (inches / day)';
      $this->prop_desc['precip_in'] = 'Precipitation (inches / day)';
      $this->prop_desc['evap_mgd'] = 'Calculated rate of evaporation off the lakes surface (MGD).';
      $this->setSingleDataColumnType('lake_elev', 'float8');
      $this->setSingleDataColumnType('evap_mgd', 'float8');
      $this->setSingleDataColumnType('et_in', 'float8');
      $this->setSingleDataColumnType('precip_in', 'float8');
   }

   function init() {
      parent::init();
      $this->Storage = $this->initstorage;
      $this->state['Storage'] = $this->initstorage;
      $this->state['maxcapacity'] = $this->maxcapacity;
      $this->state['initstorage'] = $this->initstorage;
      $this->state['max_usable'] = $this->maxcapacity - $this->unusable_storage;
      $this->state['unusable_storage'] = $this->unusable_storage;
      $this->state['fulldepth'] = $this->fulldepth;
      $this->state['Qin'] = $this->Qin;
      $this->state['Qout'] = $this->Qout;
      $this->state['discharge'] = 0.0;
      $this->state['lake_elev'] = 1.0;
      $this->state['pct_use_remain'] = 0.0;
      $this->state['precip'] = 0.0;
      $this->state['pan_evap'] = 0.0;
      $this->state['precip_in'] = NULL;
      $this->state['et_in'] = NULL;
      $this->state['evap_mgd'] = 0.0;
      $this->processors['storage_stage_area']->valuetype = 2; // 2 column lookup (col & row)
   }

   function setState() {
      parent::setState();
      $this->state['maxcapacity'] = $this->maxcapacity;
      $this->state['initstorage'] = $this->initstorage;
      $this->state['unusable_storage'] = $this->unusable_storage;
      $this->state['max_usable'] = $this->maxcapacity - $this->unusable_storage;
      $this->state['fulldepth'] = $this->fulldepth;
      $this->state['Qin'] = $this->Qin;
      $this->state['Qout'] = $this->Qout;
      $this->state['pan_evap'] = 0.0;
      $this->state['precip'] = 0.0;
      $this->state['precip_in'] = NULL;
      $this->state['et_in'] = NULL;
      $this->state['demand'] = 0.0;
      $this->state['evap_acfts'] = 0.0;
      $this->state['refill_full_mgd'] = 0.0;
      $this->state['refill'] = 0.0;
      $this->state['discharge'] = 0.0;
      $this->state['lake_elev'] = 0.0;
      $this->state['pct_use_remain'] = 1.0;
      $this->state['evap_mgd'] = 0.0;
   }
   
   function create() {
      parent::create();
      // set up a table for impoundment geometry
      $this->logDebug("Create() function called <br>");
      
      if (isset($this->processors['storage_stage_area'])) {
         unset($this->processors['storage_stage_area']);
      }
      
      // matrix subcomponent to allow users to simulate stage/storage/area tables
      $storage_stage_area = new dataMatrix;
      $storage_stage_area->listobject = $this->listobject;
      $storage_stage_area->name = 'storage_stage_area';
      $storage_stage_area->wake();
      $storage_stage_area->numcols = 3;  
      $storage_stage_area->valuetype = 2; // 2 column lookup (col & row)
      $storage_stage_area->keycol1 = ''; // key for 1st lookup variable
      $storage_stage_area->lutype1 = 1; // lookp type - interpolate for storage
      $storage_stage_area->keycol2 = 'year'; // key for 2nd lookup variable
      $storage_stage_area->lutype2 = 0; // lookup type - exact match with column names for surface area
      // add a row for the header line
      $storage_stage_area->numrows = 3;
      // since these are stored as a single dimensioned array, regardless of their lookup type 
      // (for compatibility with single dimensional HTML form variables)
      // we set alternating values representing the 2 columns (luname - acreage)
      $storage_stage_area->matrix[] = 'storage';
      $storage_stage_area->matrix[] = 'lake_elev';
      $storage_stage_area->matrix[] = 'surface_area';
      $storage_stage_area->matrix[] = 0; // put a basic sample table - conic
      $storage_stage_area->matrix[] = 0; // put a basic sample table - conic
      $storage_stage_area->matrix[] = 0; // put a basic sample table - conic
      $storage_stage_area->matrix[] = $this->maxcapacity; // put a basic sample table - conic
      $storage_stage_area->matrix[] = $this->fulldepth; // put a basic sample table - conic
      $storage_stage_area->matrix[] = $this->full_surface_area; // put a basic sample table - conic
      
      if ($this->debug) {
         $this->logDebug("Trying to add stage-surfacearea-storage sub-component matrix with values: " . print_r($storage_stage_area->matrix,1) . " <br>");
      }
      $this->addOperator('storage_stage_area', $storage_stage_area, 0);
      if ($this->debug) {
         $this->logDebug("Processors on this object: " . print_r(array_keys($this->processors),1) . " <br>");
      }
   }
   
   function step() {
      // all step methods MUST call preStep(),execProcessors(), postStep()
      $this->preStep();
      if ($this->debug) {
         $this->logDebug("$this->name Inputs obtained. thisdate = " . $this->state['thisdate']);
      }
      // execute sub-components
      $this->execProcessors();
      
      if ($this->debug) {
         $this->logDebug("Step Begin state[] array contents " . print_r($this->state,1) . " <br>\n");
      }
      //$this->debug = 1;

      $Uin = $this->state['Uin']; // heat in
      $U0 = $this->state['U']; // total heat in BTU/Kcal at previous timestep
      $T = $this->state['T']; // Temp at previous timestep
      $Q0 = $this->state['Qout']; // outflow during previous timestep
      $S0 = $this->state['Storage']; // storage at end of previous timestep (ac-ft)
      $Qin = $this->state['Qin'];
      $demand = $this->state['demand']; // assumed to be in MGD
      $refill = $this->state['refill']; // assumed to be in MGD
      $discharge = $this->state['discharge']; // assumed to be in MGD
      if ( isset($this->state['flowby']) and (is_numeric($this->state['flowby'])) ) {
         $flowby = $this->state['flowby']; // assumed to be in cfs
      } else {
         $flowby = 0;
      }
      // maintain backward compatibility with old ET nomenclature
      if (!($this->state['et_in'] === NULL)) {
         $pan_evap = $this->state['et_in'];
      } else {
         $pan_evap = $this->state['pan_evap']; // assumed to be in inches/day
      }
      // maintain backward compatibility with old precip nomenclature
      if (!($this->state['precip_in'] === NULL)) {
         $precip = $this->state['precip_in']; // assumed to be in inches/day
      } else {
         $precip = $this->state['precip']; // assumed to be in inches/day
      }
      // this checks to see if the user has subclassed the area and stage(depth) calculations
      // or if it is using the internal routines with the stage/storage/area table
      if (isset($this->processors['area'])) {
         $area = $this->state['area']; // area at the beginning of the timestep - assumed to be acres
      } else {
         // calculate area - in an ideal world, this would be solved simultaneously with the storage
         if (isset($this->processors['storage_stage_area'])) {
            // must have the stage/storage/sarea dataMatrix for this to work
            $stage = $this->processors['storage_stage_area']->evaluateMatrix($S0,'stage');
            $area = $this->processors['storage_stage_area']->evaluateMatrix($S0,'surface_area');
         } else {
            $stage = 0;
            $area = 0;
         }
      }
      $dt = $this->timer->dt; // timestep in seconds
      if (isset($this->processors['maxcapacity'])) {
         $max_capacity = $this->state['maxcapacity']; // we have subclassed this witha stage-discharge relationship or oher
      } else {
         $max_capacity = $this->maxcapacity;
      }
      
      // we need to include some ability to plug-and-play the evap and other routines to allow users to sub-class it
      // or the components that go into it, such as the storage/depth/surface_area relationships
      // could look at processors, and if any of the properties are sub-classed, just take them as they are
      // also need inputs such as the pan_evap
      // since the processors have already been exec'ed we could just take them, but we could also get fancier
      // and look at each step in the process to see if it has been sub-classed and insert it in the proper place.
      
      // calculate evaporation during this time step - acre-feet per second
      // need estimate of surface area.  SA will vary based on area, but we assume that area is same as last timestep area
      //error_log(" $area * $pan_evap / 12.0 / 86400.0 <br>");
      $evap_acfts = $area * $pan_evap / 12.0 / 86400.0;
      $precip_acfts = $area * $precip / 12.0 / 86400.0; 
      if ($this->debug) {
         $this->logDebug("Calculating P and ET: P) $precip_acfts = $area * $precip / 12.0 / 86400.0;  <br>\n ET: $evap_acfts = $area * $pan_evap / 12.0 / 86400.0;<br>\n");
      }
      //error_log("ID $this->name : $S0 + (($Qin - $flowby) * $dt / 43560.0) + (1.547 * $discharge * $dt / 43560.0)  + (1.547 * $refill * $dt / 43560.0) - (1.547 * $demand * $dt /  43560.0) - ($evap_acfts * $dt) + ($precip_acfts * dt);");
      // change in storage
      $storechange = $S0 + (($Qin - $flowby) * $dt / 43560.0) + (1.547 * $discharge * $dt / 43560.0)  + (1.547 * $refill * $dt / 43560.0) - (1.547 * $demand * $dt /  43560.0) - ($evap_acfts * $dt) + ($precip_acfts * $dt);
      if ($this->debug) {
         $this->logDebug("Calculating Volume Change: $storechange = $S0 + (($Qin - $flowby) * $dt / 43560.0)+ (1.547 * $refill * $dt / 43560.0) - (1.547 * $demand * $dt /  43560.0) - ($evap_acfts * $dt) + ($precip_acfts * $dt); <br>\n");
      }
      if ($storechange < 0) {
         $storechange = 0;
      }
      $Storage = min(array($storechange, $max_capacity));
      if ($storechange > $max_capacity) {
         $spill = ($storechange - $max_capacity) * 43560.0 / $dt;
      } else {
         $spill = 0;
      }
      if ($Storage < 0.0) {
         $Storage = 0.0;
      }
      if (isset($this->processors['Qout'])) {
         $Qout = $this->state['Qout']; // we have subclassed this witha stage-discharge relationship or oher
      } else {
         $Qout = $spill + $flowby;
      }
      
      // local unit conversion dealios
      $this->state['evap_mgd'] = $evap_acfts * 28157.7;
      $this->state['pct_use_remain'] = ($Storage - $this->state['unusable_storage']) / ($this->state['maxcapacity'] - $this->state['unusable_storage']);

      $this->state['depth'] = $depth;
      $this->state['Storage'] = $Storage;
      $this->state['Vout'] = $Vout;
      $this->state['Qout'] = $Qout;
      $this->state['depth'] = $stage;
      $this->state['Storage'] = $Storage;
      $this->state['spill'] = $spill;
      $this->state['area'] = $area;
      $this->state['evap_acfts'] = $evap_acfts;
      $this->state['storage_mg'] = $Storage / 3.07;
      $this->state['lake_elev'] = $stage;
      $this->state['refill_full_mgd'] = (($max_capacity - $Storage) / 3.07) * (86400.0 / $dt);
      
      // now calculate heat flux
      // O1 is outflow at last time step, 
      if ( ( $Qout * $dt + $Storage) > 0) {
         $U = ($Storage * ($U0 + $Uin)) / ( $Qout * $dt + $Storage);
      } else {
         $U = 0.0;
      }
      switch ($this->units) {
         case 1:
         // SI
         $T = $U / $Storage; // this is NOT right, don't know what units for storage would be in SI, since this is not really implemented
         break;
         
         case 2:
         // EE
         $T = 32.0 + ($U / ($Storage * 7.4805)) * (1.0 / 8.34); // Storage - cubic feet, 7.4805 gal/ft^3
         break;
      }
      // let's also assume that the water isn't frozen, so we limit this to zero
      if ($T < 0) {
         $T = 0;
      }
      $Uout = $U0 + $Uin - $U;
      $this->state['U'] = $U;
      $this->state['Uout'] = $Uout;
      $this->state['T'] = $T;
         
      $this->postStep();
      $this->totalflow += $Qout * $dt;
      $this->totalinflow += (1.547 * $refill + $Qin) * $dt;
      $this->totalwithdrawn += $demand * $dt;
      
      if ($this->debug) {
         $this->logDebug("Step END state[] array contents " . print_r($this->state,1) . " <br>\n");
      }
   }

   function getPublicProps() {
      # gets only properties that are visible (must be manually defined)
      $publix = parent::getPublicProps();

      array_push($publix, 'Storage');
      array_push($publix, 'depth');
      array_push($publix, 'maxcapacity');
      array_push($publix, 'max_usable');
      array_push($publix, 'initstorage');
      array_push($publix, 'Qout');
      array_push($publix, 'Qin');
      array_push($publix, 'unusable_storage');
      array_push($publix, 'evap_acfts');
      array_push($publix, 'refill_full_mgd');
      array_push($publix, 'refill');
      array_push($publix, 'lake_elev');
      array_push($publix, 'pct_use_remain');
      array_push($publix, 'evap_mgd');

      return $publix;
   }
}

class blankShell extends modelObject {

   # has no internal functions defined, all operations must come from operators added into the component
   # within the model design

   function init() {
      parent::init();
   }

   function step() {
      parent::step();
   }

}

class surfaceObject extends hydroObject {
   var $base = 5000.0; /* base width of surface, idealized as rectangle */
   var $length = 500.0;
   var $precip = 0.0;
   var $irate = 0.0;
   var $Qvel = 0.0; # sheet flow velocity
   var $pct_clay = 15.0;
   var $pct_sand = 75.0;
   var $pct_om = 0.05;
   var $ksat = 0.0;
   var $wiltp = 0.0;
   var $thetasat = 0.0;
   var $Sav = 4.68; # average Suction at wetting front
   var $fc = 0.0;
   var $totalflow = 0.0;
   var $F = 0.0; # total water infiltrated into soil column in inches
   var $sdepth = 50.0; # soil depth inches
   var $atmosdep = array();

   function init() {
      parent::init();
      $this->state['P'] = 0.0;
      $this->state['F'] = 0.0;
      $this->state['I'] = 0.0;
      $this->initSurfaceParams();
   }

   function initSurfaceParams() {

      $ksat_cm = soilhydroksat($this->pct_sand, $this->pct_clay);
      $this->ksat = $ksat_cm / 2.54;
      # other params are in length/length, so they are non-dimensional
      $this->thetasat = soilhydrothetasat($this->pct_sand, $this->pct_clay);
      $this->fc = soilhydrothetafc($this->pct_sand, $this->pct_clay);
      $this->wiltp = soilhydrowiltp($this->pct_sand, $this->pct_clay);
      $this->area = $this->length * $this->base;

      $Smax = (log(1500.0)-log(33.0))/(log($this->fc) - log($this->wiltp));
      $Smin = exp(log(33.0)+($Smax*log($this->fc)));
      $this->Sav = (($Smax + $Smin)/2.0);
      if ($this->debug) {
         $this->logDebug("Soil Properties: ThetaSat = $this->thetasat, FC = $this->fc, Ksat = $this->ksat, Sav = $this->Sav <br>\n");
      }
   }

   function addAtmos($thisinput) {
      array_push($this->atmosdep, $thisinput);
   }

   function preStep() {
      # Iold is used by storage routing routines
      $this->precip = 0;
      $this->state['P'] = 0;

      foreach ($this->inputs['Pin'] as $thisin) {
         $outparam = $thisin['param'];
         $inobject = $thisin['object'];
         $this->precip += $inobject->Qout;
         $this->state['P'] += $inobject->state['Qout'];
      }
      parent::preStep();
   }

   function step() {
      // all step methods MUST call preStep(),execProcessors(), postStep()
      $this->preStep();
      if ($this->debug) {
         $this->logDebug("$this->name Inputs obtained. thisdate = " . $this->state['thisdate']);
      }
      // execute sub-components
      $this->execProcessors();

      $Qin = $this->state['Qin'];
      $Qout = $this->state['Qout'];
      $F = $this->state['F'];
      $depth = $this->state['depth'];
      $P = $this->state['P'];
      $I = $this->state['I'];

      # get time step from timer object
      $dt = $this->timer->dt;

      if($this->debug) {
         $dtime = $this->timer->thistime->format('r');
         $this->logDebug("Calculating runoff at time $dtime <br>\n");
         #die;
      }

      # step iteration next
      $I = green_ampt( $P, $dt, $this->fc, $this->thetasat, $this->ksat, $depth, $F, $I, $this->Sav, 0.00001, $this->debug);

      $F += ($I * $dt / 3600.0);

      #$this->depth += ($this->precip - $this->irate) * $dt / 3600.0;

      list($Vout, $depth) = kinwave($depth, $Qin, $Qout, $P, $I, $this->slope, $this->length, $this->base, $dt, $this->n, $this->units, $this->debug);

      $Qout = $Vout * $this->base * $depth / 12.0;

      if ($depth < 0) {
         $depth = 0.0;
      }

      if ($this->debug) {
         $this->logDebug(" D: $depth, Qin: $Qin, Qvel = $Vout, Qout: $Qout, P: $P, I: $I, F: $F <br>\n");
      }

      $this->state['F'] = $F;
      $this->state['depth'] = $depth;
      $this->state['P'] = $P;
      $this->state['I'] = $I;
      $this->state['Vout'] = $Vout;
      $this->state['Qout'] = $Qout;
      $this->state['Qin'] = $Qin;

      $this->postStep();

      $this->totalflow += $Qout * $dt;
      $this->totalp += $P * $dt / 3600.0;

   }
}

class HabitatSuitabilityObject extends modelContainer {
   var $state = array();
   # requires the library lib_equation2.php, which has the class "Equation"
   var $equations = array(); # keyed by statevarname=>equationtext
}

class HabitatSuitabilityObject_NWRC extends HabitatSuitabilityObject {
   // this class contains default values for all parameters used in the set of 
   // NWRC habitat suitability models available from: http://www.nwrc.usgs.gov/wdb/pub/hsi/hsiintro.htm
   // child objects added below this can expect broadcast data pertaining to all of these metrics
   // by over-riding these defaults with inputs from other model components, one can customize the 
   // HSI output to reflect local modeled conditions
   var $hsi_vars = array();
   var $units = 2; // base units 1 - SI, 2 - EE 
   // *******************************
   // ** Water Physical Properties **
   // *******************************
   var $V = 0.0; // velocity ft/sec / m/sec
   var $depth = 0.0; // flow depth ft / m
   // ******************************
   // ** Water Quality Parameters **
   // ******************************
   var $pH = 6.5;
   var $T = 40.0; // Mean Water Temp degrees F / C
   var $dT_bot = 1.0; // ratio of bottom temp to mean temp
   var $dT_sur = 1.0; // ratio of surface temp to mean temp
   var $DO = 5.0; // disolved oxygen mg/L / ppm
   var $salinity = 0; // salinity ppt
   var $tds = 0; // Total Disolved Solids (ppm)
   var $tur = 0; // Turbidity (JTU)
   // *******************************
   // ** Bottom/Substrate Props    **
   // *******************************
   var $substrateclass = 'C';  # A, B, C, D - dominant class of substrate (may be changed by deposition, etc.)
   // A - Silt and Sand ( < 0.2 cm) and/or rooted vegetation
   // B - Pebble (0.2-1.5 cm)
   // C - Gravel, broken rock (1.6-2.0 cm) and boulder/cobble with adequate interstitial space
   // D - Cobble
   // E - Boulder and Bedrock
   var $sub_silt_pct = 0.2; // substrate silt percent
   var $sub_sand_pct = 0.5; // substrate sand percent
   var $sub_pebble_pct = 0.1; // substrate pebble percent
   var $sub_cobble_pct = 0.1; // substrate cobble percent
   var $sub_rock_pct = 0.1; // substrate large rock percent
   // *******************************
   // **   Channel/Segment Props   **
   // *******************************
   // general channel segment properties
   var $slope = 0.01; // slope percent
   var $width = 10.0; // channel base width ft / m
   var $length = 1000.0; // channel section length ft / m
   // channel segment pool, riffle and run properties
   // these properties will be used to calculate variations in temperature and velocity in the 
   // various pool/riffle/run micro-habitats
   // pool properties
   var $pool_pct = 0.1;
   var $pool_depth = 0.5; // depth of pools ft / m - relative to the channel mean
   var $pool_substrate = 'B'; // substrate in pools
   var $pool_class = 'B'; 
   // A - large,deep "deadwater" pools (stream mouths), 
   // B - Moderate below falls or riffle-run areas; 5-30% of bottom obscured by turbulence
   // C - Small or shallow or both, no surface turbulence and little structure
   // riffle properties
   var $riffle_pct = 0.3;
   var $riffle_depth = -0.2; // depth of riffles - relative to the channel mean
   var $riffle_substrate = 'C'; // substrate in riffles
   // run properties
   var $run_pct = 0.5;
   var $run_depth = 0.0; // depth of runs - relative to the channel mean
   var $run_substrate = 'D'; // substrate in runs
   // shallow margin properties (or littoral zone)
   var $margin_pct = 0.1;
   var $margin_depth = 0.0; // depth of runs - relative to the channel mean
   var $margin_substrate = 'A'; // substrate in runs
   // *******************************
   // **    Cover Properties       **
   // *******************************
   var $cover_pct_lg = 0.1; // percent cover from large objects, such as boulders, stumps, crevices
   var $cover_pct_sv = 0.1; // percent cover from vegetation
   var $wetland_pct = 0.0;
   var $shade_pct = 0.5; // percent of stream area shaded
   // *******************************
   // **      Food Availability    **
   // *******************************
   var $zoopl_count = 0; // mean zooplankton count per gal / liter of water
   
   function wake() {
      parent::wake();
      $this->set_HSIvars();
   }
   
   function set_HSIvars() {
      // add the broadcast LISTENER object needed by the NWRC individual species models
      $this->hsi_vars = array('Qin','V','depth','pH','T','dT_bot','dT_sur','DO','salinity','tds','tur','substrateclass','sub_silt_pct','sub_sand_pct','sub_pebble_pct','sub_cobble_pct','sub_rock_pct','slope','width','length','pool_pct','pool_depth','pool_substrate','pool_class','riffle_pct','riffle_depth','riffle_substrate','run_pct','run_depth','run_substrate','margin_pct','margin_depth','margin_substrate','cover_pct_lg','cover_pct_sv','wetland_pct','shade_pct', 'zoopl_count');
   }
   
   function setPropDesc() {
      parent::setPropDesc();
      $this->prop_desc['Qin'] = 'Upstream, or tributary inflows to this stream (cfs).  This will be combined with any local Runoff flows.';
      $this->prop_desc['V'] = 'velocity ft/sec / m/sec';
      $this->prop_desc['depth'] = 'flow depth ft / m';
      $this->prop_desc['pH'] = 'pH';
      $this->prop_desc['T'] = 'Mean Water Temp degrees F / C';
      $this->prop_desc['dT_bot'] = 'ratio of bottom temp to mean temp';
      $this->prop_desc['dT_sur'] = 'ratio of surface temp to mean temp';
      $this->prop_desc['DO = 5.0'] = 'disolved oxygen mg/L / ppm';
      $this->prop_desc['salinity'] = 'salinity ppt';
      $this->prop_desc['tds'] = 'Total Disolved Solids (ppm)';
      $this->prop_desc['tur'] = 'Turbidity (JTU)';
      $this->prop_desc['substrateclass'] = "Dominant class of substrate (may be changed by deposition, etc.)\n A - Silt and Sand ( < 0.2 cm) and/or rooted vegetation\n B - Pebble (0.2-1.5 cm)\n C - Gravel, broken rock (1.6-2.0 cm) and boulder/cobble with adequate interstitial space\n D - Cobble\n E - Boulder and Bedrock";
      $this->prop_desc['sub_silt_pct'] = 'substrate silt percent';
      $this->prop_desc['sub_sand_pct'] = 'substrate sand percent';
      $this->prop_desc['sub_pebble_pct'] = 'substrate pebble percent';
      $this->prop_desc['sub_cobble_pct'] = 'substrate cobble percent';
      $this->prop_desc['sub_rock_pct'] = 'substrate large rock percent';
      $this->prop_desc['slope'] = 'slope percent';
      $this->prop_desc['width'] = 'channel base width ft / m';
      $this->prop_desc['length'] = 'channel section length ft / m';
      $this->prop_desc['pool_pct'] = '';
      $this->prop_desc['pool_depth'] = 'depth of pools ft / m - relative to the channel mean';
      $this->prop_desc['pool_substrate'] = 'substrate in pools';
      $this->prop_desc['pool_class'] = '';
      $this->prop_desc['riffle_pct'] = '';
      $this->prop_desc['riffle_depth'] = 'depth of riffles - relative to the channel mean';
      $this->prop_desc['riffle_substrate'] = 'substrate in riffles';
      $this->prop_desc['run_pct'] = '';
      $this->prop_desc['run_depth'] = 'depth of runs - relative to the channel mean';
      $this->prop_desc['run_substrate'] = 'substrate in runs';
      $this->prop_desc['margin_pct'] = '';
      $this->prop_desc['margin_depth'] = 'depth of runs - relative to the channel mean';
      $this->prop_desc['margin_substrate'] = 'substrate in runs';
      $this->prop_desc['cover_pct_lg'] = 'percent cover from large objects, such as boulders, stumps, crevices';
      $this->prop_desc['cover_pct_sv'] = 'percent cover from vegetation';
      $this->prop_desc['wetland_pct'] = '';
      $this->prop_desc['shade_pct'] = 'percent of stream area shaded';
      $this->prop_desc['zoopl_count'] = 'mean zooplankton count per gal / liter of water';
   }
   
   function create() {
      parent::create();
      $this->set_HSIvars();
      // add the broadcast CASTING object needed by the NWRC individual species models
      $hsi_bc = new broadCastObject;
      $hsi_bc->name = 'Broadcast HSI Parameters';
      $hsi_bc->wake();
      $hsi_bc->local_varname = $this->hsi_vars;
      $hsi_bc->broadcast_varname = $this->hsi_vars;
      $hsi_bc->broadcast_hub = 'child';
      $hsi_bc->broadcast_mode = 'cast';
      if ($this->debug) {
         $this->logDebug("Trying to add broadcast sub-component with values: " . print_r($hsi_bc->local_varname,1) . " <br>");
      }
      $this->addOperator('Broadcast HSI Parameters', $hsi_bc, 0);
      
   }
   
}

class HSI_NWRC_species extends modelObject {
   // these are stand-alone objects, but are best when added as the child of a HabitatSuitabilityObject_NWRC
   // since it has the expected broadcast parameters that are needed by the models from NWRC
   var $hsi_vars = array();
   
   function wake() {
      parent::wake();
      
      $this->set_HSIvars();
   }
   
   function set_HSIvars() {
      $this->hsi_vars = array('Qin','V','depth','pH','T','dT_bot','dT_sur','DO','salinity','tds','tur','substrateclass','sub_silt_pct','sub_sand_pct','sub_pebble_pct','sub_cobble_pct','sub_rock_pct','slope','width','length','pool_pct','pool_depth','pool_substrate','pool_class','riffle_pct','riffle_depth','riffle_substrate','run_pct','run_depth','run_substrate','margin_pct','margin_depth','margin_substrate','cover_pct_lg','cover_pct_sv','wetland_pct','shade_pct', 'zoopl_count');
   }
   
   function create() {
      parent::create();
      $this->set_HSIvars();
      // add the broadcast LISTENER object needed by the NWRC individual species models
      $hsi_bc = new broadCastObject;
      $hsi_bc->name = 'Listen HSI Parameters';
      $hsi_bc->wake();
      $hsi_bc->local_varname = $this->hsi_vars;
      $hsi_bc->broadcast_varname = $this->hsi_vars;
      $hsi_bc->broadcast_hub = 'parent';
      $hsi_bc->broadcast_mode = 'read';
      if ($this->debug) {
         $this->logDebug("Trying to add Listener sub-component with values: " . print_r($hsi_bc->local_varname,1) . " <br>");
      }
      $this->addOperator('Listen HSI Parameters', $hsi_bc, 0);
      
   }
}

class HSI_NWRC_american_shad extends HSI_NWRC_species {
   
   function create() {
      parent::create();
      // add all of the widgets for this, including the base curves in the HSI doc
      
      
      //$this->addOperator('Listen HSI Parameters', $hsi_bc, 0);
      // V1 - mean surface water temp during spawning
      // V2 - mean water velocity during spawning
      // V3 - mean surface water temp during egg larval development
      // V4 - mean near-bottom water temp during winter and spring
      // V5 - percentage of areas supporting emergent and/or submerged vegetation
   }
   
   function step() {
      parent::step();
      // perform timestep relevant calculations
      
   }
   
   function computeHSI() {
      // compute the actual value of the HSI for this, it may only occur at certain times,
      // based on the restrictions for evaluation of each individual factor
      // or it might be computed every step, but with certain factors only being updated
      // when the simulation is at the appropriate time to evaluate
      
   }
      
}


class PopulationGenerationObject extends modelContainer {
   # specifically for use with "age-class" type of entities, clones itself whjen reproducing, and sets properties on child obejct
   # also tracks all children, keeping a cumulative population of all descendants

   var $parent_object = -1;
   var $log2parent = 1; # sends logging info back to parent

   var $base_name = ''; # base of name for object children

   var $age_resolution = 'year'; # year, month, day, hour, minute, second
   var $birth_date = ''; # date of birth in age resolution (year = YYYY-01-01 00:00:00, month = YYYY-MM-01-01 00:00:00, day = YYYY-MM-DD 00:00:00, etc.)
   var $birth_class = '' ; # contains the short_format date variable
   var $birth_seconds = ''; # DOB in seconds since the Epoch
   var $age = 0.0;
   var $population = 0.0; # population of this generation (set as initial population in model interface)
   var $child_pop = 0.0; # population of descendant generations
   var $total_pop = 0.0; # population of this generation and all descendants (population + child_pop)

   # mortality
   var $death_rate = 1.0; # rate is calculated every 1.0 age resolution units
   var $max_age = -1; # units of age resolution, -1 means no explicit max age
   var $mortality_pop = 0.0; # starts with zero
   var $alive = 1;

   # reproduction
   var $birth_rate = 1.0; # if population only reproduces during certain times of the year, can sub-class
                          # this with a lookup table that is only active at the spawning times
   var $birth_pop = 0.0; # starts with zero
   var $birth_frequency = 1; # units of age resolution
   var $min_birth_age = -1; # units of age resolution, -1 means no lower reproduction restriction
   var $max_birth_age = -1; # units of age resolution, -1 means no upper reproduction restriction

   # record of birth classes
   var $birthclasses = array();

   function init() {

      parent::init();

      # explicitly set up column types for my properties
      $this->dbcolumntypes['child_pop'] = 'float8';
      $this->dbcolumntypes['total_pop'] = 'float8';
      $this->dbcolumntypes['birth_rate'] = 'float8';
      $this->dbcolumntypes['mortality_pop'] = 'float8';
      $this->dbcolumntypes['max_age'] = 'float8';
      $this->dbcolumntypes['death_rate'] = 'float8';
      $this->dbcolumntypes['population'] = 'float8';
      $this->dbcolumntypes['age'] = 'float8';
      $this->dbcolumntypes['birth_seconds'] = 'bigint';
      $this->dbcolumntypes['birth_date'] = 'timestamp';
      $this->dbcolumntypes['birth_frequency'] = 'float8';
      $this->dbcolumntypes['refract_interval'] = 'float8';

      if (strlen($this->base_name) == 0) {
         $this->base_name = $this->name;
      }

      $this->birthclasses = array();

      switch($this->age_resolution) {
         case 'year':
            $this->age_interval = 365.25 * 24.0 * 60.0 * 60.0;
            $this->birth_format = 'Y-01-01 00:00:00';
            $this->short_format = 'Y';
         break;

         case 'month':
            $this->age_interval = 30.4375 * 24.0 * 60.0 * 60.0;
            $this->birth_format = 'Y-m-01 00:00:00';
            $this->short_format = 'm';
         break;

         case 'day':
            $this->age_interval = 24.0 * 60.0 * 60.0;
            $this->birth_format = 'Y-m-d 00:00:00';
            $this->short_format = 'd';
         break;

         case 'hour':
            $this->age_interval = 60.0 * 60.0;
            $this->birth_format = 'Y-m-d H:i:00';
            $this->short_format = 'H';
         break;

         case 'second':
            $this->age_interval = 60.0;
            $this->birth_format = 'Y-m-d H:i:s';
            $this->short_format = 'i';
         break;

         default:
            $this->age_interval = 365.25 * 24.0 * 60.0 * 60.0;
            $this->birth_format = 'Y-m-d H:i:s';
            $this->short_format = 's';
         break;

      }
   }

   function finish() {

      # iterate through each stored component, and delete any child population objects
      #error_log("Finishing object " . $this->name);
      $this->compexeclist = array();
      foreach ($this->components as $thiscomp) {
         # evaluate the equation
         if ($this->debug) {
            $this->logDebug("Checking for child process:" . $thiscomp->name . "<br>\n");
         }
         # set all required inputs for the equation
         if ( !(get_class($thiscomp) == get_class($this)) ) {
            array_push($this->compexeclist, $thiscomp->componentid);
         }

      }
      #error_log("Including components for Finishing: " . print_r($this->compexeclist,1));
      parent::finish();

   }




   function execComponents() {

      if ($this->debug) {
         $this->logDebug("Culling dead components from $this->name.<br>\n");
         #error_log("Going through components for $this->name.");
      }

      # iterate through each equation stored in this object
      $live_list = array();

      foreach ($this->compexeclist as $thiscomp) {
         # evaluate the equation
         if ($this->debug) {
            $this->logDebug("Checking $thiscomp<br>\n");
            #error_log("Executing $thiscomp .");
         }
         # set all required inputs for the equation
         if ($this->components[$thiscomp]->alive) {
            array_push($live_list, $thiscomp);
            if ($this->debug) {
               $this->logDebug("Keeping $thiscomp \n<br>");
            }
         } else {
            unset($this->components[$thiscomp]);
            if ($this->debug) {
               $this->logDebug("Destroying $thiscomp \n<br>");
            }
         }
      }
      $this->compexeclist = $live_list;

      # now, we are cleaned up, so go ahead and execute children
      parent::execComponents();
   }

   function setState() {
      parent::setState();

      $this->state['name'] = $this->name;
      $this->state['population'] = $this->population;
      $this->state['child_pop'] = $this->child_pop;
      $this->state['birth_pop'] = $this->birth_pop;
      $this->state['birth_rate'] = $this->birth_rate;
      $this->state['death_rate'] = $this->death_rate;
      $this->state['birth_date'] = $this->birth_date;
      $this->state['mortality_pop'] = $this->mortality_pop;
      $this->state['age'] = $this->age;
      $this->state['total_pop'] = $this->population;
      $this->state['birth_frequency'] = $this->birth_frequency;
      $this->state['refract_interval'] = 0.0;

   }

   function setBirthDate() {
      # set my birth date to NOW!!
      $this->birth_date = $this->timer->thistime->format($this->birth_format);
      $this->last_birth = $this->timer->timeseconds;
      $this->birth_seconds = $this->timer->timeseconds;
      $this->birth_class = $this->timer->thistime->format($this->short_format);
      $this->state['birth_date'] = $this->birth_date;

      if ($this->debug) {
         $this->logDebug("Birth Date Set to: " . $this->birth_date . "\n<br>");
         #error_log("Birth Date Set to: " . $this->birth_date);
      }
   }

   function setParent($parent_object) {
      $this->parent_object = $parent_object;
   }

   function addCloneComponent($clone_id) {
      $this->addComponent(clone $this, $clone_id);
   }

   function getValue($thistime, $thisvar) {
      # currrently, does nothing with the time, assumes that the input time is
      # equal to the current modeled time and returns the current value
      if ($this->debug) {
         $sv = $this->state;
         if (isset($sv['the_geom'])) {
            $sv['the_geom'] = 'HIDDEN';
         }
         $this->logDebug("Variable $thisvar requested from $this->name at step #" . $this->timer->steps . ", returning " . $this->state[$thisvar] . " from " . print_r($sv,1) );
      }
      return $this->state[$thisvar];
   }

   function step() {
      // all step methods MUST call preStep(),execProcessors(), postStep()
      $this->preStep();
      if ($this->debug) {
         $this->logDebug("$this->name Inputs obtained. thisdate = " . $this->state['thisdate']);
      }
      if (strlen($this->birth_date) == 0) {
         $this->setBirthDate();
      }
      # execute children
      $this->execComponents();
      # calculate age
      # subtract current date from birth_date, then convert into units of this objects age_resolution
      $time_seconds = $this->timer->timeseconds;
      $age_seconds = $time_seconds - $this->birth_seconds;
      $refract_seconds = $time_seconds - $this->last_birth;
      $age = $age_seconds / $this->age_interval;
      $refract_interval = $refract_seconds / $this->age_interval;
      # now execute any operations on this object
      $this->execProcessors();

      # get variables from state container, in case any are altered by internal processors
      $birth_rate = $this->state['birth_rate'];
      $death_rate = $this->state['death_rate'];
      $population = $this->state['population'];
      $mortality_pop = $this->state['mortality_pop'];
      $child_pop = $this->state['child_pop'];

      $birth_pop = 0; # assume no birthing, check later for birth_pop set in state by internal processor which overrides the standard method

      # handle death/die-off
      # first zero out population if it has exceeded max age (if set)
      if ( ($this->max_age > 0) and ($age > $this->max_age) ) {
         $this->population = 0;
         $population = 0;
         $this->alive = 0;
         if ($this->debug) {
            $this->logDebug("Max Age of " . $this->max_age . " exceeded by " . $this->name . " ( age = " . $age . " )\n<br>");
            $this->logDebug("Calculated from age in seconds " . $age_seconds . " divided by age interval " . $this->age_interval . " at time " . $time_seconds . " ( birth seconds = " . $this->birth_seconds . " )\n<br>");
            #error_log("Max Age of " . $this->max_age . " exceeded by " . $this->name . " ( age = " . $age . " )\n<br>");
            #error_log("Calculated from age in seconds " . $age_seconds . " divided by age interval " . $this->age_interval . " at time " . $time_seconds . " ( birth seconds = " . $this->birth_seconds . " )\n<br>");
         }
      }

      if ($population <= 0) {
         $this->alive = 0;
      }

      $procvars = array_keys($this->processors);
      # death is handled on a continual basis, so we divide the timestep by the age_interval to scale the death rate
      if (!in_array('mortality_pop', $procvars)) {
         # use embedded mortality calculation
         $mortality_pop = ($this->timer->dt / $this->age_interval) * ($death_rate) * $population;
      }

      # handle birth
      # done differently than death, assumed that their is a refractory period after reproduction, this is so that
      # we are not continually spawning young. Could handle this differently, by storing a link to a child population,
      # referenced by year-class (or whatever the age_interval is ), and then adding new births into that population
      if ( ($birth_rate > 0) and ($this->alive) ) {
         # check for minimum/maximum birth ages
         $old_enough = 0;
         $young_enough = 0;
         $rested_enough = 0;

         if ($this->min_birth_age <= $age) {
            $old_enough = 1;
         }
         if ( ($this->max_birth_age >= $age) or ($this->max_birth_age == -1) ) {
            $young_enough = 1;
         }
         # check for reproductive refractory period
         if ( $refract_interval >= $this->birth_frequency ) {
            $rested_enough = 1;
         }

         $can_reproduce = $old_enough * $young_enough * $rested_enough;

         if ($can_reproduce) {
            # use embedded birth calculation
            $birth_pop = $birth_rate * $population;
         }
      }

      # check if birth_pop is superceded by an external calculation
      if ( in_array('birth_pop', $procvars ) ) {
         $birth_pop = $this->state['birth_pop'];
      }

      if ($this->debug) {
         $this->logDebug("Birth Pop Calculated on $this->name, pop = " . $birth_pop . ", alive? " . $this->alive . " at " . $this->timer->timestamp . "\n<br>");
         #error_log("Birth Pop Calculated on $this->name, pop = " . $birth_pop . ", alive? " . $this->alive . " at " . $this->timer->timestamp . "\n<br>");
      }

      if ( ($birth_pop > 0) and ($this->alive) ) {
         $this->addBirthClass($birth_pop);
      }



      $population = $population - $mortality_pop;
      # do not include birth pop here, because this is figured elsewhere
      if ($population < 0) {
         $population = 0;
      }

      # now, set state variables
      $this->state['birth_rate'] = $birth_rate;
      $this->state['death_rate'] = $death_rate;
      $this->state['population'] = $population;
      $this->state['mortality_pop'] = $mortality_pop;
      $this->state['birth_pop'] = $birth_pop;
      $this->state['age'] = $age;
      $this->state['refract_interval'] = $refract_interval;
      if ($this->debug) {
         $this->logDebug("Calculating total population from child population, " . $child_pop . " and parent pop, " . $population . "\n<br>");
      }
      $total_pop = $population + $child_pop;
      $this->state['total_pop'] = $total_pop;

      #error_log("Total pop on $this->name at step #" . $this->timer->steps . " = " . $this->state['total_pop'] . "<br>");

      # log my values - use the pass up method so that any
      $this->state['thisdate'] = $this->timer->thistime->format('Y-m-d');
      $this->state['time'] = $this->timer->thistime->format('r');
      $this->state['year'] = $this->timer->thistime->format('Y');
      $this->state['month'] = $this->timer->thistime->format('m');
      $this->state['day'] = $this->timer->thistime->format('d');
      if (is_object($this->parent_object)) {
         $this->parent_object->postStep($this->state);
      } else {
         $this->postStep();
      }

   }

   function addBirthClass($birth_pop) {
      if ($this->debug) {
         $this->logDebug("$this->name requests adding $birth_pop \n<br>");
         #error_log("$this->name requests adding $birth_pop \n<br>");
      }
      $birthdate = $this->timer->thistime->format($this->birth_format);
      if (is_object($this->parent_object)) {
         $new_child = $this->parent_object->getBirthClass($birthdate);
      } else {
         $new_child = $this->getBirthClass($birthdate);
      }
      #$new_child = clone($this);
      if ($this->debug) {
         $this->logDebug("Adding $birth_pop to Birth Class $birthdate, " . $new_child->state['population'] . " + " .  + $birth_pop . "\n<br>");
         #error_log("Adding $birth_pop to Birth Class $birthdate, " . $new_child->state['population'] . " + " .  + $birth_pop . "\n<br>");
      }
      $new_child->setStateVar('population', $new_child->state['population'] + $birth_pop);
      $new_child->setStateVar('total_pop', $new_child->state['total_pop'] + $birth_pop);
      if ($this->debug) {
         $this->logDebug($new_child->name . " Updated, population = " . $new_child->state['population'] . "\n<br>");
         #error_log($new_child->name . " Updated, population = " . $new_child->state['population'] . "\n<br>");
      }

      # stash the time of birth for refractory period calculation
      $this->last_birth = $this->timer->timeseconds;
   }

   function getBirthClass($birthdate) {
      if (is_object($this->parent_object)) {
         # pass the request up the line
         $bcs = $this->parent_object->getBirthClass($birthdate);
         return $bcs;
      } else {
         $dbg_obj = $this->components['Population: Shad_2007-01-04 00:00:00'];

         if ($this->debug) {
            $this->logDebug("Checking State of $dbg_obj->name , population = " . $dbg_obj->state['population'] . "<br>\n");
            $this->logDebug("Birth Class $birthdate Requested\n<br>");
         }
         # if we are at the top object, handle the request
         $classname = $this->base_name . "_" . $birthdate;
         if (in_array($classname, array_keys($this->components))) {
            if ($this->debug) {
               $this->logDebug("Birth Class $birthdate Exists in " . $this->components[$classname]->name . "\n<br>");
               #error_log("Birth Class $birthdate Exists in " . $this->components[$classname]->name . "\n<br>");
            }
            return $this->components[$classname];
         } else {
            if ($this->debug) {
               $this->logDebug("Creating Birth Class $birthdate\n<br>");
               #error_log("Creating Birth Class $birthdate\n<br>");
            }
            # need to create a new object for this birthclass
            $this->addCloneComponent($this->base_name . "_" . $birthdate);
            $new_child = $this->components[$this->base_name . "_" . $birthdate];
            if ($this->debug) {
               $this->logDebug("Checking State of $dbg_obj->name , population = " . $dbg_obj->state['population'] . "<br>\n");
            }
            $new_child->setProp('base_name', $this->base_name);
            $new_inputs = clone $this->inputs;
            $new_child->setProp('inputs', $new_inputs);
            $new_child->setProp('inputs', array());
            $new_child->setProp('components', array());
            $new_child->init();
            $new_child->setProp('state', array());
            $new_child->setSimTimer($this->timer);
            $new_child->setBirthDate();
            #$new_child->setDebug(0);
            $new_child->setProp('population', 0);
            $new_child->setProp('total_pop', 0);
            $new_child->setProp('child_pop', 0);
            $new_child->setProp('alive', 1);
            $new_child->setProp('name', $this->base_name . " " . $this->birth_class . "-" . $new_child->birth_class);
            # set a unique compid for this child
            $new_child->setProp('componentid', $this->base_name . "_" . $birthdate);
            if ($this->debug) {
               $arr = get_class_methods(get_class($new_child));
               $this->logDebug("Child added to $this->name with methods "  . print_r($arr,1) . "\n<br>");
               #error_log("Child " . $new_child->name . " added to $this->name " );
            }
            if (is_object($this->parent_object)) {
               $new_child->setParent($this->parent_object);
            } else {
               $new_child->setParent($this);
            }
            if ($this->debug) {
               $this->logDebug("Checking State of $dbg_obj->name , population = " . $dbg_obj->state['population'] . "<br>\n");
            }
            $new_child->setState();
            # clear inputs for total pop on child object to avoid redundancy
            $this->addInput('child_pop', 'total_pop', $new_child);
            $this->birthclasses[$birthdate] = $new_child;
            if ($this->debug) {
               $this->logDebug("$new_child->name added to birth Class $birthdate \n<br>");
               #error_log("$new_child->name added to birth Class $birthdate \n<br>");
               $this->logDebug("Checking State of $dbg_obj->name , population = " . $dbg_obj->state['population'] . "<br>\n");
            }

            return $new_child;
         }
      }
   }

}

class stockComponent extends modelObject {

   var $inflows = array();
   var $outflows = array();
   var $serialist = 'inflows,outflows';
   var $loggable = 1; // can log the value in a data table

   function setState() {
      parent::setState();
   }

   function step() {
      parent::step();
      # we will later use all inputs to accumulate and decrement stocks and flows, but for now, we will
      # just have it do nothing
   }

   function sleep() {
      parent::sleep();
      # we will later use all inputs to accumulate and decrement stocks and flows, but for now, we will
      # just have it do nothing
   }

   function finish() {
      parent::finish();
   }
}

class reportObject extends modelObject {

   var $imgurl = '';
   var $cache_log = 0; # store variable state log in an external file?  Defaults to 1 for graph and report objects, 0 for others
   # requires lib_plot.php to produce graphic output

   function setState() {
      parent::setState();
   }

   function step() {
      parent::step();
      if ($this->timer->finished) {
         # simulation finished, go ahead and generate any graphs
         $this->log2file();
      }
   }

   function finish() {
      parent::finish();
   }
}

class dataConnectionObject extends timeSeriesInput {

   var $conntype = 1; # 1 - postgis, 2 - ODBC, 3 - Oracle, 4 - WFS, 5 - object to object query, 6 - XML, 7 - RSS
   var $dbobject = -1; # need to keep this seperate from the listobject, which is used by the system for logging, etc.
   var $host = 'localhost';
   var $dbname = 'wsp';
   var $port = 5432;
   var $single_datecol = 1;
   var $datecolumn = ''; # use this if $single_datecol = true
   var $yearcolumn = '';
   var $monthcolumn = ''; # otherwise, need to have a column with the year, month, and day
   var $daycolumn = '';
   var $initval = 0;
   var $username = 'wsp_ro';
   var $password = 'q_only';
   var $table = ''; # selected table/dataset from the data source
   var $alltables = array();
   var $localprocs = array();
   var $lat_col = '';
   var $lon_col = '';
   var $restrict_spatial = 0;
   var $area_m = 0.0; // the area of the object geometry if this is set
   var $lasttable = ''; # last table value, for reference
   var $sql_query = ''; # this would be for a user defined query.  This can be dicey, since it could be a security risk if
                        # the user had write privileges.
   var $public_sql = ''; # this is the query that we run to create the publicly visible columns
   var $remote_query = '';
   var $transform_query = ''; // this is a test to see if we can perform the who shebang on the remote server
   // if it is a postgresql connection, we should be able to do this (if it has postgis that is)
   var $groupcols = ''; # columns to use in grouping
   var $scratchtable = ''; # table for storing local copy of raw query data
   var $schema = ''; # postgis specific schema for temp tables
   var $force_refresh = 1;
   var $data_refreshed = 0;
   var $rawdbfile = ''; # file name to cache raw data values to avoid continuous querying
   var $max_memory_values = 1000;
   var $log2db = 0; // this saves processing time immensely if this is turned off
   var $groupremote = 1; // whether to use the "performGroupedRemoteQueries()" function, which does transforms on the server side to reduce the amount of local data storage and temp table creation overhead, which can be substantial in the case of things like the CBP data

   function init() {
      $this->localprocs = array();
      parent::init();
      # get list of available tables and colmns
      $this->setupDBConn();

      # all columns in the raw data query are assumed to be private data
      # in order to make them public, we have to explicitly declare them/process them with a
      # component 'dataConnectionTransform'.  This will allow us to do summaries, rename columns, whatever
      # it stores the results in $this->public_sql
      $this->preProcess();
      # now that we have our raw query, restrict spatial extent if desired
      $theserecs = array();
      $cache_failed = 0;

      # now, get the RAW data for this query and store it in the tstable
      if ($this->debug) {
         $this->logDebug("Getting Data<br>\n");
      }
      $this->getData();
      if ($this->debug) {
         $this->logDebug("Data retrieved<br>\n");
      }

      # if an input for scratchtable is set, this means that we are using a remote query, and will do no querying ourselves
      if (isset($this->inputs['scratchtable'])) {
         if ($this->debug) {
            $this->logDebug("Trying to gain data from remote connection.<br>\n");
         }
         if (is_object($this->inputs['scratchtable'][0]['object'])) {
            $theserecs = $this->getRemoteData();
         }
      } else {
         if ( ($this->conntype == 1) and ($this->groupremote)) { 
            // try the new groupedremoteQuery function
            if ($this->debug) {
               $this->logDebug("Performing Grouped Query<br>\n");
            }
            $theserecs = $this->performGroupedRemoteQueries();
         } else {
            if ($this->debug) {
               $this->logDebug("Setting local table<br>\n");
            }
            $this->setupLocalTable($this->dbobject->queryrecords);
            if ($this->debug) {
               $this->logDebug("Setting geometry column<br>\n");
            }
            $this->setupGeometryColumn();
            if ($this->debug) {
               $this->logDebug("Performing local queries<br>\n");
            }
            $theserecs = $this->performLocalQueries();
            # blank out query records to save memory
            $this->dbobject->queryrecords = array();
         }
      }

      # and add them to our timeSeries values, otherwise, there are no time series values added
      $this->addQueryData($theserecs);
      ksort($this->tsvalues);
      // need to use our parent objects time series caching functions if they exist, since they take place in the 
      // parent call to init(), which takes place BEFORE we load our data
         
      if ( (count($this->tsvalues) > $this->max_memory_values) and ($this->max_memory_values > 0)) {
         //error_log("tsvalues cacheing enabled on $this->name");
         $this->tsvalues2listobject();
         $this->getCurrentDataSlice();
         $mem_use = (memory_get_usage(true) / (1024.0 * 1024.0));
         $mem_use_malloc = (memory_get_usage(false) / (1024.0 * 1024.0));
         //error_log("Memory Use after caching timeseries data on $this->name = $mem_use ( $mem_use_malloc )<br>\n");
      }
      
      $this->getGeometryArea();

   }


   function wake() {
      $this->localprocs = array();
      $this->setupDBConn(1);
      parent::wake();
      $this->prop_desc['area_m'] = 'Area of this objects geometry in square meters.';
   }

   function finish() {
      #
      parent::finish();
      # now, if we have defined an X/Y column, we go ahead and add the geometry
      if (is_object($this->listobject)) {
         # now, clean up
         if ($this->listobject->tableExists($scratchname)) {
            $this->listobject->querystring = " DROP TABLE $scratchname ";
            if ($this->debug) {
               $this->logDebug($this->listobject->querystring . " ;<br>");
            }
            $this->listobject->performQuery();
         }

         if ( in_array($this->lat_col, $this->columns) and in_array($this->lon_col, $this->columns) ) {
            # now, if we have defined an X/Y column, we have to clean up the geomtry table
            $this->listobject->querystring = " SELECT nspname FROM pg_namespace WHERE oid = pg_my_temp_schema() ";
            if ($this->debug) {
               $this->logDebug($this->listobject->querystring . " ;<br>");
            }
            $this->listobject->performQuery();
            $schema = $this->listobject->getRecordValue(1,'nspname');
            $this->listobject->querystring = " select dropGeometryColumn ( '$schema', '$this->scratchtable', 'the_geom') ";
            if ($this->debug) {
               $this->logDebug($this->listobject->querystring . " ;<br>");
            }
            $this->listobject->performQuery();
         }
      }

   }

   function sleep() {
      parent::sleep();
      $this->dbobject = NULL;
   }

   function setState() {
      parent::setState();
      # puts columns from query into state array
      $this->getTablesColumns();
   }

   function getPublicProps() {
      # gets only properties that are visible (must be manually defined)
      $publix = parent::getPublicProps();
      foreach ($this->localprocs as $thiscol) {
         array_push($publix, $thiscol);
      }

      array_push($publix, 'the_geom');
      array_push($publix, 'area_m');

      return $publix;
   }

   function getPrivateProps() {
      # gets all viewable variables in the local context only.  These are the column names
      $privitz = $this->localprocs;

      return $privitz;
   }

   function showHTMLInfo() {
      $htmlinfo = parent::showHTMLInfo();

      # puts columns from query into state array
      #$this->getData();
      #$htmlinfo .= 'Query: ' . $this->dbobject->querystring;
      #$htmlinfo .= print_r($this->dbobject->queryrecords,1);
      #$htmlinfo .= print_r($this->state,1);
      $htmlinfo .= "<hr>$this->name query = <br>" . $this->subLocalProperties($this->sql_query);
      return $htmlinfo;
   }

   function preProcess() {
      parent::preProcess();
      
      # if we have defined the_geom as an input, go ahead and grab that ahead of time, since we will want to have it
      # when we call getData.
      # this will be unreliable unless the link to the_geom is a parent, otherwise, the init() method may be called 
      # before the init() method of whatever object we link from.
      if (in_array('the_geom', array_keys($this->inputs))) {
         foreach ($this->inputs['the_geom'] as $thisin) {
            if (is_object($thisin['object'])) {
               $pname = $thisin['param'];
               $inobject = $thisin['object'];
               //error_log("I would like to retrieve $pname from another object ");
               
               if (property_exists($inobject, $pname)) {
                  $this->the_geom = $inobject->$pname;
                  //error_log("Geometry set to: " . substr($this->the_geom,0,64) . " ; ");
               }
               
            }
         }
      }
      
      list($public_cols, $group_cols) = $this->chooseLocalColumns();
      $this->public_sql .= $public_cols;
      $this->groupcols .= $group_cols;
      

   }
   
   function chooseLocalColumns() {
      // this is kind of a legacy, when we didn't want to allow access to all columns,
      // this will stay here for the base object, for the time being, but will be sub-classed 
      // by all children, under the assumption that if a column is brought in by some query, 
      // then it must be desired to be used.  If not, there would be no reason to query it 
      // in the first place
      $public_cols = '';
      $group_cols = '';
      $pdel = '';
      $gdel = '';
      if ($this->single_datecol == 1) {
         $public_cols = "\"$this->datecolumn\"";
         $group_cols = "\"$this->datecolumn\"";
         $pdel = ' ,';
         $gdel = ' ,';
      } else {
         $public_cols = "\"$this->yearcolumn\", \"$this->monthcolumn\", \"$this->daycolumn\"";
         $group_cols = "\"$this->yearcolumn\", \"$this->monthcolumn\", \"$this->daycolumn\"";
         $pdel = ' ,';
         $gdel = ' ,';
      }
      
      foreach ($this->processors as $thisproc) {
         // looks for dataconnectiontransforms
         if (is_object($thisproc)) {
            if ( isset($thisproc->mysql) and (strlen(isset($thisproc->mysql)) > 0) ) {
               $public_cols .= $pdel . $thisproc->mysql . " " . $this->listobject->alias_string . " \"$thisproc->name\"";
               if (strlen($thisproc->groupcol) > 0) {
                  $group_cols .= $gdel . "\"$thisproc->groupcol\"";
               }
               if ($this->debug) {
                  $this->logDebug("Found additional public query column: $thisproc->name ; <br>");
               }
            }
         }
      }# the parent routine calls the pre-cprocess method on all children, now iterate through looking for dataConnTransform children
      return array($public_cols, $group_cols);
   }

   function setupDBConn($refresh = 0) {
      # set up the appropriate database connection
      #if ( (!is_object($this->dbobject)) or $refresh) {
         #error_log("Setting up DB Connection ");
         if ($this->debug) {
            $this->logDebug("DB Conn params: $this->host port=$this->port dbname=$this->dbname user=$this->username password=xxxxx <br>\n");
         }
         switch ($this->conntype) {
            case 1:
            # postgis will call all tables
            $this->dbobject = new pgsql_QueryObject;
            $this->dbobject->dbconn = pg_connect("host=$this->host port=$this->port dbname=$this->dbname user=$this->username password=$this->password");
            #error_log("PG Connection: host=$this->host port=$this->port dbname=$this->dbname user=$this->username password=$this->password <br>");
            break;

            case 2:
            # postgis will call all tables
            $this->dbobject = new odbc_QueryObject;
            $this->dbobject->dbconn = odbc_connect( $this->dbname, $this->username, $this->password);
            $tbls = $this->dbobject->getTables();
            if ($this->debug) {
               $this->logDebug("Tables: " . print_r($tbls, 1) . "<br>");
            }
            #error_log("Tables: " . print_r($tbls, 1) . "<br>");
            break;

            case 3:
            # Oracle will call embedded table methods
            $this->dbobject = new oci8_QueryObject;
            if (function_exists('oci_connect')) {
               $this->dbobject->dbconn = oci_connect("$this->username", "$this->password", "$this->dbname");
            }

            break;

            case 4:
            # WFS will require a getCapabilities call.  Don't yet know how to parse that.
            break;

            case 5:
            # Shared data connection, uses the data gathered by another dataConnection object as the source by
            # accessing its local table
            break;

            case 6:
            # XML Feed - this will not be done here, sub-classes by xmlDataConnection object class
            //$this->dbobject = new rss_listObject;
            break;

            case 7:
            # RSS Feed - this will not be done here, sub-classes by RSSDataConnection object class
            //$this->dbobject = new rss_listObject;
            break;

         }
      #}
   }

   function getData() {
      # run this step, unless we have a shared data connection, in which case we use the shared objects data
      $this->data_refreshed = 0;
      $this->logDebug("Getting Data");
      if ($this->debug) {
         $this->logDebug("Getting Data");
      }
      if (is_object($this->dbobject) and (strlen($this->sql_query) > 0) ) {
         // check to see if query has any wildcards in it that we should sub for
         // this should have a select box, so that we don't inadvertently goof it up
         $this->dbobject->querystring = "select * from ( " . $this->subLocalProperties($this->sql_query);
         $this->dbobject->querystring .= ") as bar ";
         $this->dbobject->querystring .= " where (1 = 1) ";
         if ($this->restrict_spatial and (strlen(trim($this->the_geom)) > 0) ) {
            $this->dbobject->querystring .= " and within( ";
            $this->dbobject->querystring .= "GeomFromText('POINT(' || $this->lon_col || ' ' || $this->lat_col || ' )', 4326 )";
            $this->dbobject->querystring .= " ,GeomFromText('$this->the_geom',4326) ) ";
         }
         if ($this->single_datecol and is_object($this->timer) ) {
            $this->logDebug("Adding Timespan Restriction");
            $sdate = $this->timer->thistime->format('Y-m-d');
            $ndate = $this->timer->endtime->format('Y-m-d');
            $this->dbobject->querystring .= " and $this->datecolumn >= '$sdate' ";
            $this->dbobject->querystring .= " and $this->datecolumn <= '$ndate' ";
         }
         
         $this->remote_query = $this->dbobject->querystring;
         //error_log("Query :" . $this->dbobject->querystring);
         if ($this->debug) {
            $this->logDebug("Query defined: " . $this->dbobject->querystring . "; <br>");
         }
         $cache_failed = 1; // set this to failed, regardless, 
                            //then we set it to 0 if we get cached data, otherwise, query anew
         
         //error_log("Checking Cache setting: Cache setting: $this->cache_ts <br>");
         
         if ( ($this->cache_ts == 1) and ($this->force_refresh <> 1) ) {
            //error_log("Cache setting: $this->cache_ts , Refresh setting: $this->force_refresh , Looking for raw values in cache file <br>");
            if ($this->debug) {
               $this->logDebug("Looking for raw values in cache file <br>");
            }
            # stash these in a file
            if (strlen($this->rawdbfile) == 0) {
               $this->rawdbfile = 'rawdbvalues.' . $this->componentid . '.csv';
            }
            $filename = $this->outdir . '/' . $this->rawdbfile;
            $theserecs = readDelimitedFile($filename, $this->translateDelim($this->delimiter), 1);
            if (count($theserecs) > 0) {
               $cache_failed = 0;
               $this->dbobject->queryrecords = $theserecs;
               if ($this->debug) {
                  $this->logDebug(count($theserecs) . " raw values found in cache file <br>");
               }
            }
         }
         if ($cache_failed == 1) {
            if ($this->debug) {
               $this->logDebug(" Cache retrieval failed/disabled. Performing query.<br>");
            }
            //error_log(" Cache retrieval failed/disabled. Performing query.<br>");
            $this->dbobject->performQuery();
            $this->data_refreshed = 1;
         }
      } else {
         if ($this->debug) {
            $isobj = is_object($this->dbobject);
            $querylen = strlen($this->sql_query);
            $this->logDebug("Data Retrieval not performed, Is dbobject set? ($isobj) - Query length: $querylen<br>");
         }
      }

      if ($this->cache_ts == 1 and $this->data_refreshed) {
         //error_log("Putting data in cachde file<br>");
         # stash these in a file
         $this->rawDBValues2file($this->dbobject->queryrecords);
      }
   }
   
   function getGeometryArea() {
      
      if ( strlen(trim($this->the_geom)) > 0 ) {
         If ($this->debug) {
            $this->logdebug(" Querying geometry area for this watershed.<br>");
         }
         // get the area of this geometry for later use
         $this->dbobject->querystring = " select area2d( transform(GeomFromText('$this->the_geom',4326),26918) ) ";
         $this->dbobject->performQuery();
         if (count($this->dbobject->queryrecords) > 0) {
            $this->area_m = $this->dbobject->getRecordValue(1,'area2d');
            $this->state['area_m'] = $this->area_m;
         }
         if ($this->debug) {
            $this->logdebug("Geometry area query: " . $this->dbobject->querystring . " ;<br>");
            $this->logdebug("Geometry area set to $this->area_m .<br>");
         }
      }
   }
   
   function subLocalProperties($thisquery) {
      // check to see if we want to substitute any values into the query string.  these will be 
      // indicated by [variable name] in brackets
      // we must have a list of variables that are approved, so we can't go showing our password for the db server
      $pprops = $this->getPublicProps();
      $searched = '';
      foreach ($pprops as $thisprop) {
         if ( isset($this->$thisprop) ) {
            $thisquery = str_replace("[$thisprop]", $this->$thisprop, $thisquery);
            $searched .= " " . "[$thisprop]";
         }
      }
      //error_log("Searched: $searched ; <br>");
      //error_log("Query defined: $thisquery ; <br>");
      return $thisquery;
   }
      

   function getRemoteData() {

      # first, verify that the remote data source is actually a functioning remote source
      if (method_exists($this->inputs['scratchtable'][0]['object'], 'doRemoteQuery')) {
         # source has remoteQuery method, now see if we need to use it
         # check if we have cached out time series data in a local file.
         if ($this->cache_ts) {
            # if this is set, data has already been retrieved from the cache by the parent init() method
            # thus, we need to check to see if the data exists in the tsvalues array
            # if the tsvalues have been retrieved we can return
            if ( (count($this->tsvalues) > 0) and ($this->inputs['scratchtable'][0]['object']->data_refreshed == 0) ) {
               if ($this->debug) {
                  $this->logDebug("Cached data retrieved, and remote source not updated, no need to query.<br>");
               }
               return array();
            }
         }

         # also need to check if we have all of the variables in this file
         # also need to check if remote data source has updated its query this run
         if ($this->debug) {
            $this->logDebug("Remote Object exists with doRemoteQuery method, requesting data.<br>");
         }
         #error_log("Object requesting remote query " . $this->name . "<br>");
         #error_log("Remote refreshed " . $this->inputs['scratchtable'][0]['object']->data_refreshed . "<br>");
         #error_log("Local record count " . count($this->tsvalues) . "<br>");
         #error_log("Remote Object exists with doRemoteQuery method, requesting data.<br>");
         $theserecs = $this->inputs['scratchtable'][0]['object']->doRemoteQuery($this->username, $this->password, $this->the_geom);
         if ($this->debug) {
            $nr = count($theserecs);
            $this->logDebug("$nr records returned from remote query.<br>");
         }
         $this->datecolumn = $this->inputs['scratchtable'][0]['object']->datecolumn;
         $this->single_datecol = $this->inputs['scratchtable'][0]['object']->single_datecol;
         $this->yearcolumn = $this->inputs['scratchtable'][0]['object']->yearcolumn;
         $this->monthcolumn = $this->inputs['scratchtable'][0]['object']->monthcolumn;
         $this->daycolumn = $this->inputs['scratchtable'][0]['object']->daycolumn;
      }

      return $theserecs;
   }

   function setupLocalTable($theserecs) {
      # this will take the raw data records, and process them for public consumption, as well as restricting
      # access in a spatial manner
      $columns = array();
      $sprecs = array();

      if ($this->conntype <> 5) {
         $scratchname = "tmp_db$this->sessionid" . "_$this->componentid";
      } else {
         if (isset($this->inputs['scratchtable'])) {
            if (property_exists($this->inputs['scratchtable'][0]->scratchtable)) {
               $scratchname = $this->inputs['scratchtable'][0]->scratchtable;
            } else {
               $scratchname = "tmp_db$this->sessionid" . "_$this->componentid";
            }
         }
      }
      if ($this->debug) {
         $this->logDebug("Public records routine called <br>");
      }
      # default to a guess of the schema name
      $this->schema = 'pg_temp_1';
      # first we store the data in a local, temp table
      if ( is_object($this->listobject) and ($this->conntype <> 5) ) {
         # only have to set up the tables if this is NOT a shared connection
         # format for output
         if ($this->debug) {
            $this->logDebug("Outputting Time Series to db: $scratchname <br>");
         }
         $columns = array_keys($theserecs[0]);
         if ($this->debug) {
            $this->logDebug("Found columns: " . print_r($columns,1) . "<br>" );
         }
         $numin = count($theserecs);
         if ($this->debug) {
            $this->logDebug("Input data array has $numin records.<br>");
         }
         
         // set up a custom set of dbdcolumntypes here, so that it does not load columns for local 
         // state variables, since they will then be fetched from the timeseries table and overwrite 
         // the state values (or any local sub-processors) with NULL values
         $localdbcols = array();
         foreach ($columns as $colname) {
            if (isset($this->dbcolumntypes[trim($colname)])) {
               $localdbcols[trim($colname)] = $this->dbcolumntypes[trim($colname)];
            } else {
               if ($this->debug) {
                  $this->logDebug("$colname not found in dbcolumntypes<br>");
               }
            }
         }
         //$this->listobject->debug = 1;
         $this->localtab_create_sql = $this->listobject->array2tmpTable($theserecs, $scratchname, $columns, $localdbcols, 1, $this->bufferlog);
         //$this->listobject->debug = 0;
         
         if ($this->debug) {
            //error_log("$this->name calling array2tmptable with localdbcols - " . print_r($localdbcols,1));
            $this->logDebug("$this->localtab_create_sql<br>");
         }
         if ($this->debug) {
            $this->logDebug("Sent the following column formats: " . print_r($localdbcols,1) . "<br>");
            $this->logDebug("Getting schema name for temp table.<br>");
         }
         $this->listobject->querystring = " SELECT nspname FROM pg_namespace WHERE oid = pg_my_temp_schema(); ";
         if ($this->debug) {
            $this->logDebug($this->listobject->querystring . " ;<br>");
         }
         $this->listobject->performQuery();
         $this->schema = $this->listobject->getRecordValue(1,'nspname');
         if ($this->debug) {
            $this->listobject->querystring = " SELECT count(*) as numrecs FROM $scratchname; ";
            $this->listobject->performQuery();
            $numrecs = $this->listobject->getRecordValue(1,'numrecs');
            $this->logDebug($numrecs . " records in local table;<br>");
            //error_log($numrecs . " records in local table;<br>");
         }
      } else {
         # format for output
         if ($this->debug) {
            $this->logDebug("List object not set.<br>");
         }
         return;
      }

      $this->scratchtable = $scratchname;
      $this->columns = $columns;

   }

   function setupGeometryColumn() {
      # this will take the raw data records, and process them for ppublic consumtion, as well as restricting
      # access in a spatial manner

      $this->geomclause = '';
      $schema = $this->schema;
      $scratchname = $this->scratchtable;
      if ($this->debug) {
         $this->logDebug("Checking for spatial constraints: $this->lat_col , $this->lon_col.<br>");
      }
      # now, if we have defined an X/Y column, we go ahead and add the geometry
      if ( in_array($this->lat_col, $this->columns) and in_array($this->lon_col, $this->columns) and ($this->restrict_spatial) ) {
         if ($this->debug) {
            $this->logDebug("Geometry columns located. Preparing query<br>");
         }
         if ($this->conntype <> 5) {
            # only need to set this up if this is NOT a shared connection
            $this->listobject->querystring = " select addGeometryColumn ( '$schema', '$scratchname', 'the_geom', 4326, 'POINT', 2) ";
            if ($this->debug) {
               $this->logDebug($this->listobject->querystring . " ;<br>");
            }
            $this->listobject->performQuery();
            $this->listobject->querystring = " UPDATE $scratchname set the_geom = GeomFromText('POINT(' || $this->lon_col || ' ' || $this->lat_col || ' )', 4326 )";
            if ($this->debug) {
               $this->logDebug($this->listobject->querystring . " ;<br>");
            }
            $this->listobject->performQuery();
            if ($this->debug) {
               $this->listobject->querystring = " SELECT extent(the_geom) as geomext FROM $scratchname; ";
               $this->listobject->performQuery();
               $geomext = $this->listobject->getRecordValue(1,'geomext');
               $this->logDebug("Geometry extent: " . $geomext . " <br>");
            }
         }
         # get spatially overlapping records
         $this->geomclause = " where within(the_geom, geomFromText('$this->the_geom', 4326)) ";
         if ($this->debug) {
            $this->logDebug($this->listobject->querystring . " ;<br>");
         }

      } else {
         if ($this->debug) {
            $this->logDebug("No spatial constraints found: $this->lat_col , $this->lon_col <br>");
         }
      }

   }

   function doRemoteQuery($un, $pw, $geom = '') {
      # this will take the raw data records, and process them for public consumption, as well as restricting
      # access in a spatial manner for a CLIENT connection, i.e., some other query object that may want either a
      # copy of these records, or a special set of spatial constraints to this data

      $scratchname = $this->scratchtable;

      $sprecs = array();

      # do not allow access to a custom query if the username and password are not matching, this increases security somewhat
      if ( ($un == $this->username) and ($pw == $this->password) ) {

         $remotegeomclause = '';

         if ($geom <> '') {
            $remotegeomclause = " where within(the_geom, geomFromText('$geom', 4326)) ";
         }

         # get spatially overlapping records
         $this->listobject->querystring = " SELECT " . $this->public_sql  . " FROM $scratchname " . $remotegeomclause;
         if (strlen($this->groupcols) > 0) {
            $this->listobject->querystring .= " GROUP BY " . $this->groupcols;
         }
         if ($this->debug) {
            $this->logDebug($this->listobject->querystring . " ;<br>");
         }
         $this->listobject->performQuery();
         $sprecs = $this->listobject->queryrecords;
      }

      return $sprecs;

   }

   function performLocalQueries() {
      # this will take the raw data records, and process them for public consumption, as well as restricting
      # access in a spatial manner

      $scratchname = $this->scratchtable;

      $sprecs = array();

      # get spatially overlapping records
      $this->listobject->querystring = " SELECT " . $this->public_sql  . " FROM $scratchname " . $this->geomclause;

      if (strlen($this->groupcols) > 0) {
         $this->listobject->querystring .= " GROUP BY " . $this->groupcols;
      }
      if ($this->debug) {
         $this->logDebug("localQuery: " . $this->listobject->querystring . " ;<br>");
      }
      $this->listobject->performQuery();
      $sprecs = $this->listobject->queryrecords;

      return $sprecs;

   }

   function performGroupedRemoteQueries() {
      # this will take the raw data records, and process them for public consumption, as well as restricting
      # access in a spatial manner
      $sprecs = array();

      # get spatially overlapping records
      $this->dbobject->querystring = " SELECT " . $this->public_sql  . " FROM ($this->remote_query) as foo " . $this->geomclause;

      if (strlen($this->groupcols) > 0) {
         $this->dbobject->querystring .= " GROUP BY " . $this->groupcols;
      }
      //if ($this->debug) {
         $this->logDebug("localQuery: " . $this->dbobject->querystring . " ;<br>");
      //}
      $this->dbobject->performQuery();
      $this->logDebug("Query Message: " . $this->dbobject->querystring . " ;<br>");
      $sprecs = $this->dbobject->queryrecords;

      return $sprecs;

   }

   function addQueryData($theserecs) {
      # expects an associative array in the format of the listobject queryrecords
      if ($this->debug) {
         $this->logDebug("Adding " . count($theserecs) . ' records <br>');
      }
      $added = 0;
      $addcount = 0;
      $total = count($theserecs);
      foreach ($theserecs as $thisrec) {
         if (strlen($this->datecolumn) > 0) {
            $tcol = $this->datecolumn;
         } else {
            $tcol = 'timestamp';
         }
         if ($this->single_datecol <> 1) {
            # need to construct a date column from a year/mo/day set of fields
            $tcol = $this->yearcolumn;
            # we set the $tcol to the year field, and then later, we check for the existence of the other fields, and if
            # they do not exist in the record, we default to 1 as their value
            if ($this->debug) {
               $this->logDebug("Using meta-column for date <br>");
               $this->logDebug("Searching for " . print_r($tcol,1) . " in " . print_r(array_keys($thisrec),1) . "<br>");
            }
         }
         if (in_array($tcol, array_keys($thisrec))) {
            if ($this->single_datecol <> 1) {
               # add default values for month and day column if they do not exist
               if (!in_array($this->monthcolumn, array_keys($thisrec))) {
                  $thisrec[$this->monthcolumn] = 1;
               }
               if (!in_array($this->daycolumn, array_keys($thisrec))) {
                  $thisrec[$this->daycolumn] = 1;
               }
               $ts = str_pad($thisrec[$this->yearcolumn], 2, '0', STR_PAD_LEFT);
               $ts .= '-' . str_pad($thisrec[$this->monthcolumn], 2, '0', STR_PAD_LEFT);
               $ts .= '-' . str_pad($thisrec[$this->daycolumn], 2, '0', STR_PAD_LEFT);
               $thisrec['thisdate'] = $ts;
            } else {
               $ts = $thisrec[$tcol];
            }
            $this->addValue($ts, $thisrec);
            #break;
         } else {
            if ($this->debug) {
               $this->logDebug("Error: Date column $tcol does not exist.<br>");
            }
         }
         $added++;
         $addcount++;
         if ( $addcount == 500) {
            $this->systemLog("$this->name added $added of $total records", 1);
            $addcount = 0;
         }
      }
   }

   function getTablesColumns() {
      
      $base_query = $this->subLocalProperties($this->sql_query);

      switch ($this->conntype) {
         case 1:
         # postgis will call all tables
         if (is_object($this->dbobject) and (strlen($base_query) > 0) ) {
            if(method_exists($this->dbobject,'performQuery')) {
               //$shortquery = " select * from ( $base_query ) as foo LIMIT 1 ";
               $shortquery = " $base_query LIMIT 1 ";
               //if ($this->debug) {
                  $this->logDebug("column qery: " . $shortquery);
               //}
               $this->dbobject->querystring = $shortquery;
               $this->dbobject->performQuery();
               $allcols = array_keys($this->dbobject->queryrecords[0]);
               foreach ($allcols as $thiscol) {
                  array_push($this->localprocs,$thiscol);
               }
            }
         }
         break;

         case 2:
         # ODBC
         if (is_object($this->dbobject) and (strlen($base_query) > 0) ) {
            if(method_exists($this->dbobject,'performQuery')) {
               $shortquery = " select * from ( $base_query ) as foo LIMIT 1 ";
               $this->dbobject->querystring = $shortquery;
               if ($this->debug) {
                  $this->logDebug("column qery: " . $shortquery);
               }
               $this->dbobject->performQuery();
               $allcols = array_keys($this->dbobject->queryrecords);
               foreach ($allcols as $thiscol) {
                  array_push($this->localprocs,$thiscol);
               }
            }
         }
         break;

         case 3:
         # Oracle
         if (is_object($this->dbobject) and (strlen($base_query) > 0) ) {
            if(method_exists($this->dbobject,'performQuery')) {
               # due to difficulty with oracles lack of a LIMIT clause, this will be very slow
               $this->dbobject->querystring = $base_query;
               if ($this->debug) {
                  $this->logDebug("column qery: " . $base_query);
               }
               $this->dbobject->performQuery();
               $allcols = array_keys($this->dbobject->queryrecords[0]);
               foreach ($allcols as $thiscol) {
                  array_push($this->localprocs,$thiscol);
               }
            }
         }

         break;

         case 4:
         # WFS will require a getCapabilities call.  Don't yet know how to parse that.
         break;

      }

   }

   function rawDBValues2file($theserecs) {
      if (strlen($this->rawdbfile) == 0) {
         $this->rawdbfile = 'rawdbvalues.' . $this->componentid . '.csv';
      }
      $filename = $this->outdir . '/' . $this->rawdbfile;
      # format for output
      $fdel = '';
      $outform = '';
      if ($this->debug) {
         $this->logDebug("Outputting Time Series to file: $this->logfile <br>");
      }
      if (count($theserecs) > 0) {
         $minkey = min(array_keys($theserecs));
         if ($this->debug) {
            $this->logDebug("Time Series Start (seconds): $minkey <br> Exporting Columns");
            $this->logDebug(array_keys($theserecs[$minkey]));
         }

         foreach (array_keys($theserecs[$minkey]) as $thiskey) {
            if (in_array($thiskey, array_keys($this->logformats))) {
               # get the log file format from here, if it is set
               if ($this->debug) {
                  $this->logDebug("Getting format for log table " . $thiskey . "\n");
               }
               $outform .= $fdel . $this->logformats[$thiskey];
            } else {
               if ($this->debug) {
                  $this->logDebug("Guessing format for log table " . $thiskey . "\n");
               }
               if (is_numeric($theserecs[$minkey][$thiskey])) {
                  $outform .= $fdel . $this->numform;
               } else {
                  $outform .= $fdel . $this->strform;
               }
            }
            $fdel = ',';
         }
         if ($this->debug) {
            $this->logDebug("Using format string: $outform <br>");
         }
         $outarr = nestArraySprintf($outform, $theserecs);
         #$this->logDebug($outarr);
         $colnames = array(array_keys($theserecs[0]));
         if ($this->debug) {
            $colcsv = join(',', $colnames);
            $this->logDebug("Columns: $colcsv <br>");
         }

         if ($this->debug) {
            $numlines = count($theserecs);
            $this->logDebug("Outputting: $numlines lines <br>");
         }

         putDelimitedFile("$filename",$colnames,$this->translateDelim($this->delimiter),1,$this->fileformat);

         putArrayToFilePlatform("$filename", $outarr,0,$this->fileformat);
      }
   }


}

class dataConnectionTransform extends modelObject {

   var $func = '';
   var $col_name = '';
   var $mysql = ''; # will contain my formatted SQL complliant column function definition
   var $groupcol = '';
   var $loggable = 1;
   var $log2db = 0; // do not create a table for this, just log in parent

   function preProcess() {
      list($myopen, $myclose, $mygroup) = $this->getFunctionFormat($this->func, $this->col_name);
      $this->mysql = "$myopen \"$this->col_name\" $myclose";
      $this->groupcol = "$mygroup";
   }
   
   function evaluate() {
      $this->result = $this->arData[$this->name];
   }


   function getFunctionFormat($func, $colname) {

      $fopen = '';
      $fclose = '';

      switch ($func) {
         case 'min':
            $fopen = 'min(';
            $fclose = ')';
            $fgroup = '';
         break;

         case 'mean':
            $fopen = 'avg(';
            $fclose = ')';
            $fgroup = '';
         break;

         case 'max':
            $fopen = 'max(';
            $fclose = ')';
            $fgroup = '';
         break;

         case 'gini':
            $fopen = 'gini(array_accum(';
            $fclose = '))';
            $fgroup = '';
         break;

         case 'sum':
            $fopen = 'sum(';
            $fclose = ')';
            $fgroup = '';
         break;

         case 'count':
            $fopen = 'count(';
            $fclose = ')';
            $fgroup = '';
         break;

         default:
         # default to a selection only, which is NOT an aggregate, therefore, we return this column for grouping
            $fgroup = $colname;
         break;
      }

      return array($fopen, $fclose, $fgroup);
   }

}

class noaaGriddedPrecip extends dataConnectionObject {
   var $groupremote = 0;
   var $extflag = 1;
   var $intflag = 1;
   var $intmethod = 0;
   var $nullvalue = 0.0;
   
   function wake() {
      parent::wake();
      $this->prop_desc['precip_wgtd'] = 'Weighted precip inputs in watershed inches.';
   }
   
   function step() {
      parent::step();
      $this->logDebug("Time series vals: " . print_r($this->tsvalues[min(array_keys($this->tsvalues))],1) . "<br>");
      if (!is_object($this->state['precip_pts'])) {
         $precip_area = 17065136.0 * $this->state['precip_pts'];
      }
      if ( $precip_area >= $this->area_m ) {
         $this->state['precip_wgtd'] = $this->state['precip_in'];
      } else {
         $this->state['precip_wgtd'] = 17065136.0 * $this->state['precip_sum'] / $this->area_m;
      }
   }

   function setState() {
      # gets only properties that are visible (must be manually defined)
      parent::setState();
      $this->state['precip_wgtd'] = 0.0;
      $this->state['precip_in'] = 0.0;
      $this->state['precip_sum'] = 0.0;
   }

   function getPublicProps() {
      # gets only properties that are visible (must be manually defined)
      $publix = parent::getPublicProps();
      array_push($publix, 'precip_wgtd');

      return $publix;
   }
   
   function finish() {
      
      # Create a mapObj, initialized with the blank mapfile
      $map_file = "/var/www/html/test/blank.map";
      $mapobject = ms_newMapObj($map_file);
      // get extent
      $this->listobject->querystring = " select xmin(extent(the_geom)), ymin(extent(the_geom)), ";
      $this->listobject->querystring .= " xmax(extent(the_geom)), ymax(extent(the_geom)) ";
      $this->listobject->querystring .= " from $this->scratchtable ";
      $this->logDebug($this->listobject->querystring . " <br>\n");
      $this->listobject->performQuery();
      $xmin = $this->listobject->getRecordValue(1,'xmin');
      $ymin = $this->listobject->getRecordValue(1,'ymin');
      $xmax = $this->listobject->getRecordValue(1,'xmax');
      $ymax = $this->listobject->getRecordValue(1,'ymax');
      
      $this->listobject->querystring = " select * ";
      $this->listobject->querystring .= " from $this->scratchtable limit 5 ";
      $this->logDebug($this->listobject->querystring . " <br>\n");
      $this->listobject->show = 0;
      $this->listobject->performQuery();
      $this->listobject->showList();
      $this->logDebug("Sample: " . $this->listobject->outstring . " <br>\n");
      
      // make query to summarize the rainfall data by point
      $this->listobject->querystring = " select x(the_geom) as x, y(the_geom) as y, ";
      $this->listobject->querystring .= "    sum(globvalue) as total_precip_in ";
      $this->listobject->querystring .= " from $this->scratchtable ";
      $this->listobject->querystring .= " group by x, y ";
      $this->logDebug($this->listobject->querystring . " <br>\n");
      error_reporting(E_ALL);
      $this->logDebug("Error fromPG: " . $this->listobject->error . " <br>\n");
      $this->listobject->performQuery();
      $qresult = $this->listobject->queryrecords;
      
      // create a map object of this summary data
      # Get the first layer and set a classification attribute
      $layer = ms_newLayerObj($mapobject);
      $layer->set("status", MS_ON);
      $layer->set("type", MS_LAYER_POINT);
      //$layer->set("minscaledenom", 70); // <------ Shows up if denom<71 and doesn't show if denom>=71
      // you can change min to max or add another if you want for the other way around
      // add new class to new layer
      $class = ms_newClassObj($layer);
      $class->label->set("font", "arial");
      $class->label->color->setRGB(0, 222, 31);
      $class->label->set("size", 10);
      $class->label->set("type", MS_TRUETYPE);
      $class->label->set("position", MS_CR);
      $class->label->set("antialias", TRUE);


      $style = ms_newStyleObj($class);
      $style->color->setRGB(0, 0, 0);
      $style->set("size", 6);
      $style->set("symbol", 0);
      $style->set("antialias", TRUE);

      $i = 0;
      $shape = ms_newShapeObj(MS_SHAPE_POINT);
      $line = ms_newLineObj();
      $max_precip = 0.0;
      foreach($qresult as $row) {
         if ($row['total_precip_in'] > $max_precip) {
            $max_precip = $row['total_precip_in'];
         }
         $this->logDebug("Adding: " . $row['x'] . "," . $row['y'] . " <br>\n");
         $pt = ms_newPointObj();
         $pt->setXY($row['x'], $row['y'], 0.0);
         $line->add( $pt );
         $i++;
      }
      $shape->add($line);
      //$pointShape->set("text", "London");
      $layer->addFeature( $shape );

      $mapobject->insertLayer($layer);
      $this->logDebug("Setting extent to $xmin,$ymin,$xmax,$ymax <br>\n");
      if ($xmin > 0) {
         $mapobject->setExtent($xmin,$ymin,$xmax,$ymax);
      }

      $image=$mapobject->draw();


      $this->logDebug("Scale Denominator: " . $mapobject->scaledenom . '<br>'); // to check what your denom is
      $mapobject->drawLabelCache($image);
      //$map->save("/tmp/test2.map"); // if you want to save mapfile to see your output
      $image_url=$image->saveWebImage();

      // new school way of showing the graph
      $this->graphstring .= "<a class='mH' onClick='document[\"image_screen\"].src = \"" . $image_url . "\"; '>$this->name</a> | ";
      $this->graphstring .= "<a href='" . $image_url . "' target='_new'>View Image in New Window</a><br>";
      error_reporting(E_ERROR);


      // after we finish, we call the parent routines to do clean up such as dropping the scratch table, etc.
      parent::finish();
      
   }
}

class XMLDataConnection extends dataConnectionObject {
   
   var $conntype = 6;
   var $feed_address = '';
   var $urls_finalized = 0; // set to 1 after finalizeFeedURLs() is called by init or wake() to prevent double execution
   var $final_feed_url = ''; // after adding any extra local variables, etc.
   // parent variable conntype will contain the descriptotr, for now, we assume RSS
   var $data_inventory_address = ''; // basically, what address to use to get a list of data columns for use by the object
   var $final_data_inventory_address = ''; // after adding any extra local variables, etc.
   var $extra_variables = ''; // a list of key=value pairs entered in a text field, if there are carriage returns, it will concatenate them along URL lines with &
   var $final_extra_variables = ''; // local internal properties appended to extra_variables (only actually modified in sub-class objects who have defined processLocalExtras())
   var $feed_inventory = array(); //
   var $feed_columns = array();
   var $cache = 'cache';
   var $cache_age = 2592000; // cache age in seconds (259200 = (86400 * 30)), i.e. 30 days
   var $read_timeout = 2400; // time out in seconds to read data file
   var $mincache = 0; // file size for automatic cache refresh
   function setupDBConn($refresh = 0) {
      // make the 
      parent::setupDBConn($refresh);
   }
   
   function init() {
      $this->dbobject = new pgsql_QueryObject;
      // check for extra URL stuff added
      define('MAGPIE_CACHE_ON', TRUE);
      define('MAGPIE_FETCH_TIME_OUT', 240);
      define('MAGPIE_CACHE_DIR', $this->basedir . "/" . $this->cache);
      $this->urls_finalized = 0;
      $this->final_extra_variables = $this->extra_variables;
      $this->processLocalExtras();
      $this->finalizeFeedURLs();
      $this->getTablesColumns();
      parent::init();
   }
   
   function wake() {
      //parent::wake();
      define('MAGPIE_CACHE_ON', TRUE);
      define('MAGPIE_FETCH_TIME_OUT', 240);
      define('MAGPIE_CACHE_DIR', $this->basedir . "/" . $this->cache);
      $this->urls_finalized = 0;
      $this->final_extra_variables = $this->extra_variables;
      $this->processLocalExtras();
      $this->finalizeFeedURLs();
      $this->getTablesColumns();
      parent::wake();
   }

   function showHTMLInfo() {
      $htmlinfo = parent::showHTMLInfo();

      # puts columns from query into state array
      #$this->getData();
      #$htmlinfo .= 'Query: ' . $this->dbobject->querystring;
      #$htmlinfo .= print_r($this->dbobject->queryrecords,1);
      #$htmlinfo .= print_r($this->state,1);
      $htmlinfo .= "<hr>$this->name query = <br>" . $this->final_feed_url;
      /* 
      // this won't work unless we have finalized our feed URL
      $enc_name = $this->encodeFilename();
      $filename = $this->basedir . "/" . $this->cache . "/" . $enc_name;
      $htmlinfo .= "<hr>Cache File = <br>" . $filename;
      */
      return $htmlinfo;
   }
   
   function chooseLocalColumns() {
      // this is kind of a legacy, when we didn't want to allow access to all columns,
      // this will stay here for the base object, for the time being, but will be sub-classed 
      // by all children, under the assumption that if a column is brought in by some query, 
      // then it must be desired to be used.  If not, there would be no reason to query it 
      // in the first place
      // this version returns all columns
      $public_cols = '*';
      $group_cols = '';
      $this->logDebug("Columns for local query: $public_cols, $group_cols <br>\n");
      return array($public_cols, $group_cols);
   }
   
   function getRemoteFileData() {
      
      // encode the file URL
      // check the cahce directory for said file
      // if the file exists in the cache
         // check the data for staleness
         // if state refreshCache()
      // if the file does NOT exist - get it (refreshCache())
         // stash a copy in the cache
      if ($this->debug) {
         $this->logDebug("Checking for cached file <br>\n");
      }
      $this->logDebug("Checking for cached file <br>\n");
      if (!$this->checkCache() or $this->force_refresh) {
         if ($this->force_refresh) {
            $this->logDebug("Refresh forced for cached file <br>\n");
         }
         $xmlfile = $this->refreshCache();
      } else {
         $xmlfile = $this->readCache();
      }
      
      return $xmlfile;
   }
   
   function refreshCache() {
      $ctx = stream_context_create(array(
          'http' => array(
              'timeout' => $this->read_timeout
              )
          )
      );
      $xmlfile = file_get_contents($this->final_feed_url, 0, $ctx);
      $enc_name = $this->encodeFilename();
      $filename = $this->basedir . "/" . $this->cache . "/" . $enc_name;
      if ($this->debug) {
         $this->logDebug("Writing $filename to cache <br>\n");
      }
      $this->logDebug("Writing $filename to cache <br>\n");
      $fp = fopen($filename, 'w');
      fwrite($fp, $xmlfile);
      return $xmlfile;
   }
   
   function readCache() {
      $enc_name = $this->encodeFilename();
      $filename = $this->basedir . "/" . $this->cache . "/" . $enc_name;
      $ctx = stream_context_create(array(
          'http' => array(
              'timeout' => $this->read_timeout
              )
          )
      );
      if ($this->debug) {
         $this->logDebug("$this->name reading $filename from cache <br>\n");
      }
      $this->logDebug("$this->name reading $filename from cache <br>\n");
      $xmlfile = file_get_contents($filename, 0, $ctx);
      return $xmlfile;
   }
   
   function encodeFilename($filename = '') {
      if ($filename == '') {
         $filename = $this->final_feed_url;
      }
      $enc_name = md5($filename);
      return $enc_name;
   }
   
   function checkCache() {
      $enc_name = $this->encodeFilename();
      $filename = $this->basedir . "/" . $this->cache . "/" . $enc_name;
      $modtime = filemtime($filename);
      $age = mktime() - $modtime;
      $file_size = filesize($filename);
      $this->logDebug("$filename age $age = mktime() - $modtime <br>\n");
      if ( ($age > $this->cache_age) or ($file_size <= $this->mincache)) {
         return false;
      }
      return true;
   }
   
   function getData() {
      $retvals = array();
      // check for extra URL stuff added
      $this->finalizeFeedURLs();
      if (class_exists('jiffyXmlReader')) {
         if ($this->debug) {
            $this->logDebug("Fetching Feed:  $this->final_feed_url <br>\n");
         }

         // ***************************************************************** //
         // START - using new internally cahcing file_get_contents
         // ***************************************************************** //
         $xmlfile = $this->getRemoteFileData();
         // instead of:
         //$xmlfile = file_get_contents($this->final_feed_url, 0, $ctx);
         $rawlength = strlen($xmlfile);
         if ($this->debug) {
            $this->logDebug("Length of raw feed:  $rawlength <br>\n");
         }
         $xml = simplexml_load_string($xmlfile);
         if ($this->debug) {
            $this->logDebug("Keys: " . print_r(array_keys((array)$xml),1) . " <br>\n");
         }
         //$xml = simplexml_load_file($this->final_feed_url);
         $linklist = $xml->channel->item;
         // ***************************************************************** //
         // END - new internally cahcing file_get_contents
         // ***************************************************************** //
         
         // this currently only works if we have a valid data column, or collection of date columns (year, mo, day)
         $valid_datecol = 0;
         $ignore_fields = array('title', 'link', 'description');  
         if ($this->datecolumn <> '') {
            $k = 0;
            // iterate through returned values, ignore fields 'title', 'link', 'description'
            $retvals = array();
            foreach ($linklist as $linkobj) {
               $thislink = (array)$linkobj;
               foreach($ignore_fields as $thisfield) {
                  unset($thislink[$thisfield]);
               }
               if ($k == 0) {
                  // check to see if this has a date returned
                  $firstrec = $thislink;
                  if ($this->debug) {
                     $this->logDebug("First record returned = " . print_r($thislink, 1) . " <br>\n");
                  }
                  if (isset($thislink[$this->datecolumn])) {
                     $valid_datecol = 1;
                  } else {
                     $this->logError("Date Column $this->datecolumn not found <br>\n");
                     $this->logDebug("Date Column $this->datecolumn not found <br>\n");
                     if ($this->debug) {
                        $this->logDebug("Date Column $this->datecolumn not found <br>\n");
                     }
                     // no data column found, so set the state to the first record and exit
                     foreach ($thislink as $thiskey=>$thisval) {
                        $this->setStateVar($thiskey, $thisval);
                     }
                     break;
                  }
               }
               $retvals[] = $thislink;
               $k++;
            }
            if ($this->debug) {
               $this->logDebug("Feed returned " . count($retvals) . " records <br>\n");
            }
            $this->logDebug("Feed returned " . count($retvals) . " records <br>\n");
         } else {
            // no data column defined so set the state to the first record and exit
            $thislink = (array)$linklist[min(array_keys($linklist))];
            foreach($ignore_fields as $thisfield) {
               unset($thislink[$thisfield]);
            }
            foreach ($thislink as $thiskey=>$thisval) {
               $this->setStateVar($thiskey, $thisval);
            }
            if ($this->debug) {
               $this->logDebug("Date column not defined<br>\n");
               $this->logDebug("Feed returned " . count($linklist) . " records <br>\n");
            }
         }
         
         
      } else {
         $this->logError("Error Retrieving Data: RSS Magpie function 'fetch_rss' is not defined - can not retrieve feed.");
      }
      
      $this->dbobject->queryrecords = $retvals;
      $numrecs = count($linklist);
      $numparsed = count($retvals);
      $this->logError("$this->name : $numrecs returned, $numparsed added to data series <br>\n");
      //error_log("$this->name : $rawlength char xml file,  $numrecs returned, $numparsed added to data series <br>\n");
   }
   
   function finalizeFeedURLs() {
      // this will incorporate any local properties, and check to make sure that the url is formed OK,
      // this creates a finalized feed url, AND a finalized data_inventory_url so that we don't try to get 
      // data that does not exist
      if (!$this->urls_finalized) {
         $extras = $this->subLocalProperties($this->final_extra_variables); 
         $url = ltrim(rtrim($this->feed_address));
         $this->final_feed_url = $this->appendExtrasToURL($url, $extras);
         if ($this->debug) {
            $this->logDebug("Final Query URL: $this->final_feed_url <br>\n");
         }
         //error_log("Final Query URL: $this->final_feed_url <br>\n");

         // only do this if we actually HAVE a data_inventory_address set
         if (strlen($this->data_inventory_address) > 0) {
            $extras = $this->subLocalProperties($this->final_extra_variables); 
            $url = ltrim(rtrim($this->data_inventory_address));
            $this->final_data_inventory_address = $this->appendExtrasToURL($url, $extras);
            if ($this->debug) {
               $this->logDebug("Final Inventory URL: $this->final_data_inventory_address <br>\n");
            }
            //error_log("Final Inventory URL: $this->final_data_inventory_address <br>\n");
         }
         $this->urls_finalized = 1;
      }
   }
   
   function processLocalExtras() {
      // this is just a stub
   }
   
   function appendExtrasToURL($url, $extra_variables) {
      $extras = preg_split("/((\r(?!\n))|((?<!\r)\n)|(\r\n))/", $this->subLocalProperties($extra_variables)); 
      $url = ltrim(rtrim($url));
      $udel = '';
      $callpieces = preg_split('[\/]', $url);
      $lastpiece = $callpieces[(count($callpieces) - 1)];
      if (!strpos($lastpiece, '?')) {
         // this URL has not parameters appended to it, so we have to add the '?' before appending parameters
         $url .= '?';
      } else {
         if (substr($url,-1) <> '?') {
            // the URL already contains a ? AND has a parameter after the ?, so set the delimiter to '&'
            $udel = '&';
         }
      }
      foreach ($extras as $thisextra) {
         if (strlen(ltrim(rtrim($thisextra))) > 0) {
            $url .= $udel . ltrim(rtrim($thisextra));
            $udel = '&';
         }
      }
      $final_url = $url;
      if ($this->debug) {
         $this->logDebug("Final Query URL: $url <br>\n");
      }
      //error_log("Final Query URL: $url <br>\n");
      return $url;
   }
   
   
   function getTablesColumns() {
      if (function_exists('fetch_rss')) {
         // this rss feed should return a single record with descriptive information
         if ($this->debug) {
            $this->logDebug("Starting Data Inventory Address: $this->data_inventory_address <br>\n");
            $this->logDebug("Final Inventory Address: $this->final_data_inventory_address <br>\n");
         }
         if (strlen(rtrim(ltrim($this->final_data_inventory_address))) > 0) {
            $rss = fetch_rss($this->final_data_inventory_address);
         } else {
            // try the regular rss data address
            $rss = fetch_rss($this->final_feed_url);
         }
         #print_r($rss->items);
         $linklist = $rss->items;
         $firstrec = $linklist[min(array_keys($linklist))];
         // stash this for use by other information gathering methods
         $this->feed_inventory = $firstrec;
         if (isset($firstrec['all_columns'])) {
            if ($this->debug) {
               $this->logdebug("RAW all_columns: " . $firstrec['all_columns'] . " <br>\n");
            }
            $all_columns = split(",", $firstrec['all_columns']);
            if (isset($firstrec['data_column_types'])) {
               $data_column_types = split(",", $firstrec['data_column_types']);
               if ($this->debug) {
                  $this->logdebug("Found data column types: " . $firstrec['data_column_types'] . " <br>\n");
               }
            } else {
               $this->logdebug("data_column_types not in inventory feed: " . print_r(array_keys($firstrec),1) . " <br>\n");
            }
            // get data column types into object
            if (isset($firstrec['data_columns'])) {
               $data_columns = split(",", $firstrec['data_columns']);
               $data_column_types = array();
               if (isset($firstrec['data_column_types'])) {
                  $data_column_types = split(",", $firstrec['data_column_types']);
                  if ($this->debug) {
                     $this->logdebug("Using data_column_types: " . print_r($data_column_types,1) . " <br>\n");
                  }
               } else {
                  if ($this->debug) {
                     $this->logdebug("data_column_types not in inventory feed: " . print_r(array_keys($firstrec),1) . " <br>\n");
                  }
               }
               $colindex = 0;
               foreach ($data_columns as $thiscol) {
                  $this->setSingleDataColumnType($thiscol, $data_column_types[$colindex]);
                  //$this->dbcolumntypes[$thiscol] = $data_column_types[$colindex];
                  if ($this->debug) {
                     $this->logdebug("Setting $thiscol to type: " . $data_column_types[$colindex] . " <br>\n");
                  }
                  $colindex++;
               }
               if (isset($firstrec['time_column'])) {
                  array_push($this->localprocs,$firstrec['time_column']);
                  $this->dbcolumntypes[$firstrec['time_column']] = 'timestamp';
                  $this->datecolumn = $firstrec['time_column'];
                  if ($this->debug) {
                     $this->logdebug("Setting datecolumn to " . $firstrec['time_column'] . " <br>\n");
                  }
               }

               if ($this->debug) {
                  $this->logdebug("Columns available: " . print_r($this->localprocs,1) . " <br>\n");
                  $this->logdebug("Column types set to: " . print_r($this->dbcolumntypes,1) . " <br>\n");
               }
            }
            foreach ($all_columns as $thiscol) {
               array_push($this->localprocs,$thiscol);
            }
            if ($this->debug) {
               $this->logdebug("Columns obtained from all_columns: " . print_r($this->localprocs,1) . " <br>\n");
            }
         } else {
            if (isset($firstrec['data_columns'])) {
               $data_columns = split(",", $firstrec['data_columns']);
               $data_column_types = array();
               if (isset($firstrec['data_column_types'])) {
                  $data_column_types = split(",", $firstrec['data_column_types']);
                  $this->logdebug("Using data_column_types: " . print_r($data_column_types,1) . " <br>\n");
               } else {
                  $this->logdebug("data_column_types not in inventory feed: " . print_r(array_keys($firstrec),1) . " <br>\n");
               }
               $colindex = 0;
               foreach ($data_columns as $thiscol) {
                  array_push($this->localprocs,$thiscol);
                  $this->dbcolumntypes[$thiscol] = $data_column_types[$colindex];
                  $this->logdebug("Setting $thiscol to type: " . $data_column_types[$colindex] . " <br>\n");
                  $colindex++;
               }
               if (isset($firstrec['time_column'])) {
                  array_push($this->localprocs,$firstrec['time_column']);
                  $this->dbcolumntypes[$firstrec['time_column']] = 'timestamp';
                  $this->datecolumn = $firstrec['time_column'];
                  if ($this->debug) {
                     $this->logdebug("Setting datecolumn to " . $firstrec['time_column'] . " <br>\n");
                  }
               }

               if ($this->debug) {
                  $this->logdebug("Columns available: " . print_r($this->localprocs,1) . " <br>\n");
                  $this->logdebug("Column types set to: " . print_r($this->dbcolumntypes,1) . " <br>\n");
               }
            } else {
               $this->logError("Error Retrieving Column Names: Data Columns Property Not set.<br>\n");
               $this->logError("Feed Info URL: $this->data_inventory_address <br>\n");
               $this->logError("Feed returned:" . print_r($linklist,1) . "<br>\n");
               $this->logError("Guessing Columns From Feed Contents" . print_r($linklist,1) . "<br>\n");
               foreach (array_keys($firstrec) as $thiscol) {
                  array_push($this->localprocs,$thiscol);
               }
            }
         }
         $this->feed_columns = $this->localprocs;
      } else {
         $this->logError("Error Retrieving Column Names: RSS Magpie function 'fetch_rss' is not defined - can not retrieve feed.");
      }
   }
   
   function createQuery() {
      // dummy function, not needed in XML object
   }

   function arrayRenameOmit($linklist, $ignore_fields, $rename_fields) {
      // processes an XML object, renames fields and ommits fields as specified
      // this will only work for a simplexml object, since the magpie rss does NOT use object format
      $retarr = array();
      foreach ($linklist as $linkobj) {
         $thislink = (array)$linkobj;
         $mapped = array();
         foreach($ignore_fields as $thisfield) {
            unset($thislink[$thisfield]);
         }
         foreach($thislink as $key=>$val) {
            if (in_array($key, array_keys($rename_fields))) {
               $mapped[$rename_fields[$key]] = $val;
            } else {
               $mapped[$key] = $val;
            }
         }
         $retarr[] = $mapped;
      }
      return $retarr;
   }
   
}


//class RSSDataConnection extends dataConnectionObject {
class RSSDataConnection extends XMLDataConnection {
   
   var $conntype = 7;
   var $feed_address = '';
   var $urls_finalized = 0; // set to 1 after finalizeFeedURLs() is called by init or wake() to prevent double execution
   var $final_feed_url = ''; // after adding any extra local variables, etc.
   // parent variable conntype will contain the descriptotr, for now, we assume RSS
   var $data_inventory_address = ''; // basically, what address to use to get a list of data columns for use by the object
   var $final_data_inventory_address = ''; // after adding any extra local variables, etc.
   var $extra_variables = ''; // a list of key=value pairs entered in a text field, if there are carriage returns, it will concatenate them along URL lines with &
   var $final_extra_variables = ''; // local internal properties appended to extra_variables (only actually modified in sub-class objects who have defined processLocalExtras())
   var $feed_inventory = array(); //
   var $feed_columns = array();
   function setupDBConn($refresh = 0) {
      // make the 
      parent::setupDBConn($refresh);
   }
   
   function init() {
      parent::init();
   }
   
   function wake() {
      parent::wake();
   }
   
   function showHTMLInfo() {
      $htmlinfo = parent::showHTMLInfo();

      # puts columns from query into state array
      #$this->getData();
      #$htmlinfo .= 'Query: ' . $this->dbobject->querystring;
      #$htmlinfo .= print_r($this->dbobject->queryrecords,1);
      #$htmlinfo .= print_r($this->state,1);
      $htmlinfo .= "<hr>RSS Connection $this->name Final Feed URL = <br>" . $this->final_feed_url;
      return $htmlinfo;
   }
   
   function getData() {
      $retvals = array();
      // check for extra URL stuff added
      $this->finalizeFeedURLs();
      if (function_exists('fetch_rss')) {
         if ($this->debug) {
            $this->logDebug("Fetching Feed:  $this->final_feed_url <br>\n");
         }
         define('MAGPIE_CACHE_ON', TRUE);
         define('MAGPIE_FETCH_TIME_OUT', 2400);
         $rss = fetch_rss($this->final_feed_url);
         #print_r($rss->items);
         $elements = array();
         $linklist = $rss->items;
         // this currently only works if we have a valid data column, or collection of date columns (year, mo, day)
         $valid_datecol = 0;
         switch ($this->single_datecol) {
            case 1:
               if ($this->datecolumn <> '') {
                  // check to see if this has a date returned
                  $firstrec = $linklist[min(array_keys($linklist))];
                  if ($this->debug) {
                     $this->logDebug("First record returned = " . print_r($firstrec, 1) . " <br>\n");
                  }
                  if (isset($firstrec[$this->datecolumn])) {
                     $valid_datecol = 1;
                  }
               }
            break;
            
         }
         
         if ($valid_datecol) {
            $retvals = $linklist;
            if ($this->debug) {
               $this->logDebug("Feed returned " . count($retvals) . " records <br>\n");
            }
         } else {
            if ($this->debug) {
               $this->logDebug("Date column $this->datecolumn not in feed <br>\n");
               $this->logDebug("Feed returned " . count($linklist) . " records <br>\n");
               $this->logDebug("MagpieRSS errors:" . $rss->ERROR . " <br>\n");
               $this->logDebug("MagpieRSS warnings:" . $rss->WARNING . " <br>\n");
               $this->logDebug("MagpieRSS object:" . print_r((array)$rss,1) . " <br>\n");
            }
         }
         
         
      } else {
         $this->logError("Error Retrieving Data: RSS Magpie function 'fetch_rss' is not defined - can not retrieve feed.");
      }
      
      $this->dbobject->queryrecords = array();
      foreach ($retvals as $thisrec) {
         $this->dbobject->queryrecords[] = $thisrec;
      }
   }
   
   function finalizeFeedURLs() {
      // this will incorporate any local properties, and check to make sure that the url is formed OK,
      // this creates a finalized feed url, AND a finalized data_inventory_url so that we don't try to get 
      // data that does not exist
      if (!$this->urls_finalized) {
         $extras = $this->subLocalProperties($this->final_extra_variables); 
         $url = ltrim(rtrim($this->feed_address));
         $this->final_feed_url = $this->appendExtrasToURL($url, $extras);
         if ($this->debug) {
            $this->logDebug("Final Query URL: $this->final_feed_url <br>\n");
         }
         //error_log("Final Query URL: $this->final_feed_url <br>\n");

         // only do this if we actually HAVE a data_inventory_address set
         if (strlen($this->data_inventory_address) > 0) {
            $extras = $this->subLocalProperties($this->final_extra_variables); 
            $url = ltrim(rtrim($this->data_inventory_address));
            $this->final_data_inventory_address = $this->appendExtrasToURL($url, $extras);
            if ($this->debug) {
               $this->logDebug("Final Inventory URL: $this->final_data_inventory_address <br>\n");
            }
            //error_log("Final Inventory URL: $this->final_data_inventory_address <br>\n");
         }
         $this->urls_finalized = 1;
      }
   }
   
   function processLocalExtras() {
      // this is just a stub
   }
   
   function appendExtrasToURL($url, $extra_variables) {
      $extras = preg_split("/((\r(?!\n))|((?<!\r)\n)|(\r\n))/", $this->subLocalProperties($extra_variables)); 
      $url = ltrim(rtrim($url));
      $udel = '';
      $callpieces = preg_split('[\/]', $url);
      $lastpiece = $callpieces[(count($callpieces) - 1)];
      if (!strpos($lastpiece, '?')) {
         // this URL has not parameters appended to it, so we have to add the '?' before appending parameters
         $url .= '?';
      } else {
         if (substr($url,-1) <> '?') {
            // the URL already contains a ? AND has a parameter after the ?, so set the delimiter to '&'
            $udel = '&';
         }
      }
      foreach ($extras as $thisextra) {
         if (strlen(ltrim(rtrim($thisextra))) > 0) {
            $url .= $udel . ltrim(rtrim($thisextra));
            $udel = '&';
         }
      }
      $final_url = $url;
      if ($this->debug) {
         $this->logDebug("Final Query URL: $url <br>\n");
      }
      //error_log("Final Query URL: $url <br>\n");
      return $url;
   }

   function createQuery() {
      // dummy function, not needed in XML object
   }
   
}

class CBPDataConnection extends dataConnectionObject {
   # this is temporary, later, it will be a strictly XML affair, but for now, I am hardwiring this as a postgresql object
   # with some special add-ons to make auto-population easier
   var $scid = -1;
   var $id1 = ''; # model data class: river, land, or met
   var $id2 = ''; # model segment: i.e., PU2_2790_3290
   var $max_memory_values = 1000;
   var $username = 'cbp_ro';
   var $password = 'CbPF!v3';
   var $dbname = 'cbp';
   var $host = 'localhost';
   
   function init() {
      $this->reCreate();
      parent::init();
   }
   
   function wake() {
      $this->reCreate();
      parent::wake();
   }
   
   function reCreate() {
      $this->createQuery();
      parent::reCreate();
   }
   
   function step() {
      parent::step();
   }

   function showHTMLInfo() {
      $htmlinfo = parent::showHTMLInfo();

      # puts columns from query into state array
      list($river, $segid, $destid) = split('_', $this->id2);
      $seginfo = getCBPSegmentLanduse($this->dbobject, $this->scid, $segid);
      if (!is_object($this->dbobject)) {
         $this->setupDBConn(1);
      }
      if (is_object($this->dbobject)) {
         $this->dbobject->queryrecords = $seginfo['local_annual'];
         $this->dbobject->show = 0;
         $this->dbobject->showList();
         //$htmlinfo .= "Segment Land Uses: <br>$this->scid, $segid :<br>" . print_r($seginfo,1);
         $htmlinfo .= "<hr>Local Annual Land Uses:<br>" . $this->dbobject->outstring;
         $this->dbobject->queryrecords = $seginfo['contrib_annual'];
         $this->dbobject->showList();
      }
      $htmlinfo .= "<hr>Total Upstream Land Uses:<br>" . $this->dbobject->outstring;
      return $htmlinfo;
   }
   
   function createQuery() {

      $this->sql_query = "  select a.td as thisdate, ";
      $this->sql_query .= "    CASE WHEN b.meanvalue is NULL THEN 0.0 ";
      $this->sql_query .= "       ELSE b.meanvalue ";
      $this->sql_query .= "    END as ivol, ";
      $this->sql_query .= "    CASE WHEN c.meanvalue is NULL THEN 0.0 ";
      $this->sql_query .= "       ELSE c.meanvalue ";
      $this->sql_query .= "    END as ovol, ";
      $this->sql_query .= "    CASE WHEN d.meanvalue is NULL THEN 0.0 ";
      $this->sql_query .= "       ELSE d.meanvalue ";
      $this->sql_query .= "    END as oheat, ";
      $this->sql_query .= "    CASE WHEN e.meanvalue is NULL THEN 0.0 ";
      $this->sql_query .= "       ELSE e.meanvalue";
      $this->sql_query .= "    END as iheat, ";
      $this->sql_query .= "    CASE WHEN f.meanvalue is NULL THEN 0.0 ";
      $this->sql_query .= "       ELSE f.meanvalue * 24.0 ";
      $this->sql_query .= "    END as prec , ";
      $this->sql_query .= "    CASE WHEN g.meanvalue is NULL THEN 0.0 ";
      $this->sql_query .= "       ELSE g.meanvalue * 24.0 ";
      $this->sql_query .= "    END as et ";
      // END - if using heat
      // this just gets any and all dates for this particular location id
      $this->sql_query .= " from (";
      $this->sql_query .= "    select date_trunc('day',thisdate) as td ";
      $this->sql_query .= "    from cbp_scenario_output where location_id in ";
      $this->sql_query .= "       (select location_id from cbp_model_location where id1 = '$this->id1' ";
      $this->sql_query .= "           and id2 = '$this->id2'";
      $this->sql_query .= "           and scenarioid = '$this->scid'";
      $this->sql_query .= "       ) ";
      $this->sql_query .= "       group by td order by td";
      $this->sql_query .= " ) as a left outer join ";
      // inflow (IVOL)
      $this->sql_query .= " (";
      $this->sql_query .= "    select date_trunc('day',thisdate) as td, avg(thisvalue) as meanvalue ";
      $this->sql_query .= "    from cbp_scenario_output where location_id in ";
      $this->sql_query .= "       (select location_id from cbp_model_location where id1 = '$this->id1' ";
      $this->sql_query .= "           and id2 = '$this->id2'";
      $this->sql_query .= "           and scenarioid = '$this->scid'";
      $this->sql_query .= "       ) ";
      $this->sql_query .= "       and param_name = 'IVOL' group by td order by td";
      $this->sql_query .= " ) as b  ";
      $this->sql_query .= " on ( a.td = b.td ) left outer join ";
      $this->sql_query .= " (";
      $this->sql_query .= "    select date_trunc('day',thisdate) as td, avg(thisvalue) as meanvalue ";
      $this->sql_query .= "    from cbp_scenario_output where location_id in ";
      $this->sql_query .= "       (select location_id from cbp_model_location where id1 = '$this->id1' ";
      $this->sql_query .= "           and scenarioid = '$this->scid'";
      $this->sql_query .= "           and id2 = '$this->id2'";
      $this->sql_query .= "    ) ";
      $this->sql_query .= "    and param_name = 'OVOL' group by td order by td";
      $this->sql_query .= " ) as c ";
      $this->sql_query .= " on ( a.td = c.td ) ";
      $this->sql_query .= " left outer join ";
      // if using heat
      $this->sql_query .= " (";
      $this->sql_query .= "    select date_trunc('day',thisdate) as td, avg(thisvalue) as meanvalue ";
      $this->sql_query .= "    from cbp_scenario_output where location_id in ";
      $this->sql_query .= "       (select location_id from cbp_model_location where id1 = '$this->id1' ";
      $this->sql_query .= "           and id2 = '$this->id2'";
      $this->sql_query .= "           and scenarioid = '$this->scid'";
      $this->sql_query .= "    ) ";
      $this->sql_query .= "    and param_name = 'OHEAT' group by td order by td";
      $this->sql_query .= " ) as d ";
      $this->sql_query .= " on ( a.td = d.td ) ";
      $this->sql_query .= " left outer join ";
      // if using heat
      $this->sql_query .= " (";
      $this->sql_query .= "    select date_trunc('day',thisdate) as td, avg(thisvalue) as meanvalue ";
      $this->sql_query .= "    from cbp_scenario_output where location_id in ";
      $this->sql_query .= "       (select location_id from cbp_model_location where id1 = '$this->id1' ";
      $this->sql_query .= "           and id2 = '$this->id2'";
      $this->sql_query .= "           and scenarioid = '$this->scid'";
      $this->sql_query .= "    ) ";
      $this->sql_query .= "    and param_name = 'IHEAT' group by td order by td";
      $this->sql_query .= " ) as e ";
      $this->sql_query .= " on ( a.td = e.td ) ";
      // END - if using heat
      // if using precip
      $this->sql_query .= " left outer join ";
      $this->sql_query .= " (";
      $this->sql_query .= "    select date_trunc('day',thisdate) as td, avg(thisvalue) as meanvalue ";
      $this->sql_query .= "    from cbp_scenario_output where location_id in ";
      $this->sql_query .= "       (select location_id from cbp_model_location where id1 = '$this->id1' ";
      $this->sql_query .= "           and id2 = '$this->id2'";
      $this->sql_query .= "           and scenarioid = '$this->scid'";
      $this->sql_query .= "    ) ";
      $this->sql_query .= "    and param_name = 'PREC' group by td order by td";
      $this->sql_query .= " ) as f ";
      $this->sql_query .= " on ( a.td = f.td ) ";
      // END - if using precip
      // if using et
      $this->sql_query .= " left outer join ";
      $this->sql_query .= " (";
      $this->sql_query .= "    select date_trunc('day',thisdate) as td, avg(thisvalue) as meanvalue ";
      $this->sql_query .= "    from cbp_scenario_output where location_id in ";
      $this->sql_query .= "       (select location_id from cbp_model_location where id1 = '$this->id1' ";
      $this->sql_query .= "           and id2 = '$this->id2'";
      $this->sql_query .= "           and scenarioid = '$this->scid'";
      $this->sql_query .= "    ) ";
      $this->sql_query .= "    and param_name = 'POTEV' group by td order by td";
      $this->sql_query .= " ) as g ";
      $this->sql_query .= " on ( a.td = g.td ) ";
      // END - if using et
      $this->sql_query .= " order by a.td ";
      
      parent::reCreate();
   }

}


class CBPLandDataConnection extends XMLDataConnection {
//class CBPLandDataConnection extends RSSDataConnection {
   var $feed_address = 'http://deq1.bse.vt.edu/wooommdev/remote/rss_cbp_land_data.php?actiontype=4';
   var $data_inventory_address = 'http://deq1.bse.vt.edu/wooommdev/remote/rss_cbp_land_data.php?actiontype=1'; 
   var $extra_variables = "startdate=[startdate]\nenddate=[enddate]"; // a list of key=value pairs entered in a text field, if there are carriage returns, it will concatenate them along URL lines with &


   // element for connecting to land use parameters, and outputs, 
   // with a facility for multiplying outputs by the land use areas DataMatrix
   // for modeling the landuse change effects
   var $lunames = array();
   var $scid = -1;
   var $id1 = 'land'; # model data class: river, land, or met
   var $id2 = ''; # land segment: i.e., A24001
   var $riverseg = ''; // optional, this will only be used during calls to "create()" method, restricting the historical land use to the given river and land segment intersection
   var $max_memory_values = 500;
   var $username = 'cbp_ro';
   var $password = 'CbPF!v3';
   var $dbname = 'cbp';
   var $host = 'localhost';
   var $locationid = -1;
   var $conntype = 7;
   var $romode = 'component';
   var $hspf_timestep = 3600.0;
   var $serialist = 'lunames';
   var $datecolumn = 'thisdatetime';
   var $landuse_var = 'landuse'; // this allows the user to switch between land use matrices
   var $mincache = 1024; // file size for automatic cache refresh, if file is not at least 1k, we might have a problem
  
   function init() {
      parent::init();
      //$this->getLandUses();
   }
   function setState() {
      parent::setState();
      $this->state['Qout'] = 0.0;
      $this->state['area_ac'] = 0.0;
      $this->state['area_sqmi'] = 0.0;
      $this->state['Qafps'] = 0.0;
      $this->state['suro'] = 0.0;
      $this->state['ifwo'] = 0.0;
      $this->state['agwo'] = 0.0;
      $this->state['in_ivld'] = 0.0;
      $this->state['landuse_var'] = $this->landuse_var;
   }
   
   function setDataColumnTypes() {
      parent::setDataColumnTypes();
      
      $statenums = array('Qout','area_ac','Qafps', 'suro', 'ifwo', 'agwo', 'prec', 'area_sqmi', 'in_ivld');
      foreach ($statenums as $thiscol) {
         $this->dbcolumntypes[$thiscol] = 'float8';
         $this->data_cols[] = $thiscol;
         $this->logformats[$thiscol] = '%s';
      }
      $this->dbcolumntypes['substrateclass'] = 'varchar(2)';
      $this->dbcolumntypes['landuse_var'] = 'varchar(255)';
      
   }
   
   function wake() {
      parent::wake();
      $this->datatemp = 'tmp_crosstab' . $this->componentid;
      $this->lunames = array();
      $this->getLandUses();
   }

   function step() {
      // all step methods MUST call preStep(),execProcessors(), postStep()
      $this->preStep();
      if ($this->debug) {
         $this->logDebug("$this->name Inputs obtained. thisdate = " . $this->state['thisdate']);
      }
      // execute sub-components
      $this->execProcessors();
      if ($this->debug) {
         $this->logDebug("<b>$this->name Sub-processors executed at hour " . $this->state['hour'] . " on " . $this->state['thisdate'] . " week " . $this->state['week'] . " month " . $this->state['month'] . ".</b><br>\n");
      }
      // now do local flow routing manipulations
      // need to multiply landuse matrix values by the appropriate ifow, agwo, and suro for that land use
      // aggregate the results into a Qout variable or some area weighted value as well
      // get landuse matrix
      $Qout = 0.0;
      $Qafps = 0.0;
      $area_ac = 0.0;
      $landuse_var = $this->state['landuse_var'];
      $thisyear = $this->state['year'];
      if (!($thisyear > 0)) {
         if ($this->debug) {
            $this->logDebug("Something is wrong with the year in the state array calling setStateTimerVars()<br>\n");
         }
         $this->setStateTimerVars();
         $thisyear = $this->state['year'];
      }
      switch ($this->romode) {
         case 'component':
            $flow_comps = array('suro', 'ifwo', 'agwo');
         break;
         
         case 'merged':
            $flow_comps = array('in_ivld');
         break;
      }
         
      $other_comps = array('prec');
      $comp_vals = array('suro'=>0.0, 'ifwo'=>0.0, 'agwo'=>0.0, 'prec'=>0.0, 'in_ivld'=>0.0);
      /*
      // test, if no 'landuse_current' sub-comp is set, draw from the landuse_historic matrix
      // this doesn't work just yet
      // schema should use "landusevar" and "landuseyear", where landusevar is the name of a matrix
      // and landuseyear specifies either a static year, the model property "thisyear" or a reference 
      // to another variable.
      // if "landuseyear" variable is not set as a sub-component, can default to use prop "thisyear"
      // if "landusevar" component is not set, default to "landuse_historic"
      // landuse_year can be a matrix, keyed on run_mode, such that:
      // 0 = some year in history (lets say 1850)
      // 1 = thisyear
      // 2 = some year representing current conditions (say 2005)
      // if "landuse_historic" is not set, then we bail, otherwise we should be good to go
      // this should maintain backward compatibility with previous incarnations of the model which 
      // used separate landuse_var settings and matrices, but did not specify a landuse_year, 
      // so long as landuse_year defaults to thisyear
      
      if ( isset($this->processors[$landuse_var]) or ( ($landuse_var == 'landuse_current') and isset($this->processors['landuse_historic']) ) ) {
         // if the "current" land use is not set,  
         if (($landuse_var == 'landuse_current') and !isset($this->processors['landuse_current']) ) {
            $landuse_matrix = $this->processors['landuse_historic'];
            $luyear = $this->current_lu_year;
      */      
      if ( isset($this->processors[$landuse_var]) ) {
         $landuse_matrix = $this->processors[$landuse_var];
         // get the values for the land uses
         $landuse_matrix->formatMatrix();
         if ($this->debug) {
            $this->logDebug("Getting land use values for year $thisyear<br>\n");
         }
         $lumatrix = $landuse_matrix->matrix_formatted;
         foreach ($lumatrix as $luname=>$values) {
            $luarea = $landuse_matrix->evaluateMatrix($luname, $thisyear);
            if (is_numeric($luarea)) {
               if ($this->debug) {
                  $this->logDebug("Found Land use $luname with area $luarea<br>\n");
               }
               $area_ac += $luarea;
               // only evaluate this if the land use area is > 0.0
               if ($luarea > 0) {
                  foreach ($flow_comps as $thiscomp) {
                     // this is the expected format of this variable, i.e. for_ifwo
                     $lu_flowvar = $luname . '_' . $thiscomp;
                     if ($this->debug) {
                        $this->logDebug("Evaluating $lu_flowvar = " . $this->state[$lu_flowvar]);
                        $this->logDebug("<br>\n");
                     }
                     if (isset($this->state[$lu_flowvar])) {
                        // converts from watershed in/ivld to watershed ft/ivld (/12.0)
                        // to acre-feet/ivld (* luarea)
                        // to cubic-feet (* 43560 ft-per-acre)
                        // to cfs (/timestep)
                        $thisflow = ( ($this->state[$lu_flowvar]/12.0) * $luarea * 43560.0) / $this->hspf_timestep;
                        $comp_vals[$thiscomp] += $thisflow;
                        $Qout += $thisflow;
                     }
                  }
                  foreach ($other_comps as $thiscomp) {
                     // this is the expected format of this variable, i.e. for_ifwo
                     $lu_flowvar = $luname . '_' . $thiscomp;
                     if (isset($this->state[$lu_flowvar])) {
                        // converts from watershed in/ivld to watershed ft/ivld (/12.0)
                        // to acre-feet/ivld (* luarea)
                        // to cubic-feet (* 43560 ft-per-acre)
                        // to cfs (/timestep)
                        // weight this comp by the land use area, then later we will un-weight it when we store in the state var
                        switch ($thiscomp) {
                           case 'prec':
                           // since precip is given as a rate in the model output, we have to convert it to a quantity
                              $thisflow = $this->state[$lu_flowvar] * $luarea * ($this->timer->timestep / $this->hspf_timestep);
                           break;

                           default:                           
                              $thisflow = $this->state[$lu_flowvar] * $luarea;
                           break;
                        }
                        $comp_vals[$thiscomp] += $thisflow;
                     }
                  }
               }
            }
         }
         $Qafps = $Qout / ($area_ac * 43560.0);
         if ($this->debug) {
            $this->logdebug("Qout = $Qout <br>\n");
            $this->logdebug("luarea = $luarea <br>\n");
            $this->logdebug("Qafps = $Qout / ($area_ac * 43560.0) <br>\n");
         }
      } else {
         if ($this->debug) {
            $this->logdebug("landuse sub-component not found <br>\n");
         }
      }
      $this->state['Qout'] = floatval($Qout);
      $this->state['area_ac'] = floatval($area_ac);
      $this->state['area_sqmi'] = floatval($area_ac) / 640.0;
      $this->state['Qafps'] = floatval($Qafps);
      $this->state['suro'] = floatval($comp_vals['suro']);
      $this->state['agwo'] = floatval($comp_vals['agwo']);
      $this->state['ifwo'] = floatval($comp_vals['ifwo']);
      $this->state['in_ivld'] = floatval($comp_vals['in_ivld']);
      foreach ($other_comps as $thiscomp) {
         // un-weight these other components now, since we want raw, not converted values
         $this->state[$thiscomp] = floatval($comp_vals[$thiscomp] / $area_ac);
      }
      
      // log the results
      if ($this->debug) {
         $this->logDebug("$this->name Calling Logstate() thisdate = ");
      }
      $this->postStep();
   }

   function showHTMLInfo() {
      $HTMLInfo = '';
      $HTMLInfo .= parent::showHTMLInfo() . "<hr>";
      if (is_object($this->dbobject)) {
         $HTMLInfo .= "<b>DB Info: </b>" . $this->dbobject->dbconn . "<hr>";
      //$this->getLandUses();
      } else {
         $HTMLInfo .= "<b>DB Error: </b> DB Object not valid <hr>";
         $this->setupDBConn(1);
      }
      $HTMLInfo .= "<b>Land Uses: </b>" . print_r($this->lunames,1) . "<hr>";

      if (isset($this->processors[$this->landuse_var])) {
         if (is_object($this->processors[$this->landuse_var])) {
            $HTMLInfo .= '<b>Land Use:</b><br>' . $this->processors[$this->landuse_var]->showHTMLInfo();
            $check_sum = $this->processors[$this->landuse_var]->checkSumCols();
            $HTMLInfo .= 'Check Sum: '. print_r($check_sum,1) . "<br>";
         } else {
            $HTMLInfo .= "Sub-component named 'landuse' is not an object.<br>";
         }
      } else {
         $HTMLInfo .= "Unabled to find sub-component named '$landuse_var' in:<br>";
         $HTMLInfo .= print_r(array_keys($this->processors),1) . "<br>";
      }
      
      $seginfo = $this->getHistoricLandUses();
      $HTMLInfo .= "<hr>Query:<br>" . $seginfo['debug'];
      $this->dbobject->queryrecords = $seginfo['local_annual'];
      $this->dbobject->show = 0;
      $this->dbobject->showList();
         
      $HTMLInfo .= "<hr>Local Land Uses:<br>" . $this->dbobject->outstring;
      return $HTMLInfo;
   }
   
   function getHistoricLandUses() {
      
      if (!is_object($this->dbobject)) {
         $this->conntype = 1; // set temporarily to pgsql
         $this->setupDBConn(1);
         $this->conntype = 7; // set temporarily to pgsql
      }
      if (is_object($this->dbobject)) {
         if (strlen($this->riverseg) > 0) {
            $riverseg = $this->riverseg;
         } else {
            $riverseg = NULL;
         }
         $seginfo = getCBPLandSegmentLanduse($this->dbobject, $this->scid, $this->id2 , $this->debug, $riverseg);
         if ($this->debug) {
            $this->logDebug($seginfo['debug']);
         }
      }
      return $seginfo;
   }
   
   function getModelOutputData($type = 'flowsum', $landuses = '') {
      
      if (!is_object($this->dbobject)) {
         $this->conntype = 1; // set temporarily to pgsql
         $this->setupDBConn(1);
         $this->conntype = 7; // set temporarily to pgsql
      }
      if (is_object($this->dbobject)) {
         if (strlen($this->riverseg) > 0) {
            $riverseg = $this->riverseg;
         } else {
            $riverseg = NULL;
         }
         if (strlen($landuses) > 0) {
            $lus = split(',', $landuses);
         } else {
            $lus = $this->lunames;
         }
         
         $seginfo = array();
         $this->dbobject->querystring = '';
         switch ($type) {
            case 'flowsum':
            sort($lus);
            foreach ($lus as $thislu) {
               $this->dbobject->querystring = $this->landSegOutputQuery('',$thislu);
               if ($this->debug) {
                  $this->logDebug($this->dbobject->querystring . "<br>");
               }
               $this->dbobject->performQuery();
               $recs = $this->dbobject->queryrecords;
               foreach ($recs as $thisrec) {
                  $seginfo[$thisrec['thisyear']]['thisyear'] = $thisrec['thisyear'];
                  $seginfo[$thisrec['thisyear']][$thislu . '_cfs'] = round($thisrec['ro_cfs'],2);
               }
            }
            break;
            
            case 'runoffsum':
            $q = $this->landSegOutputQuery('SURO');
            $basetab = "( $q ) as foo ";
            $this->dbobject->querystring = doGenericCrossTab ($dbobject, $basetab, 'lseg,thisyear', 'landuse', 'ro_cfs', 1, 0);
            break;
            
            case 'baseflowsum':
            $q = $this->landSegOutputQuery('AGWO');
            $basetab = "( $q ) as foo ";
            $this->dbobject->querystring = doGenericCrossTab ($dbobject, $basetab, 'lseg,thisyear', 'landuse', 'ro_cfs', 1, 0);
            break;
            
            case 'interflowsum':
            $q = $this->landSegOutputQuery('IFWO');
            $basetab = "( $q ) as foo ";
            $this->dbobject->querystring = doGenericCrossTab ($dbobject, $basetab, 'lseg,thisyear', 'landuse', 'ro_cfs', 1, 0);
            break;
            
         }
      }
         
      return $seginfo;
   }

   function landSegOutputQuery($flowparam = '', $luname = '') {
      $query = "  select lseg, landuse, extract(year from thisday) as thisyear, ";
      $query .= "    sum(thisvalue) as runoff, ";
      $query .= "    (avg(thisvalue / 12.0 * 640.0 * 43560.0/3600.0)/24.0) as ro_cfs, ";
      $query .= " sum(numrecs) ";
      $query .= " from (";
      $query .= "   select c.thisdate::date as thisday, b.location_id, b.id2 as lseg, ";
      $query .= "      b.id3 as landuse, sum(c.thisvalue) as thisvalue, count(c.*) as numrecs ";
      $query .= "   from cbp_model_location as b, cbp_scenario_output as c";
      $query .= "      where ";
      $query .= "       c.location_id = b.location_id";
      // restrict land uses?
      if (strlen($flowparam) > 0) {
         $query .= "      and c.param_name in ( '" . join("','",split(",", $flowparam)) . "') ";
      } else {
         $query .= "      and c.param_name in ( 'SURO' , 'IFWO', 'AGWO') ";
      }
      $query .= "      and b.id2 = '$this->id2' ";
      // restrict land uses?
      if (strlen($luname) > 0) {
         $query .= "      and b.id3 in ( '" . join("','",split(",", $luname)) . "') ";
      }
      $query .= "      and b.scenarioid = $this->scid ";
      $query .= "   group by thisday, b.id2, b.location_id, b.id3 ";
      $query .= "   order by thisday, b.id2, b.id3 ";
      $query .= " ) as foo ";
      $query .= " group by lseg, thisyear, landuse ";
      $query .= " order by lseg, landuse, thisyear ";
      return $query;
   }

   
   function create() {
      if ($this->debug) {
         $this->logDebug("Processors on this object before create(): " . print_r(array_keys($this->processors),1) . " <br>");
      }
      parent::create();
      if ($this->debug) {
         $this->logDebug("Processors after parent create(): " . print_r(array_keys($this->processors),1) . " <br>");
      }
      // set default land use
      // set basic data query
      $this->logDebug("Create() function called <br>");
      $this->lunames = array();
      //return;
      $this->getLandUses();
      
      if (count($this->lunames) == 0) {
         // if there are none set, just hit some defaults
         $this->lunames = array('for');
      }
      sort($this->lunames);
      
      $this->logDebug("Object landuses: " . print_r($this->lunames,1) . " <br>");
      
      if (isset($this->processors['landuse'])) {
         unset($this->processors['landuse']);
      }
      // landuse subcomponent to allow users to simulate land use values
      $ludef = new dataMatrix;
      $ludef->listobject = $this->listobject;
      $ludef->name = 'landuse';
      $ludef->wake();
      $ludef->numcols = 3;  
      $ludef->valuetype = 2; // 2 column lookup (col & row)
      $ludef->keycol1 = ''; // key for 1st lookup variable
      $ludef->lutype1 = 0; // lookp type - exact match for land use name
      $ludef->keycol2 = 'year'; // key for 2nd lookup variable
      $ludef->lutype2 = 1; // lookup type - interpolated for year value
      // add a row for the header line
      $ludef->numrows = count($this->lunames) + 1;
      // since these are stored as a single dimensioned array, regardless of their lookup type 
      // (for compatibility with single dimensional HTML form variables)
      // we set alternating values representing the 2 columns (luname - acreage)
      $ludef->matrix[] = 'luname - year(acres)';
      $ludef->matrix[] = 1980; // put this year in the date field as a default lower limit
      $ludef->matrix[] = date('Y'); // put current year in the date field as a default upper limit
      foreach ($this->lunames as $thisname) {
         $ludef->matrix[] = $thisname;
         $ludef->matrix[] = 0.0;
         $ludef->matrix[] = 0.0;
      }
      if ($this->debug) {
         $this->logDebug("Trying to add land use sub-component matrix with values: " . print_r($ludef->matrix,1) . " <br>");
      }
      $this->addOperator('landuse', $ludef, 0);
      
      // hiastoric landuse subcomponent to allow users access to model simulated land uses
      $luhist = new dataMatrix;
      $luhist->listobject = $this->listobject;
      $luhist->name = 'landuse_historic';
      $luhist->wake();
      $luhist->valuetype = 2; // 2 column lookup (col & row)
      $luhist->keycol1 = ''; // key for 1st lookup variable
      $luhist->lutype1 = 0; // lookp type - exact match for land use name
      $luhist->keycol2 = 'year'; // key for 2nd lookup variable
      $luhist->lutype2 = 1; // lookup type - interpolated for year value
      // add a row for the header line
      $hist_result = $this->getHistoricLandUses();
      $luhist->assocArrayToMatrix($hist_result['local_annual']);
      if ($this->debug) {
         $this->logDebug("Trying to add historic land use sub-component matrix with values: " . print_r($luhist->matrix,1) . " <br>");
      }
      $this->addOperator('landuse_historic', $luhist, 0);
      if ($this->debug) {
         $this->logDebug("Processors on this object: " . print_r(array_keys($this->processors),1) . " <br>");
      }
   }

   function getData() {
      // restrict the land uses to non-zero values set in the landuse DataMatrix if the use has not explicitly
      // proceed with parent getData routine
      parent::getData();
   }
   
   function restrictLandUses() {
      // check the extra_variables field for id3 (luname) parameter
      // if this is NOT set by the user, then go ahead and look for non-zero entries 
      // in the landuse DataMatrix and append the extra_variables field with a land use criteria 
      // to only get non-zero land uses.  This should speed up the execution time of the XML data query
      $extras = preg_split("/((\r(?!\n))|((?<!\r)\n)|(\r\n))/", $this->subLocalProperties($this->final_extra_variables));
      $edel = ''; // assume no extras to start, if we have them then we will make this a carriage return
      $e_keys = array(); // hold the keys for any extra variables here
      foreach ($extras as $thisextra) {
         list($key, $value) = split("=", $thisextra);
         $edel = "\n";
         // stow the keys in the e_keys array for searching later
         $e_keys[] = $key;
      }
      
      if (!in_array('id3', $e_keys)) {
         $nz_landuses = array();
         // user has NOT asked for specific land uses, thus, restrict the query of land uses to our non-zero ones
         // defined in the landuse DataMatrix
         if (isset($this->processors['landuse'])) {
            $landuse_matrix = $this->processors['landuse'];
            // get the values for the land uses, if there are NO non-zero land uses, we will not retrieve data 
            // call formatMatrix routine, then look in the rows for each land use for non-zero values
            // WE Should look within the start and end dates of this simulation and ONLY retrieve values within 
            // the current start and end dates, but for now, we will retrieve if ANY non-zero values occur
            // later we can figure out a smart way to do this to improve efficiency
            $landuse_matrix->formatMatrix();
            $lumatrix = $landuse_matrix->matrix_formatted;
            foreach ($lumatrix as $luname=>$values) {
               foreach ($values as $year => $luarea) {
                  if ($luarea > 0) {
                     $nz_landuses[] = $luname;
                  }
               }
            }
         } else {
            $this->logdebug("landuse sub-component not found <br>\n");
         }
         $rstring = 'id3=-1'; // send a dummy that will not match by default (no landuses)
         if (count($nz_landuses) > 0) {
            $rstring = $edel . 'id3=' . join(",", $nz_landuses);
         }
         $this->final_extra_variables .= $edel . $rstring;
         if ($this->debug) {
            $this->logDebug("restricting land uses with $rstring <br>\n");
         }
      }
         
   }
   
   function getLandUses() {
      
      // the landuse_names are stashed in the retrieval 'feed_inventory' variable 
      
      if (isset($this->feed_inventory['landuse_names'])) {
         $lu_csv = $this->feed_inventory['landuse_names'];
         //error_log("Lu CSV: " . $lu_csv . "<br>\n");
         //return;
         foreach (split(",",$lu_csv) as $thislu) {
            if ( !in_array($thislu, $this->lunames) ) {
               $this->lunames[] = $thislu;
            }
         }
         //error_log("Lu Array: " . print_r($this->lunames,1) . "<br>\n");
      }
   }

   
   function processLocalExtras() {
      // this will incorporate any local properties, and check to make sure that the url is formed OK,
      // this needs to be slightly different from the parent finalizeFeedURLs() method, so we sub-class it 
      // set our extra parameters, then call the parent method
      if (!$this->urls_finalized) {
         // final_extra_variables should be a copy of extra_variables, but if anything was appended priot, we will use it
         $extra_variables = $this->final_extra_variables;
         // check for extras, if we have some, append a newline, then the id1, and id2 props set in our object props
         $extras = preg_split("/((\r(?!\n))|((?<!\r)\n)|(\r\n))/", $this->subLocalProperties($extra_variables));
         $edel = '';
         foreach ($extras as $thisextra) {
            if (strlen(ltrim(rtrim($thisextra))) > 0) {
               $edel = "\n";
            }
         }
         // now append local properties
         $extra_variables .= $edel . 'id1=' . $this->id1;
         $edel = "\n";
         $extra_variables .= $edel . 'id2=' . $this->id2;
         $extra_variables .= $edel . 'timestep=' . $this->dt;
         $extra_variables .= $edel . 'scenarioid=' . $this->scid;
         $extra_variables .= $edel . 'romode=' . $this->romode;
         // now, set the extra_variables property to this expanded version and call the parent routine
         $this->final_extra_variables = $extra_variables;
         if ($this->debug) {
            $this->logDebug("Final Extra Variables: $extra_variables <br>\n");
         }
         //error_log("Final Query URL: $url <br>\n");
         // adds our land uses to the extra_variables parameter
         // this would speed things up, but unfortunately, we cannot do this because "landuse" is a sub-component
         // and by definition cannot be awoken until AFTER the parent is awoken.  need to rethink this if 
         // this causes a significant performance hit
         //$this->restrictLandUses();
      }
   }

}

class CBPDataInsert extends modelObject {
   // time series for inserting data into CBP mode container table
   // users and db admins should be very judicious about using these, as they involve having a username and 
   // password for an account that has write access to one or more tables.   In this specific case, they only 
   // have write access to one table, cbp_scenario_output
   function wake() {
      parent::wake();
   }
   
   function init() {
      parent::init();
   }   
}

class queryWizardComponent extends modelSubObject {

   var $goutdir = '';
   var $gouturl = '';
   var $imgurl = '';
   var $maxreportrecords = 50; 
   # maximum number of records to actually show in the report string, above this defers to downloadable file
   var $value_dbcolumntype = 'varchar(1)'; // just a dummy since, we should not even need to dump this to a db table, since it is meaningless
   var $quote_tablename = 0; // if we have unorthodox tale names, we may 
   //need to quote them, but defalt to not, since we may be given a 
   //sub-query as a table, in which case quoting would goof it up
   # query specific properties
   # column props
   #var $qcols = array();
   #var $qcols_func = array();
   #var $qcols_alias = array();
   var $qcols;
   var $qcols_func;
   var $qcols_alias;
   var $qcols_txt; # text entry column, now it is manually entered, but this is unsafe, so we should soon make it a wizard type column
   # column props
   var $wcols = array();
   var $wcols_op = array();
   var $wcols_value = array();
   var $wcols_refcols = array();
   # order by props
   var $ocols = array();
   var $loggable = 0;


   # requires lib_plot.php to produce graphic output

   function setState() {
      parent::setState();
      /*
      $this->qcols = array('name','Qout','Qin');
      $this->qcols_func = array('','min','min');
      $this->qcols_alias = array('a','b','c');
      */
      $this->reportstring = '';
   }

   function wake() {
      parent::wake();
      /*
      $this->qcols = array('name','Qout','Qin');
      $this->qcols_func = array('','min','min');
      $this->qcols_alias = array('a','b','c');
      */
   }

   function step() {
      // all step methods MUST call getInputs(), execProcessors(),  and logstate()
      parent::step();
   }

   function evaluate() {
      # do nothing
      $this->result = NULL;
   }

   function finish() {
      # create query string, need to know parent name, or simply pass the SQL to the parent. hmm. which to do?
      $this->assembleQuery();

      $this->reportstring .= $this->sqlstring . "<br>";
      if (is_object($this->listobject)) {
         $this->listobject->queryrecords = $this->executeQuery();
         $this->listobject->show = 0;
         $this->listobject->showList();
         $filename = $this->list2file($this->listobject->queryrecords);
         #$filename = $this->list2file(array());
         if (count($this->listobject->queryrecords) <= $this->maxreportrecords) {
            $this->reportstring .= "<b>Query Output:</b><br> " . $this->listobject->outstring . "<br>";
         } else {
            $this->listobject->queryrecords = array_slice($this->listobject->queryrecords, 0, $this->maxreportrecords - 1);
            $this->listobject->show = 0;
            $this->listobject->showList();
            $this->reportstring .= "<b>Query Output:</b><br> " . $this->listobject->outstring . "<br><b>Max display records exceeded, download file (below) to view results.<br>";
         }
         $this->reportstring .= "<b>Download Data:</b><br> <a href=" . $this->outurl . '/' . $filename . ">Click Here</a><br>";
      }
   }
   
   function executeQuery() {

      if (is_object($this->listobject) and $this->parentobject->log2db) {
         $this->listobject->querystring = $this->sqlstring;
         $this->listobject->performQuery();
         $theserecs = $this->listobject->queryrecords;
      } else {
         $theserecs = array();
         $this->reportstring .= "<b>Query Error:</b><br> Query output requested on $this->name, but listobject not enabled. ";
         $this->reportstring .= "Be sure that 'Log to db' is selected in parent object: " . $this->parentobject->name . " <br>";
      }
      
      return $theserecs;
   }

   function assembleQuery() {
      $sqlstring = '';
      $ptable = $this->parentobject->dbtblname;

      # selected columns and any applied functions
      $selstring = '';
      $groupstring = '';
      $sdel = '';
      $gdel = '';
      # make sure we have all entries needed (even if blank)
      $scolumns = array(
         'qcols'=>$this->qcols,
         'qcols_func'=>$this->qcols_func,
         'qcols_alias'=>$this->qcols_alias,
         'qcols_txt'=>$this->qcols_txt
      );
      $tpa = $this->makeAssoc($scolumns);
      $qcolumns = $tpa['assoc_out'];
      foreach ($qcolumns as $thiscol) {
         $qcol = $thiscol['qcols'];
         $qfunc = $thiscol['qcols_func'];
         $qalias = $thiscol['qcols_alias'];
         $qtxt = $thiscol['qcols_txt'];
         $grpcol = $qcol; # assume we use the name, unless we have an alias
         if (strlen($qcol) > 0) {
            //list($funcopen, $funcclose) = $this->getFunctionFormat($qfunc);
            //$selstring .= "$sdel $funcopen \"$qcol\" $funcclose ";
            error_log("calling formatFunctionFull($qfunc, $qcol, $qtxt) ");
            $formatted = $this->formatFunctionFull($qfunc, $qcol, $qtxt);
            error_log("returned $formatted from formatFunctionFull ");
            $selstring .= "$sdel " . $formatted;
            $grpcol = $formatted;
            $sdel = ',';
            if (strlen($qalias) > 0) {
               $selstring .= " AS \"$qalias\"";
               //$grpcol = "\"$qalias\"";
            }
            if ( !$this->isAggregate($qfunc) ) {
               $groupstring .= "$gdel $grpcol ";
               $gdel = ',';
            }
         }
      }

      # condition clause
      $wdel = '';
      $wherestring = '';
      $wcolumns = array(
         'wcols'=>$this->wcols,
         'wcols_op'=>$this->wcols_op,
         'wcols_value'=>$this->wcols_value
      );
      $tpa = $this->makeAssoc($wcolumns);
      #$this->reportstring .= $tpa['debugstring'];
      $wcolumns = $tpa['assoc_out'];
      foreach ($wcolumns as $thiscol) {
         $wcol = $thiscol['wcols'];
         $wop = $thiscol['wcols_op'];
         $wval = $thiscol['wcols_value'];
         #$this->reportstring .= "Evaluating WHERE data: $wcol, $wop, $wval<br>";
         if (strlen($wcol) > 0) {
            # must have all three, a colunn, an operator, and a comparison value
            if (strlen($wop) > 0) {
               # Format this clause
               $subclause = $this->formatWhereClause($wop, $wcol, $wval);
               if (strlen($subclause) > 0) {
                  $wherestring .= "$wdel $subclause ";
                  $wdel = 'AND';
               }
            }
         }
      }
      
      if (ltrim(rtrim($selstring)) == '') {
         $selstring = '*';
      }
      $this->sqlstring = "SELECT $selstring FROM ";
      if ($this->quote_tablename) {
         $this->sqlstring .= " \"$ptable\" ";
      } else {
         $this->sqlstring .= " $ptable ";
      }
      if (strlen($wherestring) > 0) {
         $this->sqlstring .= " WHERE $wherestring ";
      }
      if (strlen($groupstring) > 0) {
         $this->sqlstring .= " GROUP BY $groupstring ";
      }
      $odel = '';
      $orderstring = '';
      
      if (!is_array($this->ocols) ) {
         if (strlen(rtrim(ltrim($this->ocols))) > 0) {
            $ocols = array($this->ocols);
         } else {
            $ocols = array();
         }
      } else {
         $ocols = $this->ocols;
      }
      if (count($ocols) > 0) {

         foreach ($ocols as $ocol) {
            if (strlen(rtrim(ltrim($ocol))) > 0) {
               $orderstring .= " $odel \"$ocol\"";
               $odel = ',';
            }
         }
      }
      
      if (strlen($orderstring) > 0) {
         $this->sqlstring .= " ORDER BY $orderstring ";
      }
   }
   
   function isAggregate($func) {
      
      $isagg = 0;
      switch ($func) {

         case 'none':
            $isagg = 0;
         break;

         case '':
            $isagg = 0;
         break;
         
         default:
            $isagg = 1;
         break;
         
      } 
      return $isagg;
   }
   
   function formatFunctionFull($func, $col, $params) {
      
      $formatted = '';
      if (function_exists('sanitize_sql_string')) {
         $paramsan = sanitize_sql_string($params);
      } else {
         $paramsan = '0';
      }
      switch ($func) {

         case 'none':
            $formatted = " \"$col\" ";
         break;

         case '':
            $formatted = " \"$col\" ";
         break;
         
         case 'min':
            $formatted = "min( \"$col\" ) ";
         break;

         case 'mean':
            $formatted = "avg( \"$col\" ) ";
         break;

         case 'median':
            $formatted = "median( \"$col\" ) ";
         break;

         case 'max':
            $formatted = "max( \"$col\" ) ";
         break;

         case 'gini':
            $formatted = "gini(array_accum( \"$col\" ) ";
         break;

         case 'quantile':
            $formatted = "r_quantile(array_accum( \"$col\" ), $paramsan ) ";
         break;

         case 'sum':
            $formatted = "sum( \"$col\" ) ";
         break;

         case 'count':
            $formatted = "count( \"$col\" ) ";
         break;

         case 'stddev':
            $formatted = "stddev( \"$col\" ) ";
         break;
         
         default:
            $formatted .= " $func ( \"$col\" ) ";
         break;
      }
      
      return $formatted;
   }

   function formatWhereClause($wop, $wcol, $wval) {
      $whereclause = '';

      //if (!is_numeric($wval)) {
      //   $wval = "'" . $wval . "'";
      //}

      switch ($wop) {
         case 'notnull':
            $whereclause = "\"$wcol\" IS NOT NULL ";
         break;
         
         case 'in':
            $whereclause = "\"$wcol\" IN ( $wval ) ";
         break;

         default:
            $whereclause = "\"$wcol\" $wop $wval ";
         break;
      }

      return $whereclause;
   }

   function getFunctionFormat($func) {

      $fopen = '';
      $fclose = '';

      switch ($func) {
         case 'min':
            $fopen = 'min(';
            $fclose = ')';
         break;

         case 'mean':
            $fopen = 'avg(';
            $fclose = ')';
         break;

         case 'median':
            $fopen = 'median(';
            $fclose = ')';
         break;

         case 'max':
            $fopen = 'max(';
            $fclose = ')';
         break;

         case 'gini':
            $fopen = 'gini(array_accum(';
            $fclose = '))';
         break;

         case 'sum':
            $fopen = 'sum(';
            $fclose = ')';
         break;

         case 'count':
            $fopen = 'count(';
            $fclose = ')';
         break;

         case 'stddev':
            $fopen = 'stddev(';
            $fclose = ')';
         break;

         default:
         break;
      }

      return array($fopen, $fclose);
   }


   function showEditForm($formname, $disabled=0) {
      if (is_object($this->listobject)) {

         $returnInfo = array();
         $returnInfo['name'] = $this->name;
         $returnInfo['description'] = $this->description;
         $returnInfo['debug'] = '';
         $returnInfo['elemtype'] = get_class($this);

         $props = (array)$this;
         $innerHTML = '';
         $adminsetuparray = $this->listobject->adminsetuparray;
         $innerHTML .= showFormVars($this->listobject,$props,$adminsetuparray[$returnInfo['elemtype']],1, 0, $this->debug, 0, 1, $disabled, $this->fno);

         # now, show the meta columns (select, where, group, order)

         # 1 - columns to select
         $coladmin = $adminsetuparray['queryWizard_selectcolumns'];

         # set the name of the form for reference by xajax
         $coladmin['table info']['formName'] = $formname;
         $parentname = $formname . "_selectcolumns";
         $coladmin['table info']['parentname'] = $parentname;
         $childname = $formname . "_selectid";
         $coladmin['table info']['childname'] = $childname . '[]';
         $showlabels = $coladmin['table info']['showlabels'];
         $selectcolumns = array(
            'qcols'=>$this->qcols,
            'qcols_func'=>$this->qcols_func,
            'qcols_alias'=>$this->qcols_alias,
            'qcols_txt'=>$this->qcols_txt
         );
         $tpa = $this->makeAssoc($selectcolumns);
         $cols = $tpa['assoc_out'];
         # set up div to contain each seperate multi-parameter block
         $innerHTML .= showHiddenField("xajax_removeitem", -1, 1);
         $innerHTML .= "<b>SELECT:</b><div name='$parentname' id='$parentname'>";
         if (count(array_keys($cols)) > 0) {
            foreach (array_keys($cols) as $thisrowkey) {
               $thisrow = $cols[$thisrowkey];
               //$innerHTML .= "<div name='$childname"."[$thisrowkey]' id='$childname"."[$thisrowkey]'>";
               //$innerHTML .= showFormVars($this->listobject,$thisrow,$coladmin,$showlabels, 0, $this->debug, 1, 1, $disabled, $this->fno, $thisrowkey);
               $innerHTML .= "<div name='$childname"."[]' id='$childname"."[]'>";
               $innerHTML .= showFormVars($this->listobject,$thisrow,$coladmin,$showlabels, 0, $this->debug, 1, 1, $disabled, $this->fno, '');
               $innerHTML .= "</div>";
            }
         } else {
            # if none exist, add a blank line in
            $innerHTML .= "<div name='$childname"."[]' id='$childname"."[]'>";
            $innerHTML .= showFormVars($this->listobject,$thisrow,$coladmin,$showlabels, 0, $this->debug, 1, 1, $disabled, $this->fno, '');
            $innerHTML .= "</div>";
         }
         $innerHTML .= "</div>";

         # 2 - where conditions
         $coladmin = $adminsetuparray['queryWizard_wherecolumns'];

         # set the name of the form for reference by xajax
         $coladmin['table info']['formName'] = $formname;
         $parentname = $formname . "_wherecolumns";
         $coladmin['table info']['parentname'] = $parentname;
         $childname = $formname . "_whereid";
         $coladmin['table info']['childname'] = $childname . '[]';
         $showlabels = $coladmin['table info']['showlabels'];
         $wherecolumns = array(
            'wcols'=>$this->wcols,
            'wcols_op'=>$this->wcols_op,
            'wcols_value'=>$this->wcols_value
         );
         $tpa = $this->makeAssoc($wherecolumns);
         $cols = $tpa['assoc_out'];
         # set up div to contain each seperate multi-parameter block
         $innerHTML .= "<b>WHERE:</b><div name='$parentname' id='$parentname'>";
         if (count(array_keys($cols)) > 0) {
            foreach (array_keys($cols) as $thisrowkey) {
               $thisrow = $cols[$thisrowkey];
               $innerHTML .= "<div name='$childname"."[]' id='$childname"."[]'>";
               $innerHTML .= showFormVars($this->listobject,$thisrow,$coladmin,$showlabels, 0, $this->debug, 1, 1, $disabled, $this->fno, '');
               $innerHTML .= "</div>";
            }
         } else {
            # if none exist, add a blank line in
            $innerHTML .= "<div name='$childname"."[]' id='$childname"."[]'>";
            $innerHTML .= showFormVars($this->listobject,$thisrow,$coladmin,$showlabels, 0, $this->debug, 1, 1, $disabled, $this->fno, '');
            $innerHTML .= "</div>";
         }
         $innerHTML .= "</div>";

         # 3 - order columns
         $coladmin = $adminsetuparray['queryWizard_ordercolumns'];

         # set the name of the form for reference by xajax
         $coladmin['table info']['formName'] = $formname;
         $parentname = $formname . "ordercolumns";
         $coladmin['table info']['parentname'] = $parentname;
         $childname = $formname . "_orderid";
         $coladmin['table info']['childname'] = $childname . '[]';
         $showlabels = $coladmin['table info']['showlabels'];
         $ordercolumns = array(
            'ocols'=>$this->ocols
         );
         $tpa = $this->makeAssoc($ordercolumns);
         $cols = $tpa['assoc_out'];
         #$innerHTML .= $tpa['debugstring'];
         # set up div to contain each seperate multi-parameter block
         $innerHTML .= "<b>ORDER BY:</b><div name='$parentname' id='$parentname'>";
         if (count(array_keys($cols)) > 0) {
            foreach (array_keys($cols) as $thisrowkey) {
               $thisrow = $cols[$thisrowkey];
               $innerHTML .= "<div name='$childname"."[]' id='$childname"."[]'>";
               $innerHTML .= showFormVars($this->listobject,$thisrow,$coladmin,$showlabels, 0, $this->debug, 1, 1, $disabled, $this->fno, '');
               $innerHTML .= "</div>";
            }
         } else {
            # if none exist, add a blank line in
            $innerHTML .= "<div name='$childname"."[]' id='$childname"."[]'>";
            $innerHTML .= showFormVars($this->listobject,$thisrow,$coladmin,$showlabels, 0, $this->debug, 1, 1, $disabled, $this->fno, '');
            $innerHTML .= "</div>";
         }
         $innerHTML .= "</div>";

         $returnInfo['innerHTML'] = $innerHTML;

         return $returnInfo;

      }
   }

   function makeAssoc($invars) {
      $outarr = array();
      $debugout = '';
      $assoc_out = array();
      $maxcols = 0; # keep a tally on columns, make sure that a blank entry exists for any missing columns

      foreach (array_keys($invars) as $varname) {
         $debugout .= "Transposing $varname <br>";
         $varvals = $invars[$varname];
         if (!is_array($varvals)) {
            $varvals = array($varvals);
         }
         $valcount = 0;
         foreach (array_keys($varvals) as $thiskey) {
            $assoc_out[$thiskey][$varname] = $varvals[$thiskey];
            $valcount++;
         }
         if ($valcount > $maxcols) {
            $maxcols = $valcount;
         }
      }
      # insert blank entries if needed
      foreach (array_keys($invars) as $varname) {
         $thiscount = count($invars[$varname]);
         if ($thiscount < $maxcols) {
            for ($i = 0; $i < $maxcols; $i++) {
               $assoc_out[$i][$varname] = '';
            }
         }
      }
      $outarr['assoc_out'] = $assoc_out;
      $outarr['debugstring'] = $debugout;
      return $outarr;
   }
}

class graphObject extends modelObject {

   var $goutdir = '';
   var $gouturl = '';
   var $cache_log = 1; # store variable state log in an external file?  Defaults to 1 for graph and report objects, 0 for others
   var $log2db = 1;
   var $imgurl = '';
   var $gwidth = 400;
   var $gheight = 300;
   var $title = '';
   var $xlabel = '';
   var $ylabel = '';
   var $y2label = '';
   var $forceyscale = 0; # whether or not we insist on setting a scale
   var $ymin = '';
   var $ymax = '';
   var $y2min = '';
   var $y2max = '';
   var $scale = 'intlin';
   var $labelangle = 90;
   var $x_interval = -1; # this forces the routine to do an autocalculation of interval unless it is set by user
   var $num_xlabels = 5; # this forces the routine to use the # set by user
   var $graphtype = 'line';
   var $graphstring = '';
   var $adminsetup = array();
   var $restrictdates = 0; # whether or not to use the whole data record, or to restrict the dates

   # requires lib_plot.php to produce graphic output

   function setState() {
      parent::setState();
   }

   function reDraw() {

      if ($this->debug) {
         $this->logDebug("Redraw method called on $this->name<br>");
      }
      if (!$this->logLoaded) {
         #need to get the log from a table or file
         $this->logFromFile();
      }

      $this->graphResults();
      if ($this->debug) {
         $this->logDebug("<br>Image at: $this->imgurl<br>");
      }
      #$this->logDebug($this->logtable);

   }

   function step() {
      // all step methods MUST call getInputs(), execProcessors(), and logstate()
      parent::step();
   }

   function finish() {
      # simulation finished, go ahead and generate any graphs
      $this->graphResults();
      parent::finish();
   }

   function formatActiveGraph() {
      $this->graphstring = '';
      $eid = $this->componentid;
      # use a javascript trick to relaod the image to prevent caching
      $reload_js = "refreshimage(\"img" . $eid . "\");";
      $img_name = "img$eid";
      #return;
      if (is_object($this->listobject)) {
         $taboutput = new tabbedListObject;
         if (is_object($taboutput)) {
            /*
            $taboutput->name = "modelgraph_$eid";
            $taboutput->tab_names = array("graphs_$eid", "el_ctrl_$eid", 'debug');
            $taboutput->tab_buttontext = array(
               "graphs_$eid"=>'Graphs',
               "el_ctrl_$eid"=>'Graph Data',
               'debug'=>'Debug'
            );
            $taboutput->init();
            $taboutput->tab_HTML["graphs_$eid"] .= "<img id='$img_name' ";
            $taboutput->tab_HTML["graphs_$eid"] .= " title='Click to Reload'";
            $taboutput->tab_HTML["graphs_$eid"] .= " onClick='$reload_js'";
            $taboutput->tab_HTML["graphs_$eid"] .= " src='" . $this->imgurl . "'><br>";
            $taboutput->tab_HTML["el_ctrl_$eid"] .= "<a onclick=\"dg_move_file(tt1,11 , './objectlog.785.792.log.serial' )\">Scroll Through Model Data</a>";
            $taboutput->tab_HTML["el_ctrl_$eid"] .= "<b>Model Controls:</b><br>";
            $taboutput->createTabListView();
            $this->graphstring .= "<div>" . $taboutput->innerHTML . "</div>";
            if ($this->debug) {
               $this->logDebug("Finished graphing $this->name");
            }            
            */
            // new school way of showing the graph
            $this->graphstring .= "<a class='mH' onClick='document[\"image_screen\"].src = \"" . $this->imgurl . "\"; '>$this->name - $this->title</a> | ";
            $this->graphstring .= "<a href='" . $this->imgurl . "' target='_new'>View Image in New Window</a><br>";
         } else {
            if ($this->debug) {
               $this->logDebug("Using Simple Display for $this->name");
            }
            /*
            $this->graphstring .= "<img id='$img_name' ";
            $this->graphstring .= " title='Click to Reload'";
            $this->graphstring .= " onClick='$reload_js'";
            $this->graphstring .= " src='" . $this->imgurl . "'><br>";
            */
            // new school way of showing the graph
            $this->graphstring .= "<a class='mH' onClick='document[\"image_screen\"].src = \"" . $this->imgurl . "\"; '>$this->name - $this->title</a> | ";
            $this->graphstring .= "<a href='" . $this->imgurl . "' target='_new'>View Image in New Window</a><br>";
         }
      } else {
         # do nothing but put out the graph
         /*
         $this->graphstring .= "<img id='$img_name' ";
         $this->graphstring .= " title='Click to Reload'";
         $this->graphstring .= " onClick='$reload_js'";
         $this->graphstring .= " src='" . $this->imgurl . "'><br>";
         */
         if ($this->debug) {
            $this->logDebug("Listobject not set for $this->name");
         }
         // new school way of showing the graph
         $this->graphstring .= "<a class='mH' onClick='document[\"image_screen\"].src = \"" . $this->imgurl . "\"; '>$this->name - $this->title</a> | ";
         $this->graphstring .= "<a href='" . $this->imgurl . "' target='_new'>View Image in New Window</a><br>";
      }
   }


   function graphResults() {
      if ($this->debug) {
         $this->logDebug("graphResults() called on $this->name<br>");
      }

      # set up basic info
      $thisgraph = array();

      $thisgraph['title'] = $this->title;
      $thisgraph['xlabel'] = $this->xlabel;
      $thisgraph['ylabel'] = $this->ylabel;
      $thisgraph['y2label'] = $this->y2label;
      $thisgraph['gwidth'] = $this->gwidth;
      $thisgraph['gheight'] = $this->gheight;
      $thisgraph['x_interval'] = $this->x_interval;
      //$thisgraph['num_xlabels'] = $this->num_xlabels;
      $thisgraph['scale'] = $this->scale;
      if ($this->forceyscale and ($this->ymin <> $this->ymax)) {
         # use a custom scale
         $thisgraph['ymin'] = $this->ymin;
         $thisgraph['ymax'] = $this->ymax;
      }
      $thisgraph['labelangle'] = $this->labelangle;
      $thisgraph['filename'] =  'graph.' . $this->sessionid . '.' . $this->componentid;

      $i = 0;
      #$this->logDebug("<br>Processors:<br>");
      #$this->logDebug($this->processors);
      #$this->logDebug("<br>");
      $logtab = $this->getLog();
      $vars = array_keys($logtab[0]);
      if ($this->debug) {
         $this->logDebug("My data_log variables contained: " . print_r($this->data_cols,1) . "<br>");
         $this->logDebug("getLog() returned " . count($logtab) . "<br>");
         $this->logDebug("getLog() Columns: " . print_r(array_keys($logtab[0]),1) . "<br>");
      }
      
      foreach ($this->processors as $thiscol) {
         if (!$thiscol->disabled) {
            $obclass = get_class($thiscol);
            // to check to make sure that the variable is present (and avoid a crash) use the next line
            //if ( in_array($obclass, array('graphComponent')) and in_array($thiscol, $vars)) {
            if ( in_array($obclass, array('graphComponent')) ) {
               $xcol = $thiscol->xcol;
               $graphtab = $logtab;
               if ($thiscol->sorted) {
                  # this object requires a post-process sorting
                  if (strlen($thiscol->sortcol)) {
                     # sortcol must be set
                     $sortkeys = array();
                     $sortrecs = array();
                     $scol = $thiscol->sortcol;
                     $isort = 0;
                     $icount = count($logtab);
                     foreach ($logtab as $logrec) {
                        # add an index column to be used as the Xcolumn value
                        $logrec['sortindex'] = number_format(100.0*$isort/$icount,0);
                        array_push($sortkeys, $logrec[$scol]);
                        $sortrecs["$logrec[$scol]"] = $logrec;
                        $isort++;
                     }
                     ksort($sortrecs);
                  }
                  $graphtab = $sortrecs;
                  $xcol = 'sortindex';
               }
               $thisgraph['bargraphs'][$i]['graphrecs'] = $graphtab;
               $thisgraph['bargraphs'][$i]['xcol'] = $xcol;
               $thisgraph['bargraphs'][$i]['plottype'] = $thiscol->graphtype;
               if (strlen($thiscol->ycol) > 0) {
                  # using the new way
                  $thisgraph['bargraphs'][$i]['ycol'] = $thiscol->ycol;
               } else {
                  $thisgraph['bargraphs'][$i]['ycol'] = $thiscol->name;
               }
               $thisgraph['bargraphs'][$i]['color'] = $thiscol->color;
               $thisgraph['bargraphs'][$i]['weight'] = $thiscol->weight;
               $thisgraph['bargraphs'][$i]['yaxis'] = $thiscol->yaxis;
               $thisgraph['bargraphs'][$i]['ylegend'] = $thiscol->ylegend;
               #$this->logDebug("Adding graph $i <br>");
               $i++;
            }
         }
      }
      #$this->debug = 1;
      if ($this->debug) {
         $this->logDebug("Drawing $this->graphtype $this->goutdir, $this->gouturl:<br>");
         //$this->logDebug(print_r($thisgraph,1) . "<br>");
      }
      // something in this next block is triggering an error
      //it seems to be with the postgresql query object, which makes no sense but there is a 
      // call to the getColumns() method of the pg object, or some other thing that is doing a 
      // select column_name from 
      switch ($this->graphtype) {
         case 'line':
         $thisimg = showGenericMultiPlot($this->goutdir, $this->gouturl, $thisgraph, $this->debug);
//         $thisimg = showGenericMultiLine($this->goutdir, $this->gouturl, $thisgraph, $this->debug);
         $this->imgurl = $thisimg;
         $this->formatActiveGraph();
         break;
         
         case 'multi':
         $thisimg = showGenericMultiPlot($this->goutdir, $this->gouturl, $thisgraph, $this->debug);
         $this->imgurl = $thisimg;
         $this->formatActiveGraph();
         break;

         default:
         $thisimg = showGenericMultiPlot($this->goutdir, $this->gouturl, $thisgraph, $this->debug);
//         $thisimg = showGenericMultiLine($this->goutdir, $this->gouturl, $thisgraph, $this->debug);
         $this->imgurl = $thisimg;
         $this->formatActiveGraph();
         break;
      }
   }

}

class giniGraph extends graphObject {

   var $goutdir = '';
   var $gouturl = '';
   var $imgurl = '';
   var $gwidth = 400;
   var $gheight = 300;
   var $title = '';
   var $xlabel = '';
   var $ylabel = '';
   var $y2label = '';
   var $scale = 'intlin';
   var $labelangle = 90;
   var $splitmedian = 0; # 0 - do not, 1 - analyze curves above and below median seperately
   var $graphtype = 'line';

   function graphResults() {

      # set up basic info
      $thisgraph = array();

      $thisgraph['title'] = $this->title;
      $thisgraph['xlabel'] = $this->xlabel;
      $thisgraph['ylabel'] = $this->ylabel;
      $thisgraph['y2label'] = $this->y2label;
      $thisgraph['gwidth'] = $this->gwidth;
      $thisgraph['gheight'] = $this->gheight;
      $thisgraph['scale'] = $this->scale;
      $thisgraph['labelangle'] = $this->labelangle;
      $thisgraph['filename'] =  'graph.' . $this->sessionid . '.' . $this->componentid;

      $i = 0;
      #$this->logDebug("<br>Processors:<br>");
      #$this->logDebug($this->processors);
      #$this->logDebug("<br>");
      $logtab = $this->getLog();
      foreach ($this->processors as $thiscol) {
         $obclass = get_class($thiscol);
         if ( in_array($obclass, array('graphComponent')) ) {

            $xcol = $thiscol->xcol;
            # gini is automatically assumed to be sorted by the y-column
            $sortkeys = array();
            $sortrecs = array();
            if (strlen($thiscol->ycol) > 0) {
               # we are using the new way of operating
               $scol = $thiscol->ycol;
            } else {
               $scol = $thiscol->name;
            }
            $isort = 0;
            $gtotal = 0;
            $gtotalhi = 0;
            $gtotallo = 0;
            $icount = count($logtab);
            $xmedian = intval($icount / 2);
            foreach ($logtab as $logrec) {
               $isort++;
               # accumulate the population total
               $gtotal += $logrec[$scol];
               $sortindex = $logrec[$scol];
               # add an index column to be used as the Xcolumn value
               $logrec['sortindex'] = number_format(100.0*$isort/$icount,0);
               array_push($sortkeys, $logrec[$scol]);
               #$sortrecs["$sortindex"] = $logrec;
               array_push($sortrecs, $logrec[$scol]);
            }
            #ksort($sortrecs);
            sort($sortrecs);
            if ($this->splitmedian) {
               # do seperate accumulators for the portion above and below median
               $isort = 0;
               foreach ($sortrecs as $logrec) {
                  $isort++;
                  if ($isort > $xmedian) {
                     #$gtotalhi += $logrec[$scol];
                     $gtotalhi += $logrec;
                  } else {
                     #$gtotallo += $logrec[$scol];
                     $gtotallo += $logrec;
                  }
               }
            }
            if ($this->debug) {
               $this->debugstring .= "Total Records in " . $scol . " = $icount<br>";
               $this->debugstring .= "Sorted Record count = " . count($sortrecs) . "<br>";
            }
            # now, calculate gini factors and normalize on the total
            $gxn = 1.0;
            $gyn = 0.0;
            $gynhi = 0;
            $gynlo = 0;
            $lgx = 0;
            $lgy = 0;
            $ga = 0;
            $ginirec = array();
            # for split analysis
            $gahi = 0;
            $galo = 0;
            $ginihi = array();
            $ginilo = array();
            # the line representing a gini of 1.0 (equal distribution)
            $oneline = array();
            $onehi = array();
            $onelo = array();
            reset($sortrecs);
            foreach ($sortrecs as $thisrec) {
               # calculate percentage of population
               if (!$this->splitmedian) {
                  $gx = round($gxn / $icount,2);
                  #$gyn += $thisrec[$scol];
                  $gyn += $thisrec;
                  # calculate percentage of total value
                  $gy = $gyn / $gtotal;
                  $ga += 0.5 * ($gy + $lgy) * ($gx - $lgx);
                  if ($this->debug) {
                     $this->debugstring .= "Evaluating Record " . $gxn . " = $gx %, value = $gy<br>";
                  }
                  array_push($ginirec, array('gx'=>$gx, 'gy'=>$gy));
                  array_push($oneline, array('gx'=>$gx, 'gy'=>$gx));
               } else {
                  # doing a split gini at the median value
                  if ($gxn > $xmedian) {
                     $gx = number_format(($gxn - $xmedian) / ($icount - $xmedian),2);
                     #$gynhi += $thisrec[$thiscol->name];
                     $gynhi += $thisrec;
                     $gy = $gynhi / $gtotalhi;
                     if ($lgx > $gx) {
                        $lgx = 0;
                     }
                     $gahi += 0.5 * ($gy + $lgy) * ($gx - $lgx);
                     array_push($ginihi, array('gx'=>$gx, 'gy'=>$gy));
                     array_push($onelo, array('gx'=>$gx, 'gy'=>$gx));
                  } else {
                     $gx = number_format($gxn / $xmedian,2);
                     #$gynlo += $thisrec[$thiscol->name];
                     $gynlo += $thisrec;
                     $gy = $gynlo / $gtotallo;
                     $galo += 0.5 * ($gy + $lgy) * ($gx - $lgx);
                     array_push($ginilo, array('gx'=>$gx, 'gy'=>$gy));
                     array_push($onehi, array('gx'=>$gx, 'gy'=>$gx));
                  }
               }
               # stash the last x value
               $lgx = $gx;
               $lgy = $gy;
               $gxn++;
            }
            # calculate gini coefficient
            $g = number_format(1 - 2.0 * $ga,3);
            $thiscol->value = $g;
            $ghi = number_format(1 - 2.0 * $gahi,3);
            $glo = number_format(1 - 2.0 * $galo,3);
            if (!$this->splitmedian) {
               $thisgraph['bargraphs'][$i]['graphrecs'] = $ginirec;
               $thisgraph['bargraphs'][$i]['xcol'] = 'gx';
               $thisgraph['bargraphs'][$i]['ycol'] = 'gy';
               $thisgraph['bargraphs'][$i]['weight'] = $thiscol->weight;
               $thisgraph['bargraphs'][$i]['color'] = $thiscol->color;
               $thisgraph['bargraphs'][$i]['yaxis'] = $thiscol->yaxis;
               $thisgraph['bargraphs'][$i]['ylegend'] = $thiscol->ylegend . " (G = $g)";
               #$this->logDebug("Adding graph $i <br>");
               $i++;
            } else {
               $thisgraph['bargraphs'][$i]['graphrecs'] = $ginihi;
               $thisgraph['bargraphs'][$i]['xcol'] = 'gx';
               $thisgraph['bargraphs'][$i]['ycol'] = 'gy';
               $thisgraph['bargraphs'][$i]['weight'] = $thiscol->weight;
               $thisgraph['bargraphs'][$i]['color'] = $thiscol->color;
               $thisgraph['bargraphs'][$i]['yaxis'] = $thiscol->yaxis;
               $thisgraph['bargraphs'][$i]['ylegend'] = $thiscol->ylegend . " - Upper (G = $ghi)";

               #$this->logDebug("Adding graph $i <br>");
               $i++;
               $thisgraph['bargraphs'][$i]['graphrecs'] = $ginilo;
               $thisgraph['bargraphs'][$i]['xcol'] = 'gx';
               $thisgraph['bargraphs'][$i]['ycol'] = 'gy';
               $thisgraph['bargraphs'][$i]['weight'] = $thiscol->weight;
               $thisgraph['bargraphs'][$i]['color'] = $thiscol->color;
               $thisgraph['bargraphs'][$i]['yaxis'] = $thiscol->yaxis;
               $thisgraph['bargraphs'][$i]['ylegend'] = $thiscol->ylegend . " - Lower (G = $glo)";
               #$this->logDebug("Adding graph $i <br>");
               $i++;
               $oneline = $onelo;
            }

         }
      }

      # now, add the one-one line
      $thisgraph['bargraphs'][$i]['graphrecs'] = $oneline;
      $thisgraph['bargraphs'][$i]['xcol'] = 'gx';
      $thisgraph['bargraphs'][$i]['ycol'] = 'gy';
      $thisgraph['bargraphs'][$i]['color'] = 'gray';
      $thisgraph['bargraphs'][$i]['yaxis'] = 1;
      $thisgraph['bargraphs'][$i]['ylegend'] = '';
      #$this->logDebug("Adding graph $i <br>");
      $i++;

      #$this->debug = 1;
      switch ($this->graphtype) {
         case 'line':
         $thisimg = showGenericMultiLine($this->goutdir, $this->gouturl, $thisgraph, $this->debug);
         $this->imgurl = $thisimg;
         $this->formatActiveGraph();
         break;

         default:
         $thisimg = showGenericMultiLine($this->goutdir, $this->gouturl, $thisgraph, $this->debug);
         $this->imgurl = $thisimg;
         $this->formatActiveGraph();
         break;
      }
   }

}

class flowDurationGraph extends graphObject {

   var $goutdir = '';
   var $gouturl = '';
   var $imgurl = '';
   var $gwidth = 400;
   var $gheight = 300;
   var $title = '';
   var $xlabel = '';
   var $ylabel = '';
   var $y2label = '';
   //var $scale = 'intlin';
   var $scale = 'linlog';
   var $flowstat = 0; # 0 - exceedance percentage, 1 - recurrence interval
   var $normalize = 0; # normalize graph components on max, to show relative to max value (0 - 1.0)
   var $labelangle = 90;
   var $splitmedian = 0; # 0 - do not, 1 - analyze curves above and below median seperately
   var $graphtype = 'line';

   function graphResults() {

      # set up basic info
      $thisgraph = array();

      $thisgraph['title'] = $this->title;
      $thisgraph['xlabel'] = $this->xlabel;
      $thisgraph['ylabel'] = $this->ylabel;
      $thisgraph['y2label'] = $this->y2label;
      $thisgraph['gwidth'] = $this->gwidth;
      $thisgraph['gheight'] = $this->gheight;
      $thisgraph['scale'] = $this->scale;
      $thisgraph['labelangle'] = $this->labelangle;
      $thisgraph['filename'] =  'graph.' . $this->sessionid . '.' . $this->componentid;

      $i = 0;
      #$this->logDebug("<br>Processors:<br>");
      #$this->logDebug($this->processors);
      #$this->logDebug("<br>");
      $logtab = $this->getLog();
      $mingtzero = 0.001;
      $ymax = 0.001;
      $ymin = 0.001;
      foreach ($this->processors as $thiscol) {
         $obclass = get_class($thiscol);
         if ( in_array($obclass, array('graphComponent')) ) {
            $xcol = $thiscol->xcol;
            # gini is automatically assumed to be sorted by the y-column
            $sortkeys = array();
            $sortrecs = array();
            if (strlen($thiscol->ycol) > 0) {
               # we are using the new way of operating
               $scol = $thiscol->ycol;
            } else {
               $scol = $thiscol->name;
            }

            if ($this->debug) {
               $this->logDebug("Preparing $thiscol->name for graphing<br>");
            }
            $isort = 0;
            $icount = count($logtab);
            foreach ($logtab as $logrec) {
               $isort++;
               array_push($sortrecs, $logrec[$scol]);
               if ( ($logrec[$scol] > 0) and ($logrec[$scol] < $mingtzero) ) {
                  $mingtzero = $logrec[$scol] / 2.0;
               }
            }

            if ($this->debug) {
               $this->logDebug("Settng 0.0 records to $mingtzero to permit graphing on log scale<br>");
            }
            $gmax = max($sortrecs);
            if ($gmax > $ymax) {
               $ymax = $gmax;
            }
            // replaces each zero value with the minimum greater than zero value divided by 2.0 (from above)
            foreach ($sortrecs as $thiskey=>$thisval) {
               if ($thisval == 0) {
                  $sortrecs[$thiskey] = $mingtzero;
               }
            }
            $gmin = min($sortrecs);
            if ($gmin < $ymin) {
               $ymin = $gmin;
            }            
               
            switch ($this->flowstat) {
               case 0:
               # exceedence percent;
               rsort($sortrecs);
               break;

               case 0:
               # reccurence percent;
               sort($sortrecs);
               break;
            }

            if ($this->debug) {
               $this->logDebug("Total Records in " . $scol . " = $icount<br>");
               $this->logDebug("Sorted Record count = " . count($sortrecs) . "<br>");
               $this->logDebug("Max Value = " . $gmax . "<br>");
               $this->logDebug("Lowest values fixed at $gmin<br>");
            }
            # now, calculate gini factors and normalize on the total
            $gxn = 1.0;
            $gyn = 0.0;
            $fdrec = array();
            reset($sortrecs);
            foreach ($sortrecs as $thisrec) {
               # calculate percentage of population
               $gx = round($gxn / $icount,2);
               switch ($this->flowstat) {
                  case 0:
                  # exceedence percent;
                  $gx = 1.0 - $gx;
                  break;

                  case 0:
                  # reccurence percent;
                  $gx = $gx;
                  break;
               }

               # calculates percent of max flow
               if ($gmax > 0 and $this->normalize) {
                  $gy = $thisrec / $gmax;
               } else {
                  $gy = $thisrec;
               }
               if ($this->debug) {
                  $this->logDebug("Evaluating Record " . $gxn . " = $gx %, value = $gy<br>");
               }
               array_push($fdrec, array('gx'=>$gx, 'gy'=>$gy));
               # stash the last x value
               $gxn++;
            }
            $thisgraph['ymin'] = $ymin;
            //$thisgraph['ymax'] = $ymax;
            # plot this curve
            $thisgraph['bargraphs'][$i]['graphrecs'] = $fdrec;
            $thisgraph['bargraphs'][$i]['xcol'] = 'gx';
            $thisgraph['bargraphs'][$i]['ycol'] = 'gy';
            $thisgraph['bargraphs'][$i]['weight'] = $thiscol->weight;
            $thisgraph['bargraphs'][$i]['color'] = $thiscol->color;
            $thisgraph['bargraphs'][$i]['yaxis'] = $thiscol->yaxis;
            $thisgraph['bargraphs'][$i]['ylegend'] = $thiscol->ylegend;
            #$this->logDebug("Adding graph $i <br>");
            $i++;
         }
      }
      $i++;

      #$this->debug = 1;
      switch ($this->graphtype) {
         case 'line':
         $thisimg = showGenericMultiLine($this->goutdir, $this->gouturl, $thisgraph, $this->debug);
         $this->imgurl = $thisimg;
         $this->formatActiveGraph();
         break;

         default:
         $thisimg = showGenericMultiLine($this->goutdir, $this->gouturl, $thisgraph, $this->debug);
         $this->imgurl = $thisimg;
         $this->formatActiveGraph();
         break;
      }
   }

}

class graphComponent extends modelSubObject {

   var $xcol = '';
   var $ycol = '';
   var $name = ''; #varuiable name
   var $yaxis = 1;
   var $ylegend = '';
   var $color = 'black';
   var $weight = 1;
   var $arData = array();
   var $cache_log = 1; # store variable state log in an external file?  Defaults to 1 for graph and report objects, 0 for others
   var $result = 0;
   var $sorted = 0; # whether or not to sort
   var $sortcol = '';
   var $graphtype = 'line';
   var $loggable = 0;

   # acts as sub-component for graphObject

   function evaluate() {
      $this->result = $this->arData[$this->name];
      return;
   }

}

class flowTransformer extends modelObject {
   # a type of processor
   # transforms flow from one or more basins, or gages, into a single flow value
   # for use as a paired watershed type of deal, or to extrapolate flow upstream in a basin
   # to a downstream point
   # expects inputs of flow from a variety of flow objects (may be time series, but must have
   # area property set).  Also expects that
   var $inputname = 'Qin'; # the name of the input that we will aggregate
   # requires the library lib_equation2.php, which has the class "Equation"
   var $method = 0; # 0 - area-weighted flow, 1 - mean value
   var $area = 0.0;

   function init() {
      parent::init();
      $this->state[$inputname] = 0.0;
   }

   function step() {
      // all step methods MUST call preStep(),execProcessors(), postStep()
      $this->preStep();
      if ($this->debug) {
         $this->logDebug("$this->name Inputs obtained. thisdate = " . $this->state['thisdate']);
      }
      // execute sub-components
      $this->execProcessors();
      # need to look through the inputs and weight their flow inputs
      # will ignore any input whose current state is NULL (i.e., does not have an input)
      # can use one of two weighting methods, weighted by flow
      $n = 0;
      $flow = 0;
      $area = $this->area;
      $activearea = 0.0;
      switch ($this->method) {
         case 0:
         $fin = $this->inputs['flow'];
         break;

         case 1:
         $fin = $this->inputs['flowpera'];
         break;

         case 2:
         # area weighted
         $fin = $this->inputs['flowtimesa'];
         break;
      }
      if ($this->debug) {
         $this->logDebug("Calculating Flow Transformation, method: $this->method .<br>");
      }

      foreach($fin as $thisinobj) {
         $fv = $thisinobj['value'];
         if ( !($fv === NULL) ) {
            if ($this->debug) {
               $this->logDebug(" + $fv ");
            }
            $flow += $fv;
            $n++;
         }
         if ($this->debug) {
            $this->logDebug(" = $flow (aggregate flow)<br>\n");
         }
      }
      # assumes that area has been manipulated such that it is NULL if the flow is null
      foreach($this->inputs['activearea'] as $thisinobj) {
         $av = $thisinobj['value'];
         if ( !($av === NULL) ) {
            $activearea += $av;
            if ($this->debug) {
               $this->logDebug(" = $activearea (aggregate area)<br>\n");
            }
         }
      }
      switch ($this->method) {
         case 0:
         if ($activearea > 0) {
            $outflow = $area * $flow / $activearea;
         } else {
            $outflow = $flow;
         }
         break;

         case 1:
         if ($n > 0) {
            $outflow = $area * $flow / $n;
         } else {
            $outflow = NULL;
         }
         break;

         case 2:
         if ($n > 0) {
            $outflow = $area * $flow / ($activearea * $activearea);
         } else {
            $outflow = NULL;
         }
         break;
      }
      if ($this->debug) {
         $this->logDebug(" Transformed flow = $outflow <br>\n");
      }

      $this->state['Qout'] = $outflow;
      # expects that the flow input objects, whether they are time series, or other
      # must have an "area" property signifying their drainage area (acres in EE, ha in SI)

      $this->postStep();
   }

}



class reverseFlowObject extends timeSeriesInput {
   var $base = 1.0; /* base width of channel */
   var $Z = 1.0; /* side slope ratio */
   var $length = 5000.0;
   var $channeltype = 2; # only trapezoidal channels (type 2) are currently supported
   # tolerance for sollution to storage routing, percent as fraction
   var $tol = 0.001;
   # key is name, values are:
   #     priority (0 is highest priority),
   #     criteria - the name of the state variable that the criteria is based on
   #     withdrawals = array(criteriavalue, amount (volume per hour))

   function step() {
      // all step methods MUST call preStep(),execProcessors(), postStep()
      $this->preStep();
      if ($this->debug) {
         $this->logDebug("$this->name Inputs obtained. thisdate = " . $this->state['thisdate']);
      }
      // execute sub-components
      $this->execProcessors();
      $I1 = $this->state['Iold'];
      $O1 = $this->state['Qold'];
      # this is obtained from the time series input
      $O2 = $this->state['Qout'];
      $S1 = $this->state['Storage'];
      $initialStorage = $this->state['Storage'];
      $depth = $this->state['depth'];
      # assume demand = 0.0 for now
      $currentDemand = 0.0;

      if (count($this->logtable) == 0) {
         # first time, need to estimate initial storage,
         # assumes that we are in steady state, that is,
         # the initial and final Q, and S are equivalent
         $I2 = $O2;
         $I1 = $O2;
         $O1 = $O2;
         if ($this->debug) {
            $this->logDebug("Estimating initial storage");
         }
         $S1 = storageroutingInitS($I2, $this->base, $this->Z, $this->channeltype, $this->length, $this->slope, $dt, $this->n, $this->units, $this->debug);
         if ($this->debug) {
            $this->logDebug("Initial storage estimated as $S1 <br>\n");
         }
      }

      # get time step from timer object
      $dt = $this->timer->dt;

      if($this->debug) {
         $dtime = $this->timer->thistime->format('r');
         $this->logDebug("Calculating inflow at time $dtime <br>\n");
         $this->logDebug("Q1 = $O1, Q2 = $O2, I1 = $I1, base = $this->base, Z = $this->Z, type = 2, S1 = $S1, length = $this->length, slope = $this->slope, $dt, n = $this->n <br>\n");
         #die;
      }
      # step iteration next
      list($Vout, $I2, $depth, $Storage) = reverseStorageRouting($I1, $O1, $O2, $currentDemand, $this->base, $this->Z, $this->channeltype, $S1, $this->length, $this->slope, $dt, $this->n, $this->tol, $this->units, $this->debug);

      if($this->debug) {
         $teststore = storagerouting($I1, $I2, $O1, $currentDemand, $this->base, $this->Z, $this->channeltype, $S1, $this->length, $this->slope, $dt, $this->n, $this->units, 0);
         $this->logDebug($teststore);
         $this->logDebug("Inflow estimated as $I2 <br>\n");
         #die;
      }

      $this->state['Vout'] = $Vout;
      $this->state['Qold'] = $O2;
      $this->state['Iold'] = $I2;
      # since we are using this as an input
      $this->state['Iin'] = $I2;
      $this->state['depth'] = $depth;
      $this->state['Storage'] = $Storage;
      $this->state['demand'] = $currentDemand;

      $this->postStep();
   }
}

class CBPModelContainer extends modelContainer {
   var $riversegs = array();
   var $landseg = array();
   var $autoloadriver = 0; # whether or not to auto-load any child river components
   var $autoloadland = 0; # whether or not to auto-load any child land components
   var $filepath = ''; # uci file of the farthest downstream component
   var $ucidir = ''; # directory path to outlet uci file
   var $uciname = ''; # file name of outlet uci
   var $createLog = ''; # logging info for the create() method
   var $defaultProcs = 'CBPModelReachFlow';
   var $wdimex_exe = '/Library/WebServer/CGI-Executables/wdimex';

   function wake() {
      parent::wake();
      $this->ucidir = dirname($this->filepath);
      $this->uciname = basename($this->filepath);
      if ($this->autoloadriver) {
         $this->getRiverSegs();
      }

   }

   function create() {
      # this method does any operations that are batched into this object
      # it must be called AFTER the wake() method, but prior to the init() method
      parent::create();
      $this->ucidir = dirname($this->filepath);
      $this->uciname = basename($this->filepath);
      # instantiate all riversegs and land segs
      $logstr = '';
      if ($this->autoloadriver) {
         $logstr .= 'Looking for riversegs<br>';
         $this->getRiverSegs();
      }
      # add the default CBP processors, if they do not already exist
      #   CBPModelReachFlow - separates upstream and local inflows from the WDM DSN 11 input
      #      this involves adding a WDMDSNaccessor for the local 11, and for each of the upstream 11's
      #      then adding an equation component that subtracts the upstream 11s from the local 11 to get the
      #      local upland contribution for this
      #      The most upstream segment will need to be instantiated first? or since we have a consistent naming
      #      convention, we can just trust that it WILL be added once we process all members of this group?
      #      This might hold true, but all of the upstream segments will still have to have an object instantiated on them
      #      Maybe go through all segments, create objects for them, add them to this objects CONTAINED entities
      #      Then go through and add all of the sub-components.  YES!!!
      #   CBPModelReachComponent - generic object that can be used for any of the inputs, flow, or quality
      # look for components on this object, if any of the defaults are missing, add them
      foreach (split(',',$this->defaultProcs) as $thisdef) {
         foreach ($this->processors as $thisproc) {

         }
      }
      # for each riverseg, do any processors that have functions for this riverseg
      # this will add inputs for flow, and other quality constituents that are defined on this parent object
      # to each of the child riversegs
      $logstr .= "Examining Upstream Inputs to $this->uciname <br>";
      foreach ($this->riversegs as $thisreach) {
         # create it on the child
         $segid = $thisreach['segid'];
         $dsegid = $thisreach['down_segid'];
         $uci = $thisreach['uci'];
         $elementid = $thisreach['elementid'];
         $subobject = $thisreach['object'];
         # check on this objects CONTAINED sub-objects and see if it exists
         # if it does not exist, create it.  This simply creates the object in memory, in order to save this
         # newly created object for later editing, an OUTSIDE routine must be used, otherwise, this is only good
         # for the current instantiation (for example, if this were invoked during a model run call, the sub-objects
         # would be created and available only during the model run)
         if ($subobject === NULL) {
            $logstr .= "Creating Child object for Segment $segid<br>";
         }
         if ($dsegid <> -1) {
            $logstr .= "Adding upstream input from $segid to $dsegid<br>";
         }
         foreach ($this->processors as $thisproc) {
            # run the create routine on this
            # if this is a CBPComponentProc (such as flow, or qual constit)
            # create a version of it on the child
         }
      }
      $this->createLog .= $logstr;
   }

   function sleep() {
      # things to do before this goes away, or gets stored
      # turn the riversegs and landsegs arrays into strings?
      parent::sleep();
   }

   function showHTMLInfo() {
      $HTMLInfo = '';
      $HTMLInfo .= parent::showHTMLInfo();
      $HTMLInfo .= "<b>Outlet River Name: </b>" . $this->out_name . "<br>";
      $HTMLInfo .= "<b>Outlet Segment ID: </b>" . $this->out_segment . "<br>";
      $HTMLInfo .= "<b>Next Downstream Segment: </b>" . $this->down_segment . "<hr>";
      $HTMLInfo .= "<b>Found Model River Segments: </b>" . print_r($this->riversegs,1) . "<hr>";

      $HTMLInfo .= '<hr>' . $this->createLog;

      return $HTMLInfo;
   }

   function getRiverSegs() {

      if (file_exists($this->filepath)) {
         list($ucibase, $uciext) = split('\.', $this->uciname);
         list($this->out_name, $this->out_segment, $this->down_segment) = split("_", $ucibase);
         $this->riversegs = array();
         # set the down_segid to -1 since this is the outlet of this watershed
         $this->riversegs[$this->out_segment] = array('segid'=>$this->out_segment, 'uci'=>$this->uciname, 'down_segid'=>-1, 'elementid'=>-1, 'object'=>NULL);

         # repeat until no more upstream files are found
         $segsleft = array($this->out_segment);
         while(count($segsleft) > 0) {
            $currseg = array_shift($segsleft);
            $upfiles = $this->getUpstream($currseg);
            foreach ($upfiles as $thisfile) {
               list($ucibase, $uciext) = split('\.', $thisfile);
               list($out_name, $out_segment, $down_segment) = split("_", $ucibase);
               $this->riversegs[$out_segment] = array('segid'=>$out_segment, 'down_segid'=>$down_segment, 'uci'=>$thisfile,'elementid'=>-1, 'object'=>NULL);
               array_push($segsleft, $out_segment);
            }
         }

         # now, iterate through river segments, and check to see if they are already instantiated as objects under this
         # component -- should we do this here?  This might should be NOT the place to do this.  Hmmm ... maybe there should
         # be some other facility, in a model import script or something that creates these objects.
         # we can go a couple of routes here.  We could specify parameters of interest as components
         # of this container, then at runtime instantiate the necessary subwatershed reaches and landsegs, and then add the
         # appropriate operators on them.  For example:
         # specify - flow
         # instantiate - one HSPF container for each reach
         # add components at runtime - add components for upstream inflow, local inflow, flow out on each reach obbject
         # positives - we would maintain object nature of this routine, and cleanly define each reach
         # negatives - we would be unable to add static linkages to reach objects of interest from additional, user defined
         #    modeling objects

         # alternative #2
         # have a method called "create" which does specified tasks, called automatically when object is first created (or cloned)
         #    then have a button on the interface to force a re-creation.  This would enable us to re-specify included sub-objects
         #    (such as reaches, or landsegs), and enable us to specify consituents to be included in the
         #    HSPFcontainer as components that would propagate to the sub-objects on the re-creation.
         #    Might default to the creation of the basic constituents, such as flow, and perhaps DO.
         #    May consider having a function called reCreate() that defaults to calling create(), but could also include special
         #    behaviours for a given class.
      }
   }

   function getUpstream($segid) {
      $dirfiles = scandir($this->ucidir);
      $retfiles = array();
      foreach ($dirfiles as $thisfile) {
         if (strpos(strtolower($thisfile), '.uci')) {
            if (substr($thisfile, 9, 4) == $segid) {
               array_push($retfiles, $thisfile);
            }
         }
      }

      return $retfiles;
   }

}

class HSPFContainer extends modelContainer {
   var $state = array();
   var $sections = array();
   var $filepath = '';
   var $uciname = '';
   var $ucidir = '';
   var $uciobject;
   var $uciblocks;
   var $ucitables = array();
   var $blocks = array();
   var $subblocks = array();
   var $formats = array();
   var $errorstring = '';
   var $plotinfo = array();
   var $files = array();
   var $plotgens = array();
   var $plotgenfiles = array();
   var $wdms = array();
   var $wdm_dsns = array();
   var $listobject = -1;
   var $initialiazed = 0;
   var $parsed = 0;
   var $wdm_messagefile = '';
   var $hspf_timestep = 3600; # time step of HSPF model in seconds
   var $max_memory_values = -1; # passed to DSNs to cache data in order to save memory & speed execution
   var $wdimex_exe = '/Library/WebServer/CGI-Executables/wdimex';

   # requires the library lib_equation2.php, which has the class "Equation"
   var $equations = array(); # keyed by statevarname=>equationtext

   function wake() {
      parent::wake();
      $this->parseUCI();
   }

   function setCompID($thisid) {
      parent::setCompID($thisid);
   }
   
   function setState() {
      parent::setState();
      $this->state['hspf_timestep'] = $this->hspf_timestep;
      
   }
   
   function sleep() {
      parent::sleep();
      # things to do before this goes away, or gets stored
      $this->uciobject = NULL;
      $this->ucitables = array();
      $this->uciblocks = array();
      $this->sections = array();
      $this->formats = array();
      $this->blocks = array();
      $this->subblocks = array();
      $this->wdms = array();
      $this->wdm_dsns = array();
      $this->plotinfo = array();
      $this->files = array();
      $this->plotgens = array();
      $this->plotgenfiles = array();
   }

   function init() {
      
      if ( (!is_object($this->listobject)) or (strlen($this->filepath) == 0)) {
         $this->errorstring .= "You must set a UCI file, and a list object.<br>";
         if (!is_object($this->listobject)) {
            $this->errorstring .= "&nbsp;&nbsp;&nbsp;<i>List object missing.</i><br>";
         }
         if (strlen($this->filepath) == 0) {
            $this->errorstring .= "&nbsp;&nbsp;&nbsp;<i>Null File Path: $this->filepath </i>.<br>";
         }
      } else {
         if (!$this->parsed) {
            $this->parseUCI();
         }

         ############################################
         # now, create plotgen object for all files #
         ############################################
         if ($this->debug) {
            $this->logDebug("Checking for Plotgens ; <br>");
         }
         $this->listobject->querystring = "  select filepath, count(*) ";
         $this->listobject->querystring .= " from $this->tblprefix" . "tmp_allplotgens ";
         $this->listobject->querystring .= " group by filepath ";
         $this->listobject->performQuery();
         if ($this->debug) {
            $qs = $this->listobject->querystring;
            $this->logDebug("$qs ; <br>");
            $this->listobject->showList();
            $os = $this->listobject->outstring;
            $this->logDebug("$os ; <br>");
         }
         $this->plotgens = array();
         $pgnames = $this->listobject->queryrecords;
         $i = 0;
         #$this->debug = 1;
         #$this->debugmode = 1;
         foreach ($pgnames as $thisrec) {
            $pg_obj[$i] = new HSPFPlotgen;
            $pgparamcols = array();
            $fp = $thisrec['filepath'];
            /*
            if ($fp == 'RCHRES.localflow.1.out') {
               $pg_obj[$i]->debug = 1;
               $pg_obj[$i]->debugmode = 1;
               $pg_obj[$i]->loglines = 5;
            }
            */
            $pg_obj[$i]->filepath = dirname($this->filepath) . '/' . $fp;
            $pg_obj[$i]->tmpdir = $this->tmpdir;
            $pg_obj[$i]->wdm_messagefile = $this->wdm_messagefile;
            $this->listobject->querystring = "  select linkname, ssegno, linkgroup, targetmember, label, output_column ";
            $this->listobject->querystring .= " from $this->tblprefix" . "tmp_allplotgens ";
            $this->listobject->querystring .= " where filepath = '$fp' ";
            $this->listobject->performQuery();
            if ($this->debug) {
               $this->logDebug("Accessing plotgens on file $fp ; <br>");
               $qs = $this->listobject->querystring;
               $this->logDebug("$qs ; <br>");
               #$this->listobject->showList();
               #$os = $this->listobject->outstring;
               #$this->logDebug("$os ; <br>");
            }
            foreach ($this->listobject->queryrecords as $pgcol) {
               $pglabel = 'Plotgen - ' . $pgcol['linkname'] . " " . $pgcol['ssegno'] . " " . $pgcol['linkgroup'] . " " . $pgcol['targetmember'] . " " . $pgcol['label'] . "-" . $pgcol['output_column'];
               $this->addInput($pglabel, $pglabel, $pg_obj[$i]);
               $pgparamcols[$pglabel] = $pgcol['output_column'];
               if ($this->debug) {
                  $this->logDebug("Adding Plot label: $pglabel <br>");
                  $this->logDebug("Column:" . $pgcol['output_column'] . "<br>");
               }
            }
            $pg_obj[$i]->paramcolumns = $pgparamcols;
            if ($this->debug) {
               $this->logDebug("Param Columns on file $fp set to: <br>");
               $this->logDebug($pg_obj[$i]->paramcolumns);
               $this->logDebug("<br>");
               $this->logDebug("Param Columns on file $fp set to: <br>");
               $this->logDebug($pgparamcols);
               $this->logDebug("<br>");
               #$this->listobject->showList();
               #$os = $this->listobject->outstring;
               #$this->logDebug("$os ; <br>");
            }
            $pg_obj[$i]->setSimTimer($this->timer);
            $pg_obj[$i]->name = $fp;
            $pg_obj[$i]->debug = $this->debug;
            # set a unique id on this
            $pg_obj[$i]->componentid = $this->componentid . "_" . $i;
            #$this->errorstring .= $this->logDebug($thisrec,1);
            # must trigger init and setsimtimer from here, because these are hidden model components, and will
            # not be governed by the model container that calls the init process for all other components
            $this->addComponent($pg_obj[$i]);
            $i++;
         }
         #$this->debug = 0;
         #$this->debugmode = 0;

         ############################################
         # now, create WDM objects for all files    #
         ############################################

         # this creates WDM object shells, but does NOT enable any DSNs
         # users must now DEFINE accessible WDM components as individual sub-components
         # this will eliminate importing massive quantities of data that are not to be used
         $this->listobject->querystring = "  select filepath, handle, count(*) ";
         $this->listobject->querystring .= " from $this->tblprefix" . "tmp_allwdms ";
         $this->listobject->querystring .= " group by filepath, handle ";
         $this->listobject->performQuery();
         if ($this->debug) {
            $qs = $this->listobject->querystring;
            $this->logDebug("$qs ; <br>");
            $this->listobject->showList();
            $os = $this->listobject->outstring;
            $this->logDebug("$os ; <br>");
         }
         #$this->wdms = array();
         $pgnames = $this->listobject->queryrecords;
         # We started the count of components with the plotgens, so we need to keep these moving forward with the WDMs
         # so as not to overwrite the plotgens
         # $i = 0;
         $wdm_obj = array();
         #$this->debug = 1;
         #$this->debugmode = 1;
         foreach ($pgnames as $thisrec) {
            $wdm_obj[$i] = new HSPFWDM;
            
            $pgparamcols = array();
            $fp = $thisrec['filepath'];
            $wdmid = $thisrec['handle'];
            $wdm_obj[$i]->filepath = dirname($this->filepath) . '/' . $fp;
            $wdm_obj[$i]->wdimex_exe = $this->wdimex_exe;
            $wdm_obj[$i]->max_memory_values = $this->max_memory_values;
            $wdm_obj[$i]->name = $fp;
            $wdm_obj[$i]->tmpdir = $this->tmpdir;
            $wdm_obj[$i]->outdir = $this->outdir;
            $wdm_obj[$i]->sessionid = $this->sessionid;
            $wdm_obj[$i]->componentid = $this->componentid . $i;
            $wdm_obj[$i]->wdm_messagefile = $this->wdm_messagefile;
            $wdm_obj[$i]->listobject = $this->listobject;
            $wdm_obj[$i]->setSimTimer($this->timer);
            #error_log("Adding WDM Component $i");
            $this->wdm_files[$wdmid]['object'] = $wdm_obj[$i];
            $i++;
            #error_log("Creating Base WDM object for " . $wdmid);
         }
      }
      $this->initialiazed = 1;
      if ($this->debug) {
         $this->logDebug("Components: <br>");
         # commented out because trying to log an object will cause troubles
         # $this->logDebug($this->components);
         $this->logDebug("<br>");
      }

      # this will do all the normal stuff, including initializing processors, some of which MAY be DSN's
      # so we do it, then return to instantiate the WDMs with their associated DSNs
      parent::init();
      # now, any DSN accessors have been declared, and have called the parents activateDSN function
      foreach ($this->wdm_files as $thiswdm) {
         //if (is_object($thiswdm['object'])) {
            $thiswdm['object']->init();
         //}
      }

   }
   
   function setUpBlockList() {
      
      $this->blocks = array('FILES', 'PLTGEN', 'SCHEMATIC', 'EXT SOURCES', 'EXT TARGETS', 'MASS-LINK', 'RCHRES', 'PERLND', 'IMPLND', 'COPY');
      $this->subblocks = array(
         'FILES'=>array(''),
         'PLTGEN'=>array('PLOTINFO','CURV-DATA'),
         'SCHEMATIC'=>array(''),
         'EXT SOURCES'=>array(''),
         'EXT TARGETS'=>array(''),
         'MASS-LINK'=>array('MASS-LINK'),
         'RCHRES'=>array('GEN-INFO','HYDR-PARM2'),
         'PERLND'=>array('GEN-INFO'),
         'IMPLND'=>array('GEN-INFO'),
         'COPY'=>array('TIMESERIES')
      );
      $this->formats = array(
         'FILES'=>array('FILES'=>$this->uciobject->ucitables['FILES']),
         'PLTGEN'=>array(
            'PLOTINFO'=>$this->uciobject->ucitables['PLOTINFO'],
            'CURV-DATA'=>$this->uciobject->ucitables['CURV-DATA']
         ),
         'SCHEMATIC'=>array('SCHEMATIC'=>$this->uciobject->ucitables['SCHEMATIC']),
         'EXT TARGETS'=>array('EXT TARGETS'=>$this->uciobject->ucitables['EXT TARGETS']),
         'EXT SOURCES'=>array('EXT SOURCES'=>$this->uciobject->ucitables['EXT SOURCES']),
         'MASS-LINK'=>array('MASS-LINK'=>$this->uciobject->ucitables['MASS-LINKS']),
         'RCHRES'=>array('GEN-INFO'=>$this->uciobject->ucitables['RGEN-INFO'],'HYDR-PARM2'=>$this->uciobject->ucitables['HYDR-PARM2']),
         'PERLND'=>array('GEN-INFO'=>$this->uciobject->ucitables['PGEN-INFO']),
         'IMPLND'=>array('GEN-INFO'=>$this->uciobject->ucitables['PGEN-INFO']),
         'COPY'=>array('TIMESERIES'=>$this->uciobject->ucitables['TIMESERIES'])
      );
      
   }

   function step() {
      # step any DSN accessors have been declared
      foreach ($this->wdm_files as $thiswdm) {
         $thiswdm['object']->step();
      }
      # this will do all the normal stuff, including stepping processors, some of which MAY be DSN's
      # so we do that first, and now we can step their associated DSNs and they will have the needed data
      parent::step();
   }

   function finish() {
      # step any DSN accessors have been declared
      foreach ($this->wdm_files as $thiswdm) {
         $thiswdm['object']->finish();
      }

      # this will do all the normal stuff, including stepping processors, some of which MAY be DSN's
      # so we do that first, and now we can step their associated DSNs and they will have the needed data
      parent::finish();
   }

   function cleanUp() {
      # remove all the temp tables associated with this object
      $temp_tables = array("$this->tblprefix" . "tmp_allwdms", "$this->tblprefix" . "tmp_allplotgens", "$this->tblprefix" . "uciblocks");
      # remove all the temp tables associated with this object
      foreach ($temp_tables as $this_tbl) {
         if (is_object($this->listobject)) {
            if ($this->listobject->tableExists($this_tbl)) {
               $this->listobject->querystring = "  drop table $this_tbl ";
               $this->listobject->performQuery();
            }
         }
      }
      
      # cleanUp any DSN accessors have been declared
      foreach ($this->wdm_files as $thiswdm) {
         if (is_object($thiswdm['object'])) {
            if (method_exists($thiswdm['object'],'cleanUp')) {
               $thiswdm['object']->cleanUp();
            }
            unset($thiswdm['object']);
         }
      }
      
      # get rid of all temp tables created with UCI parsing
      foreach (array_keys($this->uciobject->ucitables) as $this_block) {
         if (is_object($this->listobject)) {
            if ($this->listobject->tableExists($this->db_cache_name)) {
               $this_tbl = $this->uciobject->ucitables[$this_block]['tablename'];
               $this->listobject->querystring = "  drop table $this_tbl ";
               $this->listobject->performQuery();
            }
         }
      }
      
      # this will do all the normal stuff, including stepping processors, some of which MAY be DSN's
      # so we do that first, and now we can step their associated DSNs and they will have the needed data
      parent::cleanUp();
   }
   
   function parseUCIPart($blockname) {

      $tablename = $this->tblprefix . $this->uciobject->ucitables[$blockname]['tablename'];
      $block = $this->uciobject->ucitables[$blockname]['parentblock'];
      $subblock = $this->uciobject->ucitables[$blockname]['subblock'];
      $this->uciobject->ucitables[$blockname]['tablename'] = $tablename;
      $thisinfo = $thisinfoset[$block][$subblock];
      
      if (count($thisinfo) == 0) {
         $thisinfo[0] = array();
      }
      
      foreach (array_keys($thisinfo) as $infoid) {
         $tbdata = $thisinfo[$infoid];
         makeUCITable($this->uciobject->listobject,$blockname,$tbdata,$this->uciobject->ucitables,0, 1);
      }
      
   }


   function parseUCI() {

      # set a unique prefix for UCI tables
      # set a name for the temp table that will not hose the db
      $targ = array(' ',':','-','.');
      $repl = array('_', '_', '_', '_');
      $this->tblprefix = str_replace($targ, $repl, "tmp$this->componentid" . "_");

      if ( (!$this->listobject) or (strlen($this->filepath) == 0) or (count($this->ucitables) == 0)) {
         $this->errorstring .= "You must set a UCI file, UCI table templates, and a list object.<br>";
         $this->errorstring .= "ListObject: " . is_object($this->listobject) . "<br>";
         $this->errorstring .= "UCITable Entries: " . count($this->ucitables) . "<br>";
         $this->errorstring .= "File Path: " . $this->filepath . "<br>";
         $this->errorstring .= "Method parseUCI() abandoned.<br>";
      } else {
         $this->uciobject = new HSPF_UCIobject();
         $this->uciobject->listobject = $this->listobject;
         $this->uciobject->ucitables = $this->ucitables;
         # parses the uci, and gets the blocks present in it
         $this->ucidir = dirname($this->filepath);
         $this->uciname = basename($this->filepath);
         $this->uciobject->ucifile = $this->filepath;
         $this->uciobject->uciblocks_tbl = $this->tblprefix . 'uciblocks';
         $this->uciblocks = $this->uciobject->getUCIBlocks();
         $secar = array();

         # store the UCI in an array to speed up querying
         #$uciarray = file($this->uciobject->ucifile);
         $uciarray = $this->uciobject->ucifile;

         $this->listobject->show = 0;
         $this->listobject->tablename = '';

         # set up table information and requests for multiple parsing of UCI
         # this will save many accesses, as it only parses the file once, and gets all requested
         # blocks and sub-blocks in a single pass
         
         $this->setUpBlockList();
         $blocks = $this->blocks;
         $subblocks = $this->subblocks;
         $formats = $this->formats;

         # new code to make requests all at once
         $this->errorstring .= "Parsing All Blocks at once.<br>";
         $thisinfoset = parseMultipleUCIBlocks($uciarray, $blocks, $subblocks, $formats, 0);
         # create a custom table prefix in order to maintain table associations, reset the names in the ucitables array,
         # so that these are preserved later.  Will need to vet any functions that operate on UCI tables to make sure that they
         # query the ucitables array for the name of a table, rather than to assume that it is the original name

         $tablename = $this->tblprefix . $this->uciobject->ucitables['FILES']['tablename'];
         $this->uciobject->ucitables['FILES']['tablename'] = $tablename;
         $thisblock = 'FILES';
         $thisinfo = $thisinfoset['FILES']['FILES'];
         if (count($thisinfo) == 0) {
            $thisinfo[0] = array();
         }
         foreach (array_keys($thisinfo) as $infoid) {
            $tbdata = $thisinfo[$infoid];
            makeUCITable($this->uciobject->listobject,$thisblock,$tbdata,$this->uciobject->ucitables,0, 1);
         }

         $tablename = $this->tblprefix . $this->uciobject->ucitables['PLOTINFO']['tablename'];
         $this->uciobject->ucitables['PLOTINFO']['tablename'] = $tablename;
         $thisblock = 'PLOTINFO';
         $thisinfo = $thisinfoset['PLTGEN']['PLOTINFO'];
         if (count($thisinfo) == 0) {
            $thisinfo[0] = array();
         }
         foreach (array_keys($thisinfo) as $infoid) {
            $tbdata = $thisinfo[$infoid];
            makeUCITable($this->uciobject->listobject,$thisblock,$tbdata,$this->uciobject->ucitables,0, 1);
         }

         $tablename = $this->tblprefix . $this->uciobject->ucitables['CURV-DATA']['tablename'];
         $this->uciobject->ucitables['CURV-DATA']['tablename'] = $tablename;
         $thisblock = 'CURV-DATA';
         $HTMLInfo .= "<br>Searching UCI for $tablename <br>";
         $thisinfo = $thisinfoset['PLTGEN']['CURV-DATA'];
         if (count($thisinfo) == 0) {
            $thisinfo[0] = array();
         }
         foreach (array_keys($thisinfo) as $infoid) {
            $tbdata = $thisinfo[$infoid];
            makeUCITable($this->uciobject->listobject,$thisblock,$tbdata,$this->uciobject->ucitables,0, 1);
         }

         $tablename = $this->tblprefix . $this->uciobject->ucitables['SCHEMATIC']['tablename'];
         $this->uciobject->ucitables['SCHEMATIC']['tablename'] = $tablename;
         $thisblock = 'SCHEMATIC';
         $this->uciobject->debug = 0;
         $thisinfo = $thisinfoset['SCHEMATIC']['SCHEMATIC'];
         if (count($thisinfo) == 0) {
            $thisinfo[0] = array();
         }
         foreach (array_keys($thisinfo) as $infoid) {
            $tbdata = $thisinfo[$infoid];
            makeUCITable($this->uciobject->listobject,$thisblock,$tbdata,$this->uciobject->ucitables,0, 1);
         }

         $tablename = $this->tblprefix . $this->uciobject->ucitables['EXT TARGETS']['tablename'];
         $this->uciobject->ucitables['EXT TARGETS']['tablename'] = $tablename;
         $thisblock = 'EXT TARGETS';
         $thisinfo = $thisinfoset['EXT TARGETS']['EXT TARGETS'];
         if (count($thisinfo) == 0) {
            $thisinfo[0] = array();
         }
         foreach (array_keys($thisinfo) as $infoid) {
            $tbdata = $thisinfo[$infoid];
            makeUCITable($this->uciobject->listobject,$thisblock,$tbdata,$this->uciobject->ucitables,0, 1);
         }

         $tablename = $this->tblprefix . $this->uciobject->ucitables['EXT SOURCES']['tablename'];
         $this->uciobject->ucitables['EXT SOURCES']['tablename'] = $tablename;
         $thisblock = 'EXT SOURCES';
         $thisinfo = $thisinfoset['EXT SOURCES']['EXT SOURCES'];
         if (count($thisinfo) == 0) {
            $thisinfo[0] = array();
         }
         foreach (array_keys($thisinfo) as $infoid) {
            $tbdata = $thisinfo[$infoid];
            makeUCITable($this->uciobject->listobject,$thisblock,$tbdata,$this->uciobject->ucitables,0, 1);
         }

         $tablename = $this->tblprefix . $this->uciobject->ucitables['MASS-LINKS']['tablename'];
         $this->uciobject->ucitables['MASS-LINKS']['tablename'] = $tablename;
         $thisblock = 'MASS-LINKS';
         $thisinfo = $thisinfoset['MASS-LINK']['MASS-LINK'];
         if (count($thisinfo) == 0) {
            $thisinfo[0] = array();
         }
         foreach (array_keys($thisinfo) as $infoid) {
            $tbdata = $thisinfo[$infoid];
            makeUCITable($this->uciobject->listobject,$thisblock,$tbdata,$this->uciobject->ucitables,0, 1);
         }

         $tablename = $this->tblprefix . $this->uciobject->ucitables['RGEN-INFO']['tablename'];
         $this->uciobject->ucitables['RGEN-INFO']['tablename'] = $tablename;
         $thisinfo = $thisinfoset['RCHRES']['GEN-INFO'];
         if (count($thisinfo) == 0) {
            $thisinfo[0] = array();
         }
         $thisblock = 'RGEN-INFO';
         foreach (array_keys($thisinfo) as $infoid) {
            $tbdata = $thisinfo[$infoid];
            makeUCITable($this->uciobject->listobject,$thisblock,$tbdata,$this->uciobject->ucitables,0, 1);
         }

         $tablename = $this->tblprefix . $this->uciobject->ucitables['PGEN-INFO']['tablename'];
         $this->uciobject->ucitables['PGEN-INFO']['tablename'] = $tablename;
         $thisinfo = $thisinfoset['PERLND']['GEN-INFO'];
         if (count($thisinfo) == 0) {
            $thisinfo[0] = array();
         }
         $thisblock = 'PGEN-INFO';
         foreach (array_keys($thisinfo) as $infoid) {
            $tbdata = $thisinfo[$infoid];
            makeUCITable($this->uciobject->listobject,$thisblock,$tbdata,$this->uciobject->ucitables,0, 1);
         }

         $tablename = $this->tblprefix . $this->uciobject->ucitables['IGEN-INFO']['tablename'];
         $this->uciobject->ucitables['IGEN-INFO']['tablename'] = $tablename;
         $thisinfo = $thisinfoset['IMPLND']['GEN-INFO'];
         if (count($thisinfo) == 0) {
            $thisinfo[0] = array();
         }
         $thisblock = 'IGEN-INFO';
         foreach (array_keys($thisinfo) as $infoid) {
            $tbdata = $thisinfo[$infoid];
            makeUCITable($this->uciobject->listobject,$thisblock,$tbdata,$this->uciobject->ucitables,0, 1);
         }

         $tablename = $this->tblprefix . $this->uciobject->ucitables['TIMESERIES']['tablename'];
         $this->uciobject->ucitables['TIMESERIES']['tablename'] = $tablename;
         $thisinfo = $thisinfoset['COPY']['TIMESERIES'];
         if (count($thisinfo) == 0) {
            $thisinfo[0] = array();
         }
         $thisblock = 'TIMESERIES';
         foreach (array_keys($thisinfo) as $infoid) {
            $tbdata = $thisinfo[$infoid];
            makeUCITable($this->uciobject->listobject,$thisblock,$tbdata,$this->uciobject->ucitables,0, 1);
         }

         # output schematic outputs to a plotgen
         $this->listobject->querystring = "  select * into temp table $this->tblprefix" . "tmp_allplotgens ";
         $this->listobject->querystring .= " from ( ";
         $this->listobject->querystring .= " ( select d.ssegno, b.filepath, e.linkname, e.linkgroup, e.targetmember, ";
         $this->listobject->querystring .= "    f.label, e.targetno1, e.targetno2, f.columnno as output_column ";
         $this->listobject->querystring .= "  from $this->tblprefix" . "rchresgeninfo as a, $this->tblprefix" . "files as b, $this->tblprefix" . "plotinfo as c, $this->tblprefix" . "schematic as d, ";
         $this->listobject->querystring .= "    $this->tblprefix" . "masslinks as e, $this->tblprefix" . "curvdata as f ";
         $this->listobject->querystring .= " where c.fileno = b.fileno ";
         $this->listobject->querystring .= "    and d.sname = 'RCHRES' ";
         $this->listobject->querystring .= "    and d.dname = 'PLTGEN' ";
         $this->listobject->querystring .= "    and ( (";
         $this->listobject->querystring .= "       c.segstart <= d.dsegno ";
         $this->listobject->querystring .= "       and c.segend >= d.dsegno ";
         $this->listobject->querystring .= "    ) or ( ";
         $this->listobject->querystring .= "       c.segstart = d.dsegno ";
         $this->listobject->querystring .= "       and c.segend is null";
         $this->listobject->querystring .= "    ) ) ";
         $this->listobject->querystring .= "    and ( (";
         $this->listobject->querystring .= "       f.segstart <= d.dsegno ";
         $this->listobject->querystring .= "       and f.segend >= d.dsegno ";
         $this->listobject->querystring .= "    ) or ( ";
         $this->listobject->querystring .= "       f.segstart = d.dsegno ";
         $this->listobject->querystring .= "       and f.segend is null";
         $this->listobject->querystring .= "    ) ) ";
         $this->listobject->querystring .= "    and ( (";
         $this->listobject->querystring .= "       a.segstart <= d.ssegno ";
         $this->listobject->querystring .= "       and a.segend >= d.ssegno ";
         $this->listobject->querystring .= "    ) or ( ";
         $this->listobject->querystring .= "       a.segstart = d.ssegno ";
         $this->listobject->querystring .= "       and a.segend is null";
         $this->listobject->querystring .= "    ) ) ";
         $this->listobject->querystring .= "    and d.mlno = e.masslink ";
         $this->listobject->querystring .= "    and e.targetno1 = f.columnno ";

         $this->listobject->querystring .= " ) UNION ( ";

         $this->listobject->querystring .= "  select d.ssegno, b.filepath, e.linkname, e.linkgroup, e.targetmember, ";
         $this->listobject->querystring .= "    f.label, e.targetno1, e.targetno2, f.columnno as output_column ";
         $this->listobject->querystring .= " from $this->tblprefix" . "implndgeninfo as a, $this->tblprefix" . "files as b, $this->tblprefix" . "plotinfo as c, $this->tblprefix" . "schematic as d, ";
         $this->listobject->querystring .= "    $this->tblprefix" . "masslinks as e, $this->tblprefix" . "curvdata as f ";
         $this->listobject->querystring .= " where c.fileno = b.fileno ";
         $this->listobject->querystring .= "    and d.sname = 'IMPLND' ";
         $this->listobject->querystring .= "    and d.dname = 'PLTGEN' ";
         $this->listobject->querystring .= "    and c.segstart <= d.dsegno ";
         $this->listobject->querystring .= "    and c.segend >= d.dsegno ";
         $this->listobject->querystring .= "    and ( (";
         $this->listobject->querystring .= "       f.segstart <= d.dsegno ";
         $this->listobject->querystring .= "       and f.segend >= d.dsegno ";
         $this->listobject->querystring .= "    ) or ( ";
         $this->listobject->querystring .= "       f.segstart = d.dsegno ";
         $this->listobject->querystring .= "       and f.segend is null";
         $this->listobject->querystring .= "    ) ) ";
         $this->listobject->querystring .= "    and ( (";
         $this->listobject->querystring .= "       a.segstart <= d.ssegno ";
         $this->listobject->querystring .= "       and a.segend >= d.ssegno ";
         $this->listobject->querystring .= "    ) or ( ";
         $this->listobject->querystring .= "       a.segstart = d.ssegno ";
         $this->listobject->querystring .= "       and a.segend is null";
         $this->listobject->querystring .= "    ) ) ";
         $this->listobject->querystring .= "    and d.mlno = e.masslink ";
         $this->listobject->querystring .= "    and e.targetno1 = f.columnno ";

         $this->listobject->querystring .= " ) UNION ( ";

         $this->listobject->querystring .= "  select d.ssegno, b.filepath, e.linkname, e.linkgroup, e.targetmember, ";
         $this->listobject->querystring .= "    f.label, e.targetno1, e.targetno2, f.columnno as output_column ";
         $this->listobject->querystring .= " from $this->tblprefix" . "perlndgeninfo as a, $this->tblprefix" . "files as b, $this->tblprefix" . "plotinfo as c, $this->tblprefix" . "schematic as d, ";
         $this->listobject->querystring .= "    $this->tblprefix" . "masslinks as e, $this->tblprefix" . "curvdata as f ";
         $this->listobject->querystring .= " where c.fileno = b.fileno ";
         $this->listobject->querystring .= "    and d.sname = 'PERLND' ";
         $this->listobject->querystring .= "    and d.dname = 'PLTGEN' ";
         $this->listobject->querystring .= "    and c.segstart <= d.dsegno ";
         $this->listobject->querystring .= "    and c.segend >= d.dsegno ";
         $this->listobject->querystring .= "    and ( (";
         $this->listobject->querystring .= "       f.segstart <= d.dsegno ";
         $this->listobject->querystring .= "       and f.segend >= d.dsegno ";
         $this->listobject->querystring .= "    ) or ( ";
         $this->listobject->querystring .= "       f.segstart = d.dsegno ";
         $this->listobject->querystring .= "       and f.segend is null";
         $this->listobject->querystring .= "    ) ) ";
         $this->listobject->querystring .= "    and ( (";
         $this->listobject->querystring .= "       a.segstart <= d.ssegno ";
         $this->listobject->querystring .= "       and a.segend >= d.ssegno ";
         $this->listobject->querystring .= "    ) or ( ";
         $this->listobject->querystring .= "       a.segstart = d.ssegno ";
         $this->listobject->querystring .= "       and a.segend is null";
         $this->listobject->querystring .= "    ) ) ";
         $this->listobject->querystring .= "    and d.mlno = e.masslink ";
         $this->listobject->querystring .= "    and e.targetno1 = f.columnno ";

         $this->listobject->querystring .= " ) UNION ( ";

         $this->listobject->querystring .= "  select d.ssegno, b.filepath, e.linkname, e.linkgroup, e.targetmember, ";
         $this->listobject->querystring .= "    f.label, e.targetno1, e.targetno2, f.columnno as output_column ";
         $this->listobject->querystring .= " from $this->tblprefix" . "copytimeseries as a, $this->tblprefix" . "files as b, $this->tblprefix" . "plotinfo as c, $this->tblprefix" . "schematic as d, ";
         $this->listobject->querystring .= "    $this->tblprefix" . "masslinks as e, $this->tblprefix" . "curvdata as f ";
         $this->listobject->querystring .= " where c.fileno = b.fileno ";
         $this->listobject->querystring .= "    and d.sname = 'COPY' ";
         $this->listobject->querystring .= "    and d.dname = 'PLTGEN' ";
         $this->listobject->querystring .= "    and c.segstart <= d.dsegno ";
         $this->listobject->querystring .= "    and c.segend >= d.dsegno ";
         $this->listobject->querystring .= "    and ( (";
         $this->listobject->querystring .= "       f.segstart <= d.dsegno ";
         $this->listobject->querystring .= "       and f.segend >= d.dsegno ";
         $this->listobject->querystring .= "    ) or ( ";
         $this->listobject->querystring .= "       f.segstart = d.dsegno ";
         $this->listobject->querystring .= "       and f.segend is null";
         $this->listobject->querystring .= "    ) ) ";
         $this->listobject->querystring .= "    and ( (";
         $this->listobject->querystring .= "       a.segstart <= d.ssegno ";
         $this->listobject->querystring .= "       and a.segend >= d.ssegno ";
         $this->listobject->querystring .= "    ) or ( ";
         $this->listobject->querystring .= "       a.segstart = d.ssegno ";
         $this->listobject->querystring .= "       and a.segend is null";
         $this->listobject->querystring .= "    ) ) ";
         $this->listobject->querystring .= "    and d.mlno = e.masslink ";
         $this->listobject->querystring .= "    and e.targetno1 = f.columnno ";

         $this->listobject->querystring .= ") ) as foo ";
         #$this->errorstring .= $this->listobject->querystring . "<br>";
         $this->listobject->performQuery();

         $this->listobject->querystring = " select * from $this->tblprefix" . "tmp_allplotgens ";
         $this->listobject->performQuery();
         $this->listobject->showList();
         #$this->errorstring .= $this->listobject->querystring . "<br>";
         $this->errorstring .= $this->listobject->outstring;

         # output ext source outputs to a wdm
         if ($this->debug) {
            $this->listobject->querystring = "select *  from $this->tblprefix" . "extsources";
            $this->listobject->performQuery();
            $this->logDebug($this->listobject->querystring . " ; <br>");
            $this->listobject->showList();
            $this->logDebug($this->listobject->outstring . " <br>");
            $this->listobject->querystring = "select *  from $this->tblprefix" . "exttargets";
            $this->listobject->performQuery();
            $this->logDebug($this->listobject->querystring . " ; <br>");
            $this->listobject->showList();
            $this->logDebug($this->listobject->outstring . " <br>");
         }
         $this->listobject->querystring = "  select * into temp table $this->tblprefix" . "tmp_allwdms ";
         $this->listobject->querystring .= " from ( ";
         $this->listobject->querystring .= " ( select 'o' as io, a.sourcevolume as hspfvol, a.sourceid as hspfsegid, ";
         $this->listobject->querystring .= "    a.sourcegroup::varchar(8) as hspfgroup, ";
         $this->listobject->querystring .= "    a.sourcename as hspfmember, a.memberid1, a.memberid2, ";
         $this->listobject->querystring .= "    a.targetname as wdmname, a.targetid as dsn, b.handle, b.filepath ";
         $this->listobject->querystring .= " from $this->tblprefix" . "exttargets as a, $this->tblprefix" . "files as b ";
         $this->listobject->querystring .= " where a.sourcevolume = 'RCHRES' ";
         $this->listobject->querystring .= "    and a.targetvolume = b.handle ";
         $this->listobject->querystring .= " ) UNION ( ";
         $this->listobject->querystring .= "  select 'i' as io, a.targetvolume as hspfvol, a.segstart as hspfsegid, ";
         $this->listobject->querystring .= "    a.targetgroup as hspfgroup, a.targetname as hspfmember, ";
         $this->listobject->querystring .= "    a.targetnum1 as memberid1, a.targetnum2 as memberid2, ";
         $this->listobject->querystring .= "    a.elem as wdmname, a.recid as dsn, b.handle, b.filepath ";
         $this->listobject->querystring .= " from $this->tblprefix" . "extsources as a, $this->tblprefix" . "files as b ";
         $this->listobject->querystring .= " where a.targetvolume = 'RCHRES' ";
         $this->listobject->querystring .= "    and a.wdmid = b.handle ";
         $this->listobject->querystring .= ") ) as foo ";
         $this->listobject->performQuery();
         if ($this->debug) {
            $this->logDebug($this->listobject->querystring . " ; <br>");
         }
         # ext source columns - wdmid, recid, elem, units, defmissing, multfactor, tstran, targetvolume, segstart, segend, targetgroup, targetname, targetnum1, targetnum2

         $this->listobject->querystring = " select * from $this->tblprefix" . "tmp_allwdms ";
         $this->listobject->performQuery();
         $this->listobject->showList();
         if ($this->debug) {
            $this->logDebug("Contents of $this->tblprefix" . "tmp_allwdms <br>");
            $this->logDebug($this->listobject->outstring . " ; <br>");
         }
         $this->errorstring .= $this->listobject->outstring;

         # now, populate the wdm array, and plotgen array with the names of the files
         # this is disabled, users must now DEFINE accessible WDM components as individual sub-components
         # this will eliminate importing massive quantities of data that are not to be used
         $this->listobject->querystring = "  select handle, filepath, count(*) ";
         $this->listobject->querystring .= " from $this->tblprefix" . "tmp_allwdms ";
         $this->listobject->querystring .= " group by handle, filepath ";
         $this->listobject->performQuery();
         if ($this->debug) {
            $qs = $this->listobject->querystring;
            $this->logDebug("$qs ; <br>");
            $this->listobject->showList();
            $os = $this->listobject->outstring;
            $this->logDebug("$os ; <br>");
         }
         #$this->wdms = array();
         $pgnames = $this->listobject->queryrecords;
         # We started the count of components with the plotgens, so we need to keep these moving forward with the WDMs
         # so as not to overwrite the plotgens
         # $i = 0;
         $this->wdm_files = array();
         #$this->debug = 1;
         #$this->debugmode = 1;
         foreach ($pgnames as $thisrec) {
            $this->wdm_files[$thisrec['handle']] = array(
               'id'=>$thisrec['handle'],
               'filepath'=>$thisrec['filepath'],
               'object'=>-1,
               'active_dsns'=>array()
            );
            if ($this->debug) {
               $this->logDebug("Adding " . $thisrec['handle'] . " " . $thisrec['filepath'] . " to wdm_files <br>");
            }
         }
         $this->listobject->querystring = "  select * ";
         $this->listobject->querystring .= " from $this->tblprefix" . "tmp_allwdms ";
         $this->listobject->performQuery();
         $this->wdms = array();
         $this->wdm_dsns = array();
         foreach ($this->listobject->queryrecords as $thisrec) {
            if ($thisrec['io'] == 'i') {
               $pre = 'IN - ';
            } else {
               $pre = 'OUT - ';
            }
            $pglabel = $pre . $thisrec['handle'] . " " . $thisrec['dsn'] . " " . $thisrec['wdmname'] . " " . $thisrec['hspfvol'] . " " . $thisrec['hspfsegid'] . " " . $thisrec['hspfgroup'];
            array_push($this->wdms, $pglabel);
            $this->wdm_dsns[$pglabel] = array(
               'id'=> $thisrec['handle'],
               'dsn'=> ltrim(rtrim($thisrec['dsn']))
            );
            if ($this->debug) {
               $this->logDebug("Creating Base DSN object for " . $pglabel . "<br>");
            }
         }

         # now, populate the wdm array, and plotgen array with the names of the files
         $this->listobject->querystring = "  select * ";
         $this->listobject->querystring .= " from $this->tblprefix" . "tmp_allplotgens ";
         $this->listobject->performQuery();
         $this->plotgenfiles = array();
         foreach ($this->listobject->queryrecords as $thisrec) {
            $pglabel = 'Plotgen - ' . $thisrec['linkname'] . " " . $thisrec['ssegno'] . " " . $thisrec['linkgroup'] . " " . $thisrec['targetmember'] . " " . $thisrec['label'] . "-" . $thisrec['output_column'];
            array_push($this->plotgenfiles, $pglabel);
            $this->errorstring .= $this->logDebug($thisrec,1);
         }
         $this->parsed = 1;
         $this->errorstring .= "<br>Plotgens: " . $this->logDebug($this->plotgenfiles,1);
      }

   }

   function activateDSN($dsname) {
      #error_log("Activating DSN by Name = " . $dsname);
      if (in_array($dsname, array_keys($this->wdm_dsns))) {
         $wdmid = $this->wdm_dsns[$dsname]['id'];
         $dsn = $this->wdm_dsns[$dsname]['dsn'];
         if (in_array($wdmid, array_keys($this->wdm_files))) {
            if (is_object($this->wdm_files[$wdmid]['object'])) {
               $this->wdm_files[$wdmid]['object']->activateDSN($dsn);
            }
         }
      }
   }

   function getDSNValue($dsname) {
      $dsnval = NULL;
      #error_log("getDSNValue called for $dsname");
      if (in_array($dsname, array_keys($this->wdm_dsns))) {
         $wdmid = $this->wdm_dsns[$dsname]['id'];
         $dsn = $this->wdm_dsns[$dsname]['dsn'];
         #error_log("Found IDs for $dsname " . $wdmid . " " . $dsn);
         if (in_array($wdmid, array_keys($this->wdm_files))) {
            if (is_object($this->wdm_files[$wdmid]['object'])) {
               $dsnval = $this->wdm_files[$wdmid]['object']->getValue($this->timer->timeseconds, $dsn);
               #error_log("DSNVal retrieved " . $dsnval . " From state = " . print_r($this->wdm_files[$wdmid]['object']->state,1));
            }
         }
      }
      return $dsnval;
   }

   function getPropertyClass($propclass) {
      # Call parent method to get any standard classes matching the criteria
      if (!$this->parsed) {
         $this->parseUCI();
      }
      $returnprops = parent::getPropertyClass($propclass);
      foreach ($propclass as $thisclass) {

         switch ($thisclass) {

            case 'plotgen':
            $returnprops = array_unique(array_merge($returnprops, $this->getPlotgens()));
            #$returnprops = $rproptemp;
            break;

            case 'wdm':
            $returnprops = array_unique(array_merge($returnprops, $this->getWDMs()));
            break;

         }
      }
      #$returnprops = $this->plotgens;
      return $returnprops;
   }

   function getPublicVars() {
      if (!$this->parsed) {
         #error_log("Parsing UCI before returning properties");
         $this->parseUCI();
      }
      # gets all viewable variables
      # this is a sub-class method, to include getting plotgens
      
      $procs = $this->getPublicProcs();
      
      $publix = array_unique(array_merge(array_keys($this->state), $this->getPublicProps(), $this->getPublicProcs(), $this->getPublicInputs(), $this->getPlotgens()));
      return $publix;
   }
   
   function getPublicProps() {
      # gets only properties that are visible (must be manually defined)
      $publix = parent::getPublicProps();

      array_push($publix, 'hspf_timestep');

      return $publix;
   }

   function getPlotgens() {
      if (is_array($this->plotgenfiles)) {
         return $this->plotgenfiles;
      } else {
         return array();
      }
   }

   function getWDMs() {
      if (is_array($this->wdms)) {
         return $this->wdms;
      } else {
         return array();
      }
   }

   function showHTMLInfo() {
      $HTMLInfo = '';
      $HTMLInfo .= parent::showHTMLInfo();
      if (!$this->initialiazed) {
         #$this->init();
         $HTMLInfo .= "Calling UCI Parsing routine.<br>";
         $this->parseUCI();
      }
      $HTMLInfo .= $this->errorstring;
      $this->uciobject->debug = 0;

      if ( (!$this->listobject) or (strlen($this->filepath) == 0)) {
         $HTMLInfo .= "You must set a UCI file, and a list object.<br>";
         $HTMLInfo .= "UCI file: " . $this->filepath  . "<br>";
      } else {

         #$HTMLInfo .= $this->logDebug($this->ucitables,1);
         $HTMLInfo .= "Parsed: " . $this->filepath . "<br>";

         $this->listobject->show = 0;
         $this->listobject->tablename = '';
         
         $HTMLInfo .= "<hr>Blocks in this UCI: " . print_r($this->uciblocks,1) . "<hr>";

         $tablename = $this->uciobject->ucitables['FILES']['tablename'];
         $thisblock = 'FILES';
         $HTMLInfo .= "<br>Searching UCI for $tablename <br>";
         $this->listobject->querystring = " select * from $tablename ";
         $HTMLInfo .= $this->listobject->querystring . "<br>";
         $this->listobject->performQuery();
         $this->listobject->showList();
         $HTMLInfo .= $this->listobject->outstring;

         $tablename = $this->uciobject->ucitables['PLOTINFO']['tablename'];
         $thisblock = 'PLOTINFO';
         $HTMLInfo .= "<br>Searching UCI for $tablename <br>";
         $this->listobject->querystring = " select * from $tablename ";
         $this->listobject->performQuery();
         $this->listobject->showList();
         $HTMLInfo .= $this->listobject->outstring;

         $tablename = $this->uciobject->ucitables['CURV-DATA']['tablename'];
         $thisblock = 'CURV-DATA';
         $HTMLInfo .= "<br>Searching UCI for $tablename <br>";
         $this->listobject->querystring = " select * from $tablename ";
         $this->listobject->performQuery();
         $this->listobject->showList();
         $HTMLInfo .= $this->listobject->outstring;

         $tablename = $this->uciobject->ucitables['SCHEMATIC']['tablename'];
         $thisblock = 'SCHEMATIC';
         $HTMLInfo .= "<br>Searching UCI for $tablename <br>";
         $this->listobject->querystring = " select * from $tablename ";
         $this->listobject->performQuery();
         $this->listobject->showList();
         $HTMLInfo .= $this->listobject->outstring;

         $tablename = $this->uciobject->ucitables['EXT TARGETS']['tablename'];
         $thisblock = 'EXT TARGETS';
         $HTMLInfo .= "<br>Searching UCI for $tablename <br>";
         $this->listobject->querystring = " select * from $tablename ";
         $this->listobject->performQuery();
         $this->listobject->showList();
         $HTMLInfo .= $this->listobject->outstring;

         $tablename = $this->uciobject->ucitables['MASS-LINKS']['tablename'];
         $thisblock = 'MASS-LINKS';
         $HTMLInfo .= "<br>Searching UCI for $tablename <br>";
         $this->listobject->querystring = " select * from $tablename ";
         $this->listobject->performQuery();
         $this->listobject->showList();
         $HTMLInfo .= $this->listobject->outstring;

         $tablename = $this->uciobject->ucitables['RGEN-INFO']['tablename'];
         $thisblock = 'RGEN-INFO';
         $HTMLInfo .= "<br>Searching UCI for $tablename <br>";
         $this->listobject->querystring = " select * from $tablename ";
         $this->listobject->performQuery();
         $this->listobject->showList();
         $HTMLInfo .= $this->listobject->outstring;

         # output schematic outputs to a plotgen
         $tablename = $this->uciobject->ucitables['TIMESERIES']['tablename'];
         $HTMLInfo .= "COPY blocks:<br>";
         $this->listobject->querystring = "  select * from $tablename ";
         $this->listobject->performQuery();
         $this->listobject->showList();
         $HTMLInfo .= $this->listobject->outstring;

         # output schematic outputs to a plotgen
         $HTMLInfo .= "Reaches output to PLOTGEN:<br>";
         $this->listobject->querystring = "  select * from $this->tblprefix" . "tmp_allplotgens ";
         $this->listobject->performQuery();
         $this->listobject->showList();
         $HTMLInfo .= $this->listobject->outstring;

         # output ext target outputs to a wdm
         $HTMLInfo .= "Outputs to WDM:<br>";
         $this->listobject->querystring = "  select * from $this->tblprefix" . "tmp_allwdms where io = 'o'";
         $this->listobject->performQuery();
         $this->listobject->showList();
         $HTMLInfo .= $this->listobject->outstring;

         # input ext source outputs to hspf
         $HTMLInfo .= "Inputs from WDM:<br>";
         $this->listobject->querystring = "  select * from $this->tblprefix" . "tmp_allwdms where io = 'i'";
         $this->listobject->performQuery();
         $this->listobject->showList();
         $HTMLInfo .= $this->listobject->outstring;
      }

      return $HTMLInfo;
   }

}

class HSPFPlotgen extends timeSeriesInput {
   var $errorstring = '';
   var $plotgenoutput = '';
   var $filepath = '';
   var $paramcolumns = array();
   var $loglines = -1;

   # requires the library lib_equation2.php, which has the class "Equation"
   var $equations = array(); # keyed by statevarname=>equationtext

   function showHTMLInfo() {
      $this->init();
      $HTMLInfo = parent::showHTMLInfo();
      return $HTMLInfo;
   }

   function init() {

      if (is_object($this->listobject) and ($this->log2db == 1)) {
         # set a name for the temp table that will not hose the db
         $targ = array(' ',':','-','.');
         $repl = array('_', '_', '_', '_');
         $this->tblprefix = str_replace($targ, $repl, $this->tblprefix);
         $this->dbtblname = $this->tblprefix . 'datalog';
      }

      #error_log("initializing plotgen " . $this->filepath);

      # part of modeling widgets, expects lib_hydrology,php, and HSPFFunctions.php to be included
      # expects user to create a time series object, $flow2, and pass it as an input
      # adds time series data from a plotgen to the object, and returns it

      # $paramcolumns is an array of format:
      #   array('paramname'=>paramcolumn)
      # $totaldatacols = the number of total output columns in the file, should figure out a way to
      #  determine this automatically
      # parseHSPFMultiout($infilename,$thiscolumn, $totaldatacols)

      # $rectype = 0, hourly, 1 - daily
      $this->maxflow = 0;

      if ($this->timer == NULL) {
         return;
      }
      if ($this->timer->thistime <> '') {
         $sd = $this->timer->thistime;
         $sdts = $sd->format('U');
      }
      if ($this->timer->endtime <> '') {
         $ed = $this->timer->endtime;
         $edts = $ed->format('U');
      }

      if ($this->debug) {
         $this->logDebug("Parsing Plotgen File: $this->filepath <br>");
      }
      if (file_exists($this->filepath)) {
         $plotgen = parseHSPFMultiout($this->filepath,-1, count($this->paramcolumns), 0);
         # column 0 contains header data, column 1 contains the actual data
         $filedata = $plotgen[1];
      } else {
         $filedata = array();
         if ($this->debug) {
            $this->logDebug("$this->filepath not found.<br>");
         }
      }

      if ($this->debug) {
         $this->logDebug("<br> Parameter Columns: ");
         $this->logDebug($this->paramcolumns);
         $this->logDebug("<br>");
      }
      $linecount = 0;
      $totallines = count($filedata);
      foreach ($filedata as $thisdata) {
         $linecount++;
         if ($this->debug and ( ($linecount < $this->loglines) or ($linecount > ($totallines - $this->loglines)) or ($this->loglines < 0)) ) {
            $this->logDebug($thisdata);
         }
         $thisdate = new DateTime($thisdata[0]);
         $ts = $thisdate->format('r');
         $uts = $thisdate->format('U');
         $thisflag = '';
         # default to missing
         $thisval = 0.0;
         if ($this->debug and ( ($linecount < $this->loglines) or ($linecount > ($totallines - $this->loglines)) or ($this->loglines < 0)) ) {
            $this->logDebug("<br> Parameter Columns: ");
            $this->logDebug($this->paramcolumns);
            $this->logDebug("<br>");
         }
         #$this->logDebug("<br>");
         $withinperiod = 1;
         if ( ($this->timer->thistime <> '') and ($sdts > $uts) ) {
            # if have defined a start date, and this date is less than the start date, do not add
            $withinperiod = 0;
         }
         if ( ($this->timer->endtime <> '') and ($edts < $uts) ) {
            # if have defined an end date, and this date is greater than the end date, we are done
            break;
         }
         #$this->logDebug("Within: $within (TS: $uts, SDTS: $sdts, EDTS: $edts) <br>");
         if ($withinperiod) {
            foreach (array_keys($this->paramcolumns) as $dataitem) {

               $thiscol = $this->paramcolumns[$dataitem];
               if ($thisdata[$thiscol] <> '') {
                  $thisval = $thisdata[$thiscol];
               } else {
                  $thisval = '0.0';
               }
               if ($this->debug and ( ($linecount < $this->loglines) or ($linecount > ($totallines - $this->loglines)) or ($this->loglines < 0)) ) {
                  $this->logDebug("$dataitem : $thiscol : $thisval <br>");
               }
               # add to timeseries object
               $this->addValue($ts, $dataitem, floatval($thisval));
               if ($dataitem == 'Qout') {
                  if ($thisval > $this->maxflow) {
                     $this->maxflow = floatval($thisval);
                  }
               }
            }
            $this->addValue($ts, 'timestamp', $uts);
            $this->addValue($ts, 'thisdate', $thisdate->format('m-d-Y'));
         }
      }

      # test - will this modify the object?
      #return $tsobject;
      if ($this->debug) {
         //$this->logDebug($this->tsvalues);
      }
      #@ set up data columns
      $this->setDataColumnTypes();
      ksort($this->tsvalues);
   }


}

class HSPFWDM extends modelObject {
   var $errorstring = '';
   var $wdmoutput = '';
   var $filepath = '';
   var $debugmode = 0;
   var $wdm_messagefile = '';
   var $ereg_format = array();
   var $dsns = array();
   var $dsn_exps = array(); # place to store links to export files for dsns
   var $cache_log = 1;
   var $max_memory_values = -1; # cache values in db (saves time and memory) passed to WDMDSN
   var $wdimex_exe = '/var/www/cgi-bin/wdimex';
   var $loadall = 0; # load all dsn's by default?  This is VERY time consuming, and should be worked around
                     # perhaps by having the dsn's explicitly called by a local sub-component on the HSPF UCI

   # requires the library lib_equation2.php, which has the class "Equation"
   var $equations = array(); # keyed by statevarname=>equationtext

   function showHTMLInfo() {
      #$this->init();
      $HTMLInfo = parent::showHTMLInfo();
      return $HTMLInfo;
   }

   function finish() {
      parent::finish();
      if ($this->debug) {
         $this->logDebug("Clearing any temp files <br>");
      }
      foreach ($this->processors as $thisproc) {
         #print($thisproc->debugstring);
         #$tbl = $thisproc->dbtblname;
         #$this->listobject->querystring = "select * from $tbl limit 50";
         #error_log($this->listobject->querystring . "; <br>");
         #$this->listobject->performQuery();
         #$this->listobject->show = 0;
         #$this->listobject->showlist();
         #error_log($this->listobject->outstring . "; <br>");
      }
      $this->clearTempFiles();
   }

   function activateDSN($dsn) {
      #error_log("Activating DSN by ID = " . $dsn);
      array_push($this->dsns, $dsn);
   }

   function init() {
//$this->debug = 1;
      $this->ereg_format['dsn_line'] = "([DSN]{3})([ ]{8})([ 0-9]{5})([ 0-9A-Za-z]{63})";
      $this->ereg_format['dsn_end'] = "([ DSNE]{8})";
      $this->ereg_format['data_start'] = "([ ]{2})([DAT]{4})([ ]{7})([STAR:]{7})([ 0-9A-Za-z:]{47})";
      $this->ereg_format['data_end'] = "([ ]{2})([ DATEN]{8})";
      $this->ereg_format['label_start'] = "([ ]{2})([ LABE]{8})";
      $this->ereg_format['label_end'] = "([ ]{2})([ DLABEN]{12})";
      $this->ereg_format['label_data'] = "([ ]{4})([ A-Z]{6})([ ]{2})([ 0-9A-Za-z()/:.\-]{68})";
      #$this->ereg_format['data_line'] = "([ ]{4})([0-9]{4})([ ]{1})([ 0-9]{2})([ ]{1})([ 0-9]{2})([ ]{1})([ 0-9]{2})([ ]{1})([ 0-9]{2})([ ]{1})([ 0-9]{2})([ ]{4})([ 0-9]{2})([ ]{1})([ 0-9]{2})([ ]{1})([ 0-9]{2})([ ]{1})([ 0-9]{5})([ ]{1})([ 0-9]{2})([ ]{4})([ 0-9A-Za-z:.\-]{15})";
      $this->ereg_format['data_line'] = '([ ]{4})([0-9]{4})([ ]{1})([ 0-9]{2})([ ]{1})([ 0-9]{2})([ ]{1})([ 0-9]{2})([ ]{1})([ 0-9]{2})([ ]{1})([ 0-9]{2})([ ]{4})([ 0-9]{2})([ ]{1})([ 0-9]{2})([ ]{1})([ 0-9]{2})([ ]{1})([ 0-9]{5})([ ]{1})([ 0-9]{2})([ ]{4})([ 0-9A-Za-z:.+-]{15})';
      if (is_object($this->timer)) {
         if (is_object($this->timer->thistime)) {
            $this->startdate = $this->timer->thistime->format('Y-m-d');
         }
         if (is_object($this->timer->endtime)) {
            $this->enddate = $this->timer->endtime->format('Y-m-d');
         }
      } else {
         $this->startdate = '';
         $this->enddate = '';
      }
      if (count($this->dsns) > 0) {
         if ($this->debug) {
            $this->logDebug("Calling loadDataSet for file " . $this->filepath . "<br>");
         }
         $this->loadDataSet($this->dsns);
         #error_log("Loading DSNs " . print_r($this->dsns,1));
         //error_log("Calling loadDataSet for file " . $this->filepath . "<br>");
      } else {
         if ($this->loadall == 1) {
            $this->loadDataSet(array());
            #error_log("No DSN specified, Loading ALL DSNs " . print_r($this->dsns,1));
         }
      }

   }

   function loadDataSet($dsn = array()) {
      if (!is_array($dsn)) {
         $dsn = array($dsn);
      }

      $crit = array();

      if ( count($dsn) > 0) {
         $crit = array('DSN' => $dsn);
      }

      if ($this->debug) {
         $this->logDebug("loadDataSet Called for file " . $this->filepath . "<br>\n");
      }

      //error_log("loadDataSet Called for file " . $this->filepath . "<br>\n");

      if ($this->debug) {
         $this->logDebug("Exporting WDM " . $this->filepath . "<br>\n");
      }
      $expfile = $this->exportWDM('','',1,$dsn);
      # stash the debug setting, because you really don't want this much
      # debug info, unles you really want it, then you will go to
      # the function parseEXPFile and enable it there

      if ($this->debug) {
         $this->logDebug("Parsing " . $expfile . "<br>\n");
      }
      $stashdebug = $this->debug;
      #$this->debug = 0;
      $dsn_recs = $this->parseEXPFile($expfile, $crit, $this->startdate, $this->enddate);
      #$this->debug = $stashdebug;

      if ($this->debug) {
         $this->logDebug("Loading data from " . $expfile . "<br>\n");
         $this->logDebug(" For " . $this->startdate . " to " . $this->enddate . "<br>\n");
      }

      $d_names = array_keys($dsn_recs);
      $k = 0;
      foreach ($d_names as $thisdsn) {
         #$varname = $dsn_recs[$thisdsn]['DSN'] . '-' . $dsn_recs[$thisdsn]['labels']['TSTYPE'];
         $varname = $dsn_recs[$thisdsn]['DSN'];
         if ($this->debug) {
            $this->logDebug("Processing DSN data for $varname <br>\n");
         }
         $tsvalues = $dsn_recs[$thisdsn]['tsvalues'];

         # cache this DSN in an xml file if:
         #    * it is not already cached, so we need to create it
         #    * if we ARE forcing a refresh we assume that the cached file is out of date
         $this_dsn_cache = $this->outdir . "/cache" . $this->componentid . "_dsn_$thisdsn" . ".log";
         if (!file_exists($this_dsn_cache)) {
            $options = array();
            #error_log("Creating serializer for DSN cache");
            $serializer = new XML_Serializer($options);
            $result = $serializer->serialize($tsvalues);
            $xml = $serializer->getSerializedData();
            #error_log("DSN $thisdsn contains " . count($tsvalues) . " records.");
            #error_log("Dumping DSN $thisdsn to file: $this_dsn_cache");
            file_put_contents($this_dsn_cache, $xml);
         }

         if ($this->debug) {
            $this->logDebug("Creating DSN Object for $varname <br>\n");
         }
         $d = new WDMDSN;
         $d->name = $varname;
         $d->setSimTimer($this->timer);
         $d->max_memory_values = $this->max_memory_values;
         $d->setProp('sessionid', $this->sessionid . "_" . $k);
         $d->setProp('componentid', $this->componentid . "_" . $k);
         $k++;
         //error_log("WDMDSN create with max_memory_values set to " . $d->max_memory_values);
         $d->init();
         if ($this->debug) {
            //$d->debug = 1;
            $d->debugmode = 0;
            $this->logDebug("Adding Records to DSN Object <br>\n");
         }
         if (is_object($this->listobject)) {
            if ($this->debug) {
               $this->logDebug("Setting list object on $varname <br>\n");
            }
            $d->listobject = $this->listobject;
         }
         $d->addDSNRecs($tsvalues);
         if ($this->debug) {
            $this->logDebug("Finished adding to DSN Object: " . $d->debugstring . "<br>\n");
         }
         if ($this->debug) {
            $this->logDebug("Adding Operator for $varname <br>\n");
         }
         $this->addOperator($varname, $d, 0);
      }
   }

   function tsvalues2listobject($complist = array()) {
      if (count($complist) == 0) {
         $complist = array_keys($this->processors);
      }
      foreach ($complist as $thiscomp) {
         if ($this->debug) {
            $this->logDebug("Moving time series data for $thiscomp to list object.<br>\n");
         }
         # check to see if this processor has a listobject method
         if (method_exists($this->processors[$thiscomp], 'tsvalues2listobject')) {
            # see if it has a valid list object
            if (!is_object($this->processors[$thiscomp]->listobject)) {
               if ($this->debug) {
                  $this->logDebug("$thiscomp does not have list object <br>\n");
               }
               # if not, try to add ours, if we have one
               if (is_object($this->listobject)) {
                  if ($this->debug) {
                     $this->logDebug("Copying list object to $thiscomp  <br>\n");
                  }
                  $this->processors[$thiscomp]->listobject = $this->listobject;
               }
            }
            if (is_object($this->processors[$thiscomp]->listobject)) {
               if ($this->debug) {
                  $this->logDebug("Outputting values to db for $thiscomp  <br>\n");
               }
               $this->processors[$thiscomp]->tsvalues2listobject();
            }
         }
      }
   }

   function parseEXPFile($expfile, $label_criteria = array(),$startdate='',$enddate='') {
# commented in lieu of reading whole file into memory
#      $fhandle = fopen($expfile, 'r');
      $in_dsn = 0;
      $in_data = 0;
      if ($this->debug) {
         $this->logDebug("Start and end dates: $startdate - $enddate<br>\n");
      }

      # creates a separate time series for each DSN ID
      # for now this will just return an associative array with an entry for each DSN encountered
      # but at a later date, we should actually instantiate TimeSeries Objects for each DSN
      $these_dsns = array();

      if ($this->debug) {
         $this->logDebug("Trying to import EXP data from file " . $expfile . "<br>\n");
      }
      $outmesg = "Trying to import EXP data from file " . $expfile . "<br>\n";
      //error_log($outmesg);

      $ss = '';
      $es = '';
      if (strlen($startdate) > 0) {
         $sd = new DateTime($startdate);
         $ss = $sd->format('U');
      }
      if (strlen($enddate) > 0) {
         $ed = new DateTime($enddate);
         $es = $ed->format('U');
      }
      
      # set up useful constants to be used in loops:
      $spacexplen = 8; # number of characters that make up the leading blank space regexp
      $numreglen = 16; # number of characters that make up value regexp
      $validintervals = array(3,4,5); # 3 - hourly, 4 - daily, 5 - monthly
      
      if ($this->debug) {
         $this->logDebug("Start ($startdate) and end ($enddate) epoch: $es $ss<br>\n");
      }
         #error_log("Start ($startdate) and end ($enddate) epoch: $ss $es <br>\n");

      $wholefile = file($expfile);
#      while ($thisline = fgets($fhandle,255) ) {
      #foreach ($wholefile as $thisline ) {
      #error_log("File $expfile has " . count($wholefile) . " lines");
      $lastk = -1;
      for ($k=0; $k < count($wholefile); $k++) {
         $thisline = $wholefile[$k];
         if (($k >= ($lastk + 999)) or ($lastk == -1)) {
            $outmesg = "Parsing Line $k <br>\n";
            if ($this->debug) {
               $this->logDebug($outmesg);
            }
            $lastk = $k;
         }

         if ($in_dsn) {
            #print("DSN LINE: $thisline<br>\n");
            # we are inside a DSN block, look for data line
            if ($in_data) {
               # check for data end
               ereg($this->ereg_format['data_end'], $thisline, $tokens);
               if (count($tokens) >= 3) {
                  if (rtrim(ltrim($tokens[2])) == 'END DATA') {
                     if ($this->debug) {
                        $this->logDebug("Found END of DSN DATA " . $dsn . "<br>\n");
                     }
                     $in_data = 0;
                  }
               }
               # no end found, so now parse the data
               if ($in_data and $desired) {
                  # reset the tokens array so we know if we have a pattern match
                  $tokens = array();
                  ereg($this->ereg_format['data_line'], $thisline, $tokens);
                  if (count($tokens) >= 3) {
                     if ($tokens[2] > 0) {
                        # valid numerical entry for the year, and valid line of form
                        if ($this->debug) {
                           $this->logDebug("Found Data for " . $tokens[2] . "-" . $tokens[4] . "-" . $tokens[6] . " = " . $tokens[24] . "<br>\n");
                        }
                        $yr = $tokens[2];
                        $mo = str_pad(ltrim(rtrim($tokens[4])), 2, '0', STR_PAD_LEFT);
                        $day = str_pad(ltrim(rtrim($tokens[6])), 2, '0', STR_PAD_LEFT);
                        $hr = str_pad(ltrim(rtrim($tokens[8])), 2, '0', STR_PAD_LEFT);
                        $min = str_pad(ltrim(rtrim($tokens[10])), 2, '0', STR_PAD_LEFT);
                        $sec = str_pad(ltrim(rtrim($tokens[12])), 2, '0', STR_PAD_LEFT);
                        $fixthedate = 0;
                        if ($hr == 24) {
                           # this will cause a malformed time stamp, since php considers hour 24 to be the 0 hour, next day
                           # so...
                           $fixtime = $yr . "-" . $mo . "-" . $day . " " . 23 . ":" . $min . ":" . $sec;
                           $fixobj = new DateTime($fixtime);
                           $fixobj->modify("+1 hour");
                           $fixthedate = 1;
                        }
                        $thistime = $yr . "-" . $mo . "-" . $day . " " . $hr . ":" . $min . ":" . $sec;
                        if ($fixthedate == 1) {
                           $dtobj = $fixobj;
                        } else {
                           $dtobj = new DateTime($thistime);
                        }
                        if ($this->debug) {
                           $this->logDebug("Creating Time Stamp Y-m-d H:m:s from: $thistime<br>\n");
                        }
                        $thistime = $dtobj->format('r');
                        $thisdate = $dtobj->format('Y-m-d');
                        $thissec = $dtobj->format('U');
                        $intime = 1;
                        # if we were given start and end dates, look to see if this line is within the bounds that we want
                        if ($ss <> '') {
                           if ($thissec < $ss) {
                              $intime = 0;
                           }
                        }
                        if ($es <> '') {
                           if ($thissec > $es) {
                              $intime = 0;
                           }
                        }
                        if ($this->debug) {
                           $this->logDebug(" $thistime validity check = $intime <br>\n");
                        }

                        # there are other important fields in the EXP file, but for now, I will leave it here
                        # how many values does this persist for? (may be 1, or multiple, in which case we have to massage the time set)
                        $numvals = $tokens[20]; # number of values given, if greater than 1, we have some fancy footwork to do
                        $interval = $tokens[14]; 
                        $thisval= ltrim(rtrim($tokens[24]));
                        $repeater = $tokens[22];
                        # 0 - no repeating values, if multiple, expect that many columns to follow,
                        # 1 - single value given, if multiple, use this value each time
                        if ($intime == 1) {
                           array_push($these_dsns[$dsn]['tsvalues'], array('thistime'=>$thistime, 'thisdate'=>$thisdate, 'thisvalue'=>$thisval));
                           //if ($vals_got < 5) {
                           //   error_log("Line Start: $thistime, 'thisdate' $thisdate, 'thisvalue' $thisval \n<br>\n");
                           //   error_log("Number of Values in Group: $numvals <br>\n");
                           //}
                        }
                        # now, check if this is multiple, if so, we have to parse the second number from the first line, then each
                        # successive line until we reach the end of our data
                        $intxt = '';
                        switch ($interval) {
                           case 3:
                              $intxt = 'hours';
                           break;
                           case 4:
                              $intxt = 'days';
                           break;

                           case 5:
                              $intxt = 'months';
                           break;
                        }
                        if ($numvals > 1) {
                           # check ahead, if we fall inside of numvals intervals, then parse, otherwise, skip
                           $fobj = clone $dtobj;
                           $fobj->modify("+$numvals $intxt");
                           $sps = $thissec; # the start of this chunk of multiline data
                           $spe = $fobj->format('U');  # the end of this chunk
                           if ($ss == '') {
                              $dss = $thissec; # either the current time, or the start of the desired interval (if set)
                           } else {
                              $dss = $ss;
                           }
                           if ($es == '') {
                              $des = $spe; # the end of the desired interval
                           } else {
                              $des = $es;
                           }
                           if ( ($sps <= $des) and ($spe >= $dss) ) {
                              $parsespan = 1;
                           } else {
                              $parsespan = 0;
                           }
                           #error_log("Parse $parsespan ($sps <= $des) and ($spe >= $dss) ");
                           if (in_array($interval, $validintervals) and $parsespan) {

                              if ($repeater == 1) {
                                 if ($this->debug) {
                                    $this->logDebug("Repeater needed, $thisval repeats $numvals times<br>\n");
                                 }
                                 # just duplicate the value, otherwise, we have to parse the stuff
                                 $vals_got = 0;
                                 while ($vals_got < $numvals) {
                                    $dtobj->modify("+1 $intxt");
                                    $thissec = $dtobj->format('U');
                                    if ( ($ss <> '') or ($es <> '')) {# if we were given start and end dates, look to see if this line is within the bounds that we want
                                       if ($ss <> '') {
                                          if ($thissec < $ss) {
                                             $intime = 0;
                                          }
                                       }
                                       if ($es <> '') {
                                          if ($thissec > $es) {
                                             $intime = 0;
                                          }
                                       }
                                    } else {
                                       $intime = 1;
                                    }
                                    $thistime = $dtobj->format('r');
                                    $thisdate = $dtobj->format('Y-m-d');
                                    if ($intime == 1) {
                                       array_push($these_dsns[$dsn]['tsvalues'], array('thistime'=>$thistime, 'thisdate'=>$thisdate, 'thisvalue'=>$thisval));
                                    }
                                    $vals_got++;
                                 }
                              } else {
                                 # add the second variable on the first line
                                 //$line2reg = '([ 0-9A-Za-z:.\-\+]{63})([ 0-9.E\-\+]{12})';
                                 $line2reg = '([ 0-9A-Za-z:.+-]{63})([ 0-9.E+-]{12})';
                                 $vals_got = 1;
                                 ereg($line2reg, $thisline, $tokens);
                                 // the second value on the first line shuld be at position 25
                                 $nextval = ltrim(rtrim($tokens[2]));
                                 $vals_got++;
                                 $dtobj->modify("+1 $intxt");
                                 $thissec = $dtobj->format('U');
                                 if ( ($ss <> '') or ($es <> '')) {# if we were given start and end dates, look to see if this line is within the bounds that we want
                                    if ($ss <> '') {
                                       if ($thissec < $ss) {
                                          $intime = 0;
                                       }
                                    }
                                    if ($es <> '') {
                                       if ($thissec > $es) {
                                          $intime = 0;
                                       }
                                    }
                                 } else {
                                    $intime = 1;
                                 }
                                 if ($intime == 1) {
                                    $thistime = $dtobj->format('r');
                                    $thisdate = $dtobj->format('Y-m-d');
                                    array_push($these_dsns[$dsn]['tsvalues'], array('thistime'=>$thistime, 'thisdate'=>$thisdate, 'thisvalue'=>$nextval));
                                    if ($this->debug) {
                                       $this->logDebug("2nd value added " . $thisdate . " = " . $nextval);
                                       $this->logDebug("Adding DSN $dsn: " . $thisdate . " = " . $nextval);
                                    }
                                 }
                                 # now, figure out how many lines should contain the rest of this record, and retrieve them and parse them
                                 # max 6 records per line
                                 $numlines = ceil(($numvals - $vals_got) / 6.0);
                                 for ($i = 1; $i <= $numlines; $i++) {
                                    # now get the line
                                    # old-school, OK if you have fast file system, otherwise, no good
                                    # $thisline = fgets($fhandle,255);
                                    # new school
                                    $k++;
                                    $thisline = $wholefile[$k];

                                    # calulate the number of entries that should be on this line
                                    $getnum = $numvals - $vals_got;
                                    if ($getnum > 6) {
                                       $getnum = 6;
                                    }
                                    # assemble the regexp to parse the next line of values
                                    // what this does is compute the total number of characters needed to assemble the
                                    // regexp string, so numreglen needs to be the string length of the base regular expression, so if you increase or decrease characters in the regexp (to make it more robust, or more compact) you will need to change numreglen
                                    $charlen = $spacexplen + $getnum * $numreglen;
                                    //$charlen = $getnum * 12;
                                    //$reg = str_pad('([ ]{3})', $charlen, '([ 0-9.E\-\+]{12})');
                                    $reg = str_pad('([ ]{3})', $charlen, '([ 0-9.E+-]{12})');

                                    $tokens = array();
                                    if ($this->debug) {
                                       $this->logDebug("Ereg for line $i, $getnum values, charlen $charlen: $reg<br>\n");
                                    }
                                    ereg($reg, $thisline, $tokens);
                                    $numtokes = count($tokens);
                                    if ($this->debug) {
                                       $this->logDebug("Line $i; $numtokes tokens, $getnum values wanted<br>\n");
                                       $this->logDebug("Tokens; " . print_r($tokens,1) . "<br>\n");
                                    }

                                    $cols = $numtokes - 1;
                                    for ($a = 2; $a <= $cols; $a++) {
                                       $nextval = ltrim(rtrim($tokens[$a]));
                                       $dtobj->modify("+1 $intxt");
                                       $thissec = $dtobj->format('U');
                                       $intime = 1;
                                       if ( ($ss <> '') or ($es <> '')) {# if we were given start and end dates, look to see if this line is within the bounds that we want
                                          if ($ss <> '') {
                                             if ($thissec < $ss) {
                                                $intime = 0;
                                             }
                                          }
                                          if ($es <> '') {
                                             if ($thissec > $es) {
                                                $intime = 0;
                                             }
                                          }
                                       }

                                       if ($intime == 1) {
                                          $thistime = $dtobj->format('r');
                                          $thisdate = $dtobj->format('Y-m-d');
                                          if ($this->debug) {
                                             $this->logDebug("Token position $a; Date/Time: $thistime, value = $nextval<br>\n");
                                          }

                                          array_push($these_dsns[$dsn]['tsvalues'], array('thistime'=>$thistime, 'thisdate'=>$thisdate, 'thisvalue'=>$nextval));
                                          if ($this->debug) {
                                             $this->logDebug("Adding DSN $dsn: " . $thisdate . " = " . $nextval . "<br>\n");
                                          }
                                       }
                                       $vals_got++;
                                    }
                                 }
                              }
                           }
                        }
                     }
                  }
               }
               #$this->debug = 0;
               #$this->debugmode = 0;
            } else {
               if ($in_label) {
                  if ($this->debug) {
                     $this->logDebug("Checking for LABEL end<br>\n");
                  }
                  # not yet in data block, look for the data block start
                  ereg($this->ereg_format['label_end'], $thisline, $tokens);
                  if (count($tokens) >= 3) {
                     if (rtrim(ltrim($tokens[2])) == 'END LABEL') {
                        if ($this->debug) {
                           $this->logDebug ("Found LABEL end.<br>\n");
                        }
                        $in_label = 0;
                     }
                     # check for label pieces of interest
                     if ($this->debug) {
                        $this->logDebug("Checking for LABEL entries <br>\n");
                     }
                  } else {
                     if ($this->debug) {
                        $this->logDebug("No match for label end <br>\n");
                     }
                  }
                  ereg($this->ereg_format['label_data'], $thisline, $tokens);
                  if (count($tokens) >= 5) {
                     if (rtrim(ltrim($tokens[2])) <> '') {
                        if ($this->debug) {
                           $this->logDebug ("Found " . $tokens[2] . "-" . $tokens[4] . ".<br>\n");
                        }
                        # store this label entry
                        if ($desired) {
                           $these_dsns[$dsn]['labels'][$tokens[2]] = $tokens[4];
                        }
                     }
                  }
               } else {
                  if ($this->debug) {
                     $this->logDebug("Checking for label start<br>\n");
                  }
                  # not yet in data block, look for the data block start
                  ereg($this->ereg_format['label_start'], $thisline, $tokens);
                  if (count($tokens) >= 3) {
                     if (rtrim(ltrim($tokens[2])) == 'LABEL') {
                        if ($this->debug) {
                           $this->logDebug ("Found LABEL START.<br>\n");
                        }
                        $in_label = 1;
                     }
                  }
               }
               if ($this->debug) {
                  $this->logDebug("Checking for DATA start<br>\n");
               }
               # not yet in data block, look for the data block start
               ereg($this->ereg_format['data_start'], $thisline, $tokens);
               if (count($tokens) >= 3) {
                  if ($tokens[2] == 'DATA') {
                     if ($this->debug) {
                        $this->logDebug ("Found DATA Block.<br>\n");
                     }
                     $in_data = 1;
                  }
               }
               if ($this->debug) {
                  $this->logDebug("Checking for DSN END<br>\n");
               }
               # not yet in data block, look for the data block end
               ereg($this->ereg_format['dsn_end'], $thisline, $tokens);
               if (count($tokens) >= 2) {
                  #print(print_r($tokens,1) . "<br>\n");
                  if (rtrim(ltrim($tokens[1])) == 'END DSN') {
                     if ($this->debug) {
                        $this->logDebug ("Found END DSN " . $dsn . ".<br>\n");
                     }
                     $in_dsn = 0;
                     $in_data = 0;
                  }
                  if (!$in_dsn) {
                     # check to see if we have gotten all of our dsns
                     if (isset($label_criteria['DSN'])) {
                        if (count($label_criteria['DSN']) == 0) {
                           if ($this->debug) {
                              $this->logDebug("Found all requested DSN's.  Returning.<br>\n");
                           }
                           #error_log("Found all requested DSN's.  Returning.<br>\n");
                           // Commented in lieu of reading whole file into memory
                           //fclose($fhandle);
                           return $these_dsns;
                        }
                     }
                  }
               }
            }

         } else {
            # look for the DSN tag
            ereg($this->ereg_format['dsn_line'], $thisline, $tokens);
            if (count($tokens) >= 2) {
               if ($tokens[1] == 'DSN') {
                  if ($this->debug) {
                     $this->logDebug ("found DSN line with DSN ID = " . $tokens[3] . "<br>\n");
                  }
                  #error_log ("found DSN line with DSN ID = " . $tokens[3] . "<br>\n");
                  $in_dsn = 1;
                  $in_data = 0;
                  #$dsn = $tokens[3];
                  $dsn = ltrim(rtrim($tokens[3]));
                  $desired = 1;
                  if (count($label_criteria) > 0) {
                     #we have been asked to only retrieve certain DSNs or LABEL-types
                     if ($this->debug) {
                        $this->logDebug("Screening for criteria " . print_r($label_criteria,1) . "<br>\n");
                     }
                     $cosas = array_keys($label_criteria);
                     if (in_array('DSN', $cosas)) {
                        $ds = $label_criteria['DSN'];
                        if ($this->debug) {
                           $this->logDebug("User requested DSNs " . print_r($ds,1) . "<br>\n");
                        }
                        if (!is_array($ds)) {
                           $ds = array($ds);
                        }
                        if (!in_array($dsn, $ds)) {
                           $desired = 0;
                           if ($this->debug) {
                              $this->logDebug("DSN $dsn is not required <br>\n");
                           }
                        } else {
                           if ($this->debug) {
                              $this->logDebug("Found Required DSN $dsn <br>\n");
                           }
                           $cache_criteria = array();
                           foreach ($ds as $thisds) {
                              if ($thisds <> $dsn) {
                                 # not the droid we were looking for, so add it back in the queue
                                 array_push($cache_criteria, $thisds);
                              }
                           }
                           $label_criteria['DSN'] = $cache_criteria;
                        }
                     }
                  }
                  if ($desired <> 0) {
                     $these_dsns[$dsn] = array('DSN' => $dsn, 'tsvalues'=>array(), 'labels'=>array());
                  }
               }
            }
         }
      }
      $outmesg = "Finished EXP parse <br>\n";
      //error_log($outmesg);

      fclose($fhandle);
      return $these_dsns;
   }

   function exportWDM($infile='', $expfilename ='', $tmp = 1, $dsns = array()) {
      # NOTE: it is very important that if you are on a dos system (maybe others too) that the wdimex routine
      # does NOT like long file names, nor long file paths, and in fact, there is a maximum file name length
      # thus, when using wdimex to export, one needs to have a temp dir that is a short path,
      # c:\temp\ is good for windows, and of course, \tmp\ is a safe bet for unix
      # if the user passes in there own infile and expfile, these checks do not get made, so buyer beware
      # if no file is passed in, assume it is this file
      # if dsns is a blank array, it will export all datasets, which can be 
      # very time consuming, thus it is always more efficient to single them out
      # particularly if you onlyu need a small number of dsns
      if (strlen($infile) == 0) {
         $infile = $this->filepath;
      }

      # we assume this is dos so me have to create a tmep wdm file of proper length or wdimex will choke
      $base = '';
      $ext = 'wdm';
      if ($this->debug) {
         $this->logDebug("Trying to create WDM with base: $base and ext: $ext <br>");
      }
      # using 0 and 99999 will automatically generate a filename with less than or equal to 8 places (since the base is 3)
      $wdmfilename = $this->generateTempFileName($base, $ext, 0, 99999);
      if ($this->debug) {
         $this->logDebug("WDM FILE: $wdmfilename <br>");
      }
      //error_log("WDM FILE: $wdmfilename <br>");
      # now, copy the wdm to the temp file
      if ($this->debug) {
         $this->logDebug("Copying $infile to $wdmfilename <br>");
      }
      $wdmfile = $this->copy2TempFile($infile, $wdmfilename);

      if (strlen($expfilename) == 0) {
         # make a file name
         # assume this is a dos platform, we must create a file name that is the proper length,
         # or wdimex will choke
         $base = 'wdm';
         $ext = 'exp';
         # using 0 and 99999 will automatically generate a filename with less than or equal to 8 places (since the base is 3)
         if ($this->debug) {
            $this->logDebug("Calling file name generation routine<br>");
         }
         $expfilename = $this->generateTempFileName($base, $ext, 0, 99999);
         //if ($this->debug) {
            $this->logDebug("File name generation returned: $expfilename<br>");
         //}
      }
      # open and close it just to get it in the system
      $this->openTempFile($expfilename, 'rw', 'file', $this->platform);
      $this->closeTempFile($expfilename);
      if ($this->debug) {
         $this->logDebug("EXP FILE: $expfilename <br>");
      }

      # we must format the commands differently if we are trying to export 
      # individual dsns, or if we are exporting them all
      $wdimex = array();
      if (count($dsns) > 0) {
         # now assemble the export function commands for ALL DSN's in this volume
         /* do an import from existing wdm */
         array_push($wdimex,"$wdmfile\n");  /* send the wdm name to wdimex */
         array_push($wdimex,"$this->wdm_messagefile\n");   /* indicate the wdm file which has header information */
         array_push($wdimex,"E\n");   /* select export option */
         array_push($wdimex,"$expfilename\n");   /* give the import file name */
         array_push($wdimex,"\n");  /* Carriage Return to end comment line */
         array_push($wdimex,"S\n");  /* Export Single at a time */
         foreach ($dsns as $thisdsn) {
            array_push($wdimex,"$thisdsn\n");  /* Export DSN Number */
         }
         array_push($wdimex,"0\n");  /* 0 tells it we are finished */
         array_push($wdimex,"R\n");  /* return to operating system */
         $overwrite = 1;
         //if ($this->debug) {
            $this->logDebug("Generated Script: " . print_r($wdimex,1) . "<br>");
         //}
      } else {
         # create a file name for this?
         # now assemble the export function commands for ALL DSN's in this volume
         /* do an import from existing wdm */
         array_push($wdimex,"$wdmfile\n");  /* send the wdm name to wdimex */
         array_push($wdimex,"$this->wdm_messagefile\n");   /* indicate the wdm file which has header information */
         array_push($wdimex,"E\n");   /* select export option */
         array_push($wdimex,"$expfilename\n");   /* give the import file name */
         array_push($wdimex,"\n");  /* Carriage Return to end comment line */
         array_push($wdimex,"A\n");  /* Export All */
         array_push($wdimex,"A\n");  /* Update All Attributes */
         array_push($wdimex,"R\n");  /* return to operating system */
         $overwrite = 1;
         if ($this->debug) {
            $this->logDebug("Generated Script: " . print_r($wdimex,1) . "<br>");
         }
      }
      # need to genreate a temp file name for the proc log file so that it 
      # will not create conflicts
      $proclogfile = $this->generateTempFileName('proc', 'log', 0, 99999);
      $descriptorspec = array(
         0 => array("pipe", "r"),  // stdin is a pipe that the child will read from
         1 => array("pipe", "w"),  // stdout is a pipe that the child will write to
         2 => array("file", "/tmp/error-output.txt", "a") // stderr is a file to write to
      );

      $cwd = '/tmp';
      $env = array('some_option' => 'aeiou');
      if ($this->debug) {
         $this->logDebug("Calling $this->wdimex_exe <br>\n");
      }
      $process = proc_open($this->wdimex_exe, $descriptorspec, $pipes, $cwd, $env);

      if (is_resource($process)) {
         // $pipes now looks like this:
         // 0 => writeable handle connected to child stdin
         // 1 => readable handle connected to child stdout
         // Any error output will be appended to /tmp/error-output.txt

         foreach ($wdimex as $thisline) {
            //error_log($thisline . "<br>");
            fwrite($pipes[0], $thisline);
            #echo stream_get_contents($pipes[1]) . "<br>";
         }
         fclose($pipes[0]);

         //error_log(stream_get_contents($pipes[1]));
         fclose($pipes[1]);

         // It is important that you close any pipes before calling
         // proc_close in order to avoid a deadlock
         $return_value = proc_close($process);

         //error_log("command returned $return_value\n");
      } else {
         //error_log("Process did not run");
      }

      if ($this->debug) {
         $this->logDebug("<br>Command Output:<br> $wdimexresult <br>");
      }
      return $expfilename;

   }

   function importEXPFile($expfile, $wdmfile='') {
      if (strlen($wdmfile) == 0) {
         $wdmfile = $this->filepath;
      }
      $wdimex = array();

      # verify that exp file exists, otherwise, return with Error
      if (!file_exists($expfile)) {
         $this->logError("<b>Error:</b> Export File $expfile does not exist<br>");
      }
      if (!file_exists($wdmfile)) {
         $this->logError("<b>Notice:</b> WDM File $wdmfile does not exist, trying to create<br>");
         /* create the wdm, import the exp file, then run hspf and get the data */
         array_push($wdimex,"$wdmfile");  /* send the wdm name to wdimex */
         array_push($wdimex,"C");   /* select to create the WDM */
         array_push($wdimex,"N");   /* say no to putting headers on the file */
         array_push($wdimex,"$this->wdm_messagefile");   /* indicate the wdm file which has header information */
         array_push($wdimex,"R");  /* return to operating system */

         if ($this->debug) {
            $this->logDebug("Generated Script: " . print_r($wdimex,1) . "<br>");
         }
         $scriptfile = $this->generateTempFileName('exp', 'txt', 0, 99999);
         # open and close it just to get it in the system
         $this->openTempFile($scriptfile, 'rw', 'file', $this->platform);
         $this->closeTempFile($scriptfile);
         putArrayToFilePlatform("$scriptfile",$wdimex,1,$this->platform);
         # now, try to execute the create script
         if ($this->debug) {
            $this->logDebug("<br>Trying to use wdimex to create the WDM with command:<br>cat $scriptfile | $this->wdimex_exe<br>");
         }
         $wdimexresult = shell_exec("cat $scriptfile | $this->wdimex_exe");
         if ($this->debug) {
            $this->logDebug("<br>Command Output:<br> $wdimexresult <br>");
         }

      }

      if (!file_exists($wdmfile)) {
         $this->logError("<b>Error:</b> WDM $wdmfile does not exist, and could not create <br>");
         return;
      } else {
         # clear the wdimex array for the insert statement
         $wdimex = array();
         /* do an import to existing wdm */
         array_push($wdimex,"$wdmfile");  /* send the wdm name to wdimex */
         array_push($wdimex,"$this->wdm_messagefile");   /* indicate the wdm file which has header information */
         array_push($wdimex,"I");   /* select import option */
         array_push($wdimex,"$expfile");   /* give the import file name */
         array_push($wdimex,"R");  /* return to operating system */

         if ($this->debug) {
            $this->logDebug("Generated Script: " . print_r($wdimex,1) . "<br>");
         }
         $scriptfile = $this->generateTempFileName('exp', 'txt', 0, 99999);
         # open and close it just to get it in the system
         $this->openTempFile($scriptfile, 'rw', 'file', $this->platform);
         $this->closeTempFile($scriptfile);
         putArrayToFilePlatform("$scriptfile",$wdimex,1,$this->platform);
         # now, try to execute the create script
         if ($this->debug) {
            $this->logDebug("<br>Trying to use wdimex to create the WDM with command:<br>cat $scriptfile | $this->wdimex_exe<br>");
         }
         $wdimexresult = shell_exec("cat $scriptfile | $this->wdimex_exe");
         if ($this->debug) {
            $this->logDebug("<br>Command Output:<br> $wdimexresult <br>");
         }

      }
      return $wdmfile;


   }

   function unionWDMs($src_wdms, $wdmfile) {
      if (strlen($wdmfile) == 0) {
         $wdmfile = $this->filepath;
      }

      foreach ($src_wdms as $this_src) {
         $expfile = $this->exportWDM($this_src);
         $this->importEXPFile($expfile, $wdmfile);
      }

      return;

   }

   function init_old($tsobject, $filename, $paramcolumns, $totaldatacols, $startdate, $enddate, $debug) {

      # part of modeling widgets, expects lib_hydrology,php, and HSPFFunctions.php to be included
      # expects user to create a time series object, $flow2, and pass it as an input
      # adds time series data from a plotgen to the object, and returns it

      # $paramcolumns is an array of format:
      #   array('paramname'=>paramcolumn)
      # $totaldatacols = the number of total output columns in the file, should figure out a way to
      #  determine this automatically
      # parseHSPFMultiout($infilename,$thiscolumn, $totaldatacols)

      # $rectype = 0, hourly, 1 - daily
      $this->maxflow = 0;
      if ($this->timer->thistime <> '') {
         $sd = $this->timer->thistime;
         $sdts = $sd->format('U');
      }
      if ($this->timer->endtime <> '') {
         $ed = $this->timer->endtime;
         $edts = $ed->format('U');
      }

      #$this->logDebug("Parsing Plotgen File: $staid <br>");
      $plotgen = parseHSPFMultiout($this->filepath,1, $totaldatacols, 0);
      # column 0 contains header data, column 1 contains the actual data
      $filedata = $plotgen[1];

      foreach ($filedata as $thisdata) {
         if ($this->debug) {
            $this->logDebug($thisdata);
         }
         $thisdate = new DateTime($thisdata[0]);
         $ts = $thisdate->format('r');
         $uts = $thisdate->format('U');
         $thisflag = '';
         # default to missing
         $thisval = 0.0;
         #$this->logDebug(array_keys($paramcolumns));
         #$this->logDebug("<br>");
         $withinperiod = 1;
         if ( ($this->timer->thistime <> '') and ($sdts > $uts) ) {
            # if have defined a start date, and this date is less than the start date, do not add
            $withinperiod = 0;
         }
         if ( ($this->timer->endtime <> '') and ($edts < $uts) ) {
            # if have defined an end date, and this date is greater than the end date, we are done
            break;
         }
         #$this->logDebug("Within: $within (TS: $uts, SDTS: $sdts, EDTS: $edts) <br>");
         if ($withinperiod) {
            foreach (array_keys($paramcolumns) as $dataitem) {

               $thiscol = $paramcolumns[$dataitem];
               if ($thisdata[$thiscol] <> '') {
                  $thisval = $thisdata[$thiscol];
               } else {
                  $thisval = '0.0';
               }
               #$this->logDebug("$dataitem : $thiscol : $thisval <br>");
               # add to timeseries object
               $this->addValue($ts, $dataitem, floatval($thisval));
               if ($dataname == 'Qout') {
                  if ($thisval > $this->maxflow) {
                     $this->maxflow = $thisval;
                  }
               }
            }
            $this->addValue($ts, 'timestamp', $ts);
            $this->addValue($ts, 'thisdate', $thisdate->format('m-d-Y'));
         }
      }
      ksort($this->tsvalues);

      # test - will this modify the object?
      #return $tsobject;
   }


}

class WDMDSN extends timeSeriesInput {

   var $dsn = '';
   var $intmethod = 3;
   var $dtobj;
   var $loggable = 1; // can log the value in a data table

   function setDataColumnTypes() {
      parent::setDataColumnTypes();

      $this->dbcolumntypes['thisvalue'] = 'float8';
      $this->dbcolumntypes['thistime'] = 'timestamp';
      $this->dbcolumntypes['timestamp'] = 'bigint';
   }

   function evaluate() {
      $this->result = $this->state['thisvalue'];
      #error_log("State of DSN $dsn " . print_r($this->state, 1));
   }
   
   function logState() {
      # do not log this item till we figure out why there is the trouble with the
      # thistime column coming out as an integer, and hosing the logging routine.
   }
   
   function cleanUp() {
      parent::cleanUp();
      if (is_object($this->dtobj)) {
         unset($this->dtobj);
      }
   }

   function addDSNRecs($theserecs) {
      # expects records formatted adccording to the routines in HSPFWDM object
      if ($this->debug) {
         $this->logDebug("Adding " . count($theserecs) . ' records <br>');
      }
      //error_log("Adding " . count($theserecs) . ' records <br>');
      //error_log("Sample DSN Record " . print_r($theserecs[0],1) . '  <br>');
      if (!is_object($this->dtobj)) {
         $this->dtobj = new DateTime;
      }
      $n = 0;
      foreach ($theserecs as $thisrec) {
         $ts = date('r',strtotime($thisrec['thistime']));
         $this->addValue($ts, $thisrec);
         #break;
         $n++;
      }
      //error_log("$n values added <br>\n");
      ksort($this->tsvalues);
      if ( (count($this->tsvalues) > $this->max_memory_values) and ($this->max_memory_values > 0)) {
         $this->setDBCacheName();
         //error_log("tsvalues cacheing enabled on $this->name");
         $this->tsvalues2listobject();
         $this->getCurrentDataSlice();
      }
   }

}


class WDMDSNaccessor extends modelObject {

   var $name = '';
   var $wdmoutput = '';
   var $loggable = 1; // can log the value in a data table

   function init() {
      $this->parentobject->activateDSN($this->wdmoutput);
   }

   function evaluate() {
      $this->result = $this->parentobject->getDSNValue($this->wdmoutput);
   }

}


class WatershedShapeFile extends modelContainer {

   var $name = '';
   var $wdmoutput = '';
   var $serialist = 'containment_columns';

   function init() {
      parent::init();
   }

   function create() {
      # this method does any operations that are batched into this object
      # it must be called AFTER the wake() method, but prior to the init() method
      parent::create();
      
      # 1. verify that we have a shape file (or a text file with data in it is OK, 
      #    we will just not have any shapes created)
      # 2. If this is an actual shapefile, convert with shp2psql, else, try to read it 
      #    (have a selector for file type: shp, dbf, csv)
      # 3. Create a temp table with the data from the file
      # 4. Process any containment queries, and create model containers for each level of containment found, 
      #    nesting them by order of the containment column(s)
      
      
   }
   
   

}

class NOAADataObject extends timeSeriesInput {
   var $datatype = 0; # 0 - area Forecast matrix, 1 - stream flow forecast, 2 - Palmer Drought Index
   var $dataURL = 'http://www.srh.noaa.gov/data/LWX/AFMLWX';
   var $stationid = 'VAZ027';
   var $dateformat = '([0-9]{2}/[0-9]{2}/[0-9]{2})';
   var $timeformat = '([0-9]{2})';
   var $datastartcol = 14;
   var $cache_ts = 1; # always opt to store this data in a file, since these are mostly realtime value /future values,
                      # we wish to be able to store any previous record that has been made.
   var $stateabbrev = ''; # state abbreviation for NOAA zones
   var $region = 0; # noaa region code (both state and region needed for Palmer drought)
   var $dataformats = array();
   var $AFMrecordend = '$$'; # end of record for Area Forecast matrix
   var $timezone = 'EST'; # NOAA returns UTC and EST/EDT, maybe others, set desired time zone here
   var $daylightzone = 'EDT'; # corresponds to daylight savings version of zone. This is set in the init() routine, so
                              # it is not really necessary to define here
   # sample URLS:
   # Blacksburg Area Forecast Matrix: http://www.srh.noaa.gov/data/RNK/AFMRNK
   # Wakefiled Area Forecast Matrix: http://www.srh.noaa.gov/data/AKQ/AFMAKQ
   # Sterling Area Forecast Matrix: http://www.srh.noaa.gov/data/LWX/AFMLWX

   # sample data block for Area Forecast matrices
   # 6 hour format:
   #DATE               THU 01/31/08  FRI 02/01/08  SAT 02/02/08  SUN 02/03/08
   #UTC 6HRLY     05   11 17 23 05   11 17 23 05   11 17 23 05   11 17 23
   #EST 6HRLY     00   06 12 18 00   06 12 18 00   06 12 18 00   06 12 18
   #
   #MIN/MAX            23    43      30    43      30    45      25    44
   #TEMP          30   26 39 39 34   32 40 39 34   32 42 38 32   28 40 38
   #DEWPT         14   11 17 20 24   27 31 29 24   23 23 24 22   22 26 26
   #PWIND DIR          NW    SE      SE    SW      NW     W       S     W
   #WIND CHAR          LT    LT      LT    LT      GN    LT      LT    LT
   #AVG CLOUDS    FW   FW FW SC B1   OV OV OV B1   B1 B1 SC SC   SC B1 SC
   #POP 12HR            5    10      60    70      40    20      10    10
   #RAIN                         S    L  L  C  C    S
   #SNOW                              L             S
   # 3 hour format:
   #DATE             MON 01/28/08            TUE 01/29/08            WED 01/30/08
   #UTC 3HRLY     08 11 14 17 20 23 02 05 08 11 14 17 20 23 02 05 08 11 14 17 20 23
   #EST 3HRLY     03 06 09 12 15 18 21 00 03 06 09 12 15 18 21 00 03 06 09 12 15 18
   #
   #MAX/MIN                45 47 49          31          51    35 36 38          47
   #TEMP                38 44 46 42 38 36 35 34 39 47 50 46 43 41 40 38 41 45 46 41
   #DEWPT               23 21 20 22 24 25 26 28 29 32 35 37 38 39 39 33 25 19 16 16
   #RH                  54 39 35 44 57 64 69 78 67 56 56 71 82 92 96 82 52 35 29 36
   #WIND DIR            NW NW NW NW SW SW  S  S  S  S  S  S  S  S SW  W  W  W  W NW
   #WIND SPD             6  4  4  3  3  3  4  3  5  8  6  8 10 13 16 18 19 18 16 11
   #WIND GUST                                                              28
   #CLOUDS              B2 SC FW FW SC SC B1 B1 B2 OV OV OV OV OV OV B1 FW FW FW FW
   #POP 12HR                      0          10          40          70          30
   #QPF 12HR                      0           0        0.01        0.28        0.08
   #RAIN                                            S  C  L  L  L  L  C
   #WIND CHILL                                              37 34 32 29 32 37    34
   #MIN CHILL              29    38    33    30    31          32    27    27    33

   function wake() {
      parent::wake();
      // didn't really want to do this init(), BUT, we need to get our data in 
      // order to know what variables we have to offer
      #$this->init();
      // so, instead, we call jst formatvariables, and retrievedata()
      $this->setUpFormatVariables();
      $this->retrieveData();
   }

   function init() {
      parent::init();
      $this->setUpFormatVariables();
      $this->orderOperations();
      $this->retrieveData();
      ksort($this->tsvalues);
      # stash data values
      #$this->tsvalues2file();

   }

   function setUpFormatVariables() {
      # set up format strings for this data
      $this->dateformat = '([0-9]{2}/[0-9]{2}/[0-9]{2})';
      $this->datastartcol = 13; # what character is the first data column?
      $this->timeformat = '([0-9]{2})';
      $this->dataformats = array(
         # this format is accurate for the 6 hour distribution,
         '6HRLY' => array(
            'dataformat' => "([ A-Z0-9a-z]{13})([ 0-9]{3})([ 0-9]{5})([ 0-9]{3})([ 0-9]{3})([ 0-9]{3})([ 0-9]{5})([ 0-9]{3})([ 0-9]{3})([ 0-9]{3})([ 0-9]{5})([ 0-9]{3})([ 0-9]{3})([ 0-9]{3})",
            'numperday' => 4
         ),
         # this format is accurate for the 3 hour distribution,
         '3HRLY' => array(
            'dataformat' => "([ A-Z0-9a-z]{13})([ 0-9]{3})([ 0-9]{3})([ 0-9]{3})([ 0-9]{3})([ 0-9]{3})([ 0-9]{3})([ 0-9]{3})([ 0-9]{3})([ 0-9]{3})([ 0-9]{3})([ 0-9]{3})([ 0-9]{3})([ 0-9]{3})([ 0-9]{3})([ 0-9]{3})([ 0-9]{3})([ 0-9]{3})([ 0-9]{3})([ 0-9]{3})([ 0-9]{3})([ 0-9]{3})([ 0-9]{3})",
            'numperday' => 8
         )
      );

      # set the daylight savings zone if applicable
      switch ($this->timezone) {
         case 'AST':
            $this->daylightzone = 'ADT';
         break;

         case 'CST':
            $this->daylightzone = 'CDT';
         break;

         case 'EST':
            $this->daylightzone = 'EDT';
         break;

         case 'MST':
            $this->daylightzone = 'MDT';
         break;

         case 'PST':
            $this->daylightzone = 'PEDT';
         break;

         default:
         # default to no zone defined
            $this->daylightzone = $this->timezone;
         break;
      }
      $this->tsvalues = array();
   }


   function retrieveData() {
      # decide which module to use

      switch ($this->datatype) {

         case 0:
            $this->retrieveAreaMatrix();
         break;

         case 1:
            $this->retrieveFlowForecast();
         break;

         case 2:
            $this->retrievePalmerDroughtIndex();
         break;

      }

   }

   ######################################################################
   ###             Palmer Drought Index Retrieval                     ###
   ######################################################################

   function retrievePalmerDroughtIndex() {
      if ($this->debug) {
         $this->logDebug("Trying to retrieve " .$this->dataURL );
      }
      $indata = file_get_contents($this->dataURL);
      if ($this->debug) {
         $this->logDebug("Retrieved " .$this->dataURL );
      }
      $inlines = split("\n", $indata);
      $i = 0; # counter for parsed lines
      $startline = -1;
      # station ID corresponds to a region ID for this dataset
      if ($this->debug) {
         $this->logDebug("Searching for Region $this->stationid ");
      }
      $header1 = $inlines[0]; # contains region info
      $header2 = $inlines[1]; # has source info
      $header3 = $inlines[2]; # has date info

      # get the date info
      $regex = 'WEEK ([ 0-9]{2}) OF THE ([0-9]{4}) GROWING SEASON';
      ereg( $regex, $header3, $matches );
      $week = $matches[1];
      $season = $matches[2];
      $regex = 'WEEK ENDING ([ 0-9]{2}) ([ a-zA-Z]{3}) ([0-9]{4})';
      ereg( $regex, $header3, $matches );
      $day = $matches[1];
      $month = $matches[2];
      $year = $matches[3];

      # file format
#                                           SOIL     PCT                           MONTH  PRELIM-P  PRECIP
#                                         MOISTURE  FIELD                  CHANGE  MOIST  FINAL -F  NEEDED
#                                       UPPER LOWER  CAP.  POT  RUN  CROP   FROM    ANOM  PALMER    TO END
#                            TEMP  PCPN LAYER LAYER  END  EVAP  OFF MOIST   PREV    (Z)   DROUGHT   DROUGHT
#ST CD CLIMATE DIVISION       (F)  (IN)  (IN)  (IN)  WEEK (IN) (IN) INDEX   WEEK   INDEX  INDEX      (IN)
      # sample line:"MD  5 NORTHEASTERN SHORE    49.2  0.02  0.73  5.00  95.5 0.29 0.00  0.51  -0.51   -0.42   -0.59 P   1.11";
      $linereg = '([A-Z]{2}) ([ 0-9]{2}) ([ .A-Za-z0-9]{20}) ([ -.0-9]{5}) ([ -.0-9]{5}) ([ -.0-9]{5}) ([ -.0-9]{5}) ([ -.0-9]{5}) ([ -.0-9]{4}) ([ -.0-9]{4}) ([ -.0-9]{5}) ([ -.0-9]{6}) ([ -.0-9]{7}) ([ -.0-9]{7}) ([ A-Z]{1})([ -.0-9]{0,7})';
      $colnames = array('state', 'region', 'division', 'temp', 'precip', 'ul_moist', 'll_moist', 'fc_pct', 'pet', 'ro', 'crop_mi', 'delta_wk', 'z_month', 'pdi', 'flag', 'precip_need');

      $parsing = 0;
      $thisentry = array();
      # skip down till we find the "ST" marker at the beginning of the line
      for ($i = 4; $i < count($inlines); $i++) {
         #print("$thisline \n");
         $thisline = $inlines[$i];
         if (substr($thisline, 0,2) == 'ST') {
            # start parsing lines
            $parsing = 1;
         }
         if ($parsing) {
            # must clear the $parsed array, since a failure will NOT overwrite any previous contents
            #print("$thisline \n");
            $parsedvals = array();
            ereg($linereg, $thisline, $parsedvals);
            #print_r($parsedvals);
            $stateabbrev = $parsedvals[1];
            $region = $parsedvals[2];
            #print("Looking for $stateabbrev = $this->stateabbrev and $region = $this->region \n");
            if ( ($region == $this->region) and ($stateabbrev == $this->stateabbrev) ) {
               # we have a match, grab it.
               $startline = $i;
               if ($this->debug) {
                  $this->logDebug("Found $this->stationid ");
               }
               if ($this->debug) {
                  $this->logDebug(count($colnames) . " column headers \n");
               }
               $data = array_slice($parsedvals, 1, count($parsedvals) - 1);

               if ($this->debug) {
                  $this->logDebug(count($data) . " data values \n");
               }
               $thisentry = array_combine($colnames, $data );
               break;
            }
         }
      }
      # initialize the last date with today, this is valid since this is a forecast relative to today
      $lastdate = date('d/m/Y');
      $lasttime = 24; # set this up to automatically retrieve the next date
      if ($this->debug) {
         $this->logDebug("File has " . count($inlines) . " lines.");
      }
      if (count($thisentry) > 0) {
         $ts = date('r', strtotime("$day $month $year"));
         #print("Adding Values" . print_r($thisentry,1) . "\n");
         $this->addValue($ts, $thisentry);
         $this->addValue($ts, 'timestamp', date('U', strtotime("$day $month $year")));
         $this->addValue($ts, 'thisdate', date('m-d-Y', strtotime("$day $month $year")));

      }


   }

   ######################################################################
   ###           END - Palmer Drought Index Retrieval                 ###
   ######################################################################

   ######################################################################
   ###             Area Forecast Matrix Retrieval                     ###
   ######################################################################
   function retrieveAreaMatrix() {
      if ($this->debug) {
         $this->logDebug("Trying to retrieve " .$this->dataURL );
      }
      $indata = file_get_contents($this->dataURL);
      if ($this->debug) {
         $this->logDebug("Retrieved " .$this->dataURL );
      }
      $inlines = split("\n", $indata);
      $i = 0; # counter for parsed lines
      $startline = -1;
      if ($this->debug) {
         $this->logDebug("Searching for $this->stationid ");
      }
      for ($i = 0; $i < count($inlines); $i++) {
         $thisline = $inlines[$i];
         if (substr_count($thisline, $this->stationid) > 0) {
            $startline = $i;
            if ($this->debug) {
               $this->logDebug("Found $this->stationid ");
            }
            break;
         }
      }
      # initialize the last date with today, this is valid since this is a forecast relative to today
      $lastdate = date('d/m/Y');
      $lasttime = 24; # set this up to automatically retrieve the next date
      if ($this->debug) {
         $this->logDebug("File has " . count($inlines) . " lines.");
      }
      if ($startline >= 0) {
         # we found the first line, so proceed:
         $lineno = $startline;
         $infoline = '';
         # stash information below this line until we hit the DATE line
         while (!(substr_count($thisline, 'DATE '))) {
            $infoline .= " " . $thisline;
            $lineno++;
            $thisline = $inlines[$lineno];
         }
         if ($this->debug) {
            $this->logDebug("<b>Debug:</b> Info Header: " . $infoline . " <br>");
         }
         # parse the date ranges
         $dates = array();
         # stash the date line for parsing after we determine the temporal resolution
         $dateline = $inlines[$lineno];
         # parse the time stamps and determine data temporal resolution
         $atdata = 0;

         # do this until the end of record or end of file is reached
         while ((substr($inlines[$lineno],0,2) <> $this->AFMrecordend) and ($lineno < count($inlines))) {
            if ($this->debug) {
               $this->logDebug("<b>Debug:</b> Looking for records <br>");
            }

            # scan for temporal resolution and date/time header rows
            # when we find one, call the routine for parsing the record
            $thisline = $inlines[$lineno];
            if (substr($thisline,0,4) == 'DATE') {
               if ($this->debug) {
                  $this->logDebug("<b>Debug:</b> Calling Date Parsing routine <br>");
               }
               # grab the new date info
               $parseresult = $this->parseDateLines($inlines, $lineno, $lastdate, $lasttime);
               $dates = $parseresult['dates'];
               $lineno = $parseresult['lineno'];
               $datares = $parseresult['datares'];
               $times = $parseresult['times'];
               $timecols = $parseresult['timecols'];
               # grab the last date for the wraparound
               $lastdate = $dates[count($dates) -1];
               $lasttime = $dates[count($times) -1];
               if ($this->debug) {
                  $this->logDebug("<b>Debug:</b> Calling Data Parsing routine <br>");
               }

               $lineno = $this->scanLines($inlines, $lineno, $datares, $dates, $times, $timecols);
            } else {
               $lineno++;
            }
         }

      } else {
         if ($this->debug) {
            $this->logDebug("<b>Error:</b> Could not locate requested record: $this->stationid <br>");
         }
      }

   }

   function parseDateLines($inlines, $lineno, $lastdate) {

      $preferredzone = 0;
      $atdata = 0;
      $datares = '';
      $timeline = array();
      $dateline = $inlines[$lineno];
      $lineno++;
      while (!($atdata ) and ($lineno < count($inlines))) {
         $thisline = $inlines[$lineno];
         #ereg($this->dateformat, $thisline, $dates);
         $thiszone = substr($thisline,0,3);
         $thisres = rtrim(ltrim(substr($thisline, 4, 6)));
         if ($this->debug) {
            $this->logDebug("<b>Debug:</b> Time Zone/data resolution Parsed: $thiszone / $thisres <br>");
         }
         if ( ($thiszone == $this->timezone) or ($thiszone == $this->daylightzone) ) {
            # we have found our desired time zone
            $preferredzone = 1;
            $timeline = $thisline;
            $datares = $thisres;
            if ($this->debug) {
               $this->logDebug("<b>Debug:</b> Required Time Zone Found: $thiszone / $datares <br>");
            }
         }

         if (!in_array($thisres, array_keys($this->dataformats))) {
            # either this is of a format that we don;t understand, or we have reached the data lines
            # either way, we break, and then check to see if we have gotten a valid set of times
            $atdata = 1;
         }
         $lineno++;
      }

      # if we have found our preferred zone, then proceed, otherwise log an error and return
      if (!$preferredzone) {
         $this->logError("<b>Error:</b> Could not locate requested time zone $this->timezone <br>");
         return;
      }

      # if we have found a recognized temporal resolution, then proceed, otherwise log an error and return
      if (! (strlen($datares) > 0)) {
         $this->logError("<b>Error:</b> Could not locate recognized temporal resolution in " . print_r(array_keys($this->dataformats),1) . " <br>");
         return;
      }
      $dateparms = array();

      preg_match_all($this->dateformat, $dateline, $dateparms);
      $dates = $dateparms[0];
      preg_match_all($this->timeformat, substr($timeline,$this->datastartcol), $timeparms, PREG_OFFSET_CAPTURE);
      $times = array();
      $timecols = array();
      foreach ($timeparms[0] as $thistime) {
         array_push($times, $thistime[0]);
         array_push($timecols, $thistime[1]);
      }
      $numperday = $this->dataformats[$datares]['numperday'];

      if (count($dates) < (count($times) / $numperday) ) {
         # missing first day, prepend it
         array_pad($dates, (-1 * (count($dates) + 1)), $lastdate);
      }

      if ($this->debug) {
         $this->logDebug("<b>Debug:</b> Date Info, Raw Data: " . $dateline . " <br>");
         $this->logDebug("<b>Debug:</b> Date Format ereg: " . $this->dateformat . " <br>");
         $this->logDebug("<b>Debug:</b> Date Format Output: " . print_r($dateparms,1) . " <br>");
         $this->logDebug("<b>Debug:</b> Date Info, parsed: " . print_r($dates,1) . " <br>");
         $this->logDebug("<b>Debug:</b> Time Info, Raw Data: " . $timeline . " <br>");
         $this->logDebug("<b>Debug:</b> Time Format ereg: " . $this->timeformat . " <br>");
         $this->logDebug("<b>Debug:</b> Time Format Output: " . print_r($timeparms,1) . " <br>");
         $this->logDebug("<b>Debug:</b> Times, parsed: " . print_r($times,1) . " <br>");
         $this->logDebug("<b>Debug:</b> Time Columns, parsed: " . print_r($timecols,1) . " <br>");
      }

      $retarr = array();
      $retarr['dates'] = $dates;
      $retarr['lineno'] = $lineno;
      $retarr['datares'] = $datares;
      $retarr['times'] = $times;
      $retarr['timecols'] = $timecols;

      return $retarr;
   }

   function scanLines($inlines, $lineno, $datares, $dates, $times, $timecols) {
      $thisformat = $this->dataformats[$datares]['dataformat'];
      $numperday = $this->dataformats[$datares]['numperday'];
      $thisline = $inlines[$lineno];
      if ($this->debug) {
         $this->logDebug("<b>Debug:</b> Format Info: $thisformat <br>");
         $this->logDebug("<b>Debug:</b> Numer of records per day: $numperday <br>");
      }

      # screen for the occurence of '$$' which mean srecord end,
      # or 'DATE' which means the next temporal resolution has been found
      while ( (substr($thisline,0,2) <> $this->AFMrecordend) and (substr($thisline,0,4) <> 'DATE') and ($lineno < count($inlines)) ) {

         ereg($thisline, $thisformat, $dataline);
         if ($this->debug) {
            $this->logDebug("<b>Debug:</b> In Line: $thisline <br>");
            $this->logDebug("<b>Debug:</b> Format Line: $thisformat <br>");
            $this->logDebug("<b>Debug:</b> Parsed Array: " . print_r($dataline,1) . " <br>");
            $this->logDebug("<b>Debug:</b> Item name: " .  substr($thisline,0,4) . "<br>");
         }
         $dataname = ltrim(rtrim(substr($thisline,0,13)));
         if (strlen($dataname) > 0) {
            # iterate through each element of our time fields and add the corresponding
            # element from the data field, with a properly formatted time stamp
            $j = 0;
            $d = 0;
            $lasttime = $times[0];
            while ($j < count($times)) {
               $thistime = $times[$j];
               if ($thistime < $lasttime) {
                  $d++;
               }
               $lasttime = $thistime;
               $thisdate = $dates[$d];
               if ($this->debug) {
                  $this->logDebug("<b>Debug:</b> Date: $thisdate <br>");
               }
               $tstring = $thisdate . " " . $thistime . ":00:00";
               # timecols has column position of time entry
               # subtract 1 from this position, to accomodate values of 100 if present
               $timepos = $timecols[$j] - 1;
               $thisval = ltrim(rtrim(substr(substr($thisline, $this->datastartcol), $timepos,3)));
               $ts = date('r', strtotime($tstring));
               if ($this->debug) {
                  $this->logDebug("<b>Debug:</b> Found: $tstring $dataname - $thisval <br>");
               }
               if (strlen($thisval) > 0 ) {
                  $this->addValue($ts, $dataname, $thisval);
                  $this->addValue($ts, 'timestamp', date('U', $ts));
                  $this->addValue($ts, 'thisdate', date('m-d-Y', $ts));
                  if ($this->debug) {
                     $this->logDebug("<b>Debug:</b> Adding: $tstring $dataname - $thisval <br>");
                  }
               }
               $j++;
            }
         }

         $lineno++;
         $thisline = $inlines[$lineno];
      }

      return $lineno;
   }
   ######################################################################
   ###           END - Area Forecast Matrix Retrieval                 ###
   ######################################################################

}

class parseFileObject extends timeSeriesInput {

   var $datecol = '';
   var $dateformat = '';
   var $timeformat = '';
   var $timecol = '';
   var $dataURL = '';
   var $missingvals = array();

   function init() {
      parent::init();
      $this->orderOperations();
      $this->retrieveData();

   }

   function setDataColumnTypes() {

      parent::setDataColumnTypes();
      # set up column formats for appropriate outputs to database
      if ( (!isset($this->dbcolumntypes)) or (!is_array($this->dbcolumntypes)) ) {
         $this->dbcolumntypes = array();
      }

      $basetypes = array(
               'abbrevdate'=>'varchar(9)',
               'miltime'=>'varchar(4)'
      );
      $thisarray = array_unique(array_merge($this->dbcolumntypes, $basetypes));
      
      $this->data_cols[] = 'abbrevdate';
      $this->data_cols[] = 'miltime';

      $this->dbcolumntypes = $thisarray;

      $logtypes = array(
               'abbrevdate'=>'%s',
               'miltime'=>'%s'
      );
      $thisarray = array_unique(array_merge($this->logformats, $logtypes));

      $this->logformats = $thisarray;
   }

   function retrieveData() {
      # Basic Format:
      # Date        Time  Inflow  Outflow     Elev     Elev       Gen   Rainfall    ELev     Elev
      # 13JUN2008   1200       0        0    300.40   300.41     0.00      0.00    258.20   258.28
      #
      # date format: DDmonYYYY (mon is 3 letter month abbreviation)
      # time format: MIL  (4 digit with leading zeroes)
      # datecol and timecol must be set, if timecol is '', then we will create a timestamp with out it, which defaults to 00:00:00
      # datecol MUST be set to retrieve data
      $this->datecol = 'abbrevdate';
      $this->timecol = 'miltime';
      $this->dateformat = '([ 0-9]{2})([ A-Z]{3})([ 0-9]{4})';
      $this->timeformat = '([0-9]{2})([0-9]{2})';
      # these will be passed in later, perhaps if this has widespread use, for now they help to convert the parsed date,
      # which can be in any order (not necessarily one interpretable by php) and turn it into an ordered time/date
      $dateorder = array('d','m','y');
      $timeorder = array('h','m');
      $this->missingvals = array('?MIS', '?MISS', '-99', '?MISST');

      if ($this->debug) {
         $this->logDebug("Retrieve Date method called." );
      }

      if ( strlen($this->datecol) > 0) {

         # this will serve as a template for quick and dirty data retrieval and parsing
         # this requires the input of a parsing string, and a date and time field
         # normally, the user will enter the "linereg" and the "colnames" as field inputs, but for now,
         # we will hardwire these
         $linereg = '([A-Z0-9]{9}) ([ 0-9]{6}) ([ -.A-Z?0-9]{7}) ([ -.A-Z?0-9]{8}) ([ -.A-Z?0-9]{9}) ([ -.A-Z?0-9]{8}) ([ -.A-Z?0-9]{8}) ([ -.A-Z?0-9]{9}) ([ -.A-Z?0-9]{9}) ([ -.A-Z?0-9]{8})';
         $colnames = array('abbrevdate', 'miltime', 'inflow', 'outflow', 'elev1', 'elev2', 'gen_mwh', 'rainfall', 'gage1_msl', 'gage2_msl');

         if ($this->debug) {
            $this->logDebug("Trying to retrieve " .$this->dataURL );
         }
         
         $ctx = stream_context_create(array(
             'http' => array(
                 'timeout' => 240
                 )
             )
         );
         $indata = file_get_contents($this->dataURL, 0, $ctx);
         if ($this->debug) {
            $this->logDebug("Retrieved " .$this->dataURL );
         }
         $inlines = split("\n", $indata);

         $parsing = 0;
         $thisentry = array();
         # just start parsing, we will do it until we reach the end
         foreach ($inlines as $thisline) {
            #print("$thisline \n");
            # must clear the $parsed array, since a failure will NOT overwrite any previous contents

            $parsedvals = array();
            ereg($linereg, $thisline, $parsedvals);
            if ($this->debug) {
               $this->logDebug("File Entry Parsed to:");
               $this->logDebug($parsedvals);
            }
            $data = array_slice($parsedvals, 1, count($parsedvals) - 1);
            $thisentry = array_combine($colnames, $data );
            if ($this->debug) {
               $this->logDebug("Data and Keys merged to:");
               $this->logDebug($thisentry);
            }
            $dateparts = array();
            $ps = array();
            ereg($this->dateformat, $thisentry[$this->datecol], $ps);
            $ardate = array_slice($ps, 1, count($ps) - 1);
            if ($this->debug) {
               $this->logDebug("Data :" . $thisentry[$this->datecol] . ' ');
               $this->logDebug("Parsed to:");
               $this->logDebug($ardate);
                  $this->logDebug("From:");
               $this->logDebug($ps);
            }
            foreach ($dateorder as $thispart) {
               $dateparts[$thispart] = array_shift($ardate);
            }
            $timeparts = array('h'=>0,'m'=>0,'s'=>0);
            if (strlen($this->timeformat) > 0) {
               $parsedvals = array();
               ereg($this->timeformat, $thisentry[$this->timecol], $parsedvals);
               $artime = array_slice($parsedvals, 1, count($parsedvals) - 1);
               if ($this->debug) {
                  $this->logDebug("Data :" . $thisentry[$this->timecol] . ' ');
                  $this->logDebug("Parsed to:");
                  $this->logDebug($artime);
                  $this->logDebug("From:");
                  $this->logDebug($parsedvals);
               }
               foreach ($timeorder as $thispart) {
                  $timeparts[$thispart] = array_shift($artime);
               }
            }
            # only adds it if it is a valid date
            if ($this->debug) {
               $this->logDebug("Checking Validity of Date:");
               $this->logDebug($dateparts);
            }
            if (strtotime($dateparts['m'] . ' ' . $dateparts['d'] . ' ' . $dateparts['y'])) {
               $datestamp = strtotime($dateparts['m'] . ' ' . $dateparts['d'] . ' ' . $dateparts['y']);
               list($dateparts['m'],$dateparts['d'],$dateparts['y']) = split('-',date('n-j-Y', $datestamp));
               $timeseconds = mktime(ltrim($timeparts['h']),ltrim($timeparts['m']),$timeparts['s'],$dateparts['m'],$dateparts['d'],$dateparts['y']);
               $timestamp = date('r', $timeseconds);
               $thisdate = date('m-d-Y', $timeseconds);
               $thisentry['timestamp'] = $timestamp;
               $thisentry['thisdate'] = $thisdate;
               if ($this->debug) {
                  $this->logDebug("Number of entries in array: " . count(array_keys($thisentry)) . "\n");
               }
               if (count(array_keys($thisentry)) > 2 ) {
                  if ($this->debug) {
                     $this->logDebug("Adding " . count(array_keys($thisentry)) . " Values\n");
                  }
                  foreach($thisentry as $thiskey => $thisval) {
                     # set to NULL if it is a missing code

                     if (in_array(ltrim(rtrim($thisval)), $this->missingvals)) {
                        $this->logDebug("Missing Value Found $thisdate " . $timeparts['h'] . ":" . $timeparts['m'] . " ". $thisval);
                        $thisval = 'NULL';
                     }
                     $this->addValue($timestamp, $thiskey, $thisval);
                  }
                  if ($this->debug) {
                     $this->logDebug("Entry Added for $thisdate " . $timeparts['h'] . ":" . $timeparts['m'] . " ");
                     $this->logDebug($thisentry);
                  }
               }
            }
         }
      }
   }
}

class droughtMonitor extends modelObject {
   # shell object for drought monitoring
   var $flowgage = '';
   var $palmer_region = '';
   var $gw_gage = '';
   var $the_geom = '';


}

class USGSGageObject extends timeSeriesInput {
   var $maxflow = 0.0; /* maximum flow during period */
   var $startdate = '';
   var $enddate = '';
   var $data_periods = array();
   var $flow_begin = '';
   var $flow_end = '';
   var $laststaid = '';
   var $staid = '';
   var $siteid = '';
   var $force_refresh = 0; # whether or not to query the station for record dates each time this object is initialized
   var $period = 7;
   var $ddnu = '';
   var $area = -1.0; # drainage area in sq. miles
   var $stationstats = array();
   var $recformat = 'rdb';
   var $rectype = 1; # 0 - realtime, 1 - daily mean, 2 - daily stats, 3 - station inventory
   var $dataitems = '00060,00010';
   var $uri = ''; # the URI used to retrieve NWIS data
   var $code_name = array();
   var $code_suffix = array();
   var $datadefaults = array();
   var $result = 0;
   var $sitetype = 1; # 1 - stream gage, 2 - groundwater, 3 - reservoir level
   var $stat_dbtblname = '';
   // widget to obtain station information
   var $xml_station_info_url = "http://deq1.bse.vt.edu/wooommdev/remote/xml_usgs_basin.php";

   function setState() {
      parent::setState();
      $this->state['Qout'] = 0.0;
      $this->state['Temp'] = 0.0;
      $this->state['Qinches'] = 0.0;
      $this->state['Qfps'] = 0.0;
      $this->state['area'] = $this->area;
      
      $sitecodes = array(
         1=>array('00060'=>'Qout', '00010'=>'Temp', '00095'=>'specific_cond','00045'=>'precip'),
         2=>array('72019'=>'tabledepth','00045'=>'precip'),
         3=>array('00062'=>'stage','00045'=>'precip')
      );
      # when various codes are returned, a specific suffix can be used to obtain the exact desired measurement
      $codesuffixes = array(
         1=>array('00060'=>'', '00010'=>'','00045'=>'','00095'=>''),
         2=>array('72019'=>'00001'),
         3=>array('00062'=>'','00045'=>'','00095'=>'')
      );
      $datadefaults = array(
         'Qout'=>0.0,
         'Temp'=>0.0,
         'specific_cond'=>0.0,
         'precip'=>0.0,
         'stage'=>0.0
      );
      $this->code_name = $sitecodes[$this->sitetype];
      $this->code_suffix = $codesuffixes[$this->sitetype];
      $this->dataitems = join(',', array_keys($this->code_name));
      $this->datadefaults = $datadefaults;
      #$this->getStationInfo();
   }

   function wake() {
      if ($this->debug) {
         $this->logDebug("Waking " . $this->name . " at " . date('r'));
      }
      parent::wake();
      if ($this->debug) {
         $this->logDebug("Finished waking " . $this->name . " at " . date('r'));
      }
      
      if (strlen(rtrim(ltrim($this->area))) == 0) {
         $this->area = -1;
      }

      if ($this->area < 0) {
         # get the station data, do it once
         $this->forcerefresh = 1;
         $this->getStationInfo();
      }
   }

   function getPublicProps() {
      # gets only properties that are visible (must be manually defined)
      $publix = parent::getPublicProps();
      # add specific USGS parameter names
      foreach (array_values($this->code_name) as $thiscode) {
         array_push($publix, $thiscode);
      }

      return $publix;
   }

   function setProp($propname, $propvalue) {
      # checks to see if we should stow the value for laststaid
      # this is used to eliminate redundant calls to query the station basic data
      parent::setProp($propname, $propvalue);
      if ($propname == 'staid') {
         # refresh station info
         #$this->getStationInfo();
      }
   }
   
   function setDataColumnTypes() {
      parent::setDataColumnTypes();
      
      $statenums = array('area', 'Qout', 'Temp', 'Qinches', 'Qfps');
      foreach ($statenums as $thiscol) {
         $this->dbcolumntypes[$thiscol] = 'float8';
         $this->data_cols[] = $thiscol;
      }
   }
   
   function create() {
      if (strlen($this->staid) > 0 ) {
         $this->getStationStats();
         $this->addStatTable($this->stationstats_lookup);
      }
   }
   
   function addStatTable($thistab) {
      if ($this->debug) {
         $this->logDebug("Receied request to add stat array: " . print_r($thistab,1) . " <br>");
      }
      $assoc = array();
      $keys = array();
      $i = 0;
      foreach ($thistab as $mo => $statpairs) {
         $row = array();
         $row['month'] = $mo;
         $row['0.0'] = 0.0;
         foreach ($statpairs as $thisstat => $thisval) {
            preg_match('/[0-9]+/',$thisstat,$num);
            if ($this->debug) {
               $this->logDebug($thisstat . " : " . floatval($num[0])/100.0 . " = $thisval\n");
            }
            $statkey = floatval($num[0])/100.0;
            //$statkey = floatval($num[0]);
            $row["$statkey"] = $thisval;
         }
         $assoc[$i] = $row;
         $i++;
      }
      
      // hiastoric landuse subcomponent to allow users access to model simulated land uses
      $mostat = new dataMatrix;
      $mostat->listobject = $this->listobject;
      $mostat->name = 'landuse_historic';
      $mostat->defaultval = 1.0;
      $mostat->wake();
      $mostat->valuetype = 2; // 2 column lookup (col & row)
      $mostat->keycol1 = 'month'; // key for 1st lookup variable
      $mostat->lutype1 = 0; // lookup type - exact match for month
      $mostat->keycol2 = 'Qout'; // key for 2nd lookup variable
      $mostat->lutype2 = 3; // lookup type - interpolated for return period value
      // add a row for the header line
      $mostat->assocArrayToMatrix($assoc);
      if ($this->debug) {
         $this->logDebug("Trying to add historic land use sub-component matrix with values: " . print_r($mostat->matrix,1) . " <br>");
      }
      $this->addOperator('exceedence_monthly', $mostat, 0);
      if ($this->debug) {
         $this->logDebug("Processors on this object: " . print_r(array_keys($this->processors),1) . " <br>");
      }
   }


   function init() {
      parent::init();
      // initialize dates with dummy variables
      if ($this->startdate == '') {
         $this->startdate = date('Y-m-d');
      }
      if ($this->enddate == '') {
         $this->enddate = date('Y-m-d');
      }
      $this->logDebug("Debug Mode for $this->name : $this->debug <br> ");
      
      # set a name for the temp table that will not hose the db
      $targ = array(' ',':','-','.');
      $repl = array('_', '_', '_', '_');
      $this->tblprefix = str_replace($targ, $repl, 'tmp_usgs' . $this->staid . '_' . "$this->componentid" . "_");
      $this->dbtblname = $this->tblprefix . 'datalog';
      $this->stat_dbtblname = $this->tblprefix . 'stationstats';
      
      $this->orderOperations();
      if (strlen(trim($this->staid)) > 0) {
         $this->getStationInfo();
         $this->retrieveData();
      }
      ksort($this->tsvalues);
      if ( (count($this->tsvalues) > $this->max_memory_values) and ($this->max_memory_values > 0)) {
         $this->setDBCacheName();
         $this->tsvalues2listobject();
         $this->getCurrentDataSlice();
      }

   }


   function evaluate() {
      $this->step();
      $this->result = $this->state['Qout'];

   }

   function getStationInfo() {
      if ($this->debug) {
         $this->logDebug("Obtaining Physical Data for station: $this->staid <br>");
      }
      
      //error_log("$this->name Retrieve Data Module PRE: Watershed Area object prop set to " . $this->area . " and state variable area set to " . $this->state['area']);
      
      if (!strlen($this->staid) > 0 ) {
         $this->logError("$this->name gage $this->staid is not valid <br>\n");
         $this->ts_enabled = 0;
      } else {
         if ( ($this->laststaid <> $this->staid) or ($this->forcerefresh)) {
            $this->logDebug("Refreshing station info for " . $this->staid . " at " . date('r') . "<br>");
            # only try to retrieve station info if staid is set, otherwise, application will retrieve info for all
            # USGS gages, which takes a long time....
            $exopt = '';
            switch ($this->sitetype) {
               case 1:
                  $exopt .= 'referred_module=sw';
               break;
               
               case 2:
                  $exopt .= 'referred_module=gw';
               break;
               
               case 3:
                  $exopt .= 'referred_module=sw';
               break;
            }
            $usgs_result = retrieveUSGSData($this->staid, $this->period, $this->debug, '', '', 3, '', '', '', $state='', '', 1, $exopt);
            $sitedata = $usgs_result['row_array'][0];
            if (isset($sitedata['discharge_begin_date'])) {
               $this->flow_begin = $sitedata['discharge_begin_date'];
            }
            if (isset($sitedata['discharge_end_date'])) {
               $this->flow_end = $sitedata['discharge_end_date'];
            }
            if (isset($sitedata['drain_area_va'])) {
               $this->area = $sitedata['drain_area_va'];
            }
            if (isset($sitedata['site_id'])) {
               $this->siteid = $sitedata['site_id'];
            }
            if (isset($sitedata['ddnu'])) {
               $this->ddnu = $sitedata['ddnu'];
            }
            $this->logDebug("Gage " . $this->staid . ", Data = " . $this->flow_begin . " to " . $this->flow_end . ', area: ' . $this->area);
         }
         $this->laststaid = $this->staid;
      }
      //error_log("Area set to : $this->area ");
      if (strlen(rtrim(ltrim($this->area))) == 0) {
         $this->area = -1;
         $this->state['area'] = 0;
      }
      
      if ($this->area <= 0) {
         $this->state['area'] = 0;
      } else {
         $this->state['area'] = $this->area;
      }
      $this->logDebug("Area set to : $this->area ");
      
      $this->logDebug("$this->name Retrieve Data Module post: Watershed Area object prop set to " . $this->area . " and state variable area set to " . $this->state['area']);
      
      // look for shape information in USGS database
      $this->getStationGeometry();

   }
   
   function getStationGeometry() {
      $ctx = stream_context_create(array(
          'http' => array(
              'timeout' => 2400
              )
          )
      );
      $feed_url = $this->xml_station_info_url . "?gage_id=$this->staid";
      $xmlfile = file_get_contents($feed_url, 0, $ctx);
      $this->logDebug("Fetching Feed:  $feed_url <br>\n");
      
      
      // avoiding this XML reader right now, in favor of a raw text geometry coming back
      if (class_exists('jiffyXmlReader')) {
         if ($this->debug) {
            $this->logDebug("Fetching Feed:  $feed_url <br>\n");
         }
         $rawlength = strlen($xmlfile);
         //error_log("USGS XML File Length = $rawlength");
         $xml = simplexml_load_string($xmlfile);
         $linklist = $xml->channel->item;
         
         $linkobj = (array)$linklist;
         $this->the_geom = $linkobj['the_geom'];
         //error_log("USGS Basin Info Columns: " . $linkobj['gage_id'] . " " . $linkobj['drainage_area']);
      }
      
      //error_log("USGS Basin geom: " . substr($this->the_geom,0,128));
   }
   
   function getStationStats() {
      if ($this->debug) {
         $this->logDebug("Obtaining Stream Flow Statistics for station: $this->staid <br>");
      }
      
      # gets historical daily flow exceedence values
      $ddnu = $this->ddnu;
      
      if ($ddnu == '') {
         $ddnu = 1;
      }
      
      $site_result = retrieveUSGSData($this->staid, '', $this->debug, '', '', 2, '', '', '00060', 'va', $this->siteid, $ddnu);
      $gagedata = $site_result['row_array'];
      $debuginfo = $site_result['debuginfo'];
      $uri = $site_result['uri'];
      if ($this->debug) {
         $this->logDebug("$debuginfo<br>");
      }

      $numstats = count($gagedata);
      //if ($this->debug) {
         $this->logDebug("URI: $uri<br>");
         $this->logDebug("$numstats records returned with ddnu = $ddnu<br>");
      //}

      if ($numstats == 0) {
         # try ddnu = 2
         $ddnu = 2;
         $site_result = retrieveUSGSData($this->staid, '', $this->debug, '', '', 2, '', '', '00060', 'va', $this->siteid, $ddnu);
         $gagedata = $site_result['row_array'];
         $numstats = count($gagedata);
         $uri = $site_result['uri'];
         //if ($this->debug) {
            $this->logDebug("URI: $uri<br>");
            $this->logDebug("$numstats records returned with ddnu = $ddnu<br>");
         //}
      }

      if ($this->debug) {
         $this->logDebug("Inserting $numstats new daily flow stats for $siteno (ID: $siteid).<br>");
      }
      
      $statcols = array(
         'agency_cd'=>'varchar(8)',
         'site_no'=>'varchar(12)',
         'parameter_cd'=>'varchar(8)',
         'dd_nu'=>'varchar(4)',
         'month_nu'=>'int4',
         'day_nu'=>'int4',
         'begin_yr'=>'int8',
         'end_yr'=>'int8',
         'count_nu'=>'int8',
         'max_va_yr'=>'int8',
         'max_va'=>'float8',
         'min_va_yr'=>'int8',
         'min_va'=>'float8',
         'mean_va'=>'float8',
         'p05_va'=>'float8',
         'p10_va'=>'float8',
         'p20_va'=>'float8',
         'p25_va'=>'float8',
         'p50_va'=>'float8',
         'p75_va'=>'float8',
         'p80_va'=>'float8',
         'p90_va'=>'float8',
         'p95_va'=>'float8'
      );
      $columns = array_keys($gagedate[0]);
      
      $this->listobject->array2tmpTable($gagedata, $this->stat_dbtblname, $columns, $statcols, 1, $this->bufferlog);
      if ($this->debug) {
         $this->logDebug("Getting schema name for temp table.<br>");
      }
      $stats = array('p05_va','p10_va','p20_va','p25_va','p50_va','p75_va','p80_va','p90_va', 'p95_va');
      $this->stationstats = $gagedata;
      $this->stationstats_lookup = array();
      foreach ($gagedata as $thisdata) {
         $lu = $thisdata['month_nu'];
         if (isset($thisdata['dat_nu'])) {
            $lu .= '-' . $thisdata['dat_nu'];
         }
         foreach ($stats as $sn) {
            $this->stationstats_lookup[$lu][$sn] = $thisdata[$sn];
         }
      }
      
      return;

   }

   function retrieveData() {
      if ($this->debug) {
         $this->logDebug("Obtaining Physical Data for station: $staid <br>");
      }
      if (!strlen($this->staid) > 0 ) {
         $this->logError("$this->name gage $this->staid is not valid <br>\n");
         $this->ts_enabled = 0;
      } else {
         $this->ts_enabled = 1;
         $usgs_result = retrieveUSGSData($this->staid, $this->period, $this->debug, '', '', 3, '', '', '');
         $sitedata = $usgs_result['row_array'][0];
         //error_log($usgs_result['uri']);
         #$this->logDebug($sitedata);
         if (isset($sitedata['drain_area_va'])) {
            $dav = $sitedata['drain_area_va'];
            $this->logDebug("<br>Area = $dav<br>");
            $this->state['area'] = $dav;
         }

         # if not given valid date ranges, will default to the period (default value = 7 days

         # gets daily flow values for indicated period
         if (is_object($this->timer)) {
            # set the timer info to be our start and end date
            #$this->logDebug($this->timer);
            $sdate = new DateTime($this->timer->thistime->format('Y-m-d'));
            $ndate = new DateTime($this->timer->endtime->format('Y-m-d'));
            $sdate->modify("-1 days");
            $ndate->modify("+1 days");
            $this->startdate = $sdate->format('Y-m-d');
            $this->enddate = $ndate->format('Y-m-d');
         }
         if ($this->debug) {
            $this->logDebug("Obtaining Flow Data for station: $this->staid $this->startdate to $this->enddate<br>");
         }
         if ( (strlen($this->startdate) > 0) and (strlen($this->enddate) > 0) ) {
            # assume date range is valid
            $this->period = '';
         }
         $site_result = retrieveUSGSData($this->staid, $this->period, $this->debug, $this->startdate, $this->enddate, $this->rectype, '', $this->recformat, $this->dataitems);
         $gagedata = $site_result['row_array'];
         $this->uri = $site_result['uri'];
         //error_log("USGS URL: $this->uri ");
         if ($this->debug) {
            $this->logDebug("Info returned from USGS retrieval routine <br>");
            $this->logDebug($site_result['debug']);
         }
         $thisno = $gagedata[0]['site_no'];
         #$this->logDebug($site_result['uri'] . "<br>");
         if ($this->debug) {
            $this->logDebug("<br><b>Adding retrieved data to time series array.</b><br>");
         }
         if (!isset($gagedata[0]['site_no'])) {
            # we came up empty here, so let's insert a single zero value for all items
            foreach (split(',', $this->dataitems) as $dataitem) {
               $dataname = $this->code_name[$dataitem];
               $gagedata[0][$dataname] = $this->datadefaults[$dataname];
            }
         }
         //error_log(print_r($gagedata[0],1));
         foreach ($gagedata as $thisdata) {
            if ($this->debug) {
               $this->logDebug($thisdata);
            }
            $thisdate = new DateTime($thisdata['datetime']);
            $ts = $thisdate->format('r');
            $uts = $thisdate->format('U');
            $thisflag = '';
            # default to missing
            $thisval = 0.0;
            foreach (split(',', $this->dataitems) as $dataitem) {
               $suffix = $this->code_suffix[$dataitem];

               foreach (array_keys($thisdata) as $thiscol) {
                  if (substr_count($thiscol, $dataitem)) {
                     # this is a flow related column, check if it is a flag or data
                     if (!substr_count($thiscol, 'cd')) {
                        # check for proper suffix
                        if ($this->debug) {
                           $this->logDebug("Searching for $dataitem" . "_$suffix" . " in $thiscol <br>");
                           $c = substr_count($thiscol, $dataitem . "_$suffix");
                        }
                        if (substr_count($thiscol, $dataitem . "_$suffix")) {
                           # must be a valid value
                           if ($thisdata[$thiscol] <> '') {
                              $thisval = $thisdata[$thiscol];
                           } else {
                              $thisval = '0.0';
                           }
                           if ($this->debug) {
                              $this->logDebug("Found $dataitem" . "_$suffix" . " = $thisval <br>");
                           }
                        }
                     }
                  }
               }
               $dataname = $this->code_name[$dataitem];
               #$this->logDebug("<br>$dataitem - $dataname <br>");
               #$this->logDebug($this->code_name);
               # multiply by area factor to adjust for area factor at inlet
               $this->addValue($ts, $dataname, floatval($thisval));
               if ($dataname == 'Qout') {
                  # add a watershed inch conversion if area > 0.0
                  if ($dav > 0) {
                     $this->addValue($ts, 'Qinches', (floatval($thisval) * 0.9917 * 0.0015625 * (1.0/$dav) * 24.0) );
                     // watershed ft/sec
                     $this->addValue($ts, 'Qfps', (floatval($thisval) / ( 640.0 * 43560.0 * $dav)) );
                  }
                  if ($thisval > $this->maxflow) {
                     $this->maxflow = $thisval;
                  }
               }
            }
            $this->addValue($ts, 'timestamp', $uts);
            #$this->addValue($ts, 'thisdate', $thisdate->format('m-d-Y'));
            $this->addValue($ts, 'thisdate', $thisdate->format('Y-m-d'));
            if ($this->debug) {
               $this->logDebug("Added ");
               $this->logDebug($this->tsvalues[$uts]);
               $this->logDebug("<br>");
            }
         }
      }
   }
}


class waterSupplyModelNode extends modelContainer {
   var $flow_mode = 0; // 0 - best available, 1 - USGS baseline, 2 - USGS Synth, 3 - VA HSPF, 4+ are for custom use
   // currently a blank class, but ultimately it might hold some sensible common properties
   
   function init() {
      parent::init();
      $this->setSingleDataColumnType('flow_mode', 'integer', $this->flow_mode);
   }
}


class waterSupplyElement extends modelContainer {
   var $flow_mode = 0; // 0 - best available, 1 - USGS baseline, 2 - USGS Synth, 3 - VA HSPF, 4+ are for custom use
   // currently a blank class, but ultimately it might hold some sensible common properties
}



class wsp_LUBasedProjection extends waterSupplyModelNode {
   // 
   
   
   function create() {
      parent::create();
      $innerHTML = '';
      // should create base sub-components for its class, which are:
      //    Land-Use definition grid (ludef):
      //       Land Use Name  | MGD/unit area
      //    Land-Use time series (luts)
      // these should have read-only names, since the names will not be allowed to change
      // add this component
      $ludef = new dataMatrix;
      $ludef->name = 'ludef';
      $ludef->wake();
      $ludef->numcols = 2;
      $ludef->numrows = 3;
      $ludef->matrix = array(0,0,0,0,0,0);
      $this->addOperator('ludef', $ludef, 0);
      $innerHTML .= "Added operator ludef <br>";
      $luts = new dataMatrix;
      $luts->name = 'luts';
      $luts->wake();
      $luts->numcols = 3;
      $luts->numrows = 3;
      $luts->matrix = array(0,0,0,0,0,0,0,0,0);
      $this->addOperator('luts', $luts, 0);
      $innerHTML .= "Added operator luts <br>";
      $retarr = array();
      $retarr['innerHTML'] = $innerHTML;
      return $retarr;
   }
   
}

class wsp_VWUDSData extends XMLDataConnection {
   // time series for withdrawal data, based on objects geometry
   var $id1 = ''; # USER ID
   var $historic_monthly = array();
   var $historic_annual = array();
   var $projected_monthly = array();
   var $projected_annual = array();
   var $maxuse_monthly = array();
   var $maxuse_annual = array();
   var $usetypes = array();
   var $historic_mgd = 0.0;
   var $current_mgd = 0.0;
   var $feed_address = 'http://deq1.bse.vt.edu/wooommdev/remote/xml_getdata_wateruse.php';
   var $data_inventory_address = 'http://deq1.bse.vt.edu/wooommdev/remote/xml_getdata_wateruse.php';
   var $datecolumn = 'thisdate';
   var $lon_col = 'lon_dd';
   var $lat_col = 'lat_dd';
   var $serialist = 'historic_monthly,historic_annual,projected_monthly,projected_annual,maxuse_monthly,maxuse_annual,usetypes';
   
   function wake() {
      parent::wake();
      $this->prop_desc['historic_mgd'] = 'Historic Demand (mgd).';
      $this->prop_desc['current_mgd'] = 'Current Demand (mgd).';
   }
   
   function init() {
      parent::init();
      
      // parent routines grab all data, now do summary queries to
      //$this->summarizeWithdrawals();
      
      // grab USGS stations
      
   }
   function setState() {
      parent::setState();
      $this->state['current_mgd'] = 0.0;
      $this->state['historic_mgd'] = 0.0;
   }
   
   function setDataColumnTypes() {
      parent::setDataColumnTypes();
      // add these to the data columns for logging
      $statenums = array('current_mgd','historic_mgd');
      foreach ($statenums as $thiscol) {
         $this->dbcolumntypes[$thiscol] = 'float8';
         $this->data_cols[] = $thiscol;
      }
      
   }

   function getPublicProps() {
      # gets only properties that are visible (must be manually defined)
      $publix = parent::getPublicProps();

      array_push($publix, 'current_mgd');
      array_push($publix, 'historic_mgd');

      return $publix;
   }
   
   function step() {
      // all step methods MUST call preStep(),execProcessors(), postStep()
      $this->preStep();
      if ($this->debug) {
         $this->logDebug("$this->name Inputs obtained. thisdate = " . $this->state['thisdate']);
      }
      // execute sub-components
      $this->execProcessors();
      if ($this->debug) {
         $this->logDebug("<b>$this->name Sub-processors executed at hour " . $this->state['hour'] . " on " . $this->state['thisdate'] . " week " . $this->state['week'] . " month " . $this->state['month'] . " year " . $this->state['year'] . ".</b><br>\n");
      }
      
      // parent does data aquisition, now calculate demands
      $thismo = $this->state['month'];
      $thisyr = $this->state['year'];
      // do historic
      $hist_demand_mgd = 0.0;
      if (isset($this->processors['historic_annual'])) {
         $hist_d = $this->processors['historic_annual']->matrix_rowcol;
         if ($this->debug) {
            $this->logDebug("<b>Evaluating Historic Demands @ $thisyr, $thismo: </b> " . print_r($hist_d,1) . " <br>");
         }
         for ($i = 1; $i < count($hist_d); $i++) {
            $wd_type = $hist_d[$i][0];
            $demand_historic_mgd = $this->processors['historic_annual']->evaluateMatrix($wd_type,$thisyr);
            $demand_historic_frac = $this->processors['historic_monthly_pct']->evaluateMatrix($wd_type,$thismo);
            $hist_demand_mgd += ($demand_historic_mgd * $demand_historic_frac);
            if ($this->debug) {
               $this->logDebug("Evaluated $wd_type,$thisyr $wd_type,$thismo = $demand_historic_mgd * $demand_historic_frac <br>");
            }
         }
         if ($this->debug) {
            $this->logDebug("Historic demand set to: $hist_demand_mgd <br>");
         }
      }
      $this->state['historic_mgd'] = $hist_demand_mgd;
      // do current
      $curr_demand_mgd = 0.0;
      if (isset($this->processors['current_annual'])) {
         $curr_d = $this->processors['current_annual']->matrix_rowcol;
         if ($this->debug) {
            $this->logDebug("<b>Evaluating Current Demands @ $thisyr, $thismo:</b>" . print_r($curr_d,1) . " <br>");
         }
         for ($i = 1; $i < count($curr_d); $i++) {
            $wd_type = $hist_d[$i][0];
            $demand_curr_mgd = $this->processors['current_annual']->evaluateMatrix($wd_type,$thisyr);
            $demand_curr_frac = $this->processors['current_monthly']->evaluateMatrix($wd_type,$thismo);
            $curr_demand_mgd += ($demand_curr_mgd * $demand_curr_frac);
            if ($this->debug) {
               $this->logDebug("Evaluated $wd_type,$thisyr $wd_type,$thismo = $demand_curr_mgd * $demand_curr_frac <br>");
            }
         }
         if ($this->debug) {
            $this->logDebug("Current demand set to: $curr_demand_mgd <br>");
         }
      }
      $this->state['current_mgd'] = $curr_demand_mgd;
      $this->postStep();
      
   }
   
   function create() {
      parent::create();
      // set default land use
      // set basic data query
      $this->logDebug("Create() function called <br>");
      // add use types
      $this->getHistoricUse();
      $this->addUseTypeComponent();
      $this->addHistoricUseComponent();
      $this->logDebug("Processors on this object: " . print_r(array_keys($this->processors),1) . " <br>");
   }
   
   function addUseTypeComponent() {
      if (isset($this->processors['usetypes'])) {
         unset($this->processors['usetypes']);
      }
      // landuse subcomponent to allow users to simulate land use values
      $usedef = new dataMatrix;
      $usedef->name = 'usetypes';
      $usedef->wake();
      $usedef->numcols = count($this->usetypes[0]);  
      $usedef->valuetype = 2; // 2 column lookup (col & row)
      $usedef->keycol1 = ''; // key for 1st lookup variable
      $usedef->lutype1 = 0; // lookup type - exact match for land use name
      $usedef->keycol2 = ''; // key for 2nd lookup variable
      $usedef->lutype2 = 0; // lookup type - interpolated for year value
      // add a row for the header line
      $usedef->numrows = count($this->usetypes) + 1;
      // since these are stored as a single dimensioned array, regardless of their lookup type 
      // (for compatibility with single dimensional HTML form variables)
      // we set alternating values representing the 2 columns (luname - acreage)
      foreach (array_keys($this->usetypes[0]) as $thisvar) {
         $usedef->matrix[] = $thisvar;
      }
      // now add the individual records
      foreach ($this->usetypes as $thistype) {
         foreach ($thistype as $thisvar) {
            $usedef->matrix[] = $thisvar;
         }
      }
      $this->logDebug("Trying to add use type sub-component matrix with values: " . print_r($usedef->matrix,1) . " <br>");
      $this->addOperator('usetypes', $usedef, 0);
   }
   
   function addHistoricUseComponent() {
      if (isset($this->processors['historic_monthly'])) {
         unset($this->processors['historic_monthly']);
      }
      // historic percent subcomponent 
      $usedef = new dataMatrix;
      $usedef->name = 'historic_monthly';
      $usedef->description = 'Historic average monthly percent of annual use';
      $usedef->wake();
      $usedef->numcols = count($this->historic_monthly[0]);  
      $usedef->valuetype = 2; // 2 column lookup (col & row)
      $usedef->keycol1 = ''; // key for 1st lookup variable
      $usedef->lutype1 = 0; // lookp type - exact match for land use name
      $usedef->keycol2 = ''; // key for 2nd lookup variable
      $usedef->lutype2 = 0; // lookup type - interpolated for year value
      // add a row for the header line
      $usedef->numrows = count($this->historic_monthly) + 1;
      // since these are stored as a single dimensioned array, regardless of their lookup type 
      // (for compatibility with single dimensional HTML form variables)
      // we set alternating values representing the 2 columns (luname - acreage)
      foreach (array_keys($this->historic_monthly[0]) as $thisvar) {
         $usedef->matrix[] = $thisvar;
      }
      // now add the individual records
      foreach ($this->historic_monthly as $thistype) {
         foreach ($thistype as $thisvar) {
            $usedef->matrix[] = $thisvar;
         }
      }
      $this->logDebug("Trying to add use type sub-component matrix with values: " . print_r($usedef->matrix,1) . " <br>");
      $this->addOperator('historic_monthly', $usedef, 0);
      
      
      // historic Total use subcomponent 
      $usedef = new dataMatrix;
      $usedef->name = 'historic_annual';
      $usedef->description = 'Historic annual use in MG per year';
      $usedef->wake();
      $usedef->numcols = count($this->historic_annual[0]);  
      $usedef->valuetype = 2; // 2 column lookup (col & row)
      $usedef->keycol1 = ''; // key for 1st lookup variable
      $usedef->lutype1 = 1; // lookp type - stair step
      // add a row for the header line
      $usedef->numrows = count($this->historic_annual) + 1;
      // since these are stored as a single dimensioned array, regardless of their lookup type 
      // (for compatibility with single dimensional HTML form variables)
      // we set alternating values representing the 2 columns (luname - acreage)
      foreach (array_keys($this->historic_annual[0]) as $thisvar) {
         $usedef->matrix[] = $thisvar;
      }
      // now add the individual records
      foreach ($this->historic_annual as $thistype) {
         foreach ($thistype as $thisvar) {
            $usedef->matrix[] = $thisvar;
         }
      }
      $this->logDebug("Trying to add use type sub-component matrix with values: " . print_r($usedef->matrix,1) . " <br>");
      $this->addOperator('historic_annual', $usedef, 0);
   }
   
   
   function getTablesColumns() {
      parent::getTablesColumns();
   }
   
   function getHistoricUse() {
      $this->historic_monthly = array();
      $this->historic_annual = array();
      $this->projected_monthly = array();
      $this->projected_annual = array();
      $this->maxuse_monthly = array();
      $this->maxuse_annual = array();
      $this->usetypes = array();
      if (function_exists('fetch_rss')) {
         // this rss feed should return a single record with descriptive information
         if ($this->debug) {
            $this->logDebug("Starting Data Inventory Address: $this->data_inventory_address <br>\n");
         }
         if (strlen(rtrim(ltrim($this->final_data_inventory_address))) > 0) {
            // actiontype=2 - get the use types and consumptive factors
            $usetype_var = "actiontype=2";
            $iurl = $this->appendExtrasToURL($this->final_data_inventory_address, $usetype_var);
            $rss = fetch_rss($iurl);
            #print_r($rss->items);
            $this->usetypes = $rss->items;
            
            // actiontype=3 - get the historical use monthly patterns
            $hist_var = "actiontype=3";
            if (strlen($this->id1) > 0) {
               $hist_var .= '&id1=' . $this->id1;
            } else {
               // we don't do the geom query if the userid is set
               if (strlen($this->the_geom) > 0) {
                  $hist_var .= '&the_geom=' . urlencode($this->the_geom);
               }
            }
            $hurl = $this->appendExtrasToURL($this->final_data_inventory_address, $hist_var);
            if ($this->debug) {
               $this->logDebug("Historic Monthly URL add-ons: $iurl <br>\n");
            }
            define('MAGPIE_CACHE_ON', TRUE);
            //$mrss = fetch_rss($iurl);
            $mrss = simplexml_load_file($hurl);
            $linklist = $mrss->channel->item;
            $ignore_fields = array('title', 'link', 'description');
            $rename_fields = array('jan'=>1,'feb'=>2,'mar'=>3,'apr'=>4,'may'=>5,'jun'=>6,'jul'=>7,'aug'=>8,'sep'=>9,'oct'=>10,'nov'=>11,'dec'=>12);
            $historic_monthly = $this->arrayRenameOmit($linklist, $ignore_fields, $rename_fields);
            // now, calculate the monthly percentages from this
            foreach ($historic_monthly as $thismo) {
               $total = $thismo[1] + $thismo[2] + $thismo[3] + $thismo[4] + $thismo[5] + $thismo[6] + $thismo[7] + $thismo[8] + $thismo[9] + $thismo[10] + $thismo[11] + $thismo[12];
               if ($total == 0) {
                  for ($i = 1; $i <= 12; $i++) {
                     $thismo[$i] = 0.0833;
                  }
               } else {
                  for ($i = 1; $i <= 12; $i++) {
                     $thismo[$i] = number_format($thismo[$i] / $total,4);
                  }
               }
               $this->historic_monthly[] = $thismo;
            }
               
            if ($this->debug) {
               $this->logDebug("Historic Monthly records: " . print_r($this->historic_monthly,1) . " <br>\n");
            }
            if ($this->debug) {
               $hcount = count($this->historic_monthly);
               $this->logDebug("Added $hcount Historic Monthly records <br>\n");
            }
            
            // actiontype=4 - get the historical use annual values
            $hist_var = "actiontype=4";
            if (strlen($this->id1) > 0) {
               $hist_var .= '&id1=' . $this->id1;
            } else {
               // we don't do the geom query if the userid is set
               if (strlen($this->the_geom) > 0) {
                  $hist_var .= '&the_geom=' . urlencode($this->the_geom);
               }
            }
            $yurl = $this->appendExtrasToURL($this->final_data_inventory_address, $hist_var);
            if ($this->debug) {
               $this->logDebug("Historic Annual URL add-ons: $yurl <br>\n");
            }
            define('MAGPIE_CACHE_ON', TRUE);
            $mrss = simplexml_load_file($yurl);
            $linklist = $mrss->channel->item;
            $ignore_fields = array('title', 'link', 'description');
            $rename_fields = array();
            $firstrec = (array)$linklist[0];
            foreach (array_keys($firstrec) as $thiscol) {
               if ($this->debug) {
                  $this->logDebug("Checking Column Name: $thiscol<br>\n");
               }
               $pos = strpos($thiscol, 'thisyear');
               if (!($pos === false)) {
                  $rename_fields[$thiscol] = str_replace('thisyear','',$thiscol);
               }
            }
            if ($this->debug) {
               $this->logDebug("Replacing Year Names: " . print_r($rename_fields,1) . " <br>\n");
            }
            $this->historic_annual = $this->arrayRenameOmit($linklist, $ignore_fields, $rename_fields);
         }
      } else {
         $this->logError("Error Retrieving Column Names: RSS Magpie function 'fetch_rss' is not defined - can not retrieve feed.");
      }
   }
   
   function summarizeWithdrawals() {
      // This is no longer valid since this is now an XML connection and the tables and dbconn's are not set up
      
      /*
      // parent routines grab all data, now do summary queries to
      // the following summaries should be generated by the XML object:
      // historic annual totals, by year and use_type (row - type, column - year)
      $this->dbobj->querystring = "  select a.cat_mp, sum(a.max_annual) as max_annual, ";
      $this->dbobj->querystring .= "    sum(a.max_annual/365.0) as max_mgd ";
      $this->dbobj->querystring .= " FROM $dbt as a, vwuds_max_withdrawal as b ";
      $this->dbobj->querystring .= " where a.mpid = b.mpid ";
      // currently, the vwuds_max withdrawal table holds only that, withdrawals, but at some point
      // it, or a table that would be more properly known as vwuds_max_annual would contain 
      // the data pertaining to transfers and the like
      $this->dbobj->querystring .= " group by a.cat_mp ";
      if ($this->debug) {
         $this->logDebug("$this->dbobj->querystring ; <br>");
      }
      $this->dbobj->performQuery();
      // historica monthly mean percent of annual by use_type (row - type, column - month)
      // update other components, such as the summary data, and the category multipliers
      $dbt = $this->dbtable;
      $this->dbobj->querystring = "  select a.cat_mp, sum(a.max_annual) as max_annual, ";
      $this->dbobj->querystring .= "    sum(a.max_annual/365.0) as max_mgd ";
      $this->dbobj->querystring .= " FROM $dbt as a, vwuds_max_withdrawal as b ";
      $this->dbobj->querystring .= " where a.mpid = b.mpid ";
      // currently, the vwuds_max withdrawal table holds only that, withdrawals, but at some point
      // it, or a table that would be more properly known as vwuds_max_annual would contain 
      // the data pertaining to transfers and the like
      $this->dbobj->querystring .= " group by a.cat_mp ";
      if ($this->debug) {
         $this->logDebug("$this->dbobj->querystring ; <br>");
      }
      $this->dbobj->performQuery();
      
      */
   }
   
}

class wsp_waterUser extends modelObject {/*
    typeid |      typename       | typeabbrev | consumption | max_day_mos
   --------+---------------------+------------+-------------+-------------
         4 | Hydro Power         | PH         |           0 |           1
         8 | Mining              | MIN        |           0 |           1
        13 | Other               | OTH        |           0 |           1
         5 | Public Water Supply | PWS        |         0.5 |        1.25
        12 | Irrigation          | IRR        |           1 |           1
         9 | Agriculture         | AGR        |        0.75 |           1
         6 | Fossil Power        | PF         |         0.9 |           1
        10 | Nuclear Power       | PN         |         0.9 |           1
        11 | Manufacturing       | MAN        |        0.25 |           1
         7 | Commerical          | COM        |        0.25 |           1
*/
   // time series for withdrawal data, based on MPID and USERID - one object per withdrawal
   var $waterusetype = ''; // VWUDS abbreviation: PWS, COM, PN, etc.
   var $wdtype = ''; // VWUDS abbreviation: GW, SW, TW
   var $annual_mg = 0.0; // may be subclassed as an array with annually varying uses or some other formula
   var $maxuse_monthly = array(); // multipliers to put against mean daily 
   var $maxuse_annual = 0.0;
   var $consumption_pct = array(); // monthly factors for computing consumption
   var $wd_info = array(); // information about this withdrawal
   var $historic_mgd = 0.0;
   var $current_mgd = 0.0;
   var $discharge_enabled = 0; // discharge is disabled unless we have explicitly set it
   var $serialist = 'wd_info,maxuse_monthly,maxuse_annual,consumption_pct';
   
   function wake() {
      parent::wake();
      $this->prop_desc['annual_mg'] = 'Historic Demand (mgd).';
      $this->prop_desc['current_mgd'] = 'Current Demand (mgd).';
      $this->prop_desc['flowby'] = 'Flow rate below which withdrawal is halted - depends on Qriver (cfs).';
   }
   
   function init() {
      parent::init();
      
      // parent routines grab all data, now do summary queries to
      //$this->summarizeWithdrawals();
      
      // grab USGS stations
      
   }
   function setState() {
      parent::setState();
      $this->state['current_mgd'] = 0.0;
      $this->state['historic_mgd'] = 0.0;
      $this->state['flowby'] = NULL;
   }
   
   function setDataColumnTypes() {
      parent::setDataColumnTypes();
      // add these to the data columns for logging
      $statenums = array('current_mgd','historic_mgd', 'flowby');
      foreach ($statenums as $thiscol) {
         $this->dbcolumntypes[$thiscol] = 'float8';
         $this->data_cols[] = $thiscol;
      }
      
   }

   function getPublicProps() {
      # gets only properties that are visible (must be manually defined)
      $publix = parent::getPublicProps();

      array_push($publix, 'current_mgd');
      array_push($publix, 'historic_mgd');
      array_push($publix, 'wd_mgd');
      array_push($publix, 'flowby');

      return $publix;
   }

   
   function step() {
      // all step methods MUST call preStep(),execProcessors(), postStep()
      $this->preStep();
      if ($this->debug) {
         $this->logDebug("$this->name Inputs obtained. thisdate = " . $this->state['thisdate']);
      }
      // execute sub-components
      $this->execProcessors();
      if ($this->debug) {
         $this->logDebug("<b>$this->name Sub-processors executed at hour " . $this->state['hour'] . " on " . $this->state['thisdate'] . " week " . $this->state['week'] . " month " . $this->state['month'] . " year " . $this->state['year'] . ".</b><br>\n");
      }
      
      
      // estimated demands are calculated here in case we do not have a time series data
      // parent does data aquisition, now calculate demands
      $thismo = $this->state['month'];
      $thisyr = $this->state['year'];
      $modays = $this->timer->modays;
      if ($modays == 0) {
         $modays = 30;
      }
      $wd_mgd = $this->state['wd_mgd'];
      $historic_mgd = $this->state['historic_mgd'];
      
      if ( ($this->state['flowby'] <> NULL) and ($this->state['Qriver'] <> NULL) ) {
         // if we have these variables, then we have the capabilty of overriding the 
         // withdrawal values
         if ( $this->state['flowby'] > $this->state['Qriver'] ) {
            $this->state['safe_yield'] = 0.0;
            $this->state['current_mgd'] = 0.0;
         }
      }
      
      // calculate the estimated discharge, unless we have over-ridden with a sub-component
      if ( (!isset($this->processors['discharge_calc'])) and ($this->discharge_enabled) ) {
         $consumption = $this->state['consumption'];
         $discharge_calc = $wd_mgd * (1.0 - $consumption);
      } else {
         if ($this->discharge_enabled) {
            $discharge_calc = $this->state['discharge_calc'];
         } else {
            $discharge_calc = 0.0;
         }
      }
      if (!is_float($discharge_calc)) {
         $discharge_calc = 0.0;
      }
      $this->state['discharge_calc'] = $discharge_calc;
      
      // calculate the estimated discharge, unless we have over-ridden with a sub-component
      if (!isset($this->processors['surface_mgd'])) {
         if ($this->wdtype == 'SW') {
            $surface_mgd = $wd_mgd;
         } else {
            $surface_mgd = 0.0; // GW and TW do not have a local withdrawal
         }
         $this->state['surface_mgd'] = $surface_mgd;
      }
      
      $this->postStep();
      
   }
   
   function create() {
      parent::create();
      // set default land use
      // set basic data query
      $this->logDebug("Create() function called <br>");
      // add use types
      $this->getHistoricUse();
      $this->addHistoricUseMatrices();
      $this->logDebug("Processors on this object: " . print_r(array_keys($this->processors),1) . " <br>");
   }

   function addHistoricUseMatrices() {
   // these matrices hold a copy of the historic monthly percent of annual (mean), and the historic annual
   // these are data pieces that can be used in place of the monthly time series on this object 
   // or as a part of the current or projected estimates
      if (isset($this->processors['historic_monthly_pct'])) {
         unset($this->processors['historic_monthly_pct']);
      }
      // historic percent subcomponent 
      $usedef = new dataMatrix;
      $usedef->name = 'historic_monthly_pct';
      $usedef->description = 'Historic average monthly percent of annual use';
      $usedef->wake();
      $usedef->numcols = 2;  
      $usedef->valuetype = 1; // 2 column lookup (col & row)
      $usedef->keycol1 = 'month'; // key for 1st lookup variable
      $usedef->lutype1 = 0; // lookp type - exact match for land use name
      $usedef->keycol2 = ''; // key for 2nd lookup variable
      $usedef->lutype2 = 0; // lookup type - interpolated for year value
      // add a row for the header line
      $usedef->numrows = 13;
      foreach (array('month_num','pct_of_annual') as $header) {
         $usedef->matrix[] = $header;
      }
      // now add the individual records
      $mos = array('jan'=>1,'feb'=>2,'mar'=>3,'apr'=>4,'may'=>5,'jun'=>6,'jul'=>7,'aug'=>8,'sep'=>9, 'oct'=>10,'nov'=>11,'dec'=>12);
      foreach ($mos as $thismo=>$thisno) {
         $usedef->matrix[] = $thisno;// map the text mo to a numerical description
         $usedef->matrix[] = $this->historic_monthly_pct[0][$thismo];
      }
      $this->logDebug("Trying to add Monthly Use fraction sub-component matrix with values: " . print_r($usedef->matrix,1) . " from " . print_r($this->historic_monthly_pct,1) . " <br>");
      $this->addOperator('historic_monthly_pct', $usedef, 0);
      
      
      // historic Total use subcomponent 
      $usedef = new dataMatrix;
      $usedef->name = 'historic_annual';
      $usedef->description = 'Historic annual use in MG per year';
      $usedef->wake();
      $usedef->numcols = count($this->historic_annual[0]);  
      $usedef->valuetype = 1; // 2 column lookup (col & row)
      $usedef->keycol1 = 'year'; // key for 1st lookup variable
      $usedef->lutype1 = 1; // lookup type - interpolated
      // add a row for the header line
      $usedef->numrows = count($this->historic_annual) + 1;
      // since these are stored as a single dimensioned array, regardless of their lookup type 
      // (for compatibility with single dimensional HTML form variables)
      // we set alternating values representing the 2 columns (luname - acreage)
      foreach (array_keys($this->historic_annual[0]) as $thisvar) {
         $usedef->matrix[] = $thisvar;
      }
      // now add the individual records
      foreach ($this->historic_annual as $thistype) {
         foreach ($thistype as $thisvar) {
            $usedef->matrix[] = $thisvar;
         }
      }
      $this->logDebug("Trying to add use type sub-component matrix with values: " . print_r($usedef->matrix,1) . " <br>");
      $this->addOperator('historic_annual', $usedef, 0);
      
      
      // consumptive use factors by month
      if (isset($this->processors['consumption'])) {
         unset($this->processors['consumption']);
      }
      $usedef = new dataMatrix;
      $usedef->name = 'consumption';
      $usedef->description = 'Monthly consumptive use factors (return flow % is [1-consumption] )';
      $usedef->wake();
      $usedef->numcols = 2;  
      $usedef->valuetype = 1; // 1 column lookup (col & row)
      $usedef->keycol1 = 'month'; // key for 1st lookup variable
      $usedef->lutype1 = 0; // lookp type - exact match for land use name
      $usedef->keycol2 = ''; // key for 2nd lookup variable
      $usedef->lutype2 = 0; // lookup type - interpolated for year value
      // add a row for the header line
      $usedef->numrows = 13;
      foreach (array('month_num','pct_consumptive') as $header) {
         $usedef->matrix[] = $header;
      }
      // now add the individual records
      $mos = array('c_jan'=>1,'c_feb'=>2,'c_mar'=>3,'c_apr'=>4,'c_may'=>5,'c_jun'=>6,'c_jul'=>7,'c_aug'=>8,'c_sep'=>9, 'c_oct'=>10,'c_nov'=>11,'c_dec'=>12);
      foreach ($mos as $thismo=>$thisno) {
         $usedef->matrix[] = $thisno;// map the text mo to a numerical description
         $usedef->matrix[] = $this->consumption_pct[$thismo];
      }
      $this->logDebug("Trying to add Monthly consumtive fraction sub-component matrix with values: " . print_r($usedef->matrix,1) . " from " . print_r($this->consumption_pct,1) . " <br>");
      $this->addOperator('consumption', $usedef, 0);
      
   }
   
   
   function getTablesColumns() {
      parent::getTablesColumns();
   }
   
   function getWDInfo() {
      $this->wd_info = array();
      if ($this->debug) {
         $this->logDebug("Withdrawal Info: " . print_r($this->wd_info,1));
      }
      return $this->wd_info;
      
   }
   
   function getConsumptionFractions($thistype = 'OTH') {
      $this->consumption_pct = array();
      if ($this->debug) {
         $this->logDebug("Consumption Info: " . print_r($this->consumption_pct,1));
      }
      return $this->consumption_pct;
      
   }
   
   function getTransfers() {
      //get any transfers associated with this MP
   }
   
   function getHistoricUse() {
      $this->historic_monthly_pct = array();
      $this->historic_annual = array();
      $this->projected_monthly = array();
      $this->projected_annual = array();
      $this->maxuse_monthly = array();
      $this->maxuse_annual = array();
      $this->usetypes = array();
      $this->getWDInfo();
      
      if (!isset($this->wd_info['CAT_MP'])) {
         $thistype = 'OTH';
      } else {
         $thistype = $this->wd_info['CAT_MP'];
      }
      
      $this->getConsumptionFractions($thistype);
      
   }
   
   function summarizeWithdrawals() {
   }
   
}


class wsp_waterUserOld extends dataConnectionObject {/*
    typeid |      typename       | typeabbrev | consumption | max_day_mos
   --------+---------------------+------------+-------------+-------------
         4 | Hydro Power         | PH         |           0 |           1
         8 | Mining              | MIN        |           0 |           1
        13 | Other               | OTH        |           0 |           1
         5 | Public Water Supply | PWS        |         0.5 |        1.25
        12 | Irrigation          | IRR        |           1 |           1
         9 | Agriculture         | AGR        |        0.75 |           1
         6 | Fossil Power        | PF         |         0.9 |           1
        10 | Nuclear Power       | PN         |         0.9 |           1
        11 | Manufacturing       | MAN        |        0.25 |           1
         7 | Commerical          | COM        |        0.25 |           1
*/
   // time series for withdrawal data, based on MPID and USERID - one object per withdrawal
   var $id1 = ''; # USER ID
   var $id2 = ''; # MP ID
   var $historic_monthly_pct = array();
   var $historic_annual = array();
   var $projected_monthly = array();
   var $projected_annual = array();
   var $maxuse_monthly = array();
   var $maxuse_annual = array();
   var $usetypes = array();
   var $consumption_pct = array();
   var $wd_info = array();
   var $historic_mgd = 0.0;
   var $current_mgd = 0.0;
   // vwuds data connection information
   var $max_memory_values = 1000;
   var $username = 'wsp_ro';
   var $password = '314159';
   var $dbname = 'vwuds';
   var $host = '128.173.217.23';
   var $intmethod = 1; // use previous value method or monthly observed withdrawals
   // vpdes database connection info
   var $vpdes_username = 'vpdes_ro';
   var $vpdes_password = 'vpd3sROpw';
   var $vpdes_dbname = 'vpdes';
   var $vpdes_host = '128.173.217.23';
   var $vpdes_db = -1;
   // end data connection information
   // VPDES permit information
   var $vpdes_permitno = '';
   var $vpdes_outfallno = ''; // if none specified then we retrieve all of them
   var $datecolumn = 'thisdate';
   var $lon_col = 'lon_dd';
   var $lat_col = 'lat_dd';
   var $serialist = 'wd_info,historic_monthly_pct,historic_annual,projected_monthly,projected_annual,maxuse_monthly,maxuse_annual,usetypes,consumption';
   
   function wake() {
      parent::wake();
      $this->prop_desc['historic_mgd'] = 'Historic Demand (mgd).';
      $this->prop_desc['current_mgd'] = 'Current Demand (mgd).';
   }
   
   function init() {
      parent::init();
      
      // parent routines grab all data, now do summary queries to
      //$this->summarizeWithdrawals();
      
      // grab USGS stations
      
   }
   function setState() {
      parent::setState();
      $this->state['current_mgd'] = 0.0;
      $this->state['historic_mgd'] = 0.0;
   }
   
   function setDataColumnTypes() {
      parent::setDataColumnTypes();
      // add these to the data columns for logging
      $statenums = array('current_mgd','historic_mgd');
      foreach ($statenums as $thiscol) {
         $this->dbcolumntypes[$thiscol] = 'float8';
         $this->data_cols[] = $thiscol;
      }
      
   }

   function getPublicProps() {
      # gets only properties that are visible (must be manually defined)
      $publix = parent::getPublicProps();

      array_push($publix, 'current_mgd');
      array_push($publix, 'historic_mgd');

      return $publix;
   }
   
   function chooseLocalColumns() {
      // this is kind of a legacy, when we didn't want to allow access to all columns,
      // this will stay here for the base object, for the time being, but will be sub-classed 
      // by all children, under the assumption that if a column is brought in by some query, 
      // then it must be desired to be used.  If not, there would be no reason to query it 
      // in the first place
      // this version returns all columns
      $public_cols = '*';
      $group_cols = '';
      $this->logDebug("Columns for local query: $public_cols, $group_cols <br>\n");
      // we also set our remote query here, which IS needed
      $this->createQuery();
      return array($public_cols, $group_cols);
   }
   
   function step() {
      // all step methods MUST call preStep(),execProcessors(), postStep()
      $this->preStep();
      if ($this->debug) {
         $this->logDebug("$this->name Inputs obtained. thisdate = " . $this->state['thisdate']);
      }
      // execute sub-components
      $this->execProcessors();
      if ($this->debug) {
         $this->logDebug("<b>$this->name Sub-processors executed at hour " . $this->state['hour'] . " on " . $this->state['thisdate'] . " week " . $this->state['week'] . " month " . $this->state['month'] . " year " . $this->state['year'] . ".</b><br>\n");
      }
      
      // demands from time series
      
      // parent does data aquisition, now calculate demands
      $thismo = $this->state['month'];
      $thisyr = $this->state['year'];
      $modays = $this->timer->modays;
      if ($modays == 0) {
         $modays = 30;
      }
      // do current
      $curr_demand_mgd = 0.0;
      if (isset($this->processors['current_annual'])) {
         $curr_d = $this->processors['current_annual']->matrix_rowcol;
         if ($this->debug) {
            $this->logDebug("<b>Evaluating Current Demands @ $thisyr, $thismo:</b>" . print_r($curr_d,1) . " <br>");
         }
         for ($i = 1; $i < count($curr_d); $i++) {
            $wd_type = $hist_d[$i][0];
            $demand_curr_mgd = $this->processors['current_annual']->evaluateMatrix($wd_type,$thisyr);
            $demand_curr_frac = $this->processors['current_monthly']->evaluateMatrix($wd_type,$thismo);
            // shouldn't we divide this by number of days in the month??
            $curr_demand_mgd += ($demand_curr_mgd * $demand_curr_frac) / $modays;
            if ($this->debug) {
               $this->logDebug("Evaluated $wd_type,$thisyr $wd_type,$thismo = $demand_curr_mgd * $demand_curr_frac <br>");
            }
         }
         if ($this->debug) {
            $this->logDebug("Current demand set to: $curr_demand_mgd <br>");
         }
      }
      $this->state['current_mgd'] = $curr_demand_mgd;
      $this->postStep();
      
   }
   
   function create() {
      parent::create();
      // set default land use
      // set basic data query
      $this->logDebug("Create() function called <br>");
      // add use types
      $this->getHistoricUse();
      $this->addHistoricUseMatrices();
      $this->logDebug("Processors on this object: " . print_r(array_keys($this->processors),1) . " <br>");
   }

   function addHistoricUseMatrices() {
   // these matrices hold a copy of the historic monthly percent of annual (mean), and the historic annual
   // these are data pieces that can be used in place of the monthly time series on this object 
   // or as a part of the current or projected estimates
      if (isset($this->processors['historic_monthly_pct'])) {
         unset($this->processors['historic_monthly_pct']);
      }
      // historic percent subcomponent 
      $usedef = new dataMatrix;
      $usedef->name = 'historic_monthly_pct';
      $usedef->description = 'Historic average monthly percent of annual use';
      $usedef->wake();
      $usedef->numcols = 2;  
      $usedef->valuetype = 1; // 2 column lookup (col & row)
      $usedef->keycol1 = 'month'; // key for 1st lookup variable
      $usedef->lutype1 = 0; // lookp type - exact match for land use name
      $usedef->keycol2 = ''; // key for 2nd lookup variable
      $usedef->lutype2 = 0; // lookup type - interpolated for year value
      // add a row for the header line
      $usedef->numrows = 13;
      foreach (array('month_num','pct_of_annual') as $header) {
         $usedef->matrix[] = $header;
      }
      // now add the individual records
      $mos = array('jan'=>1,'feb'=>2,'mar'=>3,'apr'=>4,'may'=>5,'jun'=>6,'jul'=>7,'aug'=>8,'sep'=>9, 'oct'=>10,'nov'=>11,'dec'=>12);
      foreach ($mos as $thismo=>$thisno) {
         $usedef->matrix[] = $thisno;// map the text mo to a numerical description
         $usedef->matrix[] = $this->historic_monthly_pct[0][$thismo];
      }
      $this->logDebug("Trying to add Monthly Use fraction sub-component matrix with values: " . print_r($usedef->matrix,1) . " from " . print_r($this->historic_monthly_pct,1) . " <br>");
      $this->addOperator('historic_monthly_pct', $usedef, 0);
      
      
      // historic Total use subcomponent 
      $usedef = new dataMatrix;
      $usedef->name = 'historic_annual';
      $usedef->description = 'Historic annual use in MG per year';
      $usedef->wake();
      $usedef->numcols = count($this->historic_annual[0]);  
      $usedef->valuetype = 1; // 2 column lookup (col & row)
      $usedef->keycol1 = 'year'; // key for 1st lookup variable
      $usedef->lutype1 = 1; // lookup type - interpolated
      // add a row for the header line
      $usedef->numrows = count($this->historic_annual) + 1;
      // since these are stored as a single dimensioned array, regardless of their lookup type 
      // (for compatibility with single dimensional HTML form variables)
      // we set alternating values representing the 2 columns (luname - acreage)
      foreach (array_keys($this->historic_annual[0]) as $thisvar) {
         $usedef->matrix[] = $thisvar;
      }
      // now add the individual records
      foreach ($this->historic_annual as $thistype) {
         foreach ($thistype as $thisvar) {
            $usedef->matrix[] = $thisvar;
         }
      }
      $this->logDebug("Trying to add use type sub-component matrix with values: " . print_r($usedef->matrix,1) . " <br>");
      $this->addOperator('historic_annual', $usedef, 0);
      
      
      // consumptive use factors by month
      if (isset($this->processors['consumption'])) {
         unset($this->processors['consumption']);
      }
      $usedef = new dataMatrix;
      $usedef->name = 'consumption';
      $usedef->description = 'Monthly consumptive use factors (return flow % is [1-consumption] )';
      $usedef->wake();
      $usedef->numcols = 2;  
      $usedef->valuetype = 1; // 1 column lookup (col & row)
      $usedef->keycol1 = 'month'; // key for 1st lookup variable
      $usedef->lutype1 = 0; // lookp type - exact match for land use name
      $usedef->keycol2 = ''; // key for 2nd lookup variable
      $usedef->lutype2 = 0; // lookup type - interpolated for year value
      // add a row for the header line
      $usedef->numrows = 13;
      foreach (array('month_num','pct_consumptive') as $header) {
         $usedef->matrix[] = $header;
      }
      // now add the individual records
      $mos = array('c_jan'=>1,'c_feb'=>2,'c_mar'=>3,'c_apr'=>4,'c_may'=>5,'c_jun'=>6,'c_jul'=>7,'c_aug'=>8,'c_sep'=>9, 'c_oct'=>10,'c_nov'=>11,'c_dec'=>12);
      foreach ($mos as $thismo=>$thisno) {
         $usedef->matrix[] = $thisno;// map the text mo to a numerical description
         $usedef->matrix[] = $this->consumption_pct[$thismo];
      }
      $this->logDebug("Trying to add Monthly consumtive fraction sub-component matrix with values: " . print_r($usedef->matrix,1) . " from " . print_r($this->consumption_pct,1) . " <br>");
      $this->addOperator('consumption', $usedef, 0);
      
   }
   
   
   function getTablesColumns() {
      parent::getTablesColumns();
   }
   
   function getWDInfo() {
      $this->wd_info = array();
      $this->dbobject->querystring = "  select * from vwuds_mp_detail ";
      $this->dbobject->querystring .= " where \"MPID\" = '$this->id2' ";
      $this->dbobject->querystring .= "    and \"USERID\" = '$this->id1' ";
      $this->dbobject->querystring .= "    and \"ACTION\" = '$this->action' ";
      $this->dbobject->performQuery();
      if ($this->debug) {
         $this->logDebug($this->dbobject->querystring);
      }
      $this->wd_info = $this->dbobject->queryrecords[0];
      if ($this->debug) {
         $this->logDebug("Withdrawal Info: " . print_r($this->wd_info,1));
      }
      
   }
   
   function getConsumptionFractions($thistype = 'OTH') {
      $this->consumption_pct = array();
      $this->dbobject->querystring = "  select * from waterusetype ";
      $this->dbobject->querystring .= " where typeabbrev = '$thistype' ";
      $this->dbobject->performQuery();
      if ($this->debug) {
         $this->logDebug($this->dbobject->querystring);
      }
      $this->consumption_pct = $this->dbobject->queryrecords[0];
      if ($this->debug) {
         $this->logDebug("Consumption Info: " . print_r($this->consumption_pct,1));
      }
      
   }
   
   function getTransfers() {
      //get any transfers associated with this MP
   }
   
   function getHistoricUse() {
      $this->historic_monthly_pct = array();
      $this->historic_annual = array();
      $this->projected_monthly = array();
      $this->projected_annual = array();
      $this->maxuse_monthly = array();
      $this->maxuse_annual = array();
      $this->usetypes = array();
      $this->getWDInfo();
      
      $annual_query = "  select \"YEAR\" as thisyear, ";
      $annual_query .= "    CASE ";
      $annual_query .= "       WHEN \"ANNUAL\" is null THEN 0.0 ";
      $annual_query .= "       ELSE round((\"ANNUAL/365\"*365.0)::numeric,5) ";
      $annual_query .= "    END as total_mg ";
      $annual_query .= " FROM vwuds_annual_mp_data ";
      // by putting this outside of the "ON" clause, we override the left join, only returning these specific uses
      $annual_query .= " WHERE \"USERID\" = '$this->id1' ";
      $annual_query .= " AND \"MPID\" = '$this->id2' ";
      $annual_query .= " ORDER BY \"YEAR\"";
      $this->dbobject->querystring = $annual_query;
      //error_log($this->dbobject->querystring);
      $this->dbobject->performQuery();
      $this->historic_annual = $this->dbobject->queryrecords;
      
      if (!isset($this->wd_info['CAT_MP'])) {
         $thistype = 'OTH';
      } else {
         $thistype = $this->wd_info['CAT_MP'];
      }
      
      $this->dbobject->querystring = "  select ";
      $this->dbobject->querystring .= "    round(avg(jan)::numeric,4) as jan, round(avg(feb)::numeric,4) as feb, ";
      $this->dbobject->querystring .= "    round(avg(mar)::numeric,4) as mar, round(avg(apr)::numeric,4) as apr, ";
      $this->dbobject->querystring .= "    round(avg(may)::numeric,4) as may, round(avg(jun)::numeric,4) as jun, ";
      $this->dbobject->querystring .= "    round(avg(jul)::numeric,4) as jul, round(avg(aug)::numeric,4) as aug, ";
      $this->dbobject->querystring .= "    round(avg(sep)::numeric,4) as sep, round(avg(oct)::numeric,4) as oct, ";
      $this->dbobject->querystring .= "    round(avg(nov)::numeric,4) as nov, round(avg(dec)::numeric,4) as dec ";
      $this->dbobject->querystring .= " from ( ";
      $this->dbobject->querystring .= "    select a.typeabbrev, ";
      $this->dbobject->querystring .= "    CASE ";
      $this->dbobject->querystring .= "       WHEN (b.\"ANNUAL\" is null) or (b.\"ANNUAL\" = 0) THEN 0.0 ";
      $this->dbobject->querystring .= "       ELSE round( (b.\"JANUARY\" / b.\"ANNUAL\")::numeric, 4) ";
      $this->dbobject->querystring .= "    END as jan, ";
      $this->dbobject->querystring .= "    CASE ";
      $this->dbobject->querystring .= "       WHEN (b.\"ANNUAL\" is null) or (b.\"ANNUAL\" = 0) THEN 0.0 ";
      $this->dbobject->querystring .= "       ELSE round( (b.\"FEBRUARY\" / b.\"ANNUAL\")::numeric, 4) ";
      $this->dbobject->querystring .= "    END as feb, ";
      $this->dbobject->querystring .= "    CASE ";
      $this->dbobject->querystring .= "       WHEN (b.\"ANNUAL\" is null) or (b.\"ANNUAL\" = 0) THEN 0.0 ";
      $this->dbobject->querystring .= "       ELSE round( (b.\"MARCH\" / b.\"ANNUAL\")::numeric, 4) ";
      $this->dbobject->querystring .= "    END as mar, ";
      $this->dbobject->querystring .= "    CASE ";
      $this->dbobject->querystring .= "       WHEN (b.\"ANNUAL\" is null) or (b.\"ANNUAL\" = 0) THEN 0.0 ";
      $this->dbobject->querystring .= "       ELSE round( (b.\"APRIL\" / b.\"ANNUAL\")::numeric, 4) ";
      $this->dbobject->querystring .= "    END as apr, ";
      $this->dbobject->querystring .= "    CASE ";
      $this->dbobject->querystring .= "       WHEN (b.\"ANNUAL\" is null) or (b.\"ANNUAL\" = 0) THEN 0.0 ";
      $this->dbobject->querystring .= "       ELSE round( (b.\"MAY\" / b.\"ANNUAL\")::numeric, 4) ";
      $this->dbobject->querystring .= "    END as may, ";
      $this->dbobject->querystring .= "    CASE ";
      $this->dbobject->querystring .= "       WHEN (b.\"ANNUAL\" is null) or (b.\"ANNUAL\" = 0) THEN 0.0 ";
      $this->dbobject->querystring .= "       ELSE round( (b.\"JUNE\" / b.\"ANNUAL\")::numeric, 4) ";
      $this->dbobject->querystring .= "    END as jun, ";
      $this->dbobject->querystring .= "    CASE ";
      $this->dbobject->querystring .= "       WHEN (b.\"ANNUAL\" is null) or (b.\"ANNUAL\" = 0) THEN 0.0 ";
      $this->dbobject->querystring .= "       ELSE round( (b.\"JULY\" / b.\"ANNUAL\")::numeric, 4) ";
      $this->dbobject->querystring .= "    END as jul, ";
      $this->dbobject->querystring .= "    CASE ";
      $this->dbobject->querystring .= "       WHEN (b.\"ANNUAL\" is null) or (b.\"ANNUAL\" = 0) THEN 0.0 ";
      $this->dbobject->querystring .= "       ELSE round( (b.\"AUGUST\" / b.\"ANNUAL\")::numeric, 4) ";
      $this->dbobject->querystring .= "    END as aug, ";
      $this->dbobject->querystring .= "    CASE ";
      $this->dbobject->querystring .= "       WHEN (b.\"ANNUAL\" is null) or (b.\"ANNUAL\" = 0) THEN 0.0 ";
      $this->dbobject->querystring .= "       ELSE round( (b.\"SEPTEMBER\" / b.\"ANNUAL\")::numeric, 4) ";
      $this->dbobject->querystring .= "    END as sep, ";
      $this->dbobject->querystring .= "    CASE ";
      $this->dbobject->querystring .= "       WHEN (b.\"ANNUAL\" is null) or (b.\"ANNUAL\" = 0) THEN 0.0 ";
      $this->dbobject->querystring .= "       ELSE round( (b.\"OCTOBER\" / b.\"ANNUAL\")::numeric, 4) ";
      $this->dbobject->querystring .= "    END as oct, ";
      $this->dbobject->querystring .= "    CASE ";
      $this->dbobject->querystring .= "       WHEN (b.\"ANNUAL\" is null) or (b.\"ANNUAL\" = 0) THEN 0.0 ";
      $this->dbobject->querystring .= "       ELSE round( (b.\"NOVEMBER\" / b.\"ANNUAL\")::numeric, 4) ";
      $this->dbobject->querystring .= "    END as nov, ";
      $this->dbobject->querystring .= "    CASE ";
      $this->dbobject->querystring .= "       WHEN (b.\"ANNUAL\" is null) or (b.\"ANNUAL\" = 0) THEN 0.0 ";
      $this->dbobject->querystring .= "       ELSE round( (b.\"DECEMBER\" / b.\"ANNUAL\")::numeric, 4) ";
      $this->dbobject->querystring .= "    END as dec ";
      $this->dbobject->querystring .= " from waterusetype as a left outer join vwuds_annual_mp_data as b ";
      $this->dbobject->querystring .= " on (a.typeabbrev = b.\"CAT_MP\" ";
      $this->dbobject->querystring .= "     and b.\"USERID\" = '$this->id1' ";
      $this->dbobject->querystring .= "     AND b.\"MPID\" = '$this->id2' ) ";
      $this->dbobject->querystring .= " WHERE a.typeabbrev = '" . $thistype . "' ";
      $this->dbobject->querystring .= " order by typeabbrev ";
      $this->dbobject->querystring .= " ) as foo ";
      $this->dbobject->querystring .= " group by typeabbrev";
      $this->dbobject->performQuery();
      //error_log($this->dbobject->querystring);
      $this->historic_monthly_pct = $this->dbobject->queryrecords;
      
      $this->getConsumptionFractions($thistype);
      
   }
   
   function summarizeWithdrawals() {
      // This is no longer valid since this is now an XML connection and the tables and dbconn's are not set up
      
      /*
      // parent routines grab all data, now do summary queries to
      // the following summaries should be generated by the XML object:
      // historic annual totals, by year and use_type (row - type, column - year)
      $this->dbobj->querystring = "  select a.cat_mp, sum(a.max_annual) as max_annual, ";
      $this->dbobj->querystring .= "    sum(a.max_annual/365.0) as max_mgd ";
      $this->dbobj->querystring .= " FROM $dbt as a, vwuds_max_withdrawal as b ";
      $this->dbobj->querystring .= " where a.mpid = b.mpid ";
      // currently, the vwuds_max withdrawal table holds only that, withdrawals, but at some point
      // it, or a table that would be more properly known as vwuds_max_annual would contain 
      // the data pertaining to transfers and the like
      $this->dbobj->querystring .= " group by a.cat_mp ";
      if ($this->debug) {
         $this->logDebug("$this->dbobj->querystring ; <br>");
      }
      $this->dbobj->performQuery();
      // historica monthly mean percent of annual by use_type (row - type, column - month)
      // update other components, such as the summary data, and the category multipliers
      $dbt = $this->dbtable;
      $this->dbobj->querystring = "  select a.cat_mp, sum(a.max_annual) as max_annual, ";
      $this->dbobj->querystring .= "    sum(a.max_annual/365.0) as max_mgd ";
      $this->dbobj->querystring .= " FROM $dbt as a, vwuds_max_withdrawal as b ";
      $this->dbobj->querystring .= " where a.mpid = b.mpid ";
      // currently, the vwuds_max withdrawal table holds only that, withdrawals, but at some point
      // it, or a table that would be more properly known as vwuds_max_annual would contain 
      // the data pertaining to transfers and the like
      $this->dbobj->querystring .= " group by a.cat_mp ";
      if ($this->debug) {
         $this->logDebug("$this->dbobj->querystring ; <br>");
      }
      $this->dbobj->performQuery();
      
      */
   }

   
   function createQuery() {
   
      if (is_object($this->timer)) {
         if (is_object($this->timer->thistime)) {
            $startdate = $this->timer->thistime->format('Y-m-d');
         }
         if (is_object($this->timer->endtime)) {
            $enddate = $this->timer->endtime->format('Y-m-d');
         }

         $this->sql_query = "  select thisdate, wd_mgd as historic_mgd from vwuds_monthly_data ";
         $this->sql_query .= " where userid = '$this->id1' ";
         $this->sql_query .= " AND mpid = '$this->id2' ";
         $this->sql_query .= " and thisdate >= '$startdate'";
         $this->sql_query .= " and thisdate <= '$enddate'";
         // END - if using precip
         $this->sql_query .= " order by thisdate ";
      
      } else {
         if ($this->debug) {
            $this->logDebug("Timer object not set - query not created.<br>\n");
         }
      }
      parent::reCreate();
   }
   
}



class wsp_vpdesvwuds extends timeSeriesInput {
/*
    typeid |      typename       | typeabbrev | consumption | max_day_mos
   --------+---------------------+------------+-------------+-------------
         4 | Hydro Power         | PH         |           0 |           1
         8 | Mining              | MIN        |           0 |           1
        13 | Other               | OTH        |           0 |           1
         5 | Public Water Supply | PWS        |         0.5 |        1.25
        12 | Irrigation          | IRR        |           1 |           1
         9 | Agriculture         | AGR        |        0.75 |           1
         6 | Fossil Power        | PF         |         0.9 |           1
        10 | Nuclear Power       | PN         |         0.9 |           1
        11 | Manufacturing       | MAN        |        0.25 |           1
         7 | Commerical          | COM        |        0.25 |           1
*/
   // time series for withdrawal data, based on MPID and USERID - one object per withdrawal
   var $id1 = ''; # USER ID
   var $id2 = ''; # MP ID
   var $waterusetype = ''; // VWUDS abbreviation: PWS, COM, PN, etc.
   var $wdtype = 'SW'; // VWUDS abbreviation: GW, SW, TW
   var $action = 'WL'; // VWUDS abbreviation: GW, SW, TW
   var $historic_monthly_pct = array();
   var $historic_annual = array();
   var $projected_monthly = array();
   var $projected_annual = array();
   var $max_wd_annual = 0.0;
   var $max_wd_daily = 0.0;
   var $usetypes = array();
   var $wd_info = array();
   var $consumption_pct = array();
   var $patchnull = 'none'; // whether or not topatch null records
   var $historic_mgd = 0.0;
   var $current_mgd = 0.0;
   var $current_mgy = 0.0;
   var $current_years = '2005,2006,2007,2008,2009,2010';
   var $discharge_enabled = 0; // discharge is disabled unless we have explicitly set it
   // vwuds data connection information
   var $withdrawal_enabled = 1; // withdrawal is enabled unless we have explicitly set it
   // vwuds data connection information
   var $vwuds_db = -1;
   var $max_memory_values = 1000;
   var $vwuds_username = 'wsp_ro';
   var $vwuds_password = '314159';
   var $vwuds_dbname = 'vwuds';
   var $vwuds_host = '128.173.217.23';
   var $vwuds_port = 5432;
   var $intmethod = 1; // use previous value method or monthly observed withdrawals
   // vpdes database connection info
   var $vpdes_db = -1;
   var $vpdes_username = 'vpdes_ro';
   var $vpdes_password = 'vpd3sROpw';
   var $vpdes_dbname = 'vpdes';
   var $vpdes_host = '128.173.217.23';
   var $vpdes_port = 5432;
   var $vpdes_curr_start = '2007-01-01';
   var $vpdes_curr_end = '2009-12-31';
   // end data connection information
   // VPDES permit information
   var $ps_info = array();
   var $vpdes_permitno = '';
   var $vpdes_outfallno = ''; // if none specified then we retrieve all of them?  or only 001??
   var $datecolumn = 'thisdate';
   var $lon_col = 'lon_dd';
   var $lat_col = 'lat_dd';
   var $serialist = 'wd_info,ps_info,historic_monthly_pct,historic_annual,projected_monthly,projected_annual,usetypes,consumption_pct';
   
   function wake() {
      parent::wake();
      $this->setupDBConn();
      $this->prop_desc['wd_mgd'] = 'Current modeled withdrawal rate (mgd).';
      $this->prop_desc['historic_mgd'] = 'Historic Demand (mgd).';
      $this->prop_desc['current_mgd'] = 'Current Demand (mgd).';
      $this->prop_desc['current_mgy'] = 'Current annual withdrawal (mgy).';
      $this->prop_desc['discharge_mgd'] = 'Current modeled discharge rate (mgd).';
      $this->prop_desc['discharge_vpdes_mgd'] = 'Current Demand (mgd).';
      $this->prop_desc['discharge_calc'] = 'Estimated Discharge (mgd).';
      $this->prop_desc['ps_bestest_mgd'] = 'Best estimate of discharge (mgd).';
      $this->prop_desc['max_wd_annual'] = 'Maximum single year withdrawal (mgd).';
      $this->prop_desc['surface_mgd'] = 'Rate of withdrawal from surface water in this time step (mgd).';
      $this->prop_desc['safe_yield'] = 'Maximum allowable withdrawal rate (mgd) - defaults to maximum single year divided by historical monthly fractions.';
      $this->prop_desc['flowby'] = 'Flow rate below which withdrawal is halted - depends on Qriver (cfs).';
      $this->prop_desc['Qriver'] = 'Current river flow, default variable for evaluating flowby, if NULL, flowby will not be evaluated (cfs).';
   }

   function sleep() {
      parent::sleep();
      $this->vpdes_db = NULL;
      $this->vwuds_db = NULL;
   }
   
   function init() {
      parent::init();
      
      // since this is a WD/PS object, and data for these objects is in monthly format, there is no need (currently)
      // to economize in the manner of the cached query that the DataConnection objects use.  thus, this object
      // simply sub-classes the timeSeriesInput object 
      // this is also advantageous, since this the first object to utilize two data connections, and thus it would 
      // require some re-programming.  
      // get WD data, add to time series
      // get PS data, add to time series
      $this->loadVPDESData();
      $this->loadVWUDSData();
      //$this->estimateCurrentWithdrawal();
      
   }
   function setState() {
      parent::setState();
      $this->state['wd_mgd'] = NULL;
      $this->state['current_mgd'] = NULL;
      $this->state['current_mgy'] = NULL;
      $this->state['historic_mgd'] = NULL;
      $this->state['discharge_vpdes_mgd'] = NULL;
      $this->state['wd_bestest_mgd'] = NULL;
      $this->state['ps_bestest_mgd'] = NULL;
      $this->state['discharge_calc'] = NULL;
      $this->state['max_wd_annual'] = $this->max_wd_annual;
      $this->state['max_wd_daily'] = $this->max_wd_daily;
      $this->state['safe_yield'] = NULL;
      $this->state['surface_mgd'] = NULL;
      $this->state['flowby'] = NULL;
      $this->state['Qriver'] = NULL;
   }
   
   function setDataColumnTypes() {
      parent::setDataColumnTypes();
      // add these to the data columns for logging
      $statenums = array('wd_mgd','current_mgy','current_mgd','historic_mgd','discharge_vpdes_mgd','wd_bestest_mgd','ps_bestest_mgd', 'discharge_calc','surface_mgd','discharge_mgd','historic_monthly_pct','current_monthly_discharge', 'consumption', 'max_wd_annual','safe_yield', 'flowby', 'Qriver');
      foreach ($statenums as $thiscol) {
         $this->dbcolumntypes[$thiscol] = 'float8';
         $this->data_cols[] = $thiscol;
      }
      
   }

   function getPublicProps() {
      # gets only properties that are visible (must be manually defined)
      $publix = parent::getPublicProps();

      array_push($publix, 'current_mgd');
      array_push($publix, 'wd_mgd');
      array_push($publix, 'current_mgy');
      array_push($publix, 'historic_mgd');
      array_push($publix, 'discharge_vpdes_mgd');
      array_push($publix, 'wd_bestest_mgd');
      array_push($publix, 'ps_bestest_mgd');
      array_push($publix, 'discharge_calc');
      array_push($publix, 'max_wd_annual');
      array_push($publix, 'surface_mgd');
      array_push($publix, 'flowby');
      array_push($publix, 'Qriver');

      return $publix;
   }
   
   function setupDBConn($refresh = 0) {
   
      $this->vwuds_db = new pgsql_QueryObject;
      $this->vwuds_db->dbconn = pg_connect("host=$this->vwuds_host port=$this->vwuds_port dbname=$this->vwuds_dbname user=$this->vwuds_username password=$this->vwuds_password");
   
      $this->vpdes_db = new pgsql_QueryObject;
      $this->vpdes_db->dbconn = pg_connect("host=$this->vpdes_host port=$this->vpdes_port dbname=$this->vpdes_dbname user=$this->vpdes_username password=$this->vpdes_password");

   }

   
   function step() {
      // all step methods MUST call preStep(),execProcessors(), postStep()
      $this->preStep();
      if ($this->debug) {
         $this->logDebug("$this->name Inputs obtained. thisdate = " . $this->state['thisdate']);
      }
      // execute sub-components
      $this->execProcessors();
      if ($this->debug) {
         $this->logDebug("<b>$this->name Sub-processors executed at hour " . $this->state['hour'] . " on " . $this->state['thisdate'] . " week " . $this->state['week'] . " month " . $this->state['month'] . " year " . $this->state['year'] . ".</b><br>\n");
      }
      
      
      // estimated demands are calculated here in case we do not have a time series data
      // parent does data aquisition, now calculate demands
      $thismo = $this->state['month'];
      $thisyr = $this->state['year'];
      $modays = $this->timer->modays;
      if ($modays == 0) {
         $modays = 30;
      }
      $wd_mgd = $this->state['wd_mgd'];
      $historic_mgd = $this->state['historic_mgd'];
      $discharge_vpdes_mgd = $this->state['discharge_vpdes_mgd'];
      $demand_current_mgy = $this->state['current_mgy'];
      
      // calculate the estimated discharge, unless we have over-ridden with a sub-component
      if ( (!isset($this->processors['discharge_calc'])) and ($this->discharge_enabled) ) {
         $consumption = $this->state['consumption'];
         $discharge_calc = $wd_mgd * (1.0 - $consumption);
         // perform "best estimate" for a smooth withdrawal and ps record, unless we have over-ridden with a sub-component
         if (!isset($this->processors['ps_bestest_mgd'])) {
            if ( ($discharge_vpdes_mgd === null) or ($discharge_vpdes_mgd == 'NULL')) {
               $this->state['ps_bestest_mgd'] = $this->state['discharge_calc'];
            } else {
               $this->state['ps_bestest_mgd'] = $discharge_vpdes_mgd;
            }
         }
      } else {
         if ($this->discharge_enabled) {
            $discharge_calc = $this->state['discharge_calc'];
         } else {
            $discharge_calc = 0.0;
            $this->state['discharge_calc'] = $discharge_calc;
            $this->state['ps_bestest_mgd'] = $discharge_calc;
         }
      }
      
      // calculate the estimated discharge, unless we have over-ridden with a sub-component
      if (!isset($this->processors['surface_mgd'])) {
         if ($this->wdtype == 'SW') {
            $surface_mgd = $wd_mgd;
         } else {
            $surface_mgd = 0.0; // GW and TW do not have a local withdrawal
         }
         $this->state['surface_mgd'] = $surface_mgd;
      }
      
      // do current, unless we have over-ridden with a sub-component
      if (isset($this->processors['historic_monthly_pct'])) {
         $demand_curr_frac = $this->processors['historic_monthly_pct']->evaluateMatrix($thismo);
      } else {
         $demand_curr_frac = $modays / 365.0;
      }
      if ( !isset($this->processors['current_mgd']) ) {
         $curr_demand_mgd = ($demand_current_mgy * $demand_curr_frac) / $modays;
         $this->state['current_mgd'] = $curr_demand_mgd;
      }
      // calculate the safe yield number (or permitted max)
      if (!isset($this->processors['safe_yield'])) {
         $safe_yield = ($this->state['max_wd_annual'] * $demand_curr_frac) / $modays;
         $this->state['safe_yield'] = $safe_yield;
      }
      
      if ( ($this->state['flowby'] <> NULL) and ($this->state['Qriver'] <> NULL) ) {
         // if we have these variables, then we have the capabilty of overriding the 
         // withdrawal values
         if ( $this->state['flowby'] > $this->state['Qriver'] ) {
            $this->state['safe_yield'] = 0.0;
            $this->state['current_mgd'] = 0.0;
         }
      }
      
      // check to see if we have both discharges and withdrawals from time series
      // if we have enabled value estimation, we then see if a given value is missing, and then make it
      // NULL, so that it can be accounted for later. 
      if ($this->debug) {
         $this->logDebug("Patch setting: $this->patchnull <br>\n");
         $this->logDebug("Variables: wd: $historic_mgd - ps: $discharge_vpdes_mgd<br>\n");
      }

      if (!isset($this->processors['wd_bestest_mgd'])) {
         if ( ($historic_mgd === null) or ($historic_mgd == 'NULL')) { 
            $this->estimateHistoricWithdrawal();
         } else {
            $this->state['wd_bestest_mgd'] = $historic_mgd;
         }
      }
      if (!$this->withdrawal_enabled) {
         if (!isset($this->processors['historic_mgd'])) {
            $this->state['historic_mgd'] = 0.0;
         }
         if (!isset($this->processors['wd_mgd'])) {
            $this->state['wd_mgd'] = 0.0;
         }
      }
      
      $this->postStep();
      
   }
   
   function estimateCurrentWithdrawal() {
   // estimation hierarchy
   // - use annual totals from data matrix "historic_annual" if present
   // - multiply this number by monthly distro "historic_monthly_pct" if present
      $yrs = split(',', $this->current_years);
      $wd = 0;
      $this->processors['historic_annual']->init();
      if (count($yrs) > 0) {
         if (isset($this->processors['historic_annual'])) {
            $demand_curr = 0.0;
            //$this->processors['historic_annual']->debug = 1;
            foreach ($yrs as $thisyr) {
               $dmd = $this->processors['historic_annual']->evaluateMatrix($thisyr);
               $this->logDebug("Adding $thisyr ($dmd MG) to current demand estimate <br>\n");
               $demand_curr += $dmd;
            }
            $this->logDebug($this->processors['historic_annual']->debugstring . " <br>\n");
            $wd = $demand_curr / count($yrs);
         }
         
      }
      if (!isset($this->processors['current_mgy'])) {
         $cmgy = new Equation;
         $cmgy->equation = $wd;
         $cmgy->debug = $this->debug;
         $this->addOperator('current_mgy', $cmgy, 0);
      }
      
      if (isset($this->processors['current_mgy'])) {
         $this->processors['current_mgy']->equation = $wd;
      }
   }
   
   function estimateHistoricWithdrawal() {
   // estimation hierarchy
   // - use annual totals from data matrix "historic_annual" if present
   // - multiply this number by monthly distro "historic_monthly_pct" if present
      $modays = $this->timer->modays;
      if ($modays == 0) {
         $modays = 30;
      }
      if (isset($this->state['historic_annual'])) {
         $annualwd = $this->state['historic_annual'];
         if (isset($this->state['historic_monthly_pct'])) {
            $mopct = $this->state['historic_monthly_pct'];
         } else {
            $mopct = 0.08333;
         }
         $wd = $annualwd * $mopct / $modays;
      } else {
         $wd = 0.0;
      }
      $this->state['wd_bestest_mgd'] = $wd;
   }
   
   function create() {
      parent::create();
      // set default land use
      // set basic data query
      $this->logDebug("Create() function called <br>");
      // add use types
      $this->logDebug("Getting historic water withdrawals. <br>\n");
      $this->getHistoricUse();
      $this->addHistoricUseMatrices();
      $this->getHistoricDischarges();
      $this->addHistoricPSMatrices();
      // this must be done AFTER addHistoricUseMatrices, since it relies upon the matrix historic_annual
      $this->estimateCurrentWithdrawal();
      $this->logDebug("Processors on this object: " . print_r(array_keys($this->processors),1) . " <br>");
   }

   function addHistoricPSMatrices() {
      $this->logDebug("addHistoricPSMatrices() function called <br>");
      $discharges = $this->getCurrentVPDESDischarges();
      $this->logDebug("getCurrentVPDESDischarges() returned: " . print_r($discharges,1) . "<br>");
      $this->addHistoricDischargeMatrices($discharges);
   
   }

   function addHistoricUseMatrices() {
   // these matrices hold a copy of the historic monthly percent of annual (mean), and the historic annual
   // these are data pieces that can be used in place of the monthly time series on this object 
   // or as a part of the current or projected estimates
      if (isset($this->processors['historic_monthly_pct'])) {
         unset($this->processors['historic_monthly_pct']);
      }
      // historic percent subcomponent 
      $usedef = new dataMatrix;
      $usedef->name = 'historic_monthly_pct';
      $usedef->description = 'Historic average monthly percent of annual use';
      $usedef->wake();
      $usedef->numcols = 2;  
      $usedef->valuetype = 1; // 1 column lookup (col & row)
      $usedef->keycol1 = 'month'; // key for 1st lookup variable
      $usedef->lutype1 = 0; // lookp type - exact match for land use name
      $usedef->keycol2 = ''; // key for 2nd lookup variable
      $usedef->lutype2 = 0; // lookup type - interpolated for year value
      // add a row for the header line
      $usedef->numrows = 13;
      foreach (array('month_num','pct_of_annual') as $header) {
         $usedef->matrix[] = $header;
      }
      // now add the individual records
      $mos = array('jan'=>1,'feb'=>2,'mar'=>3,'apr'=>4,'may'=>5,'jun'=>6,'jul'=>7,'aug'=>8,'sep'=>9, 'oct'=>10,'nov'=>11,'dec'=>12);
      foreach ($mos as $thismo=>$thisno) {
         $usedef->matrix[] = $thisno;// map the text mo to a numerical description
         $usedef->matrix[] = $this->historic_monthly_pct[0][$thismo];
      }
      $this->logDebug("Trying to add Monthly Use fraction sub-component matrix with values: " . print_r($usedef->matrix,1) . " from " . print_r($this->historic_monthly_pct,1) . " <br>");
      $this->addOperator('historic_monthly_pct', $usedef, 0);
      
      
      // historic Total use subcomponent 
      $usedef = new dataMatrix;
      $usedef->name = 'historic_annual';
      $usedef->description = 'Historic annual use in MG per year';
      $usedef->wake();
      $usedef->numcols = count($this->historic_annual[0]);  
      $usedef->valuetype = 1; // 2 column lookup (col & row)
      $usedef->keycol1 = 'year'; // key for 1st lookup variable
      $usedef->lutype1 = 1; // lookup type - interpolated
      // add a row for the header line
      $usedef->numrows = count($this->historic_annual) + 1;
      // since these are stored as a single dimensioned array, regardless of their lookup type 
      // (for compatibility with single dimensional HTML form variables)
      // we set alternating values representing the 2 columns (luname - acreage)
      foreach (array_keys($this->historic_annual[0]) as $thisvar) {
         $usedef->matrix[] = $thisvar;
      }
      // now add the individual records
      foreach ($this->historic_annual as $thistype) {
         foreach ($thistype as $thisvar) {
            $usedef->matrix[] = $thisvar;
         }
      }
      $this->logDebug("Trying to add historic annual sub-component matrix with values: " . print_r($usedef->matrix,1) . " <br>");
      $this->addOperator('historic_annual', $usedef, 0);
      
      
      // consumptive use factors by month
      if (isset($this->processors['consumption'])) {
         unset($this->processors['consumption']);
      }
      $usedef = new dataMatrix;
      $usedef->name = 'consumption';
      $usedef->description = 'Monthly consumptive use factors (return flow % is [1-consumption] )';
      $usedef->wake();
      $usedef->numcols = 2;  
      $usedef->valuetype = 1; // 1 column lookup (col & row)
      $usedef->keycol1 = 'month'; // key for 1st lookup variable
      $usedef->lutype1 = 0; // lookp type - exact match for land use name
      $usedef->keycol2 = ''; // key for 2nd lookup variable
      $usedef->lutype2 = 0; // lookup type - interpolated for year value
      // add a row for the header line
      $usedef->numrows = 13;
      foreach (array('month_num','pct_consumptive') as $header) {
         $usedef->matrix[] = $header;
      }
      // now add the individual records
      $mos = array('c_jan'=>1,'c_feb'=>2,'c_mar'=>3,'c_apr'=>4,'c_may'=>5,'c_jun'=>6,'c_jul'=>7,'c_aug'=>8,'c_sep'=>9, 'c_oct'=>10,'c_nov'=>11,'c_dec'=>12);
      foreach ($mos as $thismo=>$thisno) {
         $usedef->matrix[] = $thisno;// map the text mo to a numerical description
         $usedef->matrix[] = $this->consumption_pct[$thismo];
      }
      $this->logDebug("Trying to add Monthly consumtive fraction sub-component matrix with values: " . print_r($usedef->matrix,1) . " from " . print_r($this->consumption_pct,1) . " <br>");
      $this->addOperator('consumption', $usedef, 0);
      
   }

   function addHistoricDischargeMatrices($discharges) {
   // these matrices hold a copy of the historic monthly percent of annual (mean), and the historic annual
   // these are data pieces that can be used in place of the monthly time series on this object 
   // or as a part of the current or projected estimates
      if (isset($this->processors['current_monthly_discharge'])) {
         unset($this->processors['current_monthly_discharge']);
      }
      // historic percent subcomponent 
      $usedef = new dataMatrix;
      $usedef->name = 'current_monthly_discharge';
      $usedef->description = 'Current estimated mean daily discharge by month (MGD)';
      $usedef->wake();
      $usedef->numcols = 2;  
      $usedef->valuetype = 1; // 1 column lookup (col & row)
      $usedef->keycol1 = 'month'; // key for 1st lookup variable
      $usedef->lutype1 = 0; // lookp type - exact match for land use name
      $usedef->keycol2 = ''; // key for 2nd lookup variable
      $usedef->lutype2 = 0; // lookup type - interpolated for year value
      // add a row for the header line
      $usedef->numrows = 12;
      // now add the individual records
      $mos = array('jan'=>1,'feb'=>2,'mar'=>3,'apr'=>4,'may'=>5,'jun'=>6,'jul'=>7,'aug'=>8,'sep'=>9, 'oct'=>10,'nov'=>11,'dec'=>12);
      foreach ($mos as $thismo=>$thisno) {
         $usedef->matrix[] = $thisno;// map the text mo to a numerical description
         if (isset($discharges[$thisno - 1]['ps_mgd'])) {
            $usedef->matrix[] = $discharges[$thisno - 1]['ps_mgd'];
         } else {
            $usedef->matrix[] = 0.0;
         }
      }
      $this->logDebug("Trying to add Monthly discharge sub-component matrix with values: " . print_r($usedef->matrix,1) . " from " . print_r($discharges,1) . " <br>");
      $this->addOperator('current_monthly_discharge', $usedef, 0);
      
   }
   
   
   function getTablesColumns() {
      //parent::getTablesColumns();
   }
   
   function getWDInfo() { 
      if (strlen(trim($this->id2)) > 0) {
         $hasmps = TRUE;
         $mpidlist = "'" . join("','", split(",",$this->id2)) . "'";
      }
      $this->vwuds_db->querystring = "  select * from vwuds_mp_detail ";
      $this->vwuds_db->querystring .= " where  \"USERID\" = '$this->id1' ";
      if ($hasmps) {
         $this->vwuds_db->querystring .= "    and \"MPID\" in ($mpidlist) ";
      }
      $this->vwuds_db->querystring .= "    and \"ACTION\" = '$this->action' ";
      $this->vwuds_db->performQuery();
      if (count($this->vwuds_db->queryrecords) > 0) {
         $this->wd_info = $this->vwuds_db->queryrecords[0];
         // we go ahead and overwrite the value of waterusetype on the object, otherwise,
         // we allow the user-defined value to remain
         $this->waterusetype = $this->wd_info['CAT_MP'];
         $this->wdtype = $this->wd_info['TYPE'];
         $this->vpdes_permitno = $this->wd_info['VPDES'];
      } else {
         $this->wd_info = array();
      }
      if ($this->debug) {
         //$this->logDebug($this->vwuds_db->querystring);
         $this->logDebug("Basic withdrawal Info: " . print_r($this->wd_info,1) . "<br>");
      }
      
      
      $this->vwuds_db->querystring = "  select sum(max_annual) as max_annual, sum(max_maxday) as max_day from vwuds_max_action ";
      $this->vwuds_db->querystring .= " where userid = '$this->id1' ";
      if ($hasmps) {
         $this->vwuds_db->querystring .= "    and mpid in ($mpidlist) ";
      }
      $this->vwuds_db->querystring .= "    and action = '$this->action' ";
      if ($this->debug) {
         $this->logDebug("Retrieving Maximum withdrwals: " . $this->vwuds_db->querystring . " ;<br>");
      }
      $this->vwuds_db->performQuery();
      if (count($this->vwuds_db->queryrecords) > 0) {
         $this->logDebug("Max query returned: " . count($this->vwuds_db->queryrecords) . " records<br>");
         $maxinfo = $this->vwuds_db->queryrecords;
         $this->max_wd_annual = $this->vwuds_db->getRecordValue(1,'max_annual');
         $this->max_wd_daily = $this->vwuds_db->getRecordValue(1,'max_day');
      } else {
         $this->max_wd_annual = 0;
         $this->max_wd_daily = 0;
         $maxinfo = array('No records returned.');
      }
      if ($this->debug) {
         //$this->logDebug($this->vwuds_db->querystring);
         $this->logDebug("Max withdrawal Info: " . print_r($maxinfo,1) . "<br>");
      }
      
   }
   
   function getConsumptionFractions($thistype = 'OTH') {
      $this->consumption_pct = array();
      $this->vwuds_db->querystring = "  select * from waterusetype ";
      $this->vwuds_db->querystring .= " where typeabbrev = '$thistype' ";
      $this->vwuds_db->performQuery();
      if ($this->debug) {
         $this->logDebug($this->dbobject->querystring);
      }
      $this->consumption_pct = $this->vwuds_db->queryrecords[0];
      if ($this->debug) {
         $this->logDebug("Consumption Info: " . print_r($this->consumption_pct,1));
      }
      
   }
   
   function getTransfers() {
      //get any transfers associated with this MP
   }
   
   function getVPDESInfo() {
      //get any VPDES point source records associated with this MP
      if ( strlen($this->vpdes_permitno) > 0) {
         $this->vpdes_db->querystring = "  select vpdes_permit_no, outfall_no, facility_name  ";
         $this->vpdes_db->querystring .= " from vpdes_locations ";
         $this->vpdes_db->querystring .= " where vpdes_permit_no = '$this->vpdes_permitno' ";
         if (strlen($this->vpdes_outfallno) > 0) {
            $this->vpdes_db->querystring .= " AND outfall_no = '$this->vpdes_outfallno' ";
         }
         $this->vpdes_db->querystring .= " GROUP BY vpdes_permit_no, outfall_no, facility_name ";
         $this->vpdes_db->performQuery();
         if (count($this->vpdes_db->queryrecords) > 0) {
            $this->ps_info = $this->vpdes_db->queryrecords[0];
            // we go ahead and overwrite the value of waterusetype on the object, otherwise,
            // we allow the user-defined value to remain
            $this->vpdes_outfallno = $this->ps_info['outfall_no'];
         } else {
            $this->logError("No VPDES outfall information available for Permit Number $this->vpdes_permitno with outfall: $this->outfall_no <br>\n");
            $this->ps_info = array();
         }
         $this->logDebug($this->vpdes_db->querystring . "<br>");
         $this->logDebug("Consumption Info: " . print_r($this->ps_info,1) . "<br>");
      }
   }
   
   function getVPDESDischarges() {
      //get any discharges associated with this MP
   }
   
   function getCurrentVPDESDischarges() {
      //get any discharges associated with this MP
      if (is_object($this->vpdes_db) and (strlen($this->vpdes_permitno) > 0) ) {
         // try this query, gets a broader data range to accomodate for quarterly reporting
         $vpidlist = "'" . join("','", split(",",$this->vpdes_permitno)) . "'";
         $this->vpdes_db->querystring = "  select a.thismonth, ";
         $this->vpdes_db->querystring .= " CASE ";
         $this->vpdes_db->querystring .= "    WHEN avg(b.discharge_vpdes_mgd) IS NULL THEN 0.0 ";
         $this->vpdes_db->querystring .= "    ELSE avg(b.discharge_vpdes_mgd) ";
         $this->vpdes_db->querystring .= " END as ps_mgd, count(b.*) as num ";
         $this->vpdes_db->querystring .= " from ( ";
         $this->vpdes_db->querystring .= "    select generate_series as thismonth ";
         $this->vpdes_db->querystring .= "    from generate_series(1,12) ";
         $this->vpdes_db->querystring .= "    order by thismonth ";
         $this->vpdes_db->querystring .= " ) as a left outer join ( ";
         $this->vpdes_db->querystring .= "    SELECT extract(month from mon_startdate) as startmo, ";
         $this->vpdes_db->querystring .= "       extract(month from mon_enddate) as endmo, ";
         $this->vpdes_db->querystring .= "       sum(mean_value) as discharge_vpdes_mgd  ";
         $this->vpdes_db->querystring .= "    FROM vpdes_discharge_no_ms4 ";
         $this->vpdes_db->querystring .= "    WHERE vpdes_permit_no in ($vpidlist) ";
         // this is hard coded to only grab all outfalls for now
         //$this->vpdes_db->querystring .= " AND outfall_no = '$this->vpdes_outfallno' ";
         $this->vpdes_db->querystring .= "       AND mon_startdate >= '$this->vpdes_curr_start' ";
         $this->vpdes_db->querystring .= "       AND mon_startdate <= '$this->vpdes_curr_end'  ";
         // this is hard coded to only grab water for now
         $this->vpdes_db->querystring .= "       AND constit = '001' ";
         $this->vpdes_db->querystring .= "    GROUP BY mon_startdate, mon_enddate ";
         $this->vpdes_db->querystring .= "    ORDER BY mon_startdate ";
         $this->vpdes_db->querystring .= " ) as b ";
         // uses exact date match, screws up on quarterly reporters
         //$this->vpdes_db->querystring .= " on (a.thisdate = b.thisdate) ";
         // this one tries to stretch quarterly matches out
         $this->vpdes_db->querystring .= " on (a.thismonth >= b.startmo  ";
         $this->vpdes_db->querystring .= "    AND a.thismonth <= b.endmo) ";
         $this->vpdes_db->querystring .= " group by a.thismonth ";
         $this->vpdes_db->querystring .= " order by a.thismonth ";

         //if ($this->debug) {
            $this->logDebug("VPDES query: <br>\n");
            $this->logDebug($this->vpdes_db->querystring);
            $this->logDebug("<br>\n");
         //}
         $this->vpdes_db->performQuery();

         if (count($this->vpdes_db->queryrecords) > 0) {
            return $this->vpdes_db->queryrecords;
         } else {
            $this->logError("VPDES query for vpdes_permit_no = '$this->vpdes_permitno' returned no data <br>\n");
            if ($this->debug) {
               $this->logDebug("VPDES query returned no data <br>\n");
            }
         }
      } else {
         $this->logDebug("VPDES db object not set. <br>\n");
      }
   }
   
   function getHistoricUse() {
      $this->historic_monthly_pct = array();
      $this->historic_annual = array();
      $this->projected_monthly = array();
      $this->projected_annual = array();
      $this->maxuse_annual = array();
      $this->usetypes = array();
      $this->getWDInfo();
      $hasmps = FALSE;
      if (strlen(trim($this->id2)) > 0) {
         $hasmps = TRUE;
         $mpidlist = "'" . join("','", split(",",$this->id2)) . "'";
      }
      
      $annual_query = "  select \"YEAR\" as thisyear, ";
      $annual_query .= "    CASE ";
      $annual_query .= "       WHEN sum(\"ANNUAL\") is null THEN 0.0 ";
      $annual_query .= "       ELSE round(sum(\"ANNUAL/365\"*365.0)::numeric,5) ";
      $annual_query .= "    END as total_mg ";
      $annual_query .= " FROM vwuds_annual_mp_data ";
      // by putting this outside of the "ON" clause, we override the left join, only returning these specific uses
      $annual_query .= " WHERE \"USERID\" = '$this->id1' ";
      if ($hasmps) {
         $annual_query .= " AND \"MPID\" in ( $mpidlist ) ";
      }
      $annual_query .= " GROUP BY \"YEAR\"";
      $annual_query .= " ORDER BY \"YEAR\"";
      $this->vwuds_db->querystring = $annual_query;
      $this->logDebug($this->vwuds_db->querystring);
      $this->vwuds_db->performQuery();
      $this->historic_annual = $this->vwuds_db->queryrecords;
      
      if (!isset($this->wd_info['CAT_MP'])) {
         $thistype = 'OTH';
      } else {
         $thistype = $this->wd_info['CAT_MP'];
      }
      
      $this->vwuds_db->querystring = "  select ";
      $this->vwuds_db->querystring .= "    round(avg(jan)::numeric,4) as jan, round(avg(feb)::numeric,4) as feb, ";
      $this->vwuds_db->querystring .= "    round(avg(mar)::numeric,4) as mar, round(avg(apr)::numeric,4) as apr, ";
      $this->vwuds_db->querystring .= "    round(avg(may)::numeric,4) as may, round(avg(jun)::numeric,4) as jun, ";
      $this->vwuds_db->querystring .= "    round(avg(jul)::numeric,4) as jul, round(avg(aug)::numeric,4) as aug, ";
      $this->vwuds_db->querystring .= "    round(avg(sep)::numeric,4) as sep, round(avg(oct)::numeric,4) as oct, ";
      $this->vwuds_db->querystring .= "    round(avg(nov)::numeric,4) as nov, round(avg(dec)::numeric,4) as dec ";
      $this->vwuds_db->querystring .= " from ( ";
      $this->vwuds_db->querystring .= "    select a.typeabbrev, ";
      $this->vwuds_db->querystring .= "    CASE ";
      $this->vwuds_db->querystring .= "       WHEN ( (sum(b.\"ANNUAL\") is null) or (sum(b.\"ANNUAL\") = 0)) THEN 0.0 ";
      $this->vwuds_db->querystring .= "       ELSE ( sum(b.\"JANUARY\") / sum(b.\"ANNUAL\")) ";
      $this->vwuds_db->querystring .= "    END as jan, ";
      $this->vwuds_db->querystring .= "    CASE ";
      $this->vwuds_db->querystring .= "       WHEN ( (sum(b.\"ANNUAL\") is null) or (sum(b.\"ANNUAL\") = 0)) THEN 0.0 ";
      $this->vwuds_db->querystring .= "       ELSE ( sum(b.\"FEBRUARY\") / sum(b.\"ANNUAL\")) ";
      $this->vwuds_db->querystring .= "    END as feb, ";
      $this->vwuds_db->querystring .= "    CASE ";
      $this->vwuds_db->querystring .= "       WHEN ( (sum(b.\"ANNUAL\") is null) or (sum(b.\"ANNUAL\") = 0)) THEN 0.0 ";
      $this->vwuds_db->querystring .= "       ELSE ( sum(b.\"MARCH\") / sum(b.\"ANNUAL\")) ";
      $this->vwuds_db->querystring .= "    END as mar, ";
      $this->vwuds_db->querystring .= "    CASE ";
      $this->vwuds_db->querystring .= "       WHEN ( (sum(b.\"ANNUAL\") is null) or (sum(b.\"ANNUAL\") = 0)) THEN 0.0 ";
      $this->vwuds_db->querystring .= "       ELSE ( sum(b.\"APRIL\") / sum(b.\"ANNUAL\")) ";
      $this->vwuds_db->querystring .= "    END as apr, ";
      $this->vwuds_db->querystring .= "    CASE ";
      $this->vwuds_db->querystring .= "       WHEN ( (sum(b.\"ANNUAL\") is null) or (sum(b.\"ANNUAL\") = 0)) THEN 0.0 ";
      $this->vwuds_db->querystring .= "       ELSE ( sum(b.\"MAY\") / sum(b.\"ANNUAL\")) ";
      $this->vwuds_db->querystring .= "    END as may, ";
      $this->vwuds_db->querystring .= "    CASE ";
      $this->vwuds_db->querystring .= "       WHEN ( (sum(b.\"ANNUAL\") is null) or (sum(b.\"ANNUAL\") = 0)) THEN 0.0 ";
      $this->vwuds_db->querystring .= "       ELSE ( sum(b.\"JUNE\") / sum(b.\"ANNUAL\")) ";
      $this->vwuds_db->querystring .= "    END as jun, ";
      $this->vwuds_db->querystring .= "    CASE ";
      $this->vwuds_db->querystring .= "       WHEN ( (sum(b.\"ANNUAL\") is null) or (sum(b.\"ANNUAL\") = 0)) THEN 0.0 ";
      $this->vwuds_db->querystring .= "       ELSE ( sum(b.\"JULY\") / sum(b.\"ANNUAL\")) ";
      $this->vwuds_db->querystring .= "    END as jul, ";
      $this->vwuds_db->querystring .= "    CASE ";
      $this->vwuds_db->querystring .= "       WHEN ( (sum(b.\"ANNUAL\") is null) or (sum(b.\"ANNUAL\") = 0)) THEN 0.0 ";
      $this->vwuds_db->querystring .= "       ELSE ( sum(b.\"AUGUST\") / sum(b.\"ANNUAL\")) ";
      $this->vwuds_db->querystring .= "    END as aug, ";
      $this->vwuds_db->querystring .= "    CASE ";
      $this->vwuds_db->querystring .= "       WHEN ( (sum(b.\"ANNUAL\") is null) or (sum(b.\"ANNUAL\") = 0)) THEN 0.0 ";
      $this->vwuds_db->querystring .= "       ELSE ( sum(b.\"SEPTEMBER\") / sum(b.\"ANNUAL\")) ";
      $this->vwuds_db->querystring .= "    END as sep, ";
      $this->vwuds_db->querystring .= "    CASE ";
      $this->vwuds_db->querystring .= "       WHEN ( (sum(b.\"ANNUAL\") is null) or (sum(b.\"ANNUAL\") = 0)) THEN 0.0 ";
      $this->vwuds_db->querystring .= "       ELSE ( sum(b.\"OCTOBER\") / sum(b.\"ANNUAL\")) ";
      $this->vwuds_db->querystring .= "    END as oct, ";
      $this->vwuds_db->querystring .= "    CASE ";
      $this->vwuds_db->querystring .= "       WHEN ( (sum(b.\"ANNUAL\") is null) or (sum(b.\"ANNUAL\") = 0)) THEN 0.0 ";
      $this->vwuds_db->querystring .= "       ELSE ( sum(b.\"NOVEMBER\") / sum(b.\"ANNUAL\")) ";
      $this->vwuds_db->querystring .= "    END as nov, ";
      $this->vwuds_db->querystring .= "    CASE ";
      $this->vwuds_db->querystring .= "       WHEN ( (sum(b.\"ANNUAL\") is null) or (sum(b.\"ANNUAL\") = 0)) THEN 0.0 ";
      $this->vwuds_db->querystring .= "       ELSE ( sum(b.\"DECEMBER\") / sum(b.\"ANNUAL\")) ";
      $this->vwuds_db->querystring .= "    END as dec ";
      $this->vwuds_db->querystring .= " from waterusetype as a left outer join vwuds_annual_mp_data as b ";
      $this->vwuds_db->querystring .= " on (a.typeabbrev = b.\"CAT_MP\" ";
      $this->vwuds_db->querystring .= "     and b.\"USERID\" = '$this->id1' ";
      $this->vwuds_db->querystring .= "     and b.\"ACTION\" = '$this->action' ";
      if ($hasmps) {
         $this->vwuds_db->querystring .= " AND b.\"MPID\" in ( $mpidlist ) ";
      }
      $this->vwuds_db->querystring .= "    ) ";
      $this->vwuds_db->querystring .= " WHERE a.typeabbrev = '" . $thistype . "' ";
      $this->vwuds_db->querystring .= " group by typeabbrev ";
      $this->vwuds_db->querystring .= " order by typeabbrev ";
      $this->vwuds_db->querystring .= " ) as foo ";
      $this->vwuds_db->querystring .= " group by typeabbrev";
      $this->vwuds_db->performQuery();
      $this->logDebug($this->vwuds_db->querystring);
      $this->historic_monthly_pct = $this->vwuds_db->queryrecords;
      
      $this->getConsumptionFractions($thistype);
      
   }
   
   function getHistoricDischarges() {
      $this->getVPDESInfo();
      $vpidlist = "'" . join("','", split(",",$this->vpdes_permitno)) . "'";
   }
   
   function summarizeWithdrawals() {
      // This is no longer valid since this is now an XML connection and the tables and dbconn's are not set up
      
      /*
      // parent routines grab all data, now do summary queries to
      // the following summaries should be generated by the XML object:
      // historic annual totals, by year and use_type (row - type, column - year)
      $this->dbobj->querystring = "  select a.cat_mp, sum(a.max_annual) as max_annual, ";
      $this->dbobj->querystring .= "    sum(a.max_annual/365.0) as max_mgd ";
      $this->dbobj->querystring .= " FROM $dbt as a, vwuds_max_withdrawal as b ";
      $this->dbobj->querystring .= " where a.mpid = b.mpid ";
      // currently, the vwuds_max withdrawal table holds only that, withdrawals, but at some point
      // it, or a table that would be more properly known as vwuds_max_annual would contain 
      // the data pertaining to transfers and the like
      $this->dbobj->querystring .= " group by a.cat_mp ";
      if ($this->debug) {
         $this->logDebug("$this->dbobj->querystring ; <br>");
      }
      $this->dbobj->performQuery();
      // historica monthly mean percent of annual by use_type (row - type, column - month)
      // update other components, such as the summary data, and the category multipliers
      $dbt = $this->dbtable;
      $this->dbobj->querystring = "  select a.cat_mp, sum(a.max_annual) as max_annual, ";
      $this->dbobj->querystring .= "    sum(a.max_annual/365.0) as max_mgd ";
      $this->dbobj->querystring .= " FROM $dbt as a, vwuds_max_withdrawal as b ";
      $this->dbobj->querystring .= " where a.mpid = b.mpid ";
      // currently, the vwuds_max withdrawal table holds only that, withdrawals, but at some point
      // it, or a table that would be more properly known as vwuds_max_annual would contain 
      // the data pertaining to transfers and the like
      $this->dbobj->querystring .= " group by a.cat_mp ";
      if ($this->debug) {
         $this->logDebug("$this->dbobj->querystring ; <br>");
      }
      $this->dbobj->performQuery();
      
      */
   }

   
   function loadVPDESData() {
   
      if (is_object($this->timer)) {
         if (is_object($this->timer->thistime)) {
            $startdate = $this->timer->thistime->format('Y-m-d');
            $startyear = $this->timer->thistime->format('Y');
         } else {
            $this->logError("startdate object not set - VPDES query not created.<br>\n");
            return;
         }
         if (is_object($this->timer->endtime)) {
            $enddate = $this->timer->endtime->format('Y-m-d');
            $endyear = $this->timer->endtime->format('Y');
         } else {
            $this->logError("enddate object not set - VPDES query not created.<br>\n");
            return;
         }
         
         $vpidlist = "'" . join("','", split(",",$this->vpdes_permitno)) . "'";
         /*
         $this->vpdes_db->querystring = "  select a.thisdate, b.discharge_vpdes_mgd ";
         $this->vpdes_db->querystring .= " from ( ";
         $this->vpdes_db->querystring .= "    select (a.thisyear || '-' || b.thismonth || '-01')::date as thisdate, null as thisvalue ";
         $this->vpdes_db->querystring .= "    from ( ";
         $this->vpdes_db->querystring .= "       select generate_series as thisyear ";
         $this->vpdes_db->querystring .= "       from generate_series($startyear,$endyear) ";
         $this->vpdes_db->querystring .= "    ) as a, ( ";
         $this->vpdes_db->querystring .= "       select generate_series as thismonth ";
         $this->vpdes_db->querystring .= "       from generate_series(1,12) ";
         $this->vpdes_db->querystring .= "    ) as b ";
         $this->vpdes_db->querystring .= "    order by a.thisyear, b.thismonth ";
         $this->vpdes_db->querystring .= " ) as a left outer join ( ";
         $this->vpdes_db->querystring .= "    SELECT mon_startdate as thisdate, ";
         $this->vpdes_db->querystring .= "       sum(mean_value) as discharge_vpdes_mgd  ";
         $this->vpdes_db->querystring .= "    FROM vpdes_discharge_no_ms4 ";
         $this->vpdes_db->querystring .= "    WHERE vpdes_permit_no in ($vpidlist) ";
         // this is hard coded to only grab all outfalls for now
         //$this->vpdes_db->querystring .= " AND outfall_no = '$this->vpdes_outfallno' ";
         $this->vpdes_db->querystring .= "       AND mon_startdate >= '$startdate' ";
         $this->vpdes_db->querystring .= "       AND mon_startdate <= '$enddate' ";
         // this is hard coded to only grab water for now
         $this->vpdes_db->querystring .= "       AND constit = '001' ";
         $this->vpdes_db->querystring .= "    GROUP BY mon_startdate ";
         $this->vpdes_db->querystring .= "    ORDER BY mon_startdate ";
         $this->vpdes_db->querystring .= " ) as b ";
         $this->vpdes_db->querystring .= " on (a.thisdate = b.thisdate) ";
         $this->vpdes_db->querystring .= " WHERE a.thisdate >= '$startdate' ";
         $this->vpdes_db->querystring .= "    AND a.thisdate <= '$enddate' ";
         $this->vpdes_db->querystring .= " order by a.thisdate ";
         */
         
         // try this query, gets a broader data range to accomodate for quarterly reporting
         $this->vpdes_db->querystring = "  select a.thisdate, b.discharge_vpdes_mgd ";
         $this->vpdes_db->querystring .= " from ( ";
         $this->vpdes_db->querystring .= "    select (a.thisyear || '-' || b.thismonth || '-01')::date as thisdate, null as thisvalue ";
         $this->vpdes_db->querystring .= "    from ( ";
         $this->vpdes_db->querystring .= "       select generate_series as thisyear ";
         $this->vpdes_db->querystring .= "       from generate_series($startyear - 1,$endyear + 1) ";
         $this->vpdes_db->querystring .= "    ) as a, ( ";
         $this->vpdes_db->querystring .= "       select generate_series as thismonth ";
         $this->vpdes_db->querystring .= "       from generate_series(1,12) ";
         $this->vpdes_db->querystring .= "    ) as b ";
         $this->vpdes_db->querystring .= "    order by a.thisyear, b.thismonth ";
         $this->vpdes_db->querystring .= " ) as a left outer join ( ";
         $this->vpdes_db->querystring .= "    SELECT mon_startdate, mon_enddate, ";
         $this->vpdes_db->querystring .= "       sum(mean_value) as discharge_vpdes_mgd  ";
         $this->vpdes_db->querystring .= "    FROM vpdes_discharge_no_ms4 ";
         $this->vpdes_db->querystring .= "    WHERE vpdes_permit_no in ($vpidlist) ";
         // this is hard coded to only grab all outfalls for now
         //$this->vpdes_db->querystring .= " AND outfall_no = '$this->vpdes_outfallno' ";
         $this->vpdes_db->querystring .= "       AND mon_startdate >= ( '$startdate'::date - interval '3 months' ) ";
         $this->vpdes_db->querystring .= "       AND mon_startdate <= ( '$enddate'::date + interval '3 months')  ";
         // this is hard coded to only grab water for now
         $this->vpdes_db->querystring .= "       AND constit = '001' ";
         $this->vpdes_db->querystring .= "    GROUP BY mon_startdate, mon_enddate ";
         $this->vpdes_db->querystring .= "    ORDER BY mon_startdate ";
         $this->vpdes_db->querystring .= " ) as b ";
         // uses exact date match, screws up on quarterly reporters
         //$this->vpdes_db->querystring .= " on (a.thisdate = b.thisdate) ";
         // this one tries to stretch quarterly matches out
         $this->vpdes_db->querystring .= " on (a.thisdate >= b.mon_startdate  ";
         $this->vpdes_db->querystring .= "    AND a.thisdate <= b.mon_enddate) ";
         $this->vpdes_db->querystring .= " WHERE a.thisdate >= ( '$startdate'::date - interval '3 months' ) ";
         $this->vpdes_db->querystring .= "    AND a.thisdate <= ( '$enddate'::date + interval '3 months') ";
         $this->vpdes_db->querystring .= " order by a.thisdate ";
         //$this->logError("VPDES query for vpdes_permit_no = '$this->vpdes_permitno':<br>\n");
         //$this->logError($this->vpdes_db->querystring);
         //$this->logError("<br>\n");
         
         /*
         // try this query, just gives VPDES records
         $this->vpdes_db->querystring = "  select a.thisdate, b.discharge_vpdes_mgd ";
         $this->vpdes_db->querystring .= " from ( ";
         $this->vpdes_db->querystring .= "    SELECT mon_startdate as thisdate, ";
         $this->vpdes_db->querystring .= "       sum(mean_value) as discharge_vpdes_mgd  ";
         $this->vpdes_db->querystring .= "    FROM vpdes_discharge_no_ms4 ";
         $this->vpdes_db->querystring .= "    WHERE vpdes_permit_no in ($vpidlist) ";
         // this is hard coded to only grab all outfalls for now
         //$this->vpdes_db->querystring .= " AND outfall_no = '$this->vpdes_outfallno' ";
         $this->vpdes_db->querystring .= "       AND mon_startdate >= ( '$startdate'::date - interval '3 months' ) ";
         $this->vpdes_db->querystring .= "       AND mon_startdate <= ( '$enddate'::date + interval '3 months')  ";
         // this is hard coded to only grab water for now
         $this->vpdes_db->querystring .= "       AND constit = '001' ";
         $this->vpdes_db->querystring .= "    GROUP BY mon_startdate ";
         $this->vpdes_db->querystring .= "    ORDER BY mon_startdate ";
         $this->vpdes_db->querystring .= " ) as b ";
         $this->vpdes_db->querystring .= " WHERE b.thisdate >= ( '$startdate'::date - interval '3 months' ) ";
         $this->vpdes_db->querystring .= "    AND b.thisdate <= ( '$enddate'::date + interval '3 months') ";
         $this->vpdes_db->querystring .= " order by a.thisdate ";
         */
         
         if ($this->debug) {
            $this->logDebug("VPDES query: <br>\n");
            $this->logDebug($this->vpdes_db->querystring);
            $this->logDebug("<br>\n");
         }
         $this->vpdes_db->performQuery();

         if (count($this->vpdes_db->queryrecords) > 0) {
            $this->addArrayData($this->vpdes_db->queryrecords, 'thisdate', array('discharge_vpdes_mgd'));
         } else {
            $this->logError("VPDES query for vpdes_permit_no = '$this->vpdes_permitno' returned no data <br>\n");
            if ($this->debug) {
               $this->logDebug("VPDES query returned no data <br>\n");
            }
         }
      
      } else {
         if ($this->debug) {
            $this->logDebug("Timer object not set - query not created.<br>\n");
         }
         $this->logError("Timer object not set - VPDES query not created.<br>\n");
      }
      
      // add this data to a time series file
   }

   
   function loadVWUDSData() {
   
      if (is_object($this->timer)) {
         if (is_object($this->timer->thistime)) {
            $startdate = $this->timer->thistime->format('Y-m-d');
            $startyear = $this->timer->thistime->format('Y');
         } else {
            $this->logError("startdate object not set - VPDES query not created.<br>\n");
            return;
         }
         if (is_object($this->timer->endtime)) {
            $enddate = $this->timer->endtime->format('Y-m-d');
            $endyear = $this->timer->endtime->format('Y');
         } else {
            $this->logError("enddate object not set - VPDES query not created.<br>\n");
            return;
         }
         
         $hasmps = FALSE;
         if (strlen(trim($this->id2)) > 0) {
            $hasmps = TRUE;
            $mpidlist = "'" . join("','", split(",",$this->id2)) . "'";
         }

         $this->vwuds_db->querystring = "  select a.thisdate, CASE WHEN b.historic_mgd is NULL THEN 0.0 ELSE b.historic_mgd END as historic_mgd ";
         $this->vwuds_db->querystring .= " from ( ";
         $this->vwuds_db->querystring .= "    select (a.thisyear || '-' || b.thismonth || '-01')::date as thisdate, null as thisvalue ";
         $this->vwuds_db->querystring .= "    from ( ";
         $this->vwuds_db->querystring .= "       select generate_series as thisyear ";
         $this->vwuds_db->querystring .= "       from generate_series($startyear,$endyear) ";
         $this->vwuds_db->querystring .= "    ) as a, ( ";
         $this->vwuds_db->querystring .= "       select generate_series as thismonth ";
         $this->vwuds_db->querystring .= "       from generate_series(1,12) ";
         $this->vwuds_db->querystring .= "    ) as b ";
         $this->vwuds_db->querystring .= "    order by a.thisyear, b.thismonth ";
         $this->vwuds_db->querystring .= " ) as a left outer join ( ";
         $this->vwuds_db->querystring .= "    select thisdate, sum(wd_mgd) as historic_mgd ";
         $this->vwuds_db->querystring .= "    from vwuds_monthly_data ";
         $this->vwuds_db->querystring .= "    where userid = '$this->id1' ";
         if ($hasmps) {
            $this->vwuds_db->querystring .= "       AND mpid in ($mpidlist) ";
         }
         $this->vwuds_db->querystring .= "       and thisdate >= '$startdate'";
         $this->vwuds_db->querystring .= "       and thisdate <= '$enddate'";
         $this->vwuds_db->querystring .= "    group by thisdate ";
         $this->vwuds_db->querystring .= "    order by thisdate ";
         $this->vwuds_db->querystring .= " ) as b ";
         $this->vwuds_db->querystring .= " on (a.thisdate = b.thisdate) ";
         $this->vwuds_db->querystring .= " WHERE a.thisdate >= '$startdate' ";
         $this->vwuds_db->querystring .= "    AND a.thisdate <= '$enddate' ";
         $this->vwuds_db->querystring .= " order by a.thisdate ";
         //if ($this->debug) {
            $this->logDebug("VWUDS query:<br>\n");
            $this->logDebug($this->vwuds_db->querystring);
            $this->logDebug("<br>\n");
         //}
         $this->vwuds_db->performQuery();
         //$this->logError("VWUDS query for userid = '$this->id1' AND mpid in ($mpidlist):<br>\n");
         //$this->logError($this->vwuds_db->querystring);
         //$this->logError("<br>\n");
         if (count($this->vwuds_db->queryrecords) > 0) {
            $this->addArrayData($this->vwuds_db->queryrecords, 'thisdate');
         } else {
            $this->logError("VWUDS query for userid = '$this->id1' AND mpid in ($mpidlist) returned no data <br>\n");
            if ($this->debug) {
               $this->logDebug("VWUDS query returned no data <br>\n");
               $this->logDebug($this->vwuds_db->querystring);
               $this->logDebug("<br>\n");
            }
         }
      
      } else {
         if ($this->debug) {
            $this->logDebug("Timer object not set - query not created.<br>\n");
         }
         $this->logError("Timer object not set - VWUDS query not created.<br>\n");
      }
      
      // add this data to a time series file
   }



   function addArrayData($theserecs, $tcol) {
      # expects an associative array in the format of the listobject queryrecords
      if ($this->debug) {
         $this->logDebug("Adding " . count($theserecs) . ' records <br>');
      }
      foreach ($theserecs as $thisrec) {
         if (in_array($tcol, array_keys($thisrec))) {
            $ts = $thisrec[$tcol];
            $this->addValue($ts, $thisrec);
            #break;
         } else {
            if ($this->debug) {
               $this->logDebug("Error: Date column $tcol does not exist.<br>");
            }
         }
      }
   }
   
}


class hydroImpSmall extends hydroImpoundment {
   // this is a general purpose class for a simple flow-by
   // other, more complicated flow-bys will inherit this class
   var $rvars = array();
   var $wvars = array();
   var $storage_matrix = -1; // objecct shell for storage table
   var $matrix = array(); // array shell for storage table
   var $serialist = 'rvars,wvars,matrix';
   var $refill = 0;
   var $et_in = 0;
   var $precip_in = 0;
   var $demand = 0;
   var $release = 0;

   function setState() {
      parent::setState();
      $this->rvars = array('et_in','precip_in','release','demand', 'Qin', 'refill');
      $this->wvars = array('evap_mgd','Qout','lake_elev','Storage', 'refill_full');
      $this->initOnParent();
   }

   function writeToParent() {
      if (is_object($this->parentobject)) {
         foreach ($this->wvars as $thisvar) {
            $this->parentobject->setStateVar($this->name . "_" . $thisvar, $this->state[$thisvar]);
         }
      }
   }

   function initOnParent() {
      if (is_object($this->parentobject)) {
         foreach ($this->wvars as $thisvar) {
            $this->parentobject->setSingleDataColumnType($this->name . "_" . $thisvar, 'float8', 0.0);
         }
      }
   }

   function showEditForm($formname, $disabled=0) {
      if (is_object($this->listobject)) {

         $returnInfo = array();
         $returnInfo['name'] = $this->name;
         $returnInfo['description'] = $this->description;
         $returnInfo['debug'] = '';
         $returnInfo['elemtype'] = get_class($this);
         $returnInfo['innerHTML'] = '';

         //$props = (array)$this;
         $innerHTML = '';

         # set up div to contain each seperate multi-parameter block
         $innerHTML .= showHiddenField("numrows", $this->numrows, 1);
         $aset = $this->listobject->adminsetuparray[get_class($this)];
         foreach (array_keys($aset['column info']) as $tc) {
            $props[$tc] = $this->getProp($tc);
         }
         $formatted = showFormVars($this->listobject,$props,$aset,0, 1, 0, 0, 1, 0, -1, NULL, 1);
         
         $innerHTML .= "<table><tr>";
         $innerHTML .= $this->showFormHeader($formatted,$formname, $disabled );
         $innerHTML .= "<hr> ";
         $innerHTML .= $this->showFormBody($formatted,$formname, $disabled );
         $innerHTML .= "<hr> ";
         $innerHTML .= $this->showFormFooter($formatted,$formname, $disabled );
         $innerHTML .= "</tr></table>";
         
         // show the formatted matrix
         //$this->formatMatrix();
         //$innerHTML .= print_r($this->matrix_formatted,1) . "<br>";

         $returnInfo['innerHTML'] = $innerHTML;

         return $returnInfo;

      }
   }
   
   function init() {
      parent::init();
      if ($this->debug) {
         $this->logDebug("init() method set variables to " . print_r($this->state,1) . "<br>");
      }
   }

   function wake() {
      parent::wake();
      $this->setupMatrix();
      // set up the matrix for this element
   } 
   
   function sleep() {
      parent::sleep();
      // set up the matrix for this element
      unset($this->storage_matrix);
      $this->storage_matrix = -1;
   }
   
   function setupMatrix() {
      $this->storage_matrix = new dataMatrix;
      $this->storage_matrix->name = 'storage_stage_area';
      $this->storage_matrix->wake();
      $this->storage_matrix->numcols = 3;
      $this->storage_matrix->fixed_cols = true;
      $this->storage_matrix->valuetype = 2; // 1 column lookup (col & row)
      $this->storage_matrix->keycol1 = ''; // key for 1st lookup variable
      $this->storage_matrix->lutype1 = 1; // lookup type - stair step
      $this->storage_matrix->keycol2 = ''; // key for 1st lookup variable
      $this->storage_matrix->lutype2 = 1; // lookup type - stair step
      // add a row for the header line
      if ( !is_array($this->matrix) or (count($this->matrix) == 0)) {
         $this->matrix = array(0,0);
         $this->storage_matrix->numrows = 3;
         $this->storage_matrix->matrix[] = 'storage';
         $this->storage_matrix->matrix[] = 'stage';
         $this->storage_matrix->matrix[] = 'surface_area';
         $this->storage_matrix->matrix[] = 0; // put a basic sample table - conic
         $this->storage_matrix->matrix[] = 0; // put a basic sample table - conic
         $this->storage_matrix->matrix[] = 0; // put a basic sample table - conic
         $this->storage_matrix->matrix[] = $this->maxcapacity; // put a basic sample table - conic
         $this->storage_matrix->matrix[] = 0.0; // put a basic sample table - conic
         $this->storage_matrix->matrix[] = 0.0; // put a basic sample table - conic
      } else {
         $this->storage_matrix->matrix = $this->matrix;// map the text mo to a numerical description
         $this->storage_matrix->numrows = count($this->storage_matrix->matrix) / 3.0;
      }
      
      $this->addOperator('storage_stage_area', $this->storage_matrix, 0);
   }
   
   function getInputs() {
      parent::getInputs();
      if ($this->debug) {
         $this->logDebug("Initial variables on this object " . print_r($this->state,1) . "<br>");
      }
      if ($this->debug) {
         $this->logDebug("Variables from parent " . print_r($this->arData,1) . "<br>");
      }
      // now, overwrite crucial variables from parent to this objects state array
      foreach ($this->rvars as $thisvar) {
         if ($thisvar == 'release') {
            $this->setStateVar('flowby',$this->arData['release']);
         } else {
            if (isset($this->$thisvar)) {
               if ($this->debug) {
                  $this->logDebug("Setting variable " . $thisvar . " to parent value: " . $this->arData[$this->$thisvar] . "<br>");
               }
               $this->setStateVar($thisvar,$this->arData[$this->$thisvar]);
            } else {
               if ($this->debug) {
                  $this->logDebug("can not find variable " . $this->$thisvar . "<br>");
               }
            }
         }
      }
      if ($this->debug) {
         $this->logDebug("Final variables on this object " . print_r($this->state,1) . "<br>");
      }
   }
   
   function step() {
      parent::step();
      $this->value = $this->state['Qout'];
      $this->writeToParent();
   }
   
   function showFormHeader($formatted,$formname, $disabled = 0) {
      $innerHTML .= "<b>Name:</b> " . $formatted->formpieces['fields']['name'] . " | ";
      $innerHTML .= "<b>Debug Mode?:</b> " . $formatted->formpieces['fields']['debug'] . " | ";
      $innerHTML .= "<b>Exec. Rank:</b> " . $formatted->formpieces['fields']['exec_hierarch'] . "<BR>";
      $innerHTML .= "<b>Description:</b> " . $formatted->formpieces['fields']['description'];
      $innerHTML .= "<br><b>Init Storage:</b> " . $formatted->formpieces['fields']['initstorage'];
      $innerHTML .= " | <b>Max Storage:</b> " . $formatted->formpieces['fields']['maxcapacity'];
      $innerHTML .= " | <b>Dead Storage:</b> " . $formatted->formpieces['fields']['unusable_storage'];
      return $innerHTML;
   }
   
   function showFormBody($formatted,$formname, $disabled = 0) {
      $innerHTML .= "<table><tr>";
      $innerHTML .= "<td valign=top>";
      $innerHTML .= "<b>Impoundment Geometry:</b> <br>";
      //$this->storage_matrix->debug = 1;
      $innerHTML .= $this->storage_matrix->showFormBody($formatted,$formname, $disabled);
      $innerHTML .= "</td>";
      $innerHTML .= "<td valign=top>";
      $innerHTML .= "<b>Inflow (cfs):</b> " . $formatted->formpieces['fields']['Qin'];
      $innerHTML .= "<br><b>Refill (MGD):</b> " . $formatted->formpieces['fields']['refill'];
      $innerHTML .= "<br><b>Demand (MGD):</b> " . $formatted->formpieces['fields']['demand'];
      $innerHTML .= "<br><b>ET (in/day):</b> " . $formatted->formpieces['fields']['et_in'];
      $innerHTML .= "<br><b>Precip (in/day):</b> " . $formatted->formpieces['fields']['precip_in'];
      $innerHTML .= "<br><b>Release (cfs):</b> " . $formatted->formpieces['fields']['release'];
      $innerHTML .= "</td>";
      return $innerHTML;
   }
   
   function showFormFooter($formatted,$formname, $disabled = 0) {
      $innerHTML = '';
      
      $innerHTML .= $formatted->formpieces['fields']['enable_cfb'];
      $innerHTML .= " Set flowby to " . $formatted->formpieces['fields']['cfb_var'];
      $innerHTML .= " if " . $formatted->formpieces['fields']['cfb_condition'];
      $innerHTML .= " calculated flow-by <br>";
      return $innerHTML;
   }
   
}


class wsp_flowby extends modelSubObject {
   // this is a general purpose class for a simple flow-by
   // other, more complicated flow-bys will inherit this class
   
   var $enable_conservation = 0;
   var $cc_watch = 0.05;
   var $cc_warning = 0.1;
   var $cc_emergency = 0.15;
   var $custom_conservation = 0;
   var $custom_cons_var = '';
   var $enable_cfb = 0; // cfb = Conditional Flow By (like, the calculated flowby OR inflow whichever is less
   var $cfb_condition = 'lt';
   var $cfb_var = '';
   var $flowby_value = 0.0;
   var $flowby_eqn = 0.0;
   var $name = 'flowby';

   function showEditForm($formname, $disabled=0) {
      if (is_object($this->listobject)) {

         $returnInfo = array();
         $returnInfo['name'] = $this->name;
         $returnInfo['description'] = $this->description;
         $returnInfo['debug'] = '';
         $returnInfo['elemtype'] = get_class($this);
         $returnInfo['innerHTML'] = '';

         //$props = (array)$this;
         $innerHTML = '';

         # set up div to contain each seperate multi-parameter block
         $innerHTML .= showHiddenField("numrows", $this->numrows, 1);
         $aset = $this->listobject->adminsetuparray[get_class($this)];
         foreach (array_keys($aset['column info']) as $tc) {
            $props[$tc] = $this->getProp($tc);
         }
         $formatted = showFormVars($this->listobject,$props,$aset,0, 1, 0, 0, 1, 0, -1, NULL, 1);
         
         $innerHTML .= "<table><tr>";
         $innerHTML .= $this->showFormHeader($formatted,$formname, $disabled );
         $innerHTML .= "<hr> ";
         $innerHTML .= $this->showFormFlowby($formatted,$formname, $disabled );
         $innerHTML .= "<hr> ";
         $innerHTML .= $this->showFormFooter($formatted,$formname, $disabled );
         $innerHTML .= "</tr></table>";
         
         // show the formatted matrix
         //$this->formatMatrix();
         //$innerHTML .= print_r($this->matrix_formatted,1) . "<br>";

         $returnInfo['innerHTML'] = $innerHTML;

         return $returnInfo;

      }
   }
   
   function init() {
      parent::init();
      $flow_eqn = new Equation;
      $flow_eqn->equation = $this->flowby_eqn;
      $flow_eqn->debug = $this->debug;
      $this->addOperator('flowby_calc', $flow_eqn, 0);
   }
   
   function step() {
      parent::step();
      // is conservation enabled?
      // if so, which conservation mode (local or custom defined)
      // is this an either/or flow-by?
      // if so, make either or comparison and decide
      // set property $this->state['flowby_value'];
   }
   
   function evaluate() {
      
      // flowby has already been set
      $this->state['flowby_values'] = $this->state['flowby_calc'];
      $this->result = $this->state['flowby_calc'];
      if ($this->debug) {
         $this->logDebug("Checking to see if extra condition is enabled: $this->enable_cfb <br>");
      }
      if ($this->enable_cfb <> 0) {
         $this->evaluateExtraCondition();
      }
      
   }
   
   function evaluateExtraCondition() {
      $flowby = $this->result;
      if ($this->debug) {
         $this->logDebug("Evaluating additional flowby condition flowby $this->cfb_condition $this->cfb_var <br>");
      }
      if (isset($this->arData[$this->cfb_var])) {
         $cfb_val = $this->arData[$this->cfb_var];
         if ($this->debug) {
            $this->logDebug("Condtional variable value = $cfb_val <br>");
         }
         switch ($this->cfb_condition) {
            case 'lt':
            // calculated flowby or $cfb_val whichever is SMALLER
            if ($flowby > $cfb_val) {
               if ($this->debug) {
                  $this->logDebug("Condition met: $flowby > $cfb_val <br>");
               }
               $flowby = $cfb_val;
            }
            break;

            case 'gt':
            // calculated flowby or $cfb_val whichever is LARGER
            if ($flowby < $cfb_val) {
               if ($this->debug) {
                  $this->logDebug("Condition met: $flowby < $cfb_val <br>");
               }
               $flowby = $cfb_val;
            }
            break;
         }
      }
      $this->result = $flowby;
   }
   
   function showFormHeader($formatted,$formname, $disabled = 0) {
      $innerHTML .= "<b>Name:</b> " . $formatted->formpieces['fields']['name'] . " | ";
      $innerHTML .= "<b>Debug Mode?:</b> " . $formatted->formpieces['fields']['debug'] . " | ";
      $innerHTML .= "<b>Exec. Rank:</b> " . $formatted->formpieces['fields']['exec_hierarch'] . "<BR>";
      $innerHTML .= "<b>Description:</b> " . $formatted->formpieces['fields']['description'];
      return $innerHTML;
   }
   
   function showFormFlowby($formatted,$formname, $disabled = 0) {
      $innerHTML .= "<b>Flow-by Value:</b> " . $formatted->formpieces['fields']['flowby_eqn'];
      return $innerHTML;
   }
   
   function showFormFooter($formatted,$formname, $disabled = 0) {
      $innerHTML = '';
      
      $innerHTML .= $formatted->formpieces['fields']['enable_cfb'];
      $innerHTML .= " Set flowby to " . $formatted->formpieces['fields']['cfb_var'];
      $innerHTML .= " if " . $formatted->formpieces['fields']['cfb_condition'];
      $innerHTML .= " calculated flow-by <br>";
      return $innerHTML;
   }
   
}

class wsp_1tierflowby extends wsp_flowby {
   // this is a general purpose class for a simple flow-by
   // other, more complicated flow-bys will inherit this class
   
   var $enable_conservation = 0;
   var $cc_watch = 0.05;
   var $cc_warning = 0.1;
   var $cc_emergency = 0.15;
   var $custom_conservation = 0;
   var $custom_cons_var = '';
   var $enable_cfb = 0; // cfb = Conditional Flow By (like, the calculated flowby OR inflow whichever is less
   var $cfb_condition = 'lt';
   var $cfb_var = '';
   var $tier_var = '';
   var $flowby_value = 0.0;
   var $flowby_eqn = 0.0;
   var $name = 'flowby';
   var $rule_matrix = -1;
   var $matrix = array();
   var $serialist = 'matrix'; # tells routines to serialize this before storing in XML

   function showEditForm($formname, $disabled=0) {
      if (is_object($this->listobject)) {

         $returnInfo = array();
         $returnInfo['name'] = $this->name;
         $returnInfo['description'] = $this->description;
         $returnInfo['debug'] = '';
         $returnInfo['elemtype'] = get_class($this);
         $returnInfo['innerHTML'] = '';

         //$props = (array)$this;
         $innerHTML = '';

         # set up div to contain each seperate multi-parameter block
         $innerHTML .= showHiddenField("numrows", $this->numrows, 1);
         $aset = $this->listobject->adminsetuparray[get_class($this)];
         foreach (array_keys($aset['column info']) as $tc) {
            $props[$tc] = $this->getProp($tc);
         }
         $formatted = showFormVars($this->listobject,$props,$aset,0, 1, 0, 0, 1, 0, -1, NULL, 1);
         
         $innerHTML .= "<table><tr><td>";
         $innerHTML .= $this->showFormHeader($formatted,$formname, $disabled );
         $innerHTML .= "<hr> ";
         $innerHTML .= $this->showFormFlowby($formatted,$formname, $disabled);
         $innerHTML .= $this->rule_matrix->showFormBody($formatted,$formname, $disabled);
         $innerHTML .= "<hr> ";
         //$innerHTML .= "Stored values for matrix " . print_r($this->matrix,1) . "<br>";
         //$innerHTML .= "Matrix object values " . print_r($this->rule_matrix->matrix,1) . "<br>";
         $innerHTML .= $this->showFormFooter($formatted,$formname, $disabled);
         $innerHTML .= "</td></tr></table>";
         
         // show the formatted matrix
         //$this->formatMatrix();
         //$innerHTML .= print_r($this->matrix_formatted,1) . "<br>";

         $returnInfo['innerHTML'] = $innerHTML;

         return $returnInfo;

      }
   }
   
   function wake() {
      parent::wake();
      $this->setupMatrix();
      // set up the matrix for this element
   }
   
   function setupMatrix() {
      $this->rule_matrix = new dataMatrix;
      $this->rule_matrix->name = 'flowby';
      $this->rule_matrix->wake();
      $this->rule_matrix->numcols = 2;
      $this->rule_matrix->fixed_cols = true;
      $this->rule_matrix->valuetype = 1; // 1 column lookup (col & row)
      $this->rule_matrix->keycol1 = $this->cfb_var; // key for 1st lookup variable
      $this->rule_matrix->lutype1 = 2; // lookup type - stair step
      // add a row for the header line
      if ( !is_array($this->matrix) or (count($this->matrix) == 0)) {
         $this->matrix = array(0,0);
      }
      $this->rule_matrix->numrows = count($this->matrix) / 2.0;
      $this->rule_matrix->matrix = $this->matrix;// map the text mo to a numerical description
      $this->addOperator('rule_matrix', $this->rule_matrix, 0);
   }
   
   function sleep() {
      parent::sleep();
      // set up the matrix for this element
      unset($this->rule_matrix);
      $this->rule_matrix = -1;
   }
   
   function init() {
      parent::init();
   }
   
   function step() {
      parent::step();
      // is conservation enabled?
      // if so, which conservation mode (local or custom defined)
      // is this an either/or flow-by?
      // if so, make either or comparison and decide
      // set property $this->state['flowby_value'];
      // do historic
      $flowby = 0.0;
      if ($this->debug) {
         $this->logDebug("<b>Evaluating Tiered Flow-by: </b> <br>");
      }
      if (isset($this->processors['rule_matrix'])) {
         $rules = $this->processors['rule_matrix']->matrix_rowcol;
         if ($this->debug) {
            $this->logDebug("<b>Evaluating Rules: </b> " . print_r($rules,1) . " <br>");
         }
         $keyval = $this->arData[$this->tier_var];
         $flowby = $this->processors['rule_matrix']->evaluateMatrix($keyval);
         if ($this->debug) {
            $this->logDebug("<b>Flow-by key variable: </b> $this->tier_var, value = $keyval, flowby = $flowby<br>");
         }
      }
      $this->state['rule_matrix'] = $flowby;
      $this->result = $flowby;
   }
   
   function evaluate() {
      
      // flowby has already been set
      $this->result = $this->state['rule_matrix'];
      // added to insure continuity
      $this->processors['flowby_calc']->result = $this->state['rule_matrix'];
      $this->state['flowby_calc'] = $this->state['rule_matrix'];
      if ($this->enable_cfb <> 0) {
         $this->evaluateExtraCondition();
      }
      
   }
   
   function showFormHeader($formatted,$formname, $disabled = 0) {
      $innerHTML .= "<b>Name:</b> " . $formatted->formpieces['fields']['name'] . " | ";
      $innerHTML .= "<b>Debug Mode?:</b> " . $formatted->formpieces['fields']['debug'] . " | ";
      $innerHTML .= "<b>Exec. Rank:</b> " . $formatted->formpieces['fields']['exec_hierarch'] . "<BR>";
      $innerHTML .= "<b>Description:</b> " . $formatted->formpieces['fields']['description'];
      return $innerHTML;
   }
   
   function showFormFlowby($formatted,$formname, $disabled = 0) {
      $innerHTML .= "<b>Tiered Trigger Variable:</b> " . $formatted->formpieces['fields']['tier_var'];
      return $innerHTML;
   }
   
   function showFormFooter($formatted,$formname, $disabled = 0) {
      $innerHTML = '';
      
      $innerHTML .= $formatted->formpieces['fields']['enable_cfb'];
      $innerHTML .= " Set flowby to " . $formatted->formpieces['fields']['cfb_var'];
      $innerHTML .= " if " . $formatted->formpieces['fields']['cfb_condition'];
      $innerHTML .= " calculated flow-by <br>";
      return $innerHTML;
   }
   
}

class wsp_conservation extends modelSubObject {
   // this is a general purpose class for a simple flow-by
   // other, more complicated flow-bys will inherit this class
   
   var $enable_conservation = 'disabled'; // disabled, internal, or custom
   var $cc_watch = 0.05;
   var $cc_warning = 0.1;
   var $cc_emergency = 0.15;
   var $custom_cons_var = '';
   var $status_var = 'drought_status';
   var $name = 'conservation';

   function showEditForm($formname, $disabled=0) {
      if (is_object($this->listobject)) {

         $returnInfo = array();
         $returnInfo['name'] = $this->name;
         $returnInfo['description'] = $this->description;
         $returnInfo['debug'] = '';
         $returnInfo['elemtype'] = get_class($this);
         $returnInfo['innerHTML'] = '';

         //$props = (array)$this;
         $innerHTML = '';

         # set up div to contain each seperate multi-parameter block
         $innerHTML .= showHiddenField("numrows", $this->numrows, 1);
         $aset = $this->listobject->adminsetuparray[get_class($this)];
         foreach (array_keys($aset['column info']) as $tc) {
            $props[$tc] = $this->getProp($tc);
         }
         $formatted = showFormVars($this->listobject,$props,$aset,0, 1, 0, 0, 1, 0, -1, NULL, 1);
         
         $innerHTML .= "<table><tr>";
         $innerHTML .= $this->showFormHeader($formatted,$formname, $disabled);
         $innerHTML .= "<hr> ";
         $innerHTML .= $this->showFormFlowby($formatted,$formname, $disabled);
         $innerHTML .= "<hr> ";
         $innerHTML .= $this->showFormFooter($formatted,$formname, $disabled);
         $innerHTML .= "</tr></table>";
         
         // show the formatted matrix
         //$this->formatMatrix();
         //$innerHTML .= print_r($this->matrix_formatted,1) . "<br>";

         $returnInfo['innerHTML'] = $innerHTML;

         return $returnInfo;

      }
   }
   
   function init() {
      parent::init();
   }
   
   function step() {
      parent::step();
      // is conservation enabled?
      // if so, which conservation mode (local or custom defined)
      // is this an either/or flow-by?
      // if so, make either or comparison and decide
      // set property $this->state['flowby_value'];
      switch ($this->state['enable_conservation']) {
         case 'disabled':
         $reduction = 0;
         break;
         case 'internal':
         switch ($this->state[$this->status_var]) {
            case '1':
            $pct = floatval($this->cc_warning);
            break;
            case '2':
            $pct = floatval($this->cc_watch);
            break;
            case '3':
            $pct = floatval($this->cc_emergency);
            break;
            
            default:
            $pct = 0.0;
            break;
         }
         $reduction = $pct;
         break;
         case 'custom':
         $reduction = $this->state[$this->custom_cons_var];
         break;
      }
         
   }
   
   function evaluate() {
      
      // flowby has already been set
      $this->result = $this->state['reduction'];
      
   }
   
   function showFormHeader($formatted,$formname, $disabled = 0) {
      $innerHTML .= "<b>Name:</b> " . $formatted->formpieces['fields']['name'] . " | ";
      $innerHTML .= "<b>Debug Mode?:</b> " . $formatted->formpieces['fields']['debug'] . " | ";
      $innerHTML .= "<b>Exec. Rank:</b> " . $formatted->formpieces['fields']['exec_hierarch'] . "<BR>";
      $innerHTML .= "<b>Description:</b> " . $formatted->formpieces['fields']['description'];
      return $innerHTML;
   }
   
   function showFormFlowby($formatted,$formname, $disabled = 0) {
      $innerHTML .= "<b>Variable Reporting Drought Status:</b> " . $formatted->formpieces['fields']['status_var'];
      return $innerHTML;
   }
   
   function showFormFooter($formatted, $formname, $disabled = 0) {
      $innerHTML = '';
      $cd = '';
      $ci = ''; // internal - standard 3-tiered conservation
      $cc = '';
      switch ($this->enable_conservation) {
         case 'disabled':
         $cd = 'disabled';
         break;
         case 'internal':
         $ci = 'internal';
         break;
         case 'custom':
         $cc = 'custom';
         break;
      }

      $innerHTML .= showRadioButton('enable_conservation', 'disabled', $cd, '', 1, 0, '');      
      $innerHTML .= " Disable Conservation <br>";
      //$innerHTML .= $formatted->formpieces['fields']['enable_conservation'];
      $innerHTML .= showRadioButton('enable_conservation', 'internal', $ci, '', 1, 0, '');
      $innerHTML .= " Enable Conservation, % reduction Watch: " . $formatted->formpieces['fields']['cc_watch'];
      $innerHTML .= ", Warn: " . $formatted->formpieces['fields']['cc_warning'];
      $innerHTML .= ", Emerg: " . $formatted->formpieces['fields']['cc_emergency'] . "<BR>";
      //$innerHTML .= $formatted->formpieces['fields']['custom_conservation'];
      $innerHTML .= showRadioButton('enable_conservation', 'custom', $cc, '', 1, 0, '');
      $innerHTML .= " Use Custom Conservation Variable " . $formatted->formpieces['fields']['custom_cons_var'];
      return $innerHTML;
   }
   
}

class efdata_alife extends blankShell {
   // time series for withdrawal data, based on objects geometry
   function wake() {
      parent::wake();
   }
   
   function init() {
      parent::init();
   }   
}
class efdata_flow extends blankShell {
   // time series for withdrawal data, based on objects geometry
   function wake() {
      parent::wake();
   }
   
   function init() {
      parent::init();
   }   
}
class efdata_hydro extends blankShell {
   // time series for withdrawal data, based on objects geometry
   function wake() {
      parent::wake();
   }
   
   function init() {
      parent::init();
   }   
}
class efdata_wqual extends blankShell {
   // time series for withdrawal data, based on objects geometry
   function wake() {
      parent::wake();
   }
   
   function init() {
      parent::init();
   }   
}

// ***************************************************************************
// *********            Water Withdrawal Rule Components           ***********
// ***************************************************************************

class withdrawalRuleObject extends blankShell {
   var $max_annual_mg = 0;
   var $max_daily_mgd = 0;
   var $max_instant_mgd = 0;
   var $flowby;
   var $flowby_type = 1; // 1 - simple rate flowby, 2 - simple percentage flowby, 3 - simple tiered rate, 4 - simple tiered percent, 5 - monthly tiered rate, 6 - monthly tiered percent
   var $Qstream = 0; // this should be overridden by an input
   var $demand_mgd = 0;
   var $allowed_wd_mgd = 0;
   
   function wake() {
      parent::wake();
      $this->prop_desc['max_annual_mg'] = 'Maximum Total Annual Withdrawal Volume (Millions of Gallons). This is disabled if set to 0.0';
      $this->prop_desc['max_daily_mgd'] = 'Maximum Daily Withdrawal Rate (MGD).  This is disabled if set to 0.0';
      $this->prop_desc['max_instant_mgd'] = 'Maximum Instantaneous Withdrawal Rate (MGD). This is disabled if set to 0.0';
      $this->prop_desc['flowby'] = 'Rate of flow remaining in source stream after withdrawal (cfs).';
      $this->prop_desc['Qstream'] = 'Current rate of flow in source stream.  This variable should be populated by a link to the indicator stream object (cfs).';
      $this->prop_desc['demand_mgd'] = 'Current rate of desired withdrawal.  This variable may be over-written by a link to another use object (MGD).';
      $this->prop_desc['allowed_wd_mgd'] = 'Current rate of allowed withdrawal after rule evaluation. (MGD).';
   }
      

   function setState() {
      parent::setState();
      $this->state['max_annual_mg'] = $this->max_annual_mg;
      $this->state['max_daily_mgd'] = $this->max_daily_mgd;
      $this->state['max_instant_mgd'] = $this->max_instant_mgd;
      $this->state['flowby'] = $this->flowby;
      $this->state['Qstream'] = $this->flowby;
      $this->state['demand_mgd'] = $this->demand_mgd;
      $this->state['allowed_wd_mgd'] = $this->allowed_wd_mgd;
   }
   
   function setDataColumnTypes() {
      parent::setDataColumnTypes();
      
      $statenums = array('max_annual_mg', 'max_daily_mgd','max_instant_mgd', 'flowby', 'Qstream','demand_mgd','allowed_wd_mgd');
      foreach ($statenums as $thiscol) {
         $this->dbcolumntypes[$thiscol] = 'float8';
         $this->logformats[$thiscol] = '%s';
         $this->data_cols[] = $thiscol;
      }
   }
   
   
   function create() {
      parent::create();
      // set up stock items, based on the flowby_type
      if ($this->debug) {
         $this->logDebug("Create() function called <br>");
      }
      $this->addFlowByVars();
      $this->logDebug("Processors on this object: " . print_r(array_keys($this->processors),1) . " <br>");
   }
   
   function step() {
      // all step methods MUST call preStep(),execProcessors(), postStep()
      $this->preStep();
      if ($this->debug) {
         $this->logDebug("$this->name Inputs obtained. thisdate = " . $this->state['thisdate']);
      }
      // execute sub-components
      $this->execProcessors();
      
      if ( isset($this->processors['demand_mgd']) or isset($this->inputs['demand_mgd']) ) {
         // let the custom processor handle this
         $demand_mgd = $this->state['demand_mgd']; 
      } else {
         $demand_mgd = $this->max_daily_mgd;
      }
      // verify that the withdrawal does not violate the annual, instant and daily limits
      // for now we just compare to instantaneous limit, but we should keep a running 
      // tally of the total per day, or per year and restrict if those are exceeded
      if ( ($demand_mgd > $this->max_instant_mgd) ) {
         $demand_mgd = $this->max_instant_mgd;
      }
      
      if (isset($this->processors['allowed_wd_mgd'])) {
         // let the custom processor handle this
         $aw = $this->state['allowed_wd_mgd']; 
      } else {
         // otherwise, do it here
         $excess_mgd = ($this->state['Qstream'] - $this->state['flowby']) / 1.547;
         if ($excess_mgd > 0) {
            $aw = min( $excess_mgd, $demand_mgd);
         } else {
            $aw = 0.0;
         }
      }

      $state['demand_mgd'] = $demand_mgd;
      $state['allowed_wd_mgd'] = $aw;
      $this->postStep();
   }
   
   
   function addFlowByVars() {
      // 1 - simple rate flowby, 2 - simple percentage flowby, 3 - simple tiered rate, 4 - simple tiered percent, 5 - monthly tiered rate, 6 - monthly tiered percent
      switch ($this->flowby_type) {
         case 1:
         // just a single equation
         $this->addSimpleFlowBy();
         break;
         
         case 2:
         $this->addSimplePercentFlowBy();
         break;
      }
      
      // add conservation triggers
      //$this->addConservation();
   }
   
   function addSimpleFlowBy() {
      if (isset($this->processors['flowby'])) {
         unset($this->processors['flowby']);
      }
      // simple rate based flowby
      $flowby = new Equation;
      $flowby->name = 'flowby';
      $flowby->wake();
      $flowby->equation = 0.0;
      $flowby->defaultval = 0.0;
      $flowby->nanvalue = 0.0;
      $flowby->strictnull = 0;
      $flowby->nonnegative = 1;
      $flowby->minvalue = 0.0;
   
      $this->logDebug("Trying to add simple flowby <br>");
      $this->addOperator('flowby', $flowby, 0);
   }
   
   function addSimplePercentFlowBy() {            
      // simple percent based flowby
      $diversion_pct = new Equation;
      $diversion_pct->name = 'diversion_pct';
      $diversion_pct->decription = 'Allowable percentage diversion, used to caluclate flow by';
      $diversion_pct->wake();
      $diversion_pct->equation = '0.1';
      $diversion_pct->defaultval = 0.0;
      $diversion_pct->nanvalue = 0.0;
      $diversion_pct->strictnull = 0;
      $diversion_pct->nonnegative = 1;
      $diversion_pct->minvalue = 0.0;
   
      $this->logDebug("Trying to add simple diversion_pct <br>");
      $this->addOperator('diversion_pct', $diversion_pct, 0);
      
      $flowby = new Equation;
      $flowby->name = 'flowby';
      $flowby->wake();
      $flowby->equation = 'Qstream * (1.0 - diversion_pct)';
      $flowby->defaultval = 0.0;
      $flowby->nanvalue = 0.0;
      $flowby->strictnull = 0;
      $flowby->nonnegative = 1;
      $flowby->minvalue = 0.0;
   
      $this->logDebug("Trying to add simple flowby <br>");
      $this->addOperator('flowby', $flowby, 0);
   }
   
   function addConservation() {            
      // landuse subcomponent to allow users to simulate land use values
      $base_rows = array(
         0=>array('Surface Name'=>'Roof','area(sqft)'=>0,'Imp Frac'=>1.0, 'Capture Frac'=>0.9),
         1=>array('Surface Name'=>'Driveway','area(sqft)'=>0,'Imp Frac'=>1.0, 'Capture Frac'=>0.5),
         2=>array('Surface Name'=>'Patio','area(sqft)'=>0,'Imp Frac'=>1.0, 'Capture Frac'=>0.5)
      );
      $surface_cols = array_keys($base_rows[0]);
      $surface = new dataMatrix;
      $surface->name = 'usetypes';
      $surface->wake();
      $surface->numcols = count($surface_cols);  
      $surface->valuetype = 2; // 2 column lookup (col & row)
      $surface->keycol1 = ''; // key for 1st lookup variable
      $surface->lutype1 = 0; // lookp type - exact match for land use name
      $surface->keycol2 = ''; // key for 2nd lookup variable
      $surface->lutype2 = 0; // lookup type - interpolated for year value
      // add a row for the header line and default entries
      $surface->numrows = count($base_rows) + 1;
      // since these are stored as a single dimensioned array, regardless of their lookup type 
      // (for compatibility with single dimensional HTML form variables)
      // we set alternating values representing the 2 columns (luname - acreage)
      foreach ($surface_cols as $thisvar) {
         $surface->matrix[] = $thisvar;
      }
      // now add blanks the basic types individual records
      foreach ($base_rows as $thisrow) {
         foreach ($surface_cols as $thisvar) {
            $surface->matrix[] = $thisrow[$thisvar];
         }
      }
      $this->logDebug("Trying to add surface matrix with values: " . print_r($surface->matrix,1) . " <br>");
      $this->addOperator('surfaces', $surface, 0);
   }
   
   function addTieredFlowBy() {            
      // landuse subcomponent to allow users to simulate land use values
      $base_rows = array(
         0=>array('Surface Name'=>'Roof','area(sqft)'=>0,'Imp Frac'=>1.0, 'Capture Frac'=>0.9),
         1=>array('Surface Name'=>'Driveway','area(sqft)'=>0,'Imp Frac'=>1.0, 'Capture Frac'=>0.5),
         2=>array('Surface Name'=>'Patio','area(sqft)'=>0,'Imp Frac'=>1.0, 'Capture Frac'=>0.5)
      );
      $surface_cols = array_keys($base_rows[0]);
      $surface = new dataMatrix;
      $surface->name = 'usetypes';
      $surface->wake();
      $surface->numcols = count($surface_cols);  
      $surface->valuetype = 2; // 2 column lookup (col & row)
      $surface->keycol1 = ''; // key for 1st lookup variable
      $surface->lutype1 = 0; // lookp type - exact match for land use name
      $surface->keycol2 = ''; // key for 2nd lookup variable
      $surface->lutype2 = 0; // lookup type - interpolated for year value
      // add a row for the header line and default entries
      $surface->numrows = count($base_rows) + 1;
      // since these are stored as a single dimensioned array, regardless of their lookup type 
      // (for compatibility with single dimensional HTML form variables)
      // we set alternating values representing the 2 columns (luname - acreage)
      foreach ($surface_cols as $thisvar) {
         $surface->matrix[] = $thisvar;
      }
      // now add blanks the basic types individual records
      foreach ($base_rows as $thisrow) {
         foreach ($surface_cols as $thisvar) {
            $surface->matrix[] = $thisrow[$thisvar];
         }
      }
      $this->logDebug("Trying to add surface matrix with values: " . print_r($surface->matrix,1) . " <br>");
      $this->addOperator('surfaces', $surface, 0);
   }
}


// ***************************************************************************
// *********              Rainfall harvesting Components           ***********
// ***************************************************************************

class genericLandSurface extends blankShell {
   var $surface_cols;
   
   function wake() {
      parent::wake();
      $this->prop_desc['rainfall_in'] = 'Rainfall rate of input to this surface object (inches/day).';
      $this->prop_desc['imp_runoff'] = 'Runoff from impervious portion of this area (cfs).';
      $this->prop_desc['imp_runoff_gpm'] = 'Runoff from impervious portion of this area (Gal/min).';
      $this->prop_desc['imp_capture'] = 'Flows from impervious portion of this area that are captured by cistern (cfs)';
      $this->prop_desc['imp_capture_gpm'] = 'Flows from impervious portion of this area that are captured by cistern (Gal/min)';
      $this->prop_desc['area'] = 'Channel mainstem length (ft).';
   }
      

   function setState() {
      parent::setState();
      $this->state['imp_runoff'] = 0.0;
      $this->state['imp_capture'] = 0.0;
      $this->state['imp_runoff_gpm'] = 0.0;
      $this->state['imp_capture_gpm'] = 0.0;
      $this->state['area'] = 0.0;
      $this->state['rainfall_in'] = 0.0;
   }
   
   function setDataColumnTypes() {
      parent::setDataColumnTypes();
      
      $statenums = array('imp_runoff_gpm', 'imp_capture_gpm','imp_runoff', 'imp_capture','area', 'rainfall_in');
      foreach ($statenums as $thiscol) {
         $this->dbcolumntypes[$thiscol] = 'float8';
         $this->logformats[$thiscol] = '%s';
         $this->data_cols[] = $thiscol;
      }
   }
   
   
   function create() {
      parent::create();
      // set default land use
      $this->logDebug("Create() function called <br>");
      // add use types
      $this->addSurfaceComponent();
      $this->logDebug("Processors on this object: " . print_r(array_keys($this->processors),1) . " <br>");
   }
   
   function step() {
      parent::step();
      $this->calcFlows();
   }
   
   function calcFlows() {
      $this->logDebug("calcFlows() function called <br>");
      // add use types
      // sum up all surface areas, and percent impervious
      // search inputs/statevars for precip input
      // calculate total volume inflow from impervious to capture, non-capture routes
      // set values on parent for those quantities:
      //  - imp_detained (cubic feet)
      //  - imp_runoff (cubic feet)
      $dt = $this->timer->dt;
      $rainfall = $this->state['rainfall_in'];
      $imp_capture = 0.0;
      $imp_runoff = 0.0;
      $area = 0.0;
      $surface_names = array_keys($this->processors['surfaces']->matrix_formatted);
      foreach ($surface_names as $thisname) {
         
         $area += $this->processors['surfaces']->evaluateMatrix($thisname, 'area(sqft)');
         $imp_frac = $this->processors['surfaces']->evaluateMatrix($thisname, 'Imp Frac');
         $cap_frac = $this->processors['surfaces']->evaluateMatrix($thisname, 'Capture Frac');
         // $rainfall/12 = feet per day, ($dt/86400) = % of a day = cubic-feet per time step
         if ($this->debug) {
            $this->logDebug("Surface $surface_name, imp_capture += area * imp_frac * cap_frac * rainfall / ( 86400.0 * 12.0); <br>\n");
            $this->logDebug(" $imp_capture += $area * $imp_frac * $cap_frac * $rainfall / ( 86400.0 * 12.0); <br>\n");
         }
         $imp_capture += $area * $imp_frac * $cap_frac * $rainfall / ( 86400.0 * 12.0);
         if ($this->debug) {
            $this->logDebug(" imp_capture = $imp_capture <br>\n");
         }
         // add in the part of the 
         $imp_runoff += $area * $imp_frac * (1.0 - $cap_frac) * $rainfall / ( 86400.0 * 12.0);
      }
      $this->state['imp_runoff'] = $imp_runoff;
      $this->state['imp_runoff_gpm'] = $imp_runoff * 448.8; //448.8 is conversion from cfs to gpm
      $this->state['imp_capture'] = $imp_capture;
      $this->state['imp_capture_gpm'] = $imp_capture * 448.8; //448.8 is conversion from cfs to gpm
      $this->state['area'] = $area;
      $this->logDebug("Flows calculated: Imp RO: $imp_runoff, Imp Capture: $imp_capture <br>");
   }
   
   function addSurfaceComponent() {
      if (isset($this->processors['surfaces'])) {
         unset($this->processors['surfaces']);
      }
      // landuse subcomponent to allow users to simulate land use values
      $base_rows = array(
         0=>array('Surface Name'=>'Roof','area(sqft)'=>0,'Imp Frac'=>1.0, 'Capture Frac'=>0.9),
         1=>array('Surface Name'=>'Driveway','area(sqft)'=>0,'Imp Frac'=>1.0, 'Capture Frac'=>0.5),
         2=>array('Surface Name'=>'Patio','area(sqft)'=>0,'Imp Frac'=>1.0, 'Capture Frac'=>0.5)
      );
      $surface_cols = array_keys($base_rows[0]);
      $surface = new dataMatrix;
      $surface->name = 'usetypes';
      $surface->wake();
      $surface->numcols = count($surface_cols);  
      $surface->valuetype = 2; // 2 column lookup (col & row)
      $surface->keycol1 = ''; // key for 1st lookup variable
      $surface->lutype1 = 0; // lookp type - exact match for land use name
      $surface->keycol2 = ''; // key for 2nd lookup variable
      $surface->lutype2 = 0; // lookup type - interpolated for year value
      // add a row for the header line and default entries
      $surface->numrows = count($base_rows) + 1;
      // since these are stored as a single dimensioned array, regardless of their lookup type 
      // (for compatibility with single dimensional HTML form variables)
      // we set alternating values representing the 2 columns (luname - acreage)
      foreach ($surface_cols as $thisvar) {
         $surface->matrix[] = $thisvar;
      }
      // now add blanks the basic types individual records
      foreach ($base_rows as $thisrow) {
         foreach ($surface_cols as $thisvar) {
            $surface->matrix[] = $thisrow[$thisvar];
         }
      }
      $this->logDebug("Trying to add surface matrix with values: " . print_r($surface->matrix,1) . " <br>");
      $this->addOperator('surfaces', $surface, 0);
   }
}

class genericDwelling extends blankShell {
   var $occupants = 1.0;
   
   function wake() {
      parent::wake();
      $this->prop_desc['Use PPPD'] = '# of Uses Per Person Per Day.';
      $this->prop_desc['use_gpd'] = 'Calculated total use rate in Gallons/day.';
      $this->prop_desc['use_gpm'] = 'Calculated total use rate in Gallons/minute.';
   }
      

   function setState() {
      parent::setState();
      $this->state['occupants'] = $this->occupants;
      $this->state['use_gpd'] = 0.0;
      $this->state['use_gpm'] = 0.0;
   }
   
   function setDataColumnTypes() {
      parent::setDataColumnTypes();
      
      $statenums = array('use_gpm', 'use_gpd', 'occupants');
      foreach ($statenums as $thiscol) {
         $this->dbcolumntypes[$thiscol] = 'float8';
         $this->logformats[$thiscol] = '%s';
         $this->data_cols[] = $thiscol;
      }
   }
   
   
   function create() {
      parent::create();
      // set default land use
      $this->logDebug("Create() function called <br>");
      // add use types
      $this->addUseTypesComponent();
      $this->logDebug("Processors on this object: " . print_r(array_keys($this->processors),1) . " <br>");
   }
   
   function step() {
      parent::step();
      $this->calcFlows();
   }
   
   function calcFlows() {
      $this->logDebug("calcFlows() function called <br>");
      // add use types
      // sum up all surface areas, and percent impervious
      // search inputs/statevars for precip input
      // calculate total volume inflow from impervious to capture, non-capture routes
      // set values on parent for those quantities:
      //  - imp_detained (cubic feet)
      //  - imp_runoff (cubic feet)
      $dt = $this->timer->dt;
      $occupants = $this->state['occupants'];
      
      $use_names = array_keys($this->processors['usetypes']->matrix_formatted);
      $use_gpd = 0.0;
      foreach ($use_names as $thisname) {
         $rate += $this->processors['usetypes']->evaluateMatrix($thisname, 'rate');
         $use_pppd = $this->processors['usetypes']->evaluateMatrix($thisname, 'Use PPPD');
         $pct_cold = $this->processors['usetypes']->evaluateMatrix($thisname, '% cold');
         // use either time rate or use rate, not both - time rate trumps use rate
         $this_use = $rate * $use_pppd * $dt / 86400.0;
         if ($this->debug) {
            $this->logDebug("Use Type $thisname, $this_use Gal/Day <br>");
         }
         $use_gpd += $this_use;
      }
      $this->state['use_gpd'] = $use_gpd;
      $this->state['use_gpm'] = $use_gpd * 60.0 / 86400.0;
      if ($this->debug) {
         $this->logDebug("Uses calculated: $use_gpd Gal/Day<br>");
      }
   }
   
   function addUseTypesComponent() {
      if (isset($this->processors['usetypes'])) {
         unset($this->processors['usetypes']);
      }
      // landuse subcomponent to allow users to simulate land use values
      $base_rows = array(
         0=>array('Fixture'=>'Shower','rate'=>2.5,'rate units'=>'gpm', 'Use PPPD'=>5.0, 'use units'=>'min/day/person','% cold'=>0.40),
         1=>array('Fixture'=>'toilet','rate'=>1.6,'rate units'=>'Gal/use', 'Use PPPD'=>4.0, 'use units'=>'uses/day/person','% cold'=>1.0),
         2=>array('Fixture'=>'dishwasher','rate'=>15.0,'rate units'=>'Gal/use', 'Use PPPD'=>0.42, 'use units'=>'uses/day/person','% cold'=>0.40),
         3=>array('Fixture'=>'clothes washer','rate'=>42.0,'rate units'=>'Gal/use', 'Use PPPD'=>0.42, 'use units'=>'uses/day/person','% cold'=>0.40)
      );
      $usetypes_cols = array_keys($base_rows[0]);
      $usetypes = new dataMatrix;
      $usetypes->name = 'usetypes';
      $usetypes->description = "Types of water uses:  The 'rate' column and the 'Use PPPD' column should be set such that rate*Use_PPPD = gallons/day.  The 'rate units', and 'use units' columns are for descriptive purposes only.";
      $usetypes->wake();
      $usetypes->numcols = count($surface_cols);  
      $usetypes->valuetype = 2; // 2 column lookup (col & row)
      $usetypes->keycol1 = ''; // key for 1st lookup variable
      $usetypes->lutype1 = 0; // lookp type - exact match for land use name
      $usetypes->keycol2 = ''; // key for 2nd lookup variable
      $usetypes->lutype2 = 0; // lookup type - interpolated for year value
      // add a row for the header line and default entries
      $usetypes->numrows = count($base_rows) + 1;
      // since these are stored as a single dimensioned array, regardless of their lookup type 
      // (for compatibility with single dimensional HTML form variables)
      // we set alternating values representing the 2 columns (luname - acreage)
      foreach ($usetypes_cols as $thisvar) {
         $usetypes->matrix[] = $thisvar;
      }
      // now add blanks the basic types individual records
      foreach ($base_rows as $thisrow) {
         foreach ($usetypes_cols as $thisvar) {
            $usetypes->matrix[] = $thisrow[$thisvar];
         }
      }
      $this->logDebug("Trying to add surface matrix with values: " . print_r($surface->matrix,1) . " <br>");
      $this->addOperator('usetypes', $usetypes, 0);
   }
}


class hydroTank extends hydroObject {
   # a generic object, needs a depth/storage/area table
   // this object uses small container friendly numbers, such as gallons, and GPM
   var $maxcapacity = 1000.0;
   var $initstorage = 1000.0;
   var $open_air = 0; // 0 - closed tank, 1 - modeled as open (will include evap)
   
   function wake() {
      parent::wake();
      $this->prop_desc['Qin'] = 'Inflows to this tank (Gal/min).';
      $this->prop_desc['Qout'] = 'Total outflows from this tank - spillage (Gal/min).';
      $this->prop_desc['initstorage'] = 'Initial storage (Gallons).';
      $this->prop_desc['maxcapacity'] = 'Maximum storage (Gallons).';
      $this->prop_desc['demand'] = 'Rate of Water Withdrawal (Gal/min).';
      $this->prop_desc['pan_evap'] = 'Evaporation Rate off the surface area (inches/day) - evap_gpm will be calculated from this.';
      $this->prop_desc['evap_gpm'] = 'Evaporation Rate (Gal/min).';
   }

   function init() {
      parent::init();
      $this->Storage = $this->initstorage;
      $this->state['Storage'] = $this->initstorage;
      $this->state['maxcapacity'] = $this->maxcapacity;
      $this->state['initstorage'] = $this->initstorage;
      $this->state['Qin'] = $this->Qin;
      $this->state['Qout'] = $this->Qout;
      $this->processors['storage_stage_area']->valuetype = 2; // 2 column lookup (col & row)
   }

   function setState() {
      parent::setState();
      $this->state['maxcapacity'] = $this->maxcapacity;
      $this->state['initstorage'] = $this->initstorage;
      $this->state['Qin'] = $this->Qin;
      $this->state['Qout'] = $this->Qout;
      $this->state['pan_evap'] = 0.1;
      $this->state['precip'] = 0.0;
      $this->state['demand'] = 0.0;
      $this->state['evap_gpm'] = 0.0;
   }
   
   function create() {
      parent::create();
      // set up a table for impoundment geometry
      $this->logDebug("Create() function called <br>");
      
      if (isset($this->processors['storage_stage_area'])) {
         unset($this->processors['storage_stage_area']);
      }
      
      // matrix subcomponent to allow users to simulate stage/storage/area tables
      $storage_stage_area = new dataMatrix;
      $storage_stage_area->listobject = $this->listobject;
      $storage_stage_area->name = 'storage_stage_area';
      $storage_stage_area->wake();
      $storage_stage_area->numcols = 3;  
      $storage_stage_area->valuetype = 2; // 2 column lookup (col & row)
      $storage_stage_area->keycol1 = ''; // key for 1st lookup variable
      $storage_stage_area->lutype1 = 1; // lookp type - interpolate for storage
      $storage_stage_area->keycol2 = 'year'; // key for 2nd lookup variable
      $storage_stage_area->lutype2 = 1; // lookup type - interpolated for other values
      // add a row for the header line
      $storage_stage_area->numrows = 3;
      // since these are stored as a single dimensioned array, regardless of their lookup type 
      // (for compatibility with single dimensional HTML form variables)
      // we set alternating values representing the 2 columns (luname - acreage)
      $storage_stage_area->matrix[] = 'storage';
      $storage_stage_area->matrix[] = 'stage';
      $storage_stage_area->matrix[] = 'surface_area';
      $storage_stage_area->matrix[] = 0; // put a basic sample table - conic
      $storage_stage_area->matrix[] = 0; // put a basic sample table - conic
      $storage_stage_area->matrix[] = 0; // put a basic sample table - conic
      $storage_stage_area->matrix[] = $this->maxcapacity; // put a basic sample table - conic
      $storage_stage_area->matrix[] = 0.0; // put a basic sample table - conic
      $storage_stage_area->matrix[] = 0.0; // put a basic sample table - conic
      
      if ($this->debug) {
         $this->logDebug("Trying to add stage-surfacearea-storage sub-component matrix with values: " . print_r($storage_stage_area->matrix,1) . " <br>");
      }
      $this->addOperator('storage_stage_area', $storage_stage_area, 0);
      if ($this->debug) {
         $this->logDebug("Processors on this object: " . print_r(array_keys($this->processors),1) . " <br>");
      }
   }
   
   function step() {
      // all step methods MUST call preStep(),execProcessors(), postStep()
      $this->preStep();
      if ($this->debug) {
         $this->logDebug("$this->name Inputs obtained. thisdate = " . $this->state['thisdate']);
      }
      // execute sub-components
      $this->execProcessors();
      
      if ($this->debug) {
         $this->logDebug("Step Begin state[] array contents " . print_r($this->state,1) . " <br>\n");
      }

      $Q0 = $this->state['Qout']; // outflow during previous timestep
      $S0 = $this->state['Storage']; // storage at end of previous timestep (Gallons)
      $Qin = $this->state['Qin']; // inflow GPM
      $demand = $this->state['demand']; // assumed to be in GPM
      $pan_evap = $this->state['pan_evap']; // assumed to be in inches/day
      $precip = $this->state['precip']; // assumed to be in inches/day
      // this checks to see if the user has subclassed the area and stage(depth) calculations
      // or if it is using the internal routines with the stage/storage/area table
      if (isset($this->processors['area'])) {
         $area = $this->state['area']; // surface area at the beginning of the timestep - assumed to be square feet
      } else {
         // calculate area - in an ideal world, this would be solved simultaneously with the storage
         if (isset($this->processors['storage_stage_area'])) {
            // must have the stage/storage/sarea dataMatrix for this to work
            $stage = $this->processors['storage_stage_area']->evaluateMatrix($S0,'stage');
            $area = $this->processors['storage_stage_area']->evaluateMatrix($S0,'surface_area');
         } else {
            $stage = 0;
            $area = 0;
         }
      }
      $dt = $this->timer->dt; // timestep in seconds
      $max_capacity = $this->maxcapacity;
      
      // we need to include some ability to plug-and-play the evap and other routines to allow users to sub-class it
      // or the components that go into it, such as the storage/depth/surface_area relationships
      // could look at processors, and if any of the properties are sub-classed, just take them as they are
      // also need inputs such as the pan_evap
      // since the processors have already been exec'ed we could just take them, but we could also get fancier
      // and look at each step in the process to see if it has been sub-classed and insert it in the proper place.
      
      // calculate evaporation during this time step - acre-feet per second
      // need estimate of surface area.  SA will vary based on area, but we assume that area is same as last timestep area
      //error_log(" $area * $pan_evap / 12.0 / 86400.0 <br>");
      if ($this->open_air) {
         $evap_gpm = $area * $pan_evap * 60.0 / 12.0 / 86400.0;
         $precip_gpm = $area * $precip * 60.0 / 12.0 / 86400.0; 
      } else {
         $evap_gpm = 0.0;
         $precip_gpm = 0.0;
      }
      
      // change in storage
      $storechange = $S0 + ($Qin * $dt / 60.0) - ($demand * $dt / 60.0) - ($evap_gpm * $dt / 60.0) + ($precip_gpm * dt / 60.0);
      if ($storechange < 0) {
         $storechange = 0;
      }
      $Storage = min(array($storechange, $max_capacity));
      if ($storechange > $max_capacity) {
         $spill = ($storechange - $max_capacity) * 43560.0 / $dt;
      } else {
         $spill = 0;
      }
      $Qout = $spill;
      
      // local unit conversion dealios
      $this->state['evap_gpm'] = $evap_gpm;
      $this->state['pct_use_remain'] = $Storage / $this->state['maxcapacity'];

      $this->state['Storage'] = $Storage;
      $this->state['Qout'] = $Qout;
      $this->state['depth'] = $stage;
      $this->state['Storage'] = $Storage;
      $this->state['spill'] = $spill;
      $this->state['area'] = $area;
      
      $this->postStep();
      
      if ($this->debug) {
         $this->logDebug("Step END state[] array contents " . print_r($this->state,1) . " <br>\n");
      }
   }

   function getPublicProps() {
      # gets only properties that are visible (must be manually defined)
      $publix = parent::getPublicProps();

      array_push($publix, 'Storage');
      array_push($publix, 'depth');
      array_push($publix, 'maxcapacity');
      array_push($publix, 'initstorage');
      array_push($publix, 'Qout');
      array_push($publix, 'Qin');
      array_push($publix, 'evap_gpm');

      return $publix;
   }
}
   

class wsp_CumulativeImpactObject extends modelObject {
   
   // time series for withdrawal data, based on objects geometry
   
   // USGS basin shapes connection object
   var $usgsdb = -1;
   var $usgs_host = 'localhost';
   var $usgs_port = 5432;
   var $usgs_dbname = 'va_hydro';
   var $usgs_username = 'usgs_ro';
   var $usgs_password = '@ustin_CL';
   var $usgs_maxrecs = 6;
   // data holder for USGS connection
   var $usgs_basins = array();
   
   // VWUDS data connection object
   var $vwudsdb = -1;
   var $vwuds_host = 'localhost';
   var $vwuds_port = 5432;
   var $vwuds_dbname = 'vwuds';
   var $vwuds_username = 'wsp_ro';
   var $vwuds_password = '314159';
   // data holder for vwuds connection
   var $vwuds_basins = array();
   var $max_diversion = 10.0; // this is a percentage, will be converted later in the routine
   
   
   function wake() {
      parent::wake();
   }
   
   function init() {
      parent::init();
      $this->listobject->show = 0;
      
      $this->reportstring .= "<b>Getting Basins for $this->lon, $this->lat:</b><br>";
      // grab USGS stations that contain these points
      $this->getUSGSBasins($this->lon, $this->lat);
      
      // grab flow stats (if available) for USGS stations
      $this->getUSGSGageStats();
      
      // get all measuring points in this set of basins
      $this->getMeasuringPoints();
      
   }
   
   function finish() {
      $this->listobject->show = 0;
      foreach ($this->usgs_basins as $thiskey => $thisbasin) {
         $this->listobject->queryrecords = $thisbasin['stats'];
         $this->reportstring .= "<b>Basin Name:</b>" . $thisbasin['river_basi'] . "<br>";
         $this->reportstring .= "<b>USGS Gage:</b>" . $thisbasin['station_nu'] . "<br>";
         $this->reportstring .= "<b>Drainage Area:</b>" . $thisbasin['drainage_a'] . "<br>";
         $this->reportstring .= "<b>Basin Stats:</b><br>";
         $this->reportstring .= "<b>Maximum Annual Withdrawal:</b> " . number_format($thisbasin['max_annual_mg'],2) . "<br>";
         $this->reportstring .= "<b>Maximum Daily Withdrawal:</b> " . number_format($thisbasin['max_daily_mgd'],2) . " (" . number_format(($thisbasin['max_daily_mgd'] * 1.547),2) . " cfs)<br>";
         $this->reportstring .= "<b>Maximum Max Daily (with MOS):</b> " . number_format($thisbasin['max_day_mos'],2) . " (" . number_format(($thisbasin['max_day_mos'] * 1.547),2) . " cfs)<br>";
         
         $this->listobject->queryrecords = $thisbasin['withdrawals_cat'];
         $this->reportstring .= "<b>Withdrawals By Category:</b><br>";
         $this->listobject->showList();
         $this->reportstring .= $this->listobject->outstring;
         $this->reportstring .= "<b>Flow Return Period, Percent Diversion Table:</b><br>";
         $this->reportstring .= $thisbasin['exceedance_diversion_table'];
         $this->reportstring .= "<hr>";
      }
   }
   
   function getUSGSBasins($lon = -78.35, $lat = 36.997222) {
      if (!is_object($this->usgsdb)) {
         //$this->reportstring .= "Creating USGS DB Object<br>";
         $this->usgsdb = new pgsql_QueryObject;
         $this->usgsdb->dbconn = pg_connect("host=$this->usgs_host port=$this->usgs_port dbname=$this->usgs_dbname user=$this->usgs_username password=$this->usgs_password");
         $this->usgsdb->show = 0;
         //$this->reportstring .= "USGS DB Object created<br>";
      }
      
      // parent routines grab all data, now do summary queries to
      // update other components, such as the summary data, and the category multipliers
      $dbt = $this->dbtable;
      
      
      $this->usgsdb->querystring = "  select river_basi, station_nu, drainage_a, asText(the_geom) as the_geom  ";
      $this->usgsdb->querystring .= " from usgs_drainage_dd  ";
      $this->usgsdb->querystring .= " where contains(the_geom, geomfromtext('POINT( $lon $lat )',4326))  ";
      $this->usgsdb->querystring .= " order by drainage_a ";
      if ($this->usgs_maxrecs > 0) {
         $this->usgsdb->querystring .= " limit $this->usgs_maxrecs ";
      }
      if ($this->debug) {
         $this->logDebug("$this->usgsdb->querystring ; <br>");
      }
      //$this->reportstring .= $this->usgsdb->querystring;
      $this->usgsdb->performQuery();
      $this->usgsdb->showList();
      //$this->reportstring .= $this->usgsdb->outstring;
      $this->usgs_basins = $this->usgsdb->queryrecords;
      return;
   }
   
   function getMeasuringPoints() {
      if (!is_object($this->vwudsdb)) {
         $this->vwudsdb = new pgsql_QueryObject;
         $this->vwudsdb->dbconn = pg_connect("host=$this->vwuds_host port=$this->vwuds_port dbname=$this->vwuds_dbname user=$this->vwuds_username password=$this->vwuds_password");
         $this->vwudsdb->show = 0;
      }
      
      // parent routines grab all data, now do summary queries to
      // update other components, such as the summary data, and the category multipliers
      if ($this->debug) {
         $this->logDebug("Iterating through basin list" . print_r($this->usgs_basins,1) . " ; <br>");
      }
      
      foreach ($this->usgs_basins as $thiskey => $thisbasin) {
      
         // get all points in this basin area
         // right now, we are including a sub-query to get the consumptive factors and MOS multipliers 
         // from the waterusetype database.  Later, we will query the waterusetype db to give us these default
         // values, and then put them in a DataMatrix sub-component to allow the users to edit them
         $geom = $thisbasin['the_geom'];
         $basin = $thisbasin['river_basi'];
         $staid = $thisbasin['station_nu'];
         $drainage = $thisbasin['drainage_a'];
         
         $this->vwudsdb->querystring = "  SELECT a.cat_mp, sum(a.max_annual) as max_annual_mg, ";
         $this->vwudsdb->querystring .= "    sum(a.max_maxday) as max_daily_mgd, ";
         $this->vwudsdb->querystring .= "    avg(b.consumption) as consumption, avg(b.max_day_mos) as max_day_mos ";
         $this->vwudsdb->querystring .= " from vwuds_max_action as a, waterusetype as b, usgs_drainage_dd as c ";
         $this->vwudsdb->querystring .= " WHERE a.type = 'SW'  ";
         $this->vwudsdb->querystring .= "    AND a.cat_mp <> 'PH' ";
         $this->vwudsdb->querystring .= "    AND a.action = 'WL' ";
         $this->vwudsdb->querystring .= "    AND a.cat_mp = b.typeabbrev ";
         $this->vwudsdb->querystring .= "    and within(a.the_geom, c.the_geom) ";
         $this->vwudsdb->querystring .= "    and c.station_nu = '$staid' ";
         $this->vwudsdb->querystring .= " GROUP BY a.cat_mp ";
         
         if ($this->debug) {
            $this->logDebug("$this->vwudsdb->querystring ; <br>");
         }
         //error_log($this->vwudsdb->querystring . "; <br>");
         $this->vwudsdb->performQuery();
         if (count($this->vwudsdb->queryrecords) > 0) {
            $this->vwudsdb->showList();
            $this->reportstring .= $this->vwudsdb->outstring;
            $this->reportstring .= $this->vwudsdb->querystring . " ; <br>";
            $this->usgs_basins[$thiskey]['withdrawals_cat'] = $this->vwudsdb->queryrecords;
            $max_annual_mg = 0;
            $max_daily_mgd = 0;
            $max_day_mos = 0;
            foreach ($this->vwudsdb->queryrecords as $thisrec) {
               $max_annual_mg += $thisrec['max_annual_mg'];
               $max_daily_mgd += $thisrec['max_daily_mgd'];
               $max_day_mos += $thisrec['max_daily_mgd'] * $thisrec['max_day_mos'];
            }
            $this->usgs_basins[$thiskey]['max_annual_mg'] = $max_annual_mg;
            $this->usgs_basins[$thiskey]['max_daily_mgd'] = $max_daily_mgd;
            $max_annual365_mgd = $max_annual_mg / 365.0;
            $this->usgs_basins[$thiskey]['max_annual365_mgd'] = $max_annual365_mgd;
            $this->usgs_basins[$thiskey]['max_day_mos'] = $max_day_mos;

            // create Exceedance - Diversion Table
            // based on MAX DAILY
            $edt = '<table>';
            $edt .= "<tr><td><b>Month</b></td>";
            $edt .= "<td><b>5 %</b></td>";
            $edt .= "<td><b>10 %</b></td>";
            $edt .= "<td><b>20 %</b></td>";
            $edt .= "<td><b>25 %</b></td>";
            $edt .= "<td><b>50 %</b></td>";
            $edt .= "<td><b>75 %</b></td>";
            $edt .= "<td><b>80 %</b></td>";
            $edt .= "<td><b>90 %</b></td>";
            $edt .= "<td><b>95 %</b></td></tr>";
            foreach ($this->usgs_basins[$thiskey]['stats'] as $thisstat) {
               $edt .= "<tr>";
               $edt .= "<td>" . $thisstat['month_nu'] . "</td>";
               foreach (array_keys($thisstat) as $statkey) {
                  if (substr($statkey,0,1) == 'p') {
                     // 1.54 converts from MGD to CFS
                     $diversion = 100.0 * $max_day_mos * 1.54 / $thisstat[$statkey];
                     if ($diversion > $this->max_diversion) {
                        $bgcolor = "bgcolor=red";
                        $fopen = "<font color=white>";
                        $fclose = "</font>";
                     } else {
                        $fopen = "<font>";
                        $bgcolor = '';
                        $fclose = "</font>";
                     }
                     $edt .= "<td $bgcolor>$fopen" . number_format($thisstat[$statkey],2);
                     $edt .= " (" . number_format($diversion,2)  . "% )$fclose</td>";
                  }
               }
               $edt .= "</tr>";
            }
            $edt .= "</table>";

            // create Exceedance - Diversion Table
            // based on 1.5 * (MAX ANNUAL / 365.0)
            $edt .= '<b>Max Diversion based on 1.5 * Avg. of Max Annual<br>';

            $edt .= '<table>';
            $edt .= "<tr><td><b>Month</b></td>";
            $edt .= "<td><b>5 %</b></td>";
            $edt .= "<td><b>10 %</b></td>";
            $edt .= "<td><b>20 %</b></td>";
            $edt .= "<td><b>25 %</b></td>";
            $edt .= "<td><b>50 %</b></td>";
            $edt .= "<td><b>75 %</b></td>";
            $edt .= "<td><b>80 %</b></td>";
            $edt .= "<td><b>90 %</b></td>";
            $edt .= "<td><b>95 %</b></td></tr>";
            foreach ($this->usgs_basins[$thiskey]['stats'] as $thisstat) {
               $edt .= "<tr>";
               $edt .= "<td>" . $thisstat['month_nu'] . "</td>";
               foreach (array_keys($thisstat) as $statkey) {
                  if (substr($statkey,0,1) == 'p') {
                     // 1.54 converts from MGD to CFS
                     $diversion = 100.0 * 1.5 * $max_annual365_mgd * 1.54 / $thisstat[$statkey];
                     if ($diversion > $this->max_diversion) {
                        $bgcolor = "bgcolor=red";
                        $fopen = "<font color=white>";
                        $fclose = "</font>";
                     } else {
                        $fopen = "<font>";
                        $bgcolor = '';
                        $fclose = "</font>";
                     }
                     $edt .= "<td $bgcolor>$fopen" . number_format($thisstat[$statkey],2);
                     $edt .= " (" . number_format($diversion,2)  . "% )$fclose</td>";
                  }
               }
               $edt .= "</tr>";
            }
            $edt .= "</table>";

            $this->usgs_basins[$thiskey]['exceedance_diversion_table'] = $edt;
         } else {
            $this->usgs_basins[$thiskey]['exceedance_diversion_table'] = "<b>No withdrawal records exist for " . $thisbasin['station_nu'] . "</b><br>";
         }
      }
      
   }
   
   function getUSGSGageStats() {
      
      foreach ($this->usgs_basins as $thiskey => $thisbasin) {
      
         // get all points in this basin area
         // right now, we are including a sub-query to get the consumptive factors and MOS multipliers 
         // from the waterusetype database.  Later, we will query the waterusetype db to give us these default
         // values, and then put them in a DataMatrix sub-component to allow the users to edit them
         $geom = $thisbasin['the_geom'];
         $basin = $thisbasin['river_basi'];
         $staid = $thisbasin['station_nu'];
         $drainage = $thisbasin['drainage_a'];
         //$this->reportstring .= "$staid" . "; <br>";
         
         
         $thisgage = new USGSGageObject;
         $thisgage->staid = $staid;
         $thisgage->listobject = $this->listobject;
         $thisgage->wake();
         $thisgage->init();
         $numflows = count($thisgage->tsvalues);
         //$this->reportstring .= "Records: $numflows<br>";
         $thisgage->getStationInfo();
         //$this->reportstring .= "Got info<br>";
         $thisgage->getStationStats();
         //$this->reportstring .= "Got Stats<br>";
         $this->reportstring .= $thisgage->debugstring . "<br>";
         $thisgage->listobject->querystring = "  SELECT month_nu, min(min_va) as min_mo, avg(mean_va) as mean_mo, ";
         $thisgage->listobject->querystring .= "    avg(p05_va) as p05, avg(p10_va) AS p10, ";
         $thisgage->listobject->querystring .= "    avg(p20_va) AS p20, avg(p25_va) AS p25, avg(p50_va) AS p50, ";
         $thisgage->listobject->querystring .= "    avg(p75_va) AS p75, avg(p80_va) AS p80, avg(p90_va) AS p90, ";
         $thisgage->listobject->querystring .= "    avg(p95_va) AS p95 ";
         $thisgage->listobject->querystring .= " FROM $thisgage->stat_dbtblname ";
         $thisgage->listobject->querystring .= " GROUP BY month_nu ";
         $thisgage->listobject->querystring .= " ORDER BY month_nu ";
         if ($this->debug) {
            $this->logDebug("$thisgage->listobject->querystring ; <br>");
         }
         //$this->reportstring .= $thisgage->listobject->querystring . "; <br>";
         $thisgage->listobject->performQuery();
         $thisgage->listobject->showList();
         //$this->reportstring .= $thisgage->listobject->outstring . "; <br>";
         
         $this->usgs_basins[$thiskey]['stats'] = $thisgage->listobject->queryrecords;
         
      }
      
   }
   
}

function add_one($x_off)
{
    return (x_off + 1.0);
}

function green_ampt ($R ,$dt,$thetai, $thetasat, $Ks, $depth, $F, $Inf, $Sav, $tol = 0.00001) {

   $M = $thetasat - $thetai;
   $flast = $Inf;
   $fguess = $flast;
   $i = 4;


   if ($F == 0) {
      $flast = $R;
    }

    $Fwg = $F + $flast * $dt/3600.0;
    $fcalc = $Ks*(1.0+$M*$Sav/$Fwg);

    if ($fcalc > $R) {
      $frate = $R;
    } else {
      for($i = 0; (($fcalc - $fguess)*($fcalc - $fguess) > $tol) ;$i++) {
          $fguess = $fcalc;
          $Fwg = $F + $flast * $dt/3600.0;
          $fcalc = $Ks*(1.0+$M*$Sav/$Fwg);
        }
        $frate = $fcalc;
    }
    if ($fcalc > $R) {
      $frate = $R;
    }

    if ($frate < 0) {
       $frate = 0.0;
    }

    return $frate;

}


function kinwave($dep, $Qin, $Qout, $R, $I, $S, $length, $width, $dt, $n, $units, $debug) {
   $A = $length * $width;
   $tol = 0.0001;
   $lhs = 1.0;
   $rhs = 0.0;
   $j = 0;
   $diff = 1.0;
   $th = $dt/3600.0;

   $dguess = $dep + ($R - $I) * $th;
   $ldguess = 0.0;
   $lastdiff = 0.5;
   switch ($units) {
    case 1:
       $manco = 1.0; # SI
    break;

    case 2:
       $manco = 1.49; # English
    break;

    default:
       $manco = 1.0; # SI
    break;
   }

/* given d(t-dt), Qin (volume into cell in last it.), Qout (volume out of cell in last it.), R (rainfall rate), I (infiltration rate), S (slope), A (Area) calculate d and velocity and Qout, based on given Area (A):
   Qout = d * w * v, where w = sqrt(area) for all cells, regardless of flow direction.
   d = d[t-dt] + (Qin - Qout)/A + R - I : therefore;
      Qout = ( d[t-dt] - d + Qin/A + R - I ) * A
   v = 1.49*(d^2/3 * S^1/2) / n ; therefore:
      Qout = 1.49 * w * d^(5/3) * S^(1/2) / n
   Finally:
      ( d[t-dt] - d + Qin/A + R - I ) * A = 1.49 * w * d^(5/3) * S^(1/2) / n
     Must balance.

   Usage: kinWave(d,Qin,Qout,R,I,S,A,dt,n)
*/
   for ($j = 0;( (abs($diff) > $tol) && ($j < 5000) ); $j++) {

      $lhs = ( ($dep - $dguess)/12.0 + $Qin/($A) + $th*($R - $I)/12.0) *$A;
      $rhs = $th*$manco * $width * pow(($dguess/12.0),(5.0/3.0))*pow($S,(0.5)) / $n;
      $diff = $lhs - $rhs;
      # increasing $dguess will reduce the lhs and increase the rhs
      # thus, if $diff < 0 then $dguess should be reduced
      # if $diff > 0 then $dguess should be increased
      # if $diff is a different sign than $lastdiff then  our new guess
      #    should lie between the current guess and the last guess
      # if the last 2 guesses have the same signs then the new guess
      #    should be outside of the range of our last 2 guesses
      # if the new guess should be outside the range of the last 2 then
      #    we can obtain the new guess by squaring the ratio of our last 2 guesses
      #    the direction of our new guess (greater or lesser) should determine which
      #    of the last two guesses is the numerator, and which the denominator
      # if the new guess is between the last 2 guesses then we should simply
      #    choose the mean of the last two guesses as the new guess

      if ($debug) { print(" <b>$j:</b> D= $dep, R= $R, I= $I, $lhs, $rhs, dguess = $dguess, ldguess = $ldguess, diff = $diff, lastdiff = $lastdiff <br>\n"); }
      if ($debug) { print(" lhs = ( ($dep - $dguess)/12.0 + $Qin/($A) + $th*($R - $I)/12.0) *$A <br>\n"); }
      if ($debug) { print(" rhs = $th * $manco * $width * pow(($dguess/12.0),(5.0/3.0))*pow($S,(0.5)) / $n; <br>\n"); }

      # get sign of $diff and $lastdiff
      # no concern about division by zero because we would have exited the loop if
      # $lastdiff were less than tolerance which is non-zero
      if ($diff <> 0) {
         if ($j == 0) {
            # first time through, make a standard adjustment to the guess
            $lastdiff = $diff;
            $ldguess = $dguess;
            if ($debug) { print("Making our first guess. <br>\n"); }
            if ($diff < 0) {
               if ($debug) { print("Decreasing our guess. <br>\n"); }
               $dguess = $dguess * 0.9;
            } else {
               if ($debug) { print("Increasing our guess. <br>\n"); }
               $dguess = $dguess * 1.1;
            }
         } else {
            # stash the current guess
            $thisguess = $dguess;
            # make an educated new guess based on last guess results
            $lsign = $lastdiff/abs($lastdiff);
            $dsign = $diff/abs($diff);
            if ($debug) { print("dsign = $dsign, lsign = $lsign <br>\n"); }

            if ($dsign <> $lsign) {
               # choose a new guess between the last two guesses
               if ($debug) { print("Last 2 guesses have different signs. <br>\n"); }
               $neghalf = min(array($lastdiff, $diff));
               $minguess = min(array($ldguess, $dguess));
               $interval = abs($lastdiff - $diff);
               $frac = 1.0 - (abs($neghalf) / $interval);
               if ($debug) {  print(" frac = 1.0 - (abs($neghalf) / $interval) = $frac; <br>\n"); }
               $dguess = $minguess + abs($dguess - $ldguess) * $frac;
               if ($debug) { print(" dguess = $minguess + abs($dguess - $ldguess) * $frac = $dguess; <br>\n"); }
               # set last guess to whichever was closer
               if (abs($lastdiff) > abs($diff)) {
                  $ldguess = $thisguess;
                  $lastdiff = $diff;
               }
            } else {
               if ($debug) {  print("Last 2 guesses have the same signs. <br>\n"); }
               # the last two guesses have the same sign, so the same type
               # of change should occur, but with a larger magnitude
               if ($dsign < 0) {
                  # the new guess should decrease by a greater magnitude
                  # than tried previously
                  $num = min(array($ldguess, $dguess));
                  $denom = max(array($ldguess, $dguess));
                  $gfact = pow($num/$denom, 2.0);
                  if ($debug) { print("Decreasing our guess by factor $gfact. <br>\n"); }

               } else {
                  $num = max(array($ldguess, $dguess));
                  $denom = min(array($ldguess, $dguess));
                  $gfact = pow($num/$denom, 2.0);
                  if ($debug) { print("Increasing our guess by factor $gfact. <br>\n"); }
                  # the new guess should increase by a greater magnitude
                  # than tried previously
               }
               if ($debug) {  print("Changing our guess by factor $gfact. <br>\n"); }
               $dguess = $gfact * $ldguess;
            }
         }
      }
   }

  # if ($dep == 0.0) {
      # no flow when depth is zero
  #    $dguess = 0;
  # }

   $Qnew = ($manco * $dguess/12.0 * pow($dguess/12.0,(5.0/3.0)) * pow($S,(0.5)))/$n;
   if ($debug) { print("Finished: Qnew = $Qnew <br>\n"); }

   return array($Qnew, $dguess);
}


function typeii_storm($totald, $t, $dur) {

   $d = 0.0;
/*
 given total depth of rainfall during the event, the current time into the event, and the duration of the event, calculate the SCS type II rainfall curve.
   Usage: typeII_storm(totaldepth,t,dur)
  */

   $tr = 12.0 - $dur/2.0;
   $pr = 0.5 + ( ($tr/24.0) * pow( 24.04/(2 * abs($tr) + 0.04), 0.75));
   $tf = 12.0 + $dur/2.0;
   $pf = 0.5 + ( ($tf/24.0) * pow( 24.04/(2 * abs($tf) + 0.04), 0.75));
   $tn = 12.0 + $t - $dur/2.0;
   $p = 0.5 + ( ($tn/24.0) * pow( 24.04/(2 * abs($tn) + 0.04), 0.75));

   $d = totald * ( ($p - $pr) / ($pf - $pr) );

   return $d;
}



function storagerouting($I1, $I2, $O1, $W, $b, $Z, $ct, $S1, $slength, $slope, $dt, $n, $units, $debug, $maxits = 100) {
# returns all quantities of interest - Velocity, Storage, depth and Flow
/* dt is interval time in seconds */
/* $ct is channel type - not yet active */
 /* StorageRoutingQout, part of a suite of storage routing routines including:
       StorageRoutingD, StorageRoutingS
    Inputs:
       stream geometry:
          base(b),Z (trap, rect or triangle for now, later maybe pass shape in)
          length
       Inflow.old v(I1), Outflow.old(O1), Inflow.new(I2), depth.old(d1)
    calculate:
       Storage.old(S1) from depth, and geometry inputs (length term equates volume)
       Outflow.new(O2)
    Return:
       O2 (i.e. new Qout)
    Usage: StorageRoutingQout(Iold,Qin,Qout,base,Z,channeltype,Storage,length,slope,toSeconds(dt),n)
 */
 switch ($units) {
    case 1:
       $manco = 1.0; # SI
    break;

    case 2:
       $manco = 1.49; # English
    break;

    default:
       $manco = 1.0; # SI
    break;
 }


   /* d1 will be calculated from S1, length and geometry */
   $tol = 0.001; /* set tolerance for equation solution */
   /* if (channeltype == 2) { ... ; to come, for now assume trapezoidal */
   $O2 = 0.0;

   $A = $S1 / $slength; /* cross-sectional area of channel based on last storage value */
   /* solve quadratic formula */
   /* since eqn. for channel area is of the form A = bd + Zd^2 quadratic formula is then:
         Zd^2 + bd - A = 0,
      and quadratic soln. is:
         x = ( -b +/- (b^2 - 4ac)^0.5 ) / 2a; where x = Depth, a = Z, b = b, c = -A
      thus, since b is always > 0, and ((b^2 - 4ac)^0.5) > b, only + soln. will work
   */
   #$debug = 1;

   $d1 = (-1.0*$b + sqrt( (pow($b,2.0) + 4.0*$A*$Z) ) ) / (2.0 * $Z);
   $d2 = $d1 + 0.1;
   # Based on continuity equation
   # Storage = Begin_S + Inflows - Outflows
   # Continuity rearranged with flow rates added (I and O in volume/time)
   #    1) S2 = S1 + Imean*dt - Omean*dt
   #    2) Omean = (O1 + O2)*dt/2 = O1*dt/2 + O2*dt/2
   #    3) Imean = (I1 + I2)*dt/2
   # Substituting eqs. 2) and 3) from above into 1) yields:
   #    4) S2 = S1 + (I1 + I2)*dt/2 - O1*dt/2 - O2*dt/2
   # Rearranging 4) so that all unknowns (S2 and O2) are on the same side yields
   #    5) S2 + O2*dt/2 = S1 - O1*dt/2 + (I1 + I2)*dt/2
   # if we have KNOWN withdrawals we can include them on the right side of the equation
   # making 5) iinto:
   #   6) S2 + O2*dt/2 = S1 - O1*dt/2 + (I1 + I2)*dt/2 - W*dt
   # The right side ( $eq1 ) does not change, since all are known
   # the left side components, O2 and S2 can be solved iteratively using
   # Manning's equation:
   #    V = 1.49/n * R^2/3 * slope^0.5
   # and a series of guesses
   # since the depth of flow determines velocity, cross-sectional area,
   # and therefore storage volume and Outflow
   $eq2 = $S1 - ($O1/2.0)*$dt + (($I1 + $I2)*$dt)/2.0 - $W*$dt;
   $eq1 = $eq2 + 1.0;
   if ($eq2 <= 0) {
      $O2 = $S1/$dt;
      $S2 = 0.0;
      $eq1 = 0.0;
      $eq2 = 0.0;
      $d2 = 0.0;
      $V2 = 0.0;
   }
   for ($i = 0; (abs($eq1 - $eq2) > $tol); $i++) {
      $A2 = $b*$d2 + $Z*pow($d2,2.0);
      $S2 = $slength * $A2;
      $p = $b + 2.0*$d2*pow((pow($Z,2.0) + 1.0),0.5);
      $R = $A2 / $p;
      $O2 = $A2 * ($manco/$n) * pow($R,2.0/3.0) * pow($slope,0.5);
      $V2 = ($manco/$n) * pow($R,2.0/3.0) * pow($slope,0.5);
      $eq1 = $S2 + $O2*$dt/2.0;

      # old method
      /*
      if ($eq2 > $eq1) {
         $d2 = $d2*1.01;
      } else {
         $d2 = $d2*0.99;
      }
      */

      if ($i > $maxits) {
         # this tells us that we are having trouble finding a solution
         # we first try to adjust the tolerance a slight bit, if this does not work, 
         # then we assume that infllow equals outflow, and simply call for the initial Storage
         # routine to give us a storage value, then call this routine again
         if ($i < (2.0 * $maxits)) {
            # try adjusting the tolerance
            $tol = $tol * 1.1;
         } else {
            # set these to be steady state by setting outflow = inflow
            $Sest = storageroutingInitS($I2, $b, $Z, $ct, $slength, $slope, $dt, $n, $units, $debug, $maxits);
            list ($V2, $O2, $d2, $S2) = storagerouting($I2, $I2, $I2, $W, $b, $Z, $ct, $Sest, $slength, $slope, $dt, $n, $units, $debug, $maxits);
            break;
         }
      }

      # test new method for quicker solution
      $diff = $eq2 - $eq1;

      if ($debug) { print(" <b>$i:</b> D= $d1, $eq1, $eq2, dguess = $d2, ldguess = $ld2, diff = $diff, lastdiff = $lastdiff <br>\n"); }
      if ($debug) { print(" eq1 = $S2 + $O2*$dt/2.0 <br>\n"); }
      if ($debug) { print(" eq2 = $S1 - ($O1/2.0)*$dt + (($I1 + $I2)*$dt)/2.0; <br>\n"); }

      # get sign of $diff and $lastdiff
      # no concern about division by zero because we would have exited the loop if
      # $lastdiff were less than tolerance which is non-zero
      if ($diff <> 0) {
         if ($i == 0) {
            # first time through, make a standard adjustment to the guess
            $lastdiff = $diff;
            $ld2 = $d2;
            if ($debug) { print("Making our first guess. <br>\n"); }
            if ($diff < 0) {
               if ($debug) { print("Decreasing our guess. <br>\n"); }
               $d2 = $d2 * 0.9;
            } else {
               if ($debug) { print("Increasing our guess. <br>\n"); }
               $d2 = $d2 * 1.1;
            }
         } else {
            # stash the current guess
            $thisguess = $d2;
            # make an educated new guess based on last guess results
            $lsign = $lastdiff/abs($lastdiff);
            $dsign = $diff/abs($diff);
            if ($debug) { print("dsign = $dsign, lsign = $lsign <br>\n"); }

            if ($dsign <> $lsign) {
               # choose a new guess between the last two guesses
               if ($debug) { print("Last 2 guesses have different signs. <br>\n"); }
               $neghalf = min(array($lastdiff, $diff));
               $minguess = min(array($ld2, $d2));
               $interval = abs($lastdiff - $diff);
               $frac = 1.0 - (abs($neghalf) / $interval);
               if ($debug) {  print(" frac = 1.0 - (abs($neghalf) / $interval) = $frac; <br>\n"); }
               $d2 = $minguess + abs($d2 - $ld2) * $frac;
               if ($debug) { print(" d2 = $minguess + abs($d2 - $ld2) * $frac = $d2; <br>\n"); }
               # set last guess to whichever was closer
               if (abs($lastdiff) < abs($diff)) {
                  $ld2 = $thisguess;
                  $lastdiff = $diff;
               }
            } else {
               if ($debug) {  print("Last 2 guesses have the same signs. <br>\n"); }
               # the last two guesses have the same sign, so the same type
               # of change should occur, but with a larger magnitude
               if ($dsign < 0) {
                  # the new guess should decrease by a greater magnitude
                  # than tried previously
                  $num = min(array($ld2, $d2));
                  $denom = max(array($ld2, $d2));
                  $gfact = pow($num/$denom, 2.0);
                  if ($debug) { print("Decreasing our guess by factor $gfact. <br>\n"); }

               } else {
                  $num = max(array($ld2, $d2));
                  $denom = min(array($ld2, $d2));
                  $gfact = pow($num/$denom, 2.0);
                  if ($debug) { print("Increasing our guess by factor $gfact. <br>\n"); }
                  # the new guess should increase by a greater magnitude
                  # than tried previously
               }
               if ($debug) {  print("Changing our guess by factor $gfact. <br>\n"); }
               $d2 = $gfact * $ld2;
            }
         }
      }
   }

   return array($V2, $O2, $d2, $S2);
}



function storageroutingInitS($Q, $b, $Z, $channeltype, $slength, $slope, $dt, $n, $units, $debug, $maxits = 100)
{
   # estimates the inital value of storage in order to reduce warmup time
   # assumes that the system is at steady state
   #    i.e., that the initial and final storage are equivalent, and that the
   #    initial and final inputs/outputs are all equal
   /* $channeltype = 1 - triangle, 2 - trapezoid, 3 - rectangle */
   $I1 = $Q;
   $I2 = $Q;
   $O1 = $Q;
   $S1 = 0;

    switch ($units) {
       case 1:
          $manco = 1.0; # SI
       break;

       case 2:
          $manco = 1.49; # English
       break;

       default:
          $manco = 1.0; # SI
       break;
    }

 /* StorageRoutingS, part of a suite of storage routing routines including:
       StorageRoutingD, StorageRoutingQout
    Inputs:
       stream geometry:
          base(b),Z (trap, rect or triangle for now, later maybe pass shape in)
          length
       Inflow.old v(I1), Outflow.old(O1), Inflow.new(I2), depth.old(d1)
    calculate:
       Storage.old(S1) from depth, and geometry inputs (length term equates volume)
       Outflow.new(O2)
    Return:
       O2 (i.e. new Qout)
    Usage: StorageRoutingS(Iold,Qin,Qout,base,Z,channeltype,Storage,length,slope,toSeconds(dt),n)
 */

   /* d1 will be calculated from S1, length and geometry */

   $tol = 0.001; /* set tolerance for equation solution */

   /* if (channeltype == 2) { ... ; to come, for now assume trapezoidal */

   $A = $S1 / $slength; /* cross-sectional area of channel based on last storage value */
   $S2 = 0.0;
   /* solve quadratic formula */
   /* since eqn. is of the form A = bd + Zd^2 quadratic formula is then:
         Zd^2 + bd - A = 0, (ax^2 + bx + c = 0)
      and quadratic soln. is:
         x = ( -b +/- (b^2 - 4ac)^0.5 ) / 2a, a = Z, b = b, c = -A
      thus, since b is always > 0, and ((b^2 - 4ac)^0.5) > b, only + soln. will work
      Where x = d, a = Z, b = b, c = -A
   */
   # we simply have to solve mannings for the depth (and therefore area and volume)
   # that correspond to the given flow rate

   $O2 = 0.0;
   $d2 = 1.0; # set an initial, non-zero value for $d2

   for ($i = 0; (abs($Q - $O2) > $tol); $i++) {
      $A2 = $b*$d2 + $Z*pow($d2,2.0);
      $S2 = $slength * $A2;
      $p = $b + 2*$d2*pow((pow($Z,2.0) + 1),0.5);
      $R = $A2 / $p;
      $O2 = $A2 * ($manco/$n) * pow($R,2.0/3.0) * pow($slope,0.5);

      # test new method for quicker solution
      $diff = $Q - $O2;

      if ($i > $maxits) {
         break;;
      }

      if ($debug) { print(" <b>$i:</b> D= $d1, Q = $Q, $Qguess = $O2, dguess = $d2, ldguess = $ld2, diff = $diff, lastdiff = $lastdiff <br>\n"); }
      if ($debug) { print(" Q = $Q <br>\n"); }
      if ($debug) { print(" Qguess = $A2 * ($manco/$n) * pow($R,2.0/3.0) * pow($slope,0.5); <br>\n"); }

      # get sign of $diff and $lastdiff
      # no concern about division by zero because we would have exited the loop if
      # $lastdiff were less than tolerance which is non-zero
      if ($diff <> 0) {
         if ($i == 0) {
            # first time through, make a standard adjustment to the guess
            $lastdiff = $diff;
            $ld2 = $d2;
            if ($debug) { print("Making our first guess. <br>\n"); }
            if ($diff < 0) {
               if ($debug) { print("Decreasing our guess. <br>\n"); }
               $d2 = $d2 * 0.9;
            } else {
               if ($debug) { print("Increasing our guess. <br>\n"); }
               $d2 = $d2 * 1.1;
            }
         } else {
            # stash the current guess
            $thisguess = $d2;
            # make an educated new guess based on last guess results
            $lsign = $lastdiff/abs($lastdiff);
            $dsign = $diff/abs($diff);
            if ($debug) { print("dsign = $dsign, lsign = $lsign <br>\n"); }

            if ($dsign <> $lsign) {
               # choose a new guess between the last two guesses
               if ($debug) { print("Last 2 guesses have different signs. <br>\n"); }
               $neghalf = min(array($lastdiff, $diff));
               $minguess = min(array($ld2, $d2));
               $interval = abs($lastdiff - $diff);
               $frac = 1.0 - (abs($neghalf) / $interval);
               if ($debug) {  print(" frac = 1.0 - (abs($neghalf) / $interval) = $frac; <br>\n"); }
               $d2 = $minguess + abs($d2 - $ld2) * $frac;
               if ($debug) { print(" d2 = $minguess + abs($d2 - $ld2) * $frac = $d2; <br>\n"); }
               # set last guess to whichever was closer
               if (abs($lastdiff) < abs($diff)) {
                  $ld2 = $thisguess;
                  $lastdiff = $diff;
               }
            } else {
               if ($debug) {  print("Last 2 guesses have the same signs. <br>\n"); }
               # the last two guesses have the same sign, so the same type
               # of change should occur, but with a larger magnitude
               if ($dsign < 0) {
                  # the new guess should decrease by a greater magnitude
                  # than tried previously
                  $num = min(array($ld2, $d2));
                  $denom = max(array($ld2, $d2));
                  $gfact = pow($num/$denom, 2.0);
                  if ($debug) { print("Decreasing our guess by factor $gfact. <br>\n"); }

               } else {
                  $num = max(array($ld2, $d2));
                  $denom = min(array($ld2, $d2));
                  $gfact = pow($num/$denom, 2.0);
                  if ($debug) { print("Increasing our guess by factor $gfact. <br>\n"); }
                  # the new guess should increase by a greater magnitude
                  # than tried previously
               }
               if ($debug) {  print("Changing our guess by factor $gfact. <br>\n"); }
               $d2 = $gfact * $ld2;
            }
         }
      }
   }

   return $S2;
}

function reverseStorageRouting($I1, $O1, $O2, $W, $b, $Z, $ct, $S1, $slength, $slope, $dt, $n, $tol, $units, $debug, $maxits = 100) {
# takes as inputs previous in-flow (I1) and outflow(O1), current outflow(O2),
# and back-calculates the Inflow at the current time (I2)
# returns all quantities of interest - Velocity, Storage, depth and Flow
/* dt is interval time in seconds */
 /* StorageRoutingQout, part of a suite of storage routing routines including:
       StorageRoutingD, StorageRoutingS
    Inputs:
       stream geometry:
          base(b),Z (trap, rect or triangle for now, later maybe pass shape in)
          length
       Inflow.old v(I1), Outflow.old(O1), Outflow.new(O2), depth.old(d1)
    calculate:
       Storage.old(S1), Storage.new(S2) from depth, and geometry inputs (length term equates volume)
       Inflow.new(I2)
    Return:
       I2 (i.e. new Qin)
    Usage: reverseStorageRouting(Iold,Qin,Qout,base,Z,channeltype,Storage,length,slope,toSeconds(dt),n)
 */
 switch ($units) {
    case 1:
       $manco = 1.0; # SI
    break;

    case 2:
       $manco = 1.49; # English
    break;

    default:
       $manco = 1.0; # SI
    break;
 }


   /* d1 will be calculated from S1, length and geometry */
   #$tol = 0.001; /* set tolerance for equation solution */
   /* if (channeltype == 2) { ... ; to come, for now assume trapezoidal */
   # this is now an input
   # $O2 = 0.0;
   # instead, set I2 = 0.0
   $I2 = 0.0;

   $A = $S1 / $slength; /* cross-sectional area of channel based on last storage value */
   /* solve quadratic formula */
   /* since eqn. for channel area is of the form A = bd + Zd^2 quadratic formula is then:
         Zd^2 + bd - A = 0,
      and quadratic soln. is:
         x = ( -b +/- (b^2 - 4ac)^0.5 ) / 2a; where x = Depth, a = Z, b = b, c = -A
      thus, since b is always > 0, and ((b^2 - 4ac)^0.5) > b, only + soln. will work
   */
   #$debug = 1;

   $d1 = (-1.0*$b + sqrt( (pow($b,2.0) + 4.0*$A*$Z) ) ) / (2.0 * $Z);
   $d2 = $d1 + 0.1;

   # need to compare to mean flow
   $Omean = ($O1 + $O2) / 2.0;
   # Based on continuity equation
   # Storage = Begin_S + Inflows - Outflows
   # Continuity rearranged with flow rates added (I and O in volume/time)
   #    1) S2 = S1 + Imean*dt - Omean*dt
   #    2) Omean = (O1 + O2)*dt/2 = O1*dt/2 + O2*dt/2
   #    3) Imean = (I1 + I2)*dt/2 = I1*dt/2 + I2*dt/2
   # Substituting eqs. 2) and 3) from above into 1) yields:
   #    4) S2 - S1 + (O1 + O2)*dt/2 - I1*dt/2 = I2*dt/2
   # Rearranging 4) so that all unknowns (S2 and O2) are on the same side yields
   #    5) I2*dt/2 = S2 - S1 + (O1 + O2)*dt/2 - I1*dt/2
   #    6) I2 = (2.0 / dt) * (S2 - S1 + (O1 + O2)*dt/2 - I1*dt/2 )
   # The right side ( $eq1 ) does not change, since all are known
   # the left side components, O2 and S2 can be solved iteratively using
   # Manning's equation:
   #    V = 1.49/n * R^2/3 * slope^0.5
   # and a series of guesses
   # since the depth of flow determines velocity, cross-sectional area,
   # and therefore storage volume and Outflow
   $eq2 = $S1 - (($O1 + $O2)/2.0)*$dt + (($I1)*$dt)/2.0 - $W*$dt;
   $eq1 = $eq2 + 1.0;
   if ($eq2 <= 0) {
      # old, O2
      # $O2 = $S1/$dt;
      # new, I2
      # if $eq2 < 0 then we must have 0.0 inflow
      $I2 = 0.0;
      $S2 = 0.0;
      $eq1 = 0.0;
      $eq2 = 0.0;
      $d2 = 0.0;
   }
   for ($i = 0; (abs($Oguess - $Omean) > $tol); $i++) {
      $A2 = floatval($b)*$d2 + floatval($Z)*$d2*$d2;
      $S2 = floatval($slength) * $A2;
      $p = floatval($b) + 2.0*$d2*floatval(pow(($Z*$Z + 1.0),0.5));
      $R = $A2 / $p;
      # O2 is now known, so we don't solve for this
      $twothirds = 2.0/3.0;
      $r23 = pow($R,$twothirds);
      $V2 = ($manco/$n) * pow($R,$twothirds) * pow($slope,0.5);
      #$V2 = ($manco/$n) * ($R**$twothirds) * pow($slope,0.5);
      #print("($R**$twothirds) = $r23<br>");
      $Oguess = $A2 * $V2;
      $I2 = (2.0 / $dt) * ($S2 - $S1 + ($O1 + $Oguess)*$dt/2.0 - $I1*$dt/2.0 );

      # test new method for quicker solution
      $diff = $Omean - $Oguess;

      if ($debug) { print(" <b>$i:</b> O2 = $O2, Oguess = $Oguess, D= $d1, dguess = $d2, ldguess = $ld2, diff = $diff, lastdiff = $lastdiff <br>\n"); }
      if ($debug) { print(" Oguess = A2 * (manco/n) * pow(R,2.0/3.0) * pow(slope,0.5);<br>\n"); }
      if ($debug) { print(" Oguess = $A2 * ($manco/$n) * pow($R,2.0/3.0) * pow($slope,0.5) = $Oguess;<br>\n"); }
      if ($debug) { print(" I2 = (2.0 / dt) * (S2 - S1 + (O1 + Oguess)*dt/2.0 - I1*dt/2.0 ); <br>\n"); }
      if ($debug) { print(" I2 = (2.0 / $dt) * ($S2 - $S1 + ($O1 + $Oguess)*$dt/2.0 - $I1*$dt/2.0 ) = $I2; <br>\n"); }

      # get sign of $diff and $lastdiff
      # no concern about division by zero because we would have exited the loop if
      # $lastdiff were less than tolerance which is non-zero
      if ($diff <> 0) {
         if ($i == 0) {
            # first time through, make a standard adjustment to the guess
            $lastdiff = $diff;
            $ld2 = $d2;
            if ($debug) { print("Making our first guess. <br>\n"); }
            if ($diff < 0) {
               if ($debug) { print("Decreasing our guess. <br>\n"); }
               $d2 = $d2 * 0.9;
            } else {
               if ($debug) { print("Increasing our guess. <br>\n"); }
               $d2 = $d2 * 1.1;
            }
         } else {
            # stash the current guess
            $thisguess = $d2;
            # make an educated new guess based on last guess results
            $lsign = $lastdiff/abs($lastdiff);
            $dsign = $diff/abs($diff);
            if ($debug) { print("dsign = $dsign, lsign = $lsign <br>\n"); }            if ($dsign <> $lsign) {
               # choose a new guess between the last two guesses
               if ($debug) { print("Last 2 guesses have different signs. <br>\n"); }
               $neghalf = min(array($lastdiff, $diff));
               $minguess = min(array($ld2, $d2));
               $interval = abs($lastdiff - $diff);
               $frac = 1.0 - (abs($neghalf) / $interval);
               if ($debug) {  print(" frac = 1.0 - (abs($neghalf) / $interval) = $frac; <br>\n"); }
               $d2 = $minguess + abs($d2 - $ld2) * $frac;
               if ($debug) { print(" d2 = $minguess + abs($d2 - $ld2) * $frac = $d2; <br>\n"); }
               # set last guess to whichever was closer
               if (abs($lastdiff) < abs($diff)) {
                  $ld2 = $thisguess;
                  $lastdiff = $diff;
               }
            } else {
               if ($debug) {  print("Last 2 guesses have the same signs. <br>\n"); }
               # the last two guesses have the same sign, so the same type
               # of change should occur, but with a larger magnitude
               if ($dsign < 0) {
                  # the new guess should decrease by a greater magnitude
                  # than tried previously
                  $num = min(array($ld2, $d2));
                  $denom = max(array($ld2, $d2));
                  $gfact = pow(($num/$denom), 2.0);
                  if ($debug) { print("Decreasing our guess by factor $gfact. <br>\n"); }

               } else {
                  $num = max(array($ld2, $d2));
                  $denom = min(array($ld2, $d2));
                  $gfact = pow(($num/$denom), 2.0);
                  if ($debug) { print("Increasing our guess by factor $gfact. <br>\n"); }
                  # the new guess should increase by a greater magnitude
                  # than tried previously
               }
               if ($debug) {  print("Changing our guess by factor $gfact. <br>\n"); }
               $d2 = $gfact * $ld2;
            }
         }
      }
   }

   $I2 = (2.0 / $dt) * ($S2 - $S1 + ($O1 + $O2)*$dt/2.0 - $I1*$dt/2.0 );
   /*
   print("A2 = floatval(b)*d2 + floatval(Z)*d2*d2;<br>\n");
   print("$A2 = floatval($b)*$d2 + floatval($Z)*$d2*$d2;<br>\n");
   print("S2 = floatval(slength) * A2;<br>\n");
   print("$S2 = floatval($slength) * $A2;<br>\n");
   print("I2 = (2.0 / dt) * (S2 - S1 + (O1 + Oguess)*dt/2.0 - I1*dt/2.0 );<br>\n");
   print("$I2 = (2.0 / $dt) * ($S2 - $S1 + ($O1 + $Oguess)*$dt/2.0 - $I1*$dt/2.0 );<br>\n");
   */

   if ($I2 < 0) {
      $I2 = 0;
   }

   return array($V2, $I2, $d2, $S2);
}


function storageroutingqout($I1, $I2, $O1, $b, $Z, $ct, $S1, $slength, $slope, $dt, $n, $debug, $maxits = 100) {

/* dt is interval time in seconds */
 /* StorageRoutingQout, part of a suite of storage routing routines including:
       StorageRoutingD, StorageRoutingS
    Inputs:
       stream geometry:
          base(b),Z (trap, rect or triangle for now, later maybe pass shape in)
          length
       Inflow.old v(I1), Outflow.old(O1), Inflow.new(I2), depth.old(d1)
    calculate:
       Storage.old(S1) from depth, and geometry inputs (length term equates volume)
       Outflow.new(O2)
    Return:
       O2 (i.e. new Qout)
    Usage: StorageRoutingQout(Iold,Qin,Qout,base,Z,channeltype,Storage,length,slope,toSeconds(dt),n)
 */


   /* d1 will be calculated from S1, length and geometry */
   $tol = 0.001; /* set tolerance for equation solution */
   /* if (channeltype == 2) { ... ; to come, for now assume trapezoidal */
   $O2 = 0.0;

   $A = $S1 / $slength; /* cross-sectional area of channel based on last storage value */
   /* solve quadratic formula */
   /* since eqn. is of the form A = bd + Zd^2 quadratic formula is then:
         Zd^2 + bd - A = 0,
      and quadratic soln. is:
         x = ( -b +/- (b^2 - 4ac)^0.5 ) / 2a, a = Z, b = b, c = -A
      thus, since b is always > 0, and ((b^2 - 4ac)^0.5) > b, only + soln. will work
   */
   #$debug = 1;

   $d1 = (-1.0*$b + sqrt( (pow($b,2.0) + 4.0*$A*$Z) ) ) / (2.0 * $Z);
   $d2 = $d1 + 0.1;
   $eq2 = $S1 - ($O1/2.0)*$dt + (($I1 + $I2)*$dt)/2.0;
   $eq1 = $eq2 + 1.0;
   if ($eq2 <= 0) {
      $O2 = $S1/$dt;
      $S2 = 0.0;
      $eq1 = 0.0;
      $eq2 = 0.0;
      $d2 = 0.0;
   }
   for ($i = 0; (abs($eq1 - $eq2) > $tol); $i++) {
      $A2 = $b*$d2 + $Z*pow($d2,2.0);
      $S2 = $slength * $A2;
      $p = $b + 2.0*$d2*pow((pow($Z,2.0) + 1.0),0.5);
      $R = $A2 / $p;
      $O2 = $A2 * (1.0/$n) * pow($R,2.0/3.0) * pow($slope,0.5);
      $eq1 = $S2 + $O2*$dt/2.0;

      # old method
      /*
      if ($eq2 > $eq1) {
         $d2 = $d2*1.01;
      } else {
         $d2 = $d2*0.99;
      }
      */

      if ($i > $maxits) {
         $O2 = $I2; # assume that inflow equals outflow if we can not solve in reasonable time frame
         break;
      }

      # test new method for quicker solution
      $diff = $eq2 - $eq1;

      if ($debug) { print(" <b>$i:</b> D= $d1, $eq1, $eq2, dguess = $d2, ldguess = $ld2, diff = $diff, lastdiff = $lastdiff <br>\n"); }
      if ($debug) { print(" eq1 = $S2 + $O2*$dt/2.0 <br>\n"); }
      if ($debug) { print(" eq2 = $S1 - ($O1/2.0)*$dt + (($I1 + $I2)*$dt)/2.0; <br>\n"); }

      # get sign of $diff and $lastdiff
      # no concern about division by zero because we would have exited the loop if
      # $lastdiff were less than tolerance which is non-zero
      if ($diff <> 0) {
         if ($i == 0) {
            # first time through, make a standard adjustment to the guess
            $lastdiff = $diff;
            $ld2 = $d2;
            if ($debug) { print("Making our first guess. <br>\n"); }
            if ($diff < 0) {
               if ($debug) { print("Decreasing our guess. <br>\n"); }
               $d2 = $d2 * 0.9;
            } else {
               if ($debug) { print("Increasing our guess. <br>\n"); }
               $d2 = $d2 * 1.1;
            }
         } else {
            # stash the current guess
            $thisguess = $d2;
            # make an educated new guess based on last guess results
            $lsign = $lastdiff/abs($lastdiff);
            $dsign = $diff/abs($diff);
            if ($debug) { print("dsign = $dsign, lsign = $lsign <br>\n"); }

            if ($dsign <> $lsign) {
               # choose a new guess between the last two guesses
               if ($debug) { print("Last 2 guesses have different signs. <br>\n"); }
               $neghalf = min(array($lastdiff, $diff));
               $minguess = min(array($ld2, $d2));
               $interval = abs($lastdiff - $diff);
               $frac = 1.0 - (abs($neghalf) / $interval);
               if ($debug) {  print(" frac = 1.0 - (abs($neghalf) / $interval) = $frac; <br>\n"); }
               $d2 = $minguess + abs($d2 - $ld2) * $frac;
               if ($debug) { print(" d2 = $minguess + abs($d2 - $ld2) * $frac = $d2; <br>\n"); }
               # set last guess to whichever was closer
               if (abs($lastdiff) < abs($diff)) {
                  $ld2 = $thisguess;
                  $lastdiff = $diff;
               }
            } else {
               if ($debug) {  print("Last 2 guesses have the same signs. <br>\n"); }
               # the last two guesses have the same sign, so the same type
               # of change should occur, but with a larger magnitude
               if ($dsign < 0) {
                  # the new guess should decrease by a greater magnitude
                  # than tried previously
                  $num = min(array($ld2, $d2));
                  $denom = max(array($ld2, $d2));
                  $gfact = pow($num/$denom, 2.0);
                  if ($debug) { print("Decreasing our guess by factor $gfact. <br>\n"); }

               } else {
                  $num = max(array($ld2, $d2));
                  $denom = min(array($ld2, $d2));
                  $gfact = pow($num/$denom, 2.0);
                  if ($debug) { print("Increasing our guess by factor $gfact. <br>\n"); }
                  # the new guess should increase by a greater magnitude
                  # than tried previously
               }
               if ($debug) {  print("Changing our guess by factor $gfact. <br>\n"); }
               $d2 = $gfact * $ld2;
            }
         }
      }
   }

   return $O2;
}


function storageroutings($I1, $I2, $O1, $b, $Z, $channeltype, $S1, $slength, $slope, $dt, $n, $debug)
{

   /* $channeltype = 1 - triangle, 2 - trapezoid, 3 - rectangle */

 /* StorageRoutingS, part of a suite of storage routing routines including:
       StorageRoutingD, StorageRoutingQout
    Inputs:
       stream geometry:
          base(b),Z (trap, rect or triangle for now, later maybe pass shape in)
          length
       Inflow.old v(I1), Outflow.old(O1), Inflow.new(I2), depth.old(d1)
    calculate:
       Storage.old(S1) from depth, and geometry inputs (length term equates volume)
       Outflow.new(O2)
    Return:
       O2 (i.e. new Qout)
    Usage: StorageRoutingS(Iold,Qin,Qout,base,Z,channeltype,Storage,length,slope,toSeconds(dt),n)
 */

   /* d1 will be calculated from S1, length and geometry */

   $tol = 0.001; /* set tolerance for equation solution */

   /* if (channeltype == 2) { ... ; to come, for now assume trapezoidal */

   $A = $S1 / $slength; /* cross-sectional area of channel based on last storage value */
   $S2 = 0.0;
   /* solve quadratic formula */
   /* since eqn. is of the form A = bd + Zd^2 quadratic formula is then:
         Zd^2 + bd - A = 0,
      and quadratic soln. is:
         x = ( -b +/- (b^2 - 4ac)^0.5 ) / 2a, a = Z, b = b, c = -A
      thus, since b is always > 0, and ((b^2 - 4ac)^0.5) > b, only + soln. will work
   */
   #$debug = 1;

   $d1 = (-1*$b + pow( (pow($b,2.0) + 4*$A*$Z), 0.5) ) / (2 * $Z);
   $d2 = $d1 + 0.1;
   $eq2 = $S1 - ($O1/2.0)*$dt + (($I1 + $I2)*$dt)/2.0;
   $eq1 = $eq2 + 1.0;

   if ($eq2 <= 0) {
      $O2 = $S1/$dt;
      $S2 = 0.0;
      $eq1 = 0.0;
      $eq2 = 0.0;
      $d2 = 0.0;
   }

   for ($i = 0; (abs($eq1 - $eq2) > $tol); $i++) {
      $A2 = $b*$d2 + $Z*pow($d2,2.0);
      $S2 = $slength * $A2;
      $p = $b + 2*$d2*pow((pow($Z,2.0) + 1),0.5);
      $R = $A2 / $p;
      $O2 = $A2 * (1.0/$n) * pow($R,2.0/3.0) * pow($slope,0.5);
      $eq1 = $S2 + $O2*$dt/2.0;
      # old method
      /*
      if ($eq2 > $eq1) {
         $d2 = $d2*1.01;
      } else {
         $d2 = $d2*0.99;
      }
      */

      # test new method for quicker solution
      $diff = $eq2 - $eq1;

      if ($debug) { print(" <b>$i:</b> D= $d1, $eq1, $eq2, dguess = $d2, ldguess = $ld2, diff = $diff, lastdiff = $lastdiff <br>\n"); }
      if ($debug) { print(" eq1 = $S2 + $O2*$dt/2.0 <br>\n"); }
      if ($debug) { print(" eq2 = $S1 - ($O1/2.0)*$dt + (($I1 + $I2)*$dt)/2.0; <br>\n"); }

      # get sign of $diff and $lastdiff
      # no concern about division by zero because we would have exited the loop if
      # $lastdiff were less than tolerance which is non-zero
      if ($diff <> 0) {
         if ($i == 0) {
            # first time through, make a standard adjustment to the guess
            $lastdiff = $diff;
            $ld2 = $d2;
            if ($debug) { print("Making our first guess. <br>\n"); }
            if ($diff < 0) {
               if ($debug) { print("Decreasing our guess. <br>\n"); }
               $d2 = $d2 * 0.9;
            } else {
               if ($debug) { print("Increasing our guess. <br>\n"); }
               $d2 = $d2 * 1.1;
            }
         } else {
            # stash the current guess
            $thisguess = $d2;
            # make an educated new guess based on last guess results
            $lsign = $lastdiff/abs($lastdiff);
            $dsign = $diff/abs($diff);
            if ($debug) { print("dsign = $dsign, lsign = $lsign <br>\n"); }

            if ($dsign <> $lsign) {
               # choose a new guess between the last two guesses
               if ($debug) { print("Last 2 guesses have different signs. <br>\n"); }
               $neghalf = min(array($lastdiff, $diff));
               $minguess = min(array($ld2, $d2));
               $interval = abs($lastdiff - $diff);
               $frac = 1.0 - (abs($neghalf) / $interval);
               if ($debug) {  print(" frac = 1.0 - (abs($neghalf) / $interval) = $frac; <br>\n"); }
               $d2 = $minguess + abs($d2 - $ld2) * $frac;
               if ($debug) { print(" d2 = $minguess + abs($d2 - $ld2) * $frac = $d2; <br>\n"); }
               # set last guess to whichever was closer
               if (abs($lastdiff) < abs($diff)) {
                  $ld2 = $thisguess;
                  $lastdiff = $diff;
               }
            } else {
               if ($debug) {  print("Last 2 guesses have the same signs. <br>\n"); }
               # the last two guesses have the same sign, so the same type
               # of change should occur, but with a larger magnitude
               if ($dsign < 0) {
                  # the new guess should decrease by a greater magnitude
                  # than tried previously
                  $num = min(array($ld2, $d2));
                  $denom = max(array($ld2, $d2));
                  $gfact = pow($num/$denom, 2.0);
                  if ($debug) { print("Decreasing our guess by factor $gfact. <br>\n"); }

               } else {
                  $num = max(array($ld2, $d2));
                  $denom = min(array($ld2, $d2));
                  $gfact = pow($num/$denom, 2.0);
                  if ($debug) { print("Increasing our guess by factor $gfact. <br>\n"); }
                  # the new guess should increase by a greater magnitude
                  # than tried previously
               }
               if ($debug) {  print("Changing our guess by factor $gfact. <br>\n"); }
               $d2 = $gfact * $ld2;
            }
         }
      }
   }

   return $S2;
}

function storageroutingd( $I1, $I2, $O1, $b, $Z, $channeltype, $S1, $slength, $slope, $dt, $n, $debug)
{

 /* StorageRoutingD, part of a suite of storage routing routines including:
       StorageRoutingS, StorageRoutingQout
    Inputs:
       stream geometry:
          base(b),Z (trap, rect or triangle for now, later maybe pass shape in)
          length
       Inflow.old v(I1), Outflow.old(O1), Inflow.new(I2), depth.old(d1)
    calculate:
       Storage.old(S1) from depth, and geometry inputs (length term equates volume)
       Outflow.new(O2)
    Return:
       d2 (i.e. new depth)
    Usage: StorageRoutingS(Iold,Qin,Qout,base,Z,channeltype,Storage,length,slope,toSeconds(dt),n)
 */

   /* $channeltype = 1 - triangle, 2 - trapezoid, 3 - rectangle */

   /* d1 will be calculated from S1, length and geometry */
   $tol = 0.001; /* set tolerance for equation solution */

   /* if (channeltype == 2) { ... ; to come, for now assume trapezoidal */

   $A = $S1 / $slength; /* cross-sectional area of channel based on last storage value */
   /* solve quadratic formula */
   /* since eqn. is of the form A = bd + Zd^2 quadratic formula is then:
         Zd^2 + bd - A = 0,
      and quadratic soln. is:
         x = ( -b +/- (b^2 - 4ac)^0.5 ) / 2a, a = Z, b = b, c = -A
      thus, since b is always > 0, and ((b^2 - 4ac)^0.5) > b, only + soln. will work
   */
   $d1 = (-1*$b + pow( (pow($b,2.0) + 4*$A*$Z), 0.5) ) / (2 * $Z);
   $d2 = $d1 + 0.1;
   $eq2 = $S1 - ($O1/2.0)*$dt + (($I1 + $I2)*$dt)/2.0;
   $eq1 = $eq2 + 1.0;

   if ($eq2 <= 0) {
      $O2 = $S1/$dt;
      $S2 = 0.0;
      $eq1 = 0.0;
      $eq2 = 0.0;
      $d2 = 0.0;
   }

   for ($i = 0; (abs($eq1 - $eq2) > $tol); $i++) {
      $A2 = $b*$d2 + $Z*pow($d2,2.0);
      $S2 = $slength * $A2;
      $p = $b + 2*$d2*pow((pow($Z,2.0) + 1),0.5);
      $R = $A2 / $p;
      $O2 = $A2 * (1.0/$n) * pow($R,2.0/3.0) * pow($slope,0.5);
      $eq1 = $S2 + $O2*$dt/2.0;
      # old method
      /*
      if ($eq2 > $eq1) {
         $d2 = $d2*1.01;
      } else {
         $d2 = $d2*0.99;
      }
      */

      # test new method for quicker solution
      $diff = $eq2 - $eq1;

      if ($debug) { print(" <b>$i:</b> D= $d1, $eq1, $eq2, dguess = $d2, ldguess = $ld2, diff = $diff, lastdiff = $lastdiff <br>\n"); }
      if ($debug) { print(" eq1 = $S2 + $O2*$dt/2.0 <br>\n"); }
      if ($debug) { print(" eq2 = $S1 - ($O1/2.0)*$dt + (($I1 + $I2)*$dt)/2.0; <br>\n"); }

      # get sign of $diff and $lastdiff
      # no concern about division by zero because we would have exited the loop if
      # $lastdiff were less than tolerance which is non-zero
      if ($diff <> 0) {
         if ($i == 0) {
            # first time through, make a standard adjustment to the guess
            $lastdiff = $diff;
            $ld2 = $d2;
            if ($debug) { print("Making our first guess. <br>\n"); }
            if ($diff < 0) {
               if ($debug) { print("Decreasing our guess. <br>\n"); }
               $d2 = $d2 * 0.9;
            } else {
               if ($debug) { print("Increasing our guess. <br>\n"); }
               $d2 = $d2 * 1.1;
            }
         } else {
            # stash the current guess
            $thisguess = $d2;
            # make an educated new guess based on last guess results
            $lsign = $lastdiff/abs($lastdiff);
            $dsign = $diff/abs($diff);
            if ($debug) { print("dsign = $dsign, lsign = $lsign <br>\n"); }

            if ($dsign <> $lsign) {
               # choose a new guess between the last two guesses
               if ($debug) { print("Last 2 guesses have different signs. <br>\n"); }
               $neghalf = min(array($lastdiff, $diff));
               $minguess = min(array($ld2, $d2));
               $interval = abs($lastdiff - $diff);
               $frac = 1.0 - (abs($neghalf) / $interval);
               if ($debug) {  print(" frac = 1.0 - (abs($neghalf) / $interval) = $frac; <br>\n"); }
               $d2 = $minguess + abs($d2 - $ld2) * $frac;
               if ($debug) { print(" d2 = $minguess + abs($d2 - $ld2) * $frac = $d2; <br>\n"); }
               # set last guess to whichever was closer
               if (abs($lastdiff) < abs($diff)) {
                  $ld2 = $thisguess;
                  $lastdiff = $diff;
               }
            } else {
               if ($debug) {  print("Last 2 guesses have the same signs. <br>\n"); }
               # the last two guesses have the same sign, so the same type
               # of change should occur, but with a larger magnitude
               if ($dsign < 0) {
                  # the new guess should decrease by a greater magnitude
                  # than tried previously
                  $num = min(array($ld2, $d2));
                  $denom = max(array($ld2, $d2));
                  $gfact = pow($num/$denom, 2.0);
                  if ($debug) { print("Decreasing our guess by factor $gfact. <br>\n"); }

               } else {
                  $num = max(array($ld2, $d2));
                  $denom = min(array($ld2, $d2));
                  $gfact = pow($num/$denom, 2.0);
                  if ($debug) { print("Increasing our guess by factor $gfact. <br>\n"); }
                  # the new guess should increase by a greater magnitude
                  # than tried previously
               }
               if ($debug) {  print("Changing our guess by factor $gfact. <br>\n"); }
               $d2 = $gfact * $ld2;
            }
         }
      }
   }

   return $d2;
}


function soilhydroksat($percent_sand, $percent_clay)
{
/* Soil texture triangle
hydraulic properties calculator
Taken from: http://www.bsyse.wsu.edu/saxton/soilwater/

Original Code written in javascript

*/


   $PWP = 0.0;  // Perm. Wilt. Point (cm3/cm3) % expressed as a decimal
   $FC = 0.0;  // Field Capacity    (cm3/cm3) % expressed as a decimal
   $SAT = 0.0;  // Saturation  (cm3/cm3) % expressed as a decimal
   $KSAT = 0.0;  // Saturated hydraulic conductivity  cm/hr

   $acoef =0.0;
   $bcoef =0.0;
   $sand_2=0.0;  // sand squared
   $clay_2=0.0;  // clay squared

   $percent_total = ($percent_sand + $percent_clay);

   if ($percent_total > 100.0)
   {  $percent_sand = 0.0;
      $percent_clay = 0.0;
   }

   if (($percent_sand > 0) && ($percent_clay > 0))
   {
      $sand_2 = $percent_sand * $percent_sand;
      $clay_2 = $percent_clay * $percent_clay;

      $acoef = exp(-4.396 - 0.0715 * $percent_clay -
                4.88e-4 * $sand_2 - 4.285e-5 * $sand_2 * $percent_clay);
      $bcoef = - 3.140 - 0.00222 * $clay_2 - 3.484e-5 * $sand_2 * $percent_clay;
      $SAT = 0.332 - 7.251e-4 * $percent_sand + 0.1276 * log10($percent_clay);

   if (($acoef != 0.0) && ($bcoef != 0.0))
   {
      $FC   = pow((0.3333/ $acoef),(1.0 / $bcoef));
      $PWP  = pow((15.0  / $acoef),(1.0 / $bcoef));
   }


      if ($SAT != 0.0)
         $KSAT =
            exp((12.012 - 0.0755 * $percent_sand)  +
            (- 3.895 + 0.03671 * $percent_sand -
                       0.1103  * $percent_clay +
                       8.7546e-4 * $clay_2) / $SAT);
    }

   return $KSAT;

 } /* end soil hydraulic characteristics, Saturated Hydraulic Conductivity (Ksat) */



function soilhydrothetasat($percent_sand, $percent_clay)
 {
 /* Soil texture triangle
 hydraulic properties calculator
 Taken from: http://www.bsyse.wsu.edu/saxton/soilwater/

 Original Code written in javascript

 */


    $PWP =0.0;  // Perm. Wilt. Point (cm3/cm3) % expressed as a decimal
    $FC =0.0;  // Field Capacity    (cm3/cm3) % expressed as a decimal
    $SAT =0.0;  // Saturation  (cm3/cm3) % expressed as a decimal
    $KSAT =0.0;  // Saturated hydraulic conductivity  cm/hr

    $acoef =0.0;
    $bcoef =0.0;
    $sand_2=0.0;  // sand squared
    $clay_2=0.0;  // clay squared

    $percent_total = ($percent_sand + $percent_clay);

    if ($percent_total > 100.0)
    {  $percent_sand = 0.0;
       $percent_clay = 0.0;
    };

    if (($percent_sand > 0) && ($percent_clay > 0))
    {
       $sand_2 = $percent_sand * $percent_sand;
       $clay_2 = $percent_clay * $percent_clay;

       $acoef = exp(-4.396 - 0.0715 * $percent_clay -
                 4.88e-4 * $sand_2 - 4.285e-5 * $sand_2 * $percent_clay);
       $bcoef = - 3.140 - 0.00222 * $clay_2 - 3.484e-5 * $sand_2 * $percent_clay;
       $SAT = 0.332 - 7.251e-4 * $percent_sand + 0.1276 * log10($percent_clay);

   if (($acoef != 0.0) && ($bcoef != 0.0))
   {
      $FC   = pow((0.3333/ $acoef),(1.0 / $bcoef));
      $PWP  = pow((15.0  / $acoef),(1.0 / $bcoef));
   }
       if ($SAT != 0.0)
          $KSAT =
             exp((12.012 - 0.0755 * $percent_sand)  +
             (- 3.895 + 0.03671 * $percent_sand -
                        0.1103  * $percent_clay +
                        8.7546e-4 * $clay_2) / $SAT);
     }

    return $SAT;

 } /* end soil hydraulic characteristics, Sat. Moisture Content (thetaSat) */


 function soilhydrothetafc($percent_sand, $percent_clay)
 {
 /*
 returns field capacity moisture content (thetafc)
 Derived from:
 Soil texture triangle
 hydraulic properties calculator
 Taken from: http://www.bsyse.wsu.edu/saxton/soilwater/

 Original Code written in javascript



 */

    $PWP   =0.0;  // Perm. Wilt. Point (cm3/cm3) % expressed as a decimal
    $FC    =0.0;  // Field Capacity    (cm3/cm3) % expressed as a decimal
    $SAT   =0.0;  // Saturation  (cm3/cm3) % expressed as a decimal
    $KSAT  =0.0;  // Saturated hydraulic conductivity  cm/hr

    $acoef =0.0;
    $bcoef =0.0;
    $sand_2=0.0;  // sand squared
    $clay_2=0.0;  // clay squared

    $percent_total = ($percent_sand + $percent_clay);

    if ($percent_total > 100.0)
    {  $percent_sand = 0.0;
       $percent_clay = 0.0;
    };

    if (($percent_sand > 0) && ($percent_clay > 0))
    {
       $sand_2 = $percent_sand * $percent_sand;
       $clay_2 = $percent_clay * $percent_clay;

       $acoef = exp(-4.396 - 0.0715 * $percent_clay -
                 4.88e-4 * $sand_2 - 4.285e-5 * $sand_2 * $percent_clay);
       $bcoef = - 3.140 - 0.00222 * $clay_2 - 3.484e-5 * $sand_2 * $percent_clay;
       $SAT = 0.332 - 7.251e-4 * $percent_sand + 0.1276 * log10($percent_clay);

   if (($acoef != 0.0) && ($bcoef != 0.0))
   {
      $FC   = pow((0.3333/ $acoef),(1.0 / $bcoef));
      $PWP  = pow((15.0  / $acoef),(1.0 / $bcoef));
   }
       if ($SAT != 0.0)
          $KSAT =
             exp((12.012 - 0.0755 * $percent_sand)  +
             (- 3.895 + 0.03671 * $percent_sand -
                        0.1103  * $percent_clay +
                        8.7546e-4 * $clay_2) / $SAT);
     }

    return $FC;

 } /* end soil hydraulic characteristics, Sat. Moisture Content (thetaSat) */

 function soilhydrowiltp($percent_sand, $percent_clay) {
 /*
 returns wilting point moisture content (wiltp)
 Derived from:
 Soil texture triangle
 hydraulic properties calculator
 Taken from: http://www.bsyse.wsu.edu/saxton/soilwater/

 Original Code written in javascript



 */

    $PWP   =0.0;  // Perm. Wilt. Point (cm3/cm3) % expressed as a decimal
    $FC    =0.0;  // Field Capacity    (cm3/cm3) % expressed as a decimal
    $SAT   =0.0;  // Saturation  (cm3/cm3) % expressed as a decimal
    $KSAT  =0.0;  // Saturated hydraulic conductivity  cm/hr

    $acoef =0.0;
    $bcoef =0.0;
    $sand_2=0.0;  // sand squared
    $clay_2=0.0;  // clay squared

    $percent_total = ($percent_sand + $percent_clay);

    if ($percent_total > 100.0)
    {  $percent_sand = 0.0;
       $percent_clay = 0.0;
    };

    if (($percent_sand > 0) && ($percent_clay > 0))
    {
       $sand_2 = $percent_sand * $percent_sand;
       $clay_2 = $percent_clay * $percent_clay;

       $acoef = exp(-4.396 - 0.0715 * $percent_clay -
                 4.88e-4 * $sand_2 - 4.285e-5 * $sand_2 * $percent_clay);
       $bcoef = - 3.140 - 0.00222 * $clay_2 - 3.484e-5 * $sand_2 * $percent_clay;
       $SAT = 0.332 - 7.251e-4 * $percent_sand + 0.1276 * log10($percent_clay);

      if (($acoef != 0.0) && ($bcoef != 0.0))
      {
         $PWP  = pow((15.0  / $acoef),(1.0 / $bcoef));
      }
   }

    return $PWP;

 } /* end soil hydraulic characteristics, Sat. Moisture Content (thetaSat) */
?>

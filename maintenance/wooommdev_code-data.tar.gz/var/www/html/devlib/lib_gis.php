<?php

/* lib_gis.php */
/* php library of postGIS functions, relies upon a listobject */

function getGroupExtents($listobject, $tablename, $geomcol, $colname, $colvals, $extrawhere='', $bufferpct=0.0, $debug=0) {

   # returns an array of the extents
   if (strlen(ltrim(rtrim($extrawhere))) > 0) {
      $ew = $extrawhere;
   } else {
      $ew = ' ( 1 = 1 ) ';
   }
   if (strlen(ltrim(rtrim($colvals))) > 0) {
      $cw = " $colname in ($colvals) ";
   } else {
      $cw = ' ( 1 = 1 ) ';
   }

   $listobject->querystring = "select extent(the_buff) from  ";
   $listobject->querystring .= " ( ";
   $listobject->querystring .= "    select buffer(extent($geomcol),$bufferpct*perimeter(extent($geomcol))/4.0) as the_buff ";
   #$listobject->querystring .= "    select scale($geomcol, 1.01, 1.01, 1.01) as the_buff ";
   $listobject->querystring .= "    from $tablename ";
   $listobject->querystring .= "    where $cw ";
   $listobject->querystring .= "       and $ew ";
   $listobject->querystring .= " ) as foo";
   if ($debug) { print(" $listobject->querystring ; <br>"); }
   $listobject->performQuery();

   $extent = $listobject->getRecordValue(1,'extent');
   if ($debug) { 
      print(" $extent <br>"); 
   }

   list($open,$geomtext,$close) = preg_split("/[()]/", $extent);

   $dims = join(",", preg_split("/[,\s]/", $geomtext));

   return $dims;

}


function splitMultiPolygon($listobject, $pkcol, $geomcol, $src_table, $dest_table, $groupcols, $debug) {
   
   if (strlen($extrawhere) > 0) {
      $whereclause = $extrawhere;
   } else {
      $whereclause = " (1 = 1) ";
   }
   
   $listobject->querystring = "  select $pkcol, numgeometries($geomcol) as numgeoms ";
   $listobject->querystring .= " from $src_table ";
   $listobject->querystring .= " where $whereclause ";
   $listobject->querystring .= " group by $pkcol, $geomcol ";
   if ($debug) { print("$listobject->querystring ; <br>"); }
   $listobject->performQuery();
   
   $theserecs = $listobject->queryrecords;
   
   foreach ($theserecs as $thisrec) {
      $thispk = $thisrec[$pkcol];
      $thisnum = $thisrec['numgeoms'];
      
      for ($n = 1; $n <= $thisnum; $n++ ) {
         
         $listobject->querystring = "  insert into $dest_table ($groupcols, $geomcol) ";
         $listobject->querystring .= " select $groupcols, geometryN($geomcol, $n) ";
         $listobject->querystring .= " from $src_table ";
         $listobject->querystring .= " where $whereclause ";
         $listobject->querystring .= "    and $pkcol = '$thispk' ";
         if ($debug) { print("$listobject->querystring ; <br>"); }
         $listobject->performQuery();
      }
   }
}



function getGroupWKT($formValues) {
   global $listobject, $debug;
   
   $projectid = $formValues['projectid'];
   $currentgroup = $formValues['currentgroup'];
   $lreditlist = $formValues['lreditlist'];
   
   if (strlen($lreditlist) > 0) {
      $segcond = " subshedid in ( " . "'" . join("','", split(',', $lreditlist)) . "'" . " ) ";
   } else {
      $segcond = "( 1 = 1)";
   }
   if (strlen($lreditlist) > 0) {
      # we have selected sub-segments, thus we need to query for shape
      $listobject->querystring = "  select 'Selected Basins' as groupname, asText(multi(memgeomunion(the_geom))) as wktshape ";
      $listobject->querystring .= " from proj_subsheds ";
      $listobject->querystring .= " where projectid = $projectid ";
      $listobject->querystring .= "    and $segcond ";
   } else {
      # otherwise, get it from the segment grouping (faster)
      $listobject->querystring = "  select groupname, asText(multi(memgeomunion(the_geom))) as wktshape ";
      $listobject->querystring .= " from proj_seggroups ";
      $listobject->querystring .= " where gid = $currentgroup ";
      $listobject->querystring .= " group by groupname ";
   }
   if ($debug) {
      $innerHTML  .= "$listobject->querystring ; <br>";
   }

   $listobject->performQuery();
   
   $groups = $listobject->queryrecords;
   return $groups;
   
}
?>
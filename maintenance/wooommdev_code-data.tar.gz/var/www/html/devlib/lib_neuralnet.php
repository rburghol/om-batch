<?php

# tremani library
if (isset($libpath)) {
   include("$libpath/class_neuralnetwork.php");
} else {
   include('./class_neuralnetwork.php');
}

class nnTremani extends modelObject {

   var $input_nodes = 1;
   var $hidden_nodes = 1;
   var $output_ndes = 1;
   var $nnobj;
   var $max = 3; // we try training the network for at most $max times
   var $max_epochs = 1000; // nmber of epochs in training run
   var $max_sqe = 0.01; // max squared error

   function init() {
      $this->nnobj = new NeuralNetwork($this->input_nodes, $this->hidden_nodes, $this->output_nodes);
      $this->nnobj->setVerbose(false);
   }

   function step() {
      parent::step();
      $in = array();
      $hid = array();
      $out = array();
      # feed training steps
      for ($i = 0; $i < $input_nodes; $i++) {
         $in[$i] = $this->state["I$i"];
      }
      for ($i = 0; $i < $output_nodes; $i++) {
         $out[$i] = $this->state["O$i"];
      }
      $this->nnobj->addTestData($in, $out);
   }

   function finish() {
      // now we train and report on the object
      // train the network in max 1000 epochs, with a max squared error of 0.01
      while (!($success = $this->nnobj->train($this->max_epochs, $this->max_sqe)) && $this->max_times -- > 0) {
         $this->outstring .= "Nothing found...<hr />";
      }

      // print a message if the network was succesfully trained
      if ($success) {
         $epochs = $this->nnobj->getEpoch();
         $this->outstring .= "Success in $epochs training rounds!<hr />";
      }

      // in any case, we print the output of the neural network
      for ($i = 0; $i < count($this->nnobj->trainInputs); $i ++) {
         $output = $this->nnobj->calculate($this->nnobj->trainInputs[$i]);
         $this->outstring .= "<br />Testset $i; ";
         $this->outstring .= "expected output = (".implode(", ", $this->nnobj->trainOutput[$i]).") ";
         $this->outstring .= "output from neural network = (".implode(", ", $output).")\n";
      }
   }

} /* end class nnTremani */

?>

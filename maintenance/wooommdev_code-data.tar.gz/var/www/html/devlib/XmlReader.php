<?php

/* Example xml file being parsed....
<?xml version="1.0"?>
<Messages>
  <Message>
    <ID>1</ID>
    <Originator>020231712</Originator>
    <Destination>020634778</Destination>
    <Message>Test message 1.</Message>
    <MessageTime>2005-03-24 8:57:40</MessageTime>
  </Message>
  <Message>
    <ID>2</ID>
    <Originator>020642863</Originator>
    <Destination>020634778</Destination>
    <Message>Test message 2.</Message>
    <MessageTime>2005-03-24 8:57:40</MessageTime>
  </Message>
</SMSMessages>

*/
/*--------------------------------------------------------------------------------------------------------
                  XmlReader

XmlReader will pick the contents of any tag defined within the $xml_tags array
                                       
---------------------------------------------------------------------------------------------------------*/
/*-------------------------------------------------------------------------------------------------------*/
//Please define the xml tags you want to read here, n the rest is history!!!

$xml_tags = array("ID", "Originator", "Destination", "Message", "MessageTime", "items");                                
/*-------------------------------------------------------------------------------------------------------*/
class jiffyXmlReader
{
   var $curr_row = 0;
   var $curr_element = "";
   var $row_array = array();
   var $records_array = array();

   function xml_parse_file($file_name)
   {
      //Initialize Parser
      $parser=xml_parser_create();
      //Specify Handlers to start and ending tag
      xml_set_element_handler($parser, "start_element", "end_element");
      //Data Handler
      xml_set_character_data_handler($parser, "character_data");
      //match the exact case
      xml_parser_set_option($parser, XML_OPTION_CASE_FOLDING, 0);
      //Open the Data File 
      $fp= fopen($file_name, "r") ;
      //read Data
      while ($data=fread($fp, 4096))
      {
         /*
         xml_parse($parser, $data,feof($fp)) or 
         die (sprintf("XML Error: %s at line %d", xml_error_string(xml_get_error_code($parser)), xml_get_current_line_number($parser)));
         */
         xml_parse($parser, $data,feof($fp));
      }
      xml_parser_free($parser);
   }
   
   function whitespace_strip(&$str)
   {
      $str=ereg_replace (' +', ' ', trim($str));
      $str=ereg_replace("[\r\t\n]","",$str);
   }
   
   function start_element($parser, $element_name, $element_attrs)
   {
      global $curr_element;
      global $xml_tags;
      global $row_array;
      global $params;
      //basically your looking for certain xml tags and then setting it to be the current element
      for($i=0; $i<count($xml_tags);$i++)
      {
         if($xml_tags[$i] == $element_name)
         {
            if($i == 0)
            {
               //initialize $row_array
               $row_array = array();
               for($j=0; $j<count($xml_tags);$j++)
               {
                  $row_array[$j] = "";
               }
            }
            $curr_element = $xml_tags[$i];
            break;
         }
      }
   }
   
   function end_element($parser, $element_name)
   {
      global $xml_tags;
      if($element_name == $xml_tags[count($xml_tags) - 1])
      {
         global $row_array;
         global $records_array;
         $records_array[] = $row_array; 
         //I'm not using $curr_row anywhere right now but I might need to in future
         global $curr_row;
         $curr_row++;
      }
   }
   
   function character_data($parser,$data)
   {
      whitespace_strip($data);
      global $row_array;
      global $curr_element;
      global $xml_tags;
      
      
      for($i=0; $i<count($xml_tags);$i++)
      {
         if($data != "")
         {
            if($xml_tags[$i] == $curr_element)
            {
               $row_array[$i] = $data;
               break;
            }
         }
         else
         {
            if($xml_tags[$i] == $curr_element)
            {
               if(!isset($row_array[$i]))
                  $row_array[$i] = "";
            }
            break;
         }
      }
   }
   
   //this function returns an array of file names for all files within a given directory
   //a rule: only put forwardslashes when necessary. If you are already in directory no need for preceding slash
   //if already in directory, no need for succeeding slash ie user '/dir1/dir2' instead of '/dir1/dir2/'
   function list_dir($files_dir='', $fileregex='') 
   {
   if (!$files_dir || !is_dir($files_dir) || !$fileregex)
   return false;
   
   $matchedfiles = array();
   
   $handle = opendir($files_dir);
   
   while(false !== ($file = readdir($handle))) 
   {
   if(is_dir($files_dir.'/'.$file) && $file <> ".." && $file <> ".") 
      {
      $subdir_matches = list_dir($files_dir.'/'.$file, $fileregex);
      $matchedfiles = array_merge($matchedfiles, $subdir_matches);
      unset($file);
   }
   elseif (!is_dir($files_dir.'/'.$file)) 
      {
      if (preg_match($fileregex, $file)) 
      array_push($matchedfiles, $files_dir.'/'.$file);
   }
   }
   closedir($handle);
   unset($handle);
   return $matchedfiles;
   }
   
   function return_dir_array($files_dir='')
   {
      $xml_files = list_dir($files_dir, "/\.(xml)$/");
      for($i=0; $i<count($xml_files); $i++)
      {
         //parse the xml file
         xml_parse_file($xml_files[$i]);
         //then delete the xml file
         //unlink($xml_files[$i]);
      }
      
      global $records_array;
      return $records_array;
   }
   
   function return_file_array($file_name)
   {
      global $records_array;
   
      if($file_name != "")
      {
         if(file_exists($file_name))
            xml_parse_file($file_name);
         else
            $records_array = NULL;
      }
      else 
         $records_array = NULL;
      
      return $records_array;
   }
}  

/*--------------------- Examples of Calling functions here -------------------------*/
/*
//to parse only 1 file
$file_name = "afrique/in/1.xml";
$return_array = return_file_array($file_name);
*/
/*
$xmlhandler = &new XmlReader;
//to parse all the xml files in a given directory
$file_dir = "config/afrique/in";
$return_array = $xmlhandler->return_dir_array($file_dir);   

if($return_array != NULL)
{
   foreach ($return_array as $row)
   {
      foreach($row as $value)
      {
         if($value == "")
            echo('Empty'. '&nbsp;&nbsp;');
         else
            echo($value . '&nbsp;&nbsp;');
      }
      echo "<br/>";
   }
}
else
{
   echo "Xml read error!";
}
*/
/*--------------------- End of Examples -------------------------*/


<?php
# this is to over-ride newer PHP defaults that turn off error reporting by default
# this is to prevent an unexpected error from revealing information that could be
# used to compromise security

# shutdown function
#ini_set('display_errors', 'On');
#ini_set('error_reporting', 'E_ALL');
//error_reporting(E_NONE);
//error_reporting('E_ERROR');
error_reporting(E_ALL);
#error_reporting(E_ALL & ~E_WARNING);
#error_reporting(E_ERROR | E_WARNING | E_PARSE);

$scriptname = $_SERVER['PHP_SELF'];
include_once('./config.local.php');
if (isset($_SESSION['projectid'])) {
   $projectid = $_SESSION['projectid'];
}

error_log("Loading master config file");
//include_once("./config.php");

error_log("Loading xajax core $libpath/xajax/xajax_core/xajax.inc.php");
include_once ("$libpath/xajax/xajax_core/xajax.inc.php");
error_log("Checking for xajax submission");
if (strlen($xajaxscript) > 0) {
   $xajax = new xajax($xajaxscript);
   $ajargtester = new xajaxArgumentManager;
   //$ajargtester->xajaxArgumentManager();
   if (isset($ajargtester->aArgs[0]['projectid'])) {
      $projectid = $ajargtester->aArgs[0]['projectid'];
      $scenarioid = $ajargtester->aArgs[0]['scenarioid'];
   }
} else {
   error_log("variable 'xajaxscript' not defined ");   
   $xajax = new xajax(NULL);
}
error_log("Finished xajax_config");   
?>

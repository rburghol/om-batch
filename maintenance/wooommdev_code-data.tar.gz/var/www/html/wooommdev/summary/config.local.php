<?php
$adminemail = 'rwburgholzer@deq.virginia.gov';
$dbname = 'model';
$dbpass = '314159';
$dbuser = 'postgres';
$dbip = 'localhost';

$vwuds_dbname = 'vwuds';
$vwuds_dbpass = '314159';
$vwuds_dbuser = 'wsp_ro';
$vwuds_dbip = 'localhost';

// session data database
$session_dbname = 'model_sessiondata';
$session_dbpass = '314159';
$session_dbuser = 'postgres';
$session_dbip = 'localhost';

# absolute path to where you put the who php files
$httproot = "/var/www/html";
$httppath = '/var/www/html';
# absolute path to where you put the who php files
$basedir = "$httppath/wooommdev/";
$basepath = "$httppath/wooommdev/";
$baseurl = '/wooommdev';
# absolute path to where you put the lib files
$libpath = "/var/www/html/devlib";
$libdir = "/var/www/html/devlib";
# URL to library folder
$liburl = '/devlib';
# URL to the web server writable directory, your jpgraph install needs to be configured to write to this directory
$gouturl = "/tmp";

# need a writeable temp dir. if using widgets that execute dos commands, one may wish to have this be a short, 8.3 compliant dirname
# such as C:/temp or /tmp (if using unix dos ports)
$tmpdir = "/var/www/html/tmp";
$shellcopy = 'cp'; # the local system copy command for shell scripts that use it

?>

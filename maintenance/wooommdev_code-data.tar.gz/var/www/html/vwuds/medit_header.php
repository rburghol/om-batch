<?php
#########################################
# Initialize libraries and functions
#########################################
#dl('php_mapscript.so');
#dl(php_mapscript.dll);

#error_reporting(2);
# show all errors/warnings/etc/
#error_reporting(2047);

include_once("config.php");
#print("<head>");
print("<script language='JavaScript' src='/scripts/scripts.js'>");
print("</script>");
# include open layers stuff
print("<script src='$liburl/OpenLayers-2.7/OpenLayers.js'></script>");
print("<script src='$scripturl/proj4js/lib/proj4js.js'></script>");
print("<script src='$scripturl/proj4js/lib/projCode/merc.js'></script>");

print("<style type=\"text/css\">");
print("  #map {");
print("      width: 600px;");
print("      height: 400px;");
print("      border: 1px solid black;");
print("  }");
print("</style>");
/*
print("<script type=\"text/javascript\">");
print("function setFNFunctions ($thiselem) { ");
print("var o = new com.filenice.actions;");
#print("alert('Executing Javascript');");
print("o.setFunctions(document.getElementById(\"$thiselem\"));");
print("} ");
#print("setFNFunctions(); ");
print("</script>");
*/
#$debug = 1;
if ($debug) {
   print("Showing FileNice Headers<br>");
}
echo $fno->showFNHeaders();
print("<link href=\"/styles/clmenu.css\" type=\"text/css\" rel=\"stylesheet\" />");
#print("</head>");
if ($gbIsHTMLMode and isset($_POST['mapa_x'])) {
   $mapa_x = $_POST['mapa_x'];
   $mapa_y = $_POST['mapa_y'];
   $incoords = "$mapa_x,$mapa_y";
}

$initmap = 1;
$mapbuffer = 0.3;

if ($projectid == -1) {
   print("<b>Error: </b>Project id not set.");
   die;
}

if ( !(strlen($thisyear ) > 0) ) {
   if (strlen($lastyear) > 0) {
      $thisyear = $lastyear;
   } else {
      $thisyear = $sceninfo['landuseyear'];
   }
}


###################################################################
# LOCAL VARIABLES
###################################################################

###################################################################
# END LOCAL VARIABLES
###################################################################

#########################################
# Initialize map basics
#########################################
# set active layer to watersheds
$invars['active_layer'] = 'selectedsegs';
#print_r($_POST);
$watershed_tbl = "proj_subsheds";
$subshed_tbl = "proj_subsheds";
$reach_tbl = "reaches_dd";
$mapfile = $projinfo['mapfile'];
#$mapfile = 'test_shp.map';
#$debug = 1;
if ($debug) {
   print("Setting up map object.<br>");
}

/*
# MAP DISABLED SINCE OPENLAYERS NOW HANDLES ALL MAPPING ON CLIENT
# SET Local variable map file here:
if ($initmap) {
   $amap = new ActiveMap;
   if ($debug) { print("Map Object created<BR>"); }
   if (strlen($gbIsHTMLMode) > 0) {
      $amap->gbIsHTMLMode = $gbIsHTMLMode;
   } else {
      $amap->gbIsHTMLMode = 0;
   }
   $amap->debug = $debug;
   if ($debug) { print("Setting map file $mapfile (in dir $basedir)<BR>"); }
   $amap->setMap($basedir,$mapfile);
   #$HTTP_SESSION_VARS["amap"] = $amap;
   if ($debug) { print("Initializing Map...<BR>"); }
} else {
   $amap->setMap($basedir,$mapfile);
}
$amap->debug = $debug;
$amap->mapform = 'giswindow';
# don't show the map name in the header
$amap->showmapname = 0;

if ($debug) {
   print("Configuring layers to display.<br>");
}


# select the reaches for this project
$reachlayer = $amap->map->getLayerByName('Reaches');
$reachlayer->setFilter(" projectid = $projectid ");
# select the watersheds for this project
$wslayer = $amap->map->getLayerByName('p5lrsegs');
$wslayer->setFilter(" projectid = $projectid ");
$wslayer = $amap->map->getLayerByName('selectedsegs');
$wslayer->setFilter(" projectid = $projectid ");

# instead we set these only for the one layer we are showing
# no need to do this since it is now set in the mapfile
#$wslayer = $amap->map->getLayerByName('proj_subsheds');
# embed the legend
if ($debug) {
   print("Applying filters.<br>");
}
$wslayer->setFilter(" projectid = $projectid ");
# embed the legend
if ($debug) {
   print("Configuring legend.<br>");
}
$amap->map->legend->set('status', MS_EMBED);


if ($debug) {
   print("Passing variables to map.<br>");
}

# set up our map
#print("Setting Up Map<br>");
$amap->formvars = $invars;
#$amap->quickviews = $theseviews;
$amap->quickviews = array();
$amap->mapname = 'Virginia Water Supply Planning';
$amap->dbobj = $listobject;
#$amap->debug = 1;

*/

#########################################
# END - Initialize map basics
#########################################


#########################################
##   Common Form Functions            ###
#########################################

function showSegSelect($listobject, $userid, $projectid, $currentgroup, $debug) {
   showActiveList($listobject, 'currentgroup', 'proj_seggroups', 'groupname', 'gid', "projectid = $projectid and ownerid = $userid ", $currentgroup, 'submit()', 'groupname', $debug);
}

function showMultiLandUseMenu($listobject, $projectid, $scenarioid, $selus, $fieldname, $extrawhere, $rows, $debug) {

   $wc = "projectid = $projectid and hspflu <> ''";
   if (strlen($extrawhere) > 0) {
      $wc .= " and $extrawhere ";
   }
   showMultiList2($listobject, $fieldname, 'landuses', 'hspflu', 'landuse, major_lutype', $selus, $wc, 'major_lutype, landuse', $debug, $rows);

}

function showSingleLandUseMenu($listobject, $projectid, $scenarioid, $selus, $fieldname, $extrawhere, $debug) {

   $wc = "projectid = $projectid and hspflu <> ''";
   if (strlen($extrawhere) > 0) {
      $wc .= " and $extrawhere ";
   }

   showActiveList($listobject, $fieldname, 'landuses', 'landuse', 'hspflu', $wc, $selus, $onchange, 'major_lutype, landuse', $debug);
}
?>

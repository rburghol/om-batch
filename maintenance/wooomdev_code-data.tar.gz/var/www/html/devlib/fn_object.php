<?php

include_once("fileNice/fileNice.php");
# check for ajax submission
if (isset($_GET['dir'])) {
   $fno = new FNObject;
   $fno->init();
   $fno->fileselect = 1;
   $fno->showFlickrForm = 0;
   $fno->showSearchForm = 0;
   $fno->showPrefsForm = 0;
   $fno->showFilePath = 0;
   $fno->fieldname = 'filepath';
   $fno->formname = 'addelement';
   $fno->restrictTypes = array('uci','csv');
   if (isset($_GET['containerid'])) {
      $fno->containerid = $_GET['containerid'];
   }
   $html = $fno->showFNBrowser($_GET, $_POST);
   echo $html;
}

?>
<?php
$noajax = 1;
$projectid = 3;
$scid = 28;
include("./xajax_modeling.element.php");
include("./lib_verify.php");

$sid = session_id();
print("Session ID = $sid \n");

?>

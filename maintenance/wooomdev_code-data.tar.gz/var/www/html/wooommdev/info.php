<?php

include('./config.php');
phpinfo();
#pg_close($listobject->dbconn);
#pg_close($cropobject->dbconn);

?>
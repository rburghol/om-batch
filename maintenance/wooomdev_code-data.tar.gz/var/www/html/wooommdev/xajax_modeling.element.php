<?php

# xajax based library - watersupply

#include_once("xajax_config.php");

include_once("xajax_modeling.common.php");
#require_once ("$libpath/xajax/xajax_core/xajax.inc.php");

if (!$noajax) {
   $xajax->processRequest();
}


function collapseableMenu($indata, $styles=array('Container'=>'mC','Header'=>'mH','Line'=>'mL','Value'=>'mO')) {


}

function refreshAnalysisWindow($formValues) {
   //include_once("adminsetup.php");
   $objResponse = new xajaxResponse();
   $divname = $formValues['divname'];
   $awin = showAnalysisWindow($formValues);
   $controlHTML = $awin['innerHTML'];
   //$controlHTML = 'test';
   $objResponse->assign($divname,"innerHTML",$controlHTML);
   return $objResponse;
}


function showModelRunForm($formValues) {
   include_once("adminsetup.php");
   $objResponse = new xajaxResponse();
   $controlHTML = modelRunForm($formValues);
   $objResponse->assign("controlpanel","innerHTML",$controlHTML);
   return $objResponse;
}


function showModelSearchForm($formValues) {
   include_once("adminsetup.php");
   $objResponse = new xajaxResponse();
   $controlHTML = modelSearchForm($formValues);
   if ($formValues['actiontype'] == 'do_search') {
      $controlHTML .= "<hr>" . modelSearchResults($formValues);
   }
   $objResponse->assign("controlpanel","innerHTML",$controlHTML);
   return $objResponse;
}


function showModelActivity($formValues) {
   global $listobject;
   $objResponse = new xajaxResponse();
   $mins = 60;
   $controlHTML = "<b>Last $mins minutes model activity</b><br>";
   $activity = getModelActivity($mins);
   $controlHTML .= $activity;
   error_log("Model activity - $activity");
   $objResponse->assign("controlpanel","innerHTML",$controlHTML);
   return $objResponse;
}

function getModelActivity($mins) {
   global $listobject;
   $listobject->querystring = "  select a.elementid, a.elemname, b.status_mesg, b.runid, b.host ";
   $listobject->querystring .= " from scen_model_element as a, system_status as b ";
   $listobject->querystring .= " where a.elementid = b.element_key ";
   $listobject->querystring .= " and b.last_updated >= now() - interval '$mins minutes' ";
   $listobject->querystring .= " order by last_updated ";
   error_log("$listobject->querystring ");
   $listobject->performQuery();
   $n = count($listobject->queryrecords);
   $listobject->show = 0;
   $listobject->showList();
   return "$n records returned <br>" . $listobject->outstring;
}

function showModelRunResult($formValues) {
   global $libpath, $adminsetuparray;
   include_once("adminsetup.php");
   #include_once("who_xmlobjects.php");
   $objResponse = new xajaxResponse();
   $innerHTML = modelRunResult($formValues);
   $controlHTML = modelRunForm($formValues);
   $objResponse->assign("controlpanel","innerHTML",$controlHTML);
   $objResponse->assign("workspace","innerHTML",$innerHTML);
   return $objResponse;
}


function openModelRunWorkspace($formValues) {
   global $libpath, $adminsetuparray, $scenarioid;
   include_once("adminsetup.php");
   #include_once("who_xmlobjects.php");
   $objResponse = new xajaxResponse();
   $innerHTML = modelRunResult($formValues);
   $objResponse->assign("workspace","innerHTML",$innerHTML);
   return $objResponse;
}

function modelSearchForm($formValues) {
   global $listobject, $projectid, $userid, $usergroupids, $debug;
   
   $scenarioid = $formValues['scenarioid'];
   if (isset($formValues['element_text'])) {
      $element_text = $formValues['element_text'];
   } else {
      $element_text = '';
   }
   
   $innerHTML = '';
   # create a scenarioid query
   $scensql = " ( select scenarioid, scenario from scenario ";
   $scensql .= "  where projectid = $projectid and ( (ownerid = $userid  and operms >= 4) ";
   $scensql .= "     or ( groupid in ($usergroupids) and gperms >= 4 ) ";
   $scensql .= "     or (pperms >= 4) ) ";
   $scensql .= "  order by scenario  ";
   $scensql .= " ) as foo ";
   
   //$innerHTML .= $scensql;

   $innerHTML .= "<form id=modelsearch name=modelsearch>";
   $innerHTML .= "Domain to Search: ";
   $innerHTML .= showActiveList($listobject, "scenarioid", $scensql, 'scenario','scenarioid', '', $scenarioid, '', '', $debug, 1, 0) . '<br>';

   $innerHTML .= "<br><b>Element Name (use '%' as wild-card): </b> ";
   $innerHTML .= showWidthTextField('element_text', $element_text, 30, '', 1);
   $innerHTML .= showHiddenField('projectid',$projectid, 1);
   $innerHTML .= showHiddenField('actiontype','do_search', 1);
   $innerHTML .= "<br>" . showGenericButton('search','Search', "xajax_showModelSearchForm(xajax.getFormValues(\"modelsearch\"))", 1);
   $innerHTML .= "</form>";
   return $innerHTML;

/*
   // eventually we want to add a query wizard like so:
   # show a set of custom queryWizard objects
   $queryparent = new blankShell;
   # setting this to the query assembled by the search object
   $queryparent->dbtblname = 'scen_model_element';
   $querywizard = new queryWizardComponent;
   $querywizard->parentobject = $queryparent;
   $querywizard->listobject = $listobject;
   # create a list for use in the form drop-downs of the various columns that we can select
   $aslist = '';
   $asep = '';
   $table_cols = array_keys($adminsetuparray['scen_model_element']['column info']);
   foreach ($table_cols as $thiscol) {
      $aslist .= $asep . $thiscol . '|' . $thiscol;
      $asep = ',';
   }
   //$controlHTML .= " Column List: $aslist <br>";
   $qset = array();
   $qset['queryWizardComponent'] = $adminsetuparray['queryWizardComponent'];
   # blank this out, since we do not want any of the informational fields
   
   $qset['queryWizardComponent']['column info'] = array("custom_to_file"=>array("type"=>3,"params"=>"0|False,1|True:ctfid:ctfname::0","label"=>"Output Results to File?","visible"=>1, "readonly"=>0, "width"=>6)); 
   foreach (array('queryWizard_selectcolumns'=>'qcols', 'queryWizard_wherecolumns'=>'wcols', 'queryWizard_ordercolumns'=>'ocols') as $colname => $lname) {
      $qset[$colname] = $adminsetuparray[$colname];
      $asrec = split(':',$qset[$colname]['column info'][$lname]['params']);
      $asrec[0] = $aslist;
      $asparams = join(':', $asrec);
      $qset[$colname]['column info'][$lname]['params'] = $asparams;
      //$controlHTML .= " Column Array for <b>$colname</b>: " . print_r($asrec,1). " <br>";
      //$controlHTML .= " Column Select Record: " . $asparams . " <br>";
   }
   $qset['queryWizard_selectcolumns']['column info']['qcols_txt']['visible'] = 0; 
   $qset['queryWizard_selectcolumns']['table info']['showlabels'] = 1; 
   $querywizard->force_cols = 1;
   $querywizard->quote_tablename = 1;
   $querywizard->force_names = array('custom_to_file'=>$custom_to_file);
   $querywizard->qcols = $formValues['qcols'];
   $querywizard->qcols_func = $formValues['qcols_func'];
   $querywizard->qcols_alias = $formValues['qcols_alias'];
   $querywizard->wcols = $formValues['wcols'];
   $querywizard->wcols_op = $formValues['wcols_op'];
   $querywizard->wcols_value = $formValues['wcols_value'];
   $querywizard->wcols_refcols = $formValues['wcols_refcols'];
   $querywizard->ocols = $formValues['ocols'];
   
   $querywizard->listobject->adminsetuparray = $qset;
   $formatinfo = $querywizard->showEditForm('custom');
   $controlHTML .= $formatinfo['innerHTML'];
   $querywizard->assembleQuery();
   $controlHTML .= $querywizard->sqlstring . "<br>";
   $controlHTML .= "<center>" . showGenericButton('search','Search', "xajax_refreshAnalysisWindow(xajax.getFormValues(\"$form_name\")) ; ", 1, 0) . "</center>";
   $controlHTML .= "</div><hr>";
   
   ############################################################
   ###                  END CUSTOM OUTPUT FORM              ###
   ############################################################
   $query_wiz['innerHTML'] = $controlHTML;
   $query_wiz['sql'] = $querywizard->sqlstring;
*/

}

function modelSearchResults($formValues) {
   global $listobject, $projectid, $userid, $usergroupids, $debug;
   $innerHTML = '';
   $scenarioid = $formValues['scenarioid'];
   $element_text = $formValues['element_text'];
   
   $listobject->querystring = "select elementid, elemname from scen_model_element where scenarioid = $scenarioid and elemname ilike '$element_text' ";
   $innerHTML .= "$listobject->querystring ; <br>";
   $listobject->performQuery();
   $qrecs = $listobject->queryrecords;
   $qlinks = array();
   
   $formname = 'elementtree';
   
   foreach($qrecs as $thisrec) {
      $rec = array();
      $elid =  $thisrec['elementid'];
      $rec['elementid'] = $elid;
      $listobject->querystring = "select dest_id from map_model_linkages where linktype = 1 and src_id = $elid ";
      $listobject->performQuery();
      if (count($listobject->queryrecords) > 0) {
         $container = $listobject->getRecordvalue(1,'dest_id');
      } else {
         $container = $elid;
      }
      
      $clickscript = "last_tab['model_element']='model_element_data0'; last_button['model_element']='model_element_0'; last_tab['modelout']='modelout_data0'; last_button['modelout']='modelout_0'; show_next('map_window_data0', 'map_window_0', 'map_window'); document.forms['$formname'].elements.elementid.value=$elid;  document.forms['$formname'].elements.actiontype.value='edit'; document.forms['$formname'].elements.activecontainerid.value=$container; document.forms['$formname'].elements.scenarioid.value=$scenarioid; xajax_showModelDesktopView(xajax.getFormValues('$formname')); ";
      $rec['elemname'] = "<a onclick=\"$clickscript ;\" >" . $thisrec['elemname'] . "</a><br>";
      $qlinks[] = $rec;
   }
   $listobject->queryrecords = $qlinks;
   $listobject->show = 0;
   $listobject->showList();
   $innerHTML .= $listobject->outstring;
   
   return $innerHTML;
}

function insertComponent($formValues) {
   global $listobject, $projectid, $scenarioid, $userid, $usergroupids, $debug, $libpath, $adminsetuparray;
   //include_once("adminsetup.php");
   #include_once("who_xmlobjects.php");
   $activecontainerid = $formValues['activecontainerid'];
   $insertresult = insertBlankComponent($formValues);
   //$formValues['scenarioid'] = $insertresult['scenarioid'];
   $innerHTML = $insertresult['innerHTML'] . "<br> Scenarioid from insertBlankComponent = " . $insertresult['scenarioid'] . "<br>";
   $elementid = $insertresult['elementid'];
   $formValues['elementid'] = $elementid;
   $objResponse = showModelDesktopView($formValues);
  // if ( ($scenarioid <> -1) ) {
  //    $browserHTML = showHierarchicalMenu($listobject, $projectid, $scenarioid, $userid, $usergroupids, 0, 0, $activecontainerid );
  //    $menutarget = 'unit_elementtree' . '_sc' . $scenarioid;
  // } else {
      //$browserHTML = "Insert component calling showHierarchicalmenu<br>";
      $browserHTML .= showHierarchicalMenu($listobject, $projectid, $scenarioid, $userid, $usergroupids, 0, 1, $activecontainerid);
      //$browserHTML .= "FINISHED showHierarchicalmenu<br>";
      $menutarget = 'objectbrowser';
//   }
   $objResponse->assign($menutarget,"innerHTML",$browserHTML);
   //$objResponse->assign("objectbrowser","innerHTML",$browserHTML);
   $objResponse->assign("commandresult","innerHTML",$innerHTML);
   return $objResponse;
}

function insertComponentClone($formValues) {
   global $listobject, $projectid, $scenarioid, $userid, $usergroupids, $debug, $libpath, $adminsetuparray;
   //include_once("adminsetup.php");
   #include_once("who_xmlobjects.php");
   if (isset($formValues['activecontainerid'])) {
      $activecontainerid = $formValues['activecontainerid'];
   }
   $elid = $formValues['elementid'];
   //error_log("Cloning $elid into $activecontainerid <br>" . print_r($formValues,1));
   $insertresult = cloneModelElement($scenarioid, $elid, $activecontainerid);
   $innerHTML = $insertresult['innerHTML'];
   $elementid = $insertresult['elementid'];
   $formValues['elementid'] = $elementid;
   $objResponse = showModelDesktopView($formValues);
   // force scenarioid = -1 since this forces full refresh of the menu, not optimal, but for now, it is what is needed
   //$browserHTML = showHierarchicalMenu($listobject, $projectid, $scenarioid, $userid, $usergroupids, 0);
   $browserHTML = showHierarchicalMenu($listobject, $projectid, -1, $userid, $usergroupids, 0);
   $objResponse->assign("commandresult","innerHTML",$innerHTML);
   $objResponse->assign("objectbrowser","innerHTML",$browserHTML);
   return $objResponse;
}

function refreshHierarchicalMenu($formValues) {
   global $listobject, $projectid, $scenarioid, $userid, $usergroupids, $debug, $libpath, $adminsetuparray;
   //include_once("adminsetup.php");
   if (isset($formValues['activecontainerid'])) {
      $activecontainerid = $formValues['activecontainerid'];
   } else {
      $activecontainerid = -1;
   }
   $objResponse = new xajaxResponse();
   // force scenarioid = -1 since this forces full refresh of the menu, not optimal, but for now, it is what is needed
   //$browserHTML = showHierarchicalMenu($listobject, $projectid, $scenarioid, $userid, $usergroupids, 0);
   $browserHTML = showHierarchicalMenu($listobject, $projectid, -1, $userid, $usergroupids, 0, 1, $activecontainer, $formValues);
   $objResponse->assign("objectbrowser","innerHTML",$browserHTML);
   return $objResponse;
}

function insertGroupClone($formValues) {
   global $listobject, $projectid, $scenarioid, $userid, $usergroupids, $debug, $libpath, $adminsetuparray;
   //include_once("adminsetup.php");
   #include_once("who_xmlobjects.php");
   $clonedata = array();
   if (isset($formValues['activecontainerid'])) {
      $clonedata['dest_parent'] = $formValues['activecontainerid'];
   }
   $elid = $formValues['elementid'];
   $clonedata['elements'] = array($elid);
   $clonedata['projectid'] = $projectid;
   $clonedata['scenarioid'] = $formValues['scenarioid'];
   $clonedata['dest_scenarioid'] = $formValues['scenarioid'];
   $innerHTML = "Cloning $elid into $activecontainerid <br>" . print_r($clonedata,1) . " <br>" . print_r($formValues,1) . " <br>";
   $insertresult = copyModelGroupFull($clonedata);
   $innerHTML .= "Clone routine output <br>" . print_r($insertresult,1) . " <br>";
   $innerHTML .= $insertresult['innerHTML'];
   $elementid = $insertresult['elementid'];
   $formValues['elementid'] = $elementid;
   $objResponse = showModelDesktopView($formValues);
   // force scenarioid = -1 since this forces full refresh of the menu, not optimal, but for now, it is what is needed
   $browserHTML = showHierarchicalMenu($listobject, $projectid, $scenarioid, $userid, $usergroupids, 0);
   $browserHTML = showHierarchicalMenu($listobject, $projectid, -1, $userid, $usergroupids, 0);
   
   $objResponse = new xajaxResponse();
   $objResponse->assign("status_bar","innerHTML",$innerHTML);
   //$objResponse->assign("commandresult","innerHTML",$innerHTML);
   $objResponse->assign("objectbrowser","innerHTML",$browserHTML);
   return $objResponse;
}

function showStatus($formValues) {
   global $listobject, $userid, $scenarioid;
   $objResponse = new xajaxResponse();
   $statusHTML = '';
   $listobject->querystring = " select status_flag, status_mesg, last_updated, element_key from system_status where process_ownerid = $userid ";
   if (isset($formValues['elementid'])) {
      # get messages about the current element that are NOT owned by this owner
      $eid = $formValues['elementid'];
      if ($eid > 0) {
         $listobject->querystring .= " UNION select status_flag, status_mesg, last_updated, element_key from system_status where element_key = $eid ";
      }
   }
   $listobject->querystring .= " GROUP BY status_flag, status_mesg, last_updated, element_key ";
   //error_log($listobject->querystring);
   //$statusHTML .= $listobject->querystring;
   
   $listobject->performQuery();
   $listobject->show = 0;
   $listobject->showList();
   $now = date('r');
   $status_mesg = $listobject->outstring;
   $statusHTML .= "Current System Status: $now<br>$status_mesg";
   
   $objResponse->assign("status_bar","innerHTML",$statusHTML);
   return $objResponse;
}

?>

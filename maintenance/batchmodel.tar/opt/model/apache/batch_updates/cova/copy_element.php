<?php

$userid = 1;
include_once('xajax_modeling.element.php');
include_once('lib_batchmodel.php');

// get outlet for terminal CBP segment
// OR, set them up manually as in here


error_reporting(E_NONE);

if (count($argv) < 2) {
   print("Usage: php copy_element.php dest_scenarioid elementid [dest_parent] \n");
   die;
}

$scenid = $argv[1];
$elementid = $argv[2];
if (isset($argv[3])) {
   $destination = $argv[3];
} else {
   $destination = -1;
}
$debug = 1;

$cbp_copy_params = array(
   'projectid'=>$projectid,
   'dest_scenarioid'=>$scenid,
   'elements'=>array($elementid),
   'dest_parent'=>$destination
);

$output = copyModelGroupFull($cbp_copy_params);

print_r($output);
?>

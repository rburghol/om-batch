<?php

$userid = 1;
include_once('xajax_modeling.element.php');
include_once('lib_batchmodel.php');
error_reporting(E_ERROR);

if (count($argv) < 2) {
   print("Usage: php cbp_calcNLCDLanduse.php elementid [lu_matrix_name=landuse_nlcd] [mode=direct, cova]\n");
   print("mode: cbp means search COVA framework from the elementid as root, direct = operate on this elementid directly. \n");
   die;
}
$elid = $argv[1];
if (isset ($argv[2])) {
   $lu_matrix_name = $argv[2];
} else {
   $lu_matrix_name = 'landuse_nlcd';
}
if (isset ($argv[3])) {
   $mode = $argv[3];
} else {
   $mode = 'direct';
}
$minyear = 1980;
$maxyear = 2050;
// get the parent shape
// get the land segs that overlap it, and the intersected shape
// apply to the land segs if they exist

// actually should get the existing shape on the model element, intersect it with NHDPlus basins, calaculating overlap %s, and then weight the resulting land use query accordingly
$wktgeom = getElementShape($elid);

$overlaps = checkOverlap($usgsdb, $wktgeom);
foreach ($overlaps as $thisnhd) {
   print("COM ID: " . $thisnhd['comid'] . " Original Area: " . $thisnhd['areasqkm_orig'] . " overlap %: " . $thisnhd['ratio'] . "\n");
   $total_area += $thisnhd['areasqkm_orig'] * $thisnhd['ratio'];
}
print("Total overlapping area " . number_format($total_area, 2) . " sq. km\n");

$lu = getNHDLandUseWKT($usgsdb, $wktgeom, 'acres');
print(print_r($lu,1) . "\n");
$lr = array();
foreach ( $lu as $thislu => $thisarea ) {

   if (substr($thislu,0,4) == 'nlcd') {
      $lr[] = array('luname'=>$thislu, $minyear => round($thisarea,3), $maxyear => round($thisarea,3));
   }

}
setLUMatrix ($elid, $lu_matrix_name, $lr);

?>

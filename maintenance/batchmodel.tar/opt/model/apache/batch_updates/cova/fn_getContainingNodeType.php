<?php

$noajax = 1;
$projectid = 3;
$userid = 1;

include_once('xajax_modeling.element.php');
error_reporting(E_ERROR);
include_once("./lib_batchmodel.php");

if (count($argv) < 2) {
   print("Usage: fn_getContainingNodeType.php elementid [objectclass] [custom1] [custom2] [max levels] \n");
   die;
}

$elementid = $argv[1];
if (isset($argv[2])) {
   if ($argv[2] <> '') {
      $types = split(',', $argv[2]);
   } else {
      $types = array();
   }
} else {
   $types = array();
}
if (isset($argv[3])) {
   if ($argv[3] <> '') {
      $custom1 = split(',', $argv[3]);
   } else {
      $custom1 = array();
   }
} else {
   $custom1 = array();
}
if (isset($argv[4])) {
   if ($argv[4] <> '') {
      $custom2 = split(',', $argv[4]);
   } else {
      $custom2 = array();
   }
} else {
   $custom2 = array();
}
if (isset($argv[5])) {
   $levels = $argv[5];
} else {
   $levels = 10;
}

$debug = 1;

//print("Requested container for Element $elementid: \n");
$tree = getContainingNodeType($elementid, 0, array('custom1'=>$custom1, 'custom2'=>$custom2, 'objectclass'=>$types), $levels, $debug);
print("Requested container for Element $elementid: \n");
print_r($tree);
print("\n");


?>
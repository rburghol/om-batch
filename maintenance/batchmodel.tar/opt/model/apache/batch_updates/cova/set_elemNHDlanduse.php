<?php

$userid = 1;
include_once('xajax_modeling.element.php');
include_once('lib_batchmodel.php');

if (count($argv) < 3) {
   print("Usage: php add_localtrib.php elementid landuse_name [units=sqmi,acres,sqkm]\n");
   die;
}
$elid = $argv[1];
$landuse_name = $argv[2];
if (isset($argv[3])) {
   $units = $argv[3];
} else {
   $units = 'acres';
}

// actually should get the existing shape on the model element, intersect it with NHDPlus basins, calaculating overlap %s, and then weight the resulting land use query accordingly
$wktgeom = getElementShape($elid);



?>


<?php

$userid = 1;
//error_reporting(E_ALL);
$noajax = 1;
include_once('xajax_modeling.element.php');
include_once('lib_batchmodel.php');

if (count($argv) < 4) {
   print("Usage: php add_localtrib.php elementid latdd londd [# of extra NHD+ basins]\n");
   die;
}
$elid = $argv[1];
$latdd = $argv[2];
$londd = $argv[3];
if (isset($argv[4])) {
   $extra_basins = $argv[4];
} else {
   $extra_basins = 0;
}


$basininfo = getMergedNHDBasin($usgsdb, $latdd, $londd, $extra_basins);
print(" NHD+ Shape Retrieved \n");
$wkt_geom = $basininfo['the_geom'];
print("NHD+ Shape for $elid = " . substr($wkt_geom,0,64) . " \n");
// set the shape
print("Setting Shape for $elid \n");
setElementGeometry($elid, 3, $wkt_geom);

print("Finished \n");


?>
